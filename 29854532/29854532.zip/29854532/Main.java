
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BankingSystem bankingSystem = new BankingSystem();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Banking System Menu:");
            System.out.println("1. Add Account");
            System.out.println("2. Remove Account");
            System.out.println("3. Update Account");
            System.out.println("4. Deposit Funds");
            System.out.println("5. Withdraw Funds");
            System.out.println("6. Transfer Funds");
            System.out.println("7. Print Accounts");
            System.out.println("8. Print Transactions");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Add account logic
                    System.out.print("Enter account ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    System.out.print("Enter initial balance: ");
                    double balance = scanner.nextDouble();
                    System.out.print("Enter account type: ");
                    String accountType = scanner.next();
                    bankingSystem.addAccount(new Account(id, customerId, balance, accountType));
                    break;
                case 2:
                    // Remove account logic
                    System.out.print("Enter account ID to remove: ");
                    int removeId = scanner.nextInt();
                    bankingSystem.removeAccount(removeId);
                    break;
                case 3:
                    // Update account logic
                    System.out.print("Enter account ID to update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter new customer ID: ");
                    int newCustomerId = scanner.nextInt();
                    System.out.print("Enter new balance: ");
                    double newBalance = scanner.nextDouble();
                    System.out.print("Enter new account type: ");
                    String newAccountType = scanner.next();
                    bankingSystem.updateAccount(updateId,
                            new Account(updateId, newCustomerId, newBalance, newAccountType));
                    break;
                case 4:
                    // Deposit funds logic
                    System.out.print("Enter account ID to deposit to: ");
                    int depositId = scanner.nextInt();
                    System.out.print("Enter amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    bankingSystem.depositFunds(depositId, depositAmount);
                    break;
                case 5:
                    // Withdraw funds logic
                    System.out.print("Enter account ID to withdraw from: ");
                    int withdrawId = scanner.nextInt();
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    bankingSystem.withdrawFunds(withdrawId, withdrawAmount);
                    break;
                case 6:
                    // Transfer funds logic
                    System.out.print("Enter account ID to transfer from: ");
                    int fromAccountId = scanner.nextInt();
                    System.out.print("Enter account ID to transfer to: ");
                    int toAccountId = scanner.nextInt();
                    System.out.print("Enter amount to transfer: ");
                    double transferAmount = scanner.nextDouble();
                    bankingSystem.transferFunds(fromAccountId, toAccountId, transferAmount);
                    break;
                case 7:
                    // Print accounts
                    bankingSystem.printAccounts();
                    break;
                case 8:
                    // Print transactions
                    bankingSystem.printTransactions();
                    break;
                case 9:
                    // Exit
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 9);

        scanner.close();
    }
}
