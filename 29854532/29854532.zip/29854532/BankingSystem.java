import java.util.*;

public class BankingSystem {
    private HashMap<Integer, Account> accounts = new HashMap<>();
    private ArrayList<Transaction> transactions = new ArrayList<>();

    // Method to add a new account
    public void addAccount(Account account) {
        if (accounts.containsKey(account.getId())) {
            System.out.println("Account with ID " + account.getId() + " already exists.");
        } else {
            accounts.put(account.getId(), account);
            System.out.println("Account added: " + account);
        }
    }

    // Method to remove an account
    public void removeAccount(int accountId) {
        if (accounts.containsKey(accountId)) {
            accounts.remove(accountId);
            System.out.println("Account with ID " + accountId + " removed.");
        } else {
            System.out.println("Account with ID " + accountId + " does not exist.");
        }
    }

    // Method to update account details
    public void updateAccount(int accountId, Account updatedAccount) {
        if (accounts.containsKey(accountId)) {
            accounts.put(accountId, updatedAccount);
            System.out.println("Account updated: " + updatedAccount);
        } else {
            System.out.println("Account with ID " + accountId + " does not exist.");
        }
    }

    // Method to deposit funds
    public void depositFunds(int accountId, double amount) {
        if (accounts.containsKey(accountId)) {
            Account account = accounts.get(accountId);
            account.setBalance(account.getBalance() + amount);
            transactions.add(new Transaction(transactions.size() + 1, accountId, "DEPOSIT", amount, new Date()));
            System.out.println("Deposited " + amount + " to account ID " + accountId);
        } else {
            System.out.println("Account with ID " + accountId + " does not exist.");
        }
    }

    // Method to withdraw funds
    public void withdrawFunds(int accountId, double amount) {
        if (accounts.containsKey(accountId)) {
            Account account = accounts.get(accountId);
            if (account.getBalance() >= amount) {
                account.setBalance(account.getBalance() - amount);
                transactions.add(new Transaction(transactions.size() + 1, accountId, "WITHDRAWAL", amount, new Date()));
                System.out.println("Withdrew " + amount + " from account ID " + accountId);
            } else {
                System.out.println("Insufficient funds in account ID " + accountId);
            }
        } else {
            System.out.println("Account with ID " + accountId + " does not exist.");
        }
    }

    // Method to transfer funds between accounts
    public void transferFunds(int fromAccountId, int toAccountId, double amount) {
        if (accounts.containsKey(fromAccountId) && accounts.containsKey(toAccountId)) {
            Account fromAccount = accounts.get(fromAccountId);
            Account toAccount = accounts.get(toAccountId);
            if (fromAccount.getBalance() >= amount) {
                fromAccount.setBalance(fromAccount.getBalance() - amount);
                toAccount.setBalance(toAccount.getBalance() + amount);
                transactions.add(
                        new Transaction(transactions.size() + 1, fromAccountId, "TRANSFER OUT", amount, new Date()));
                transactions
                        .add(new Transaction(transactions.size() + 1, toAccountId, "TRANSFER IN", amount, new Date()));
                System.out.println("Transferred " + amount + " from account ID " + fromAccountId + " to account ID "
                        + toAccountId);
            } else {
                System.out.println("Insufficient funds in account ID " + fromAccountId);
            }
        } else {
            System.out.println("One or both account IDs do not exist.");
        }
    }

    // Helper method to print account details
    public void printAccounts() {
        for (Account account : accounts.values()) {
            System.out.println(account);
        }
    }

    // Helper method to print transaction details
    public void printTransactions() {
        for (Transaction transaction : transactions) {
            System.out.println(transaction);
        }
    }
}
