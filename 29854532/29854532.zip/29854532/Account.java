
public class Account {
    private int id;
    private int customerId;
    private double balance;
    private String accountType;

    public Account(int id, int customerId, double balance, String accountType) {
        this.id = id;
        this.customerId = customerId;
        this.balance = balance;
        this.accountType = accountType;
    }

    // Getters and setters methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    @Override
    public String toString() {
        return "Account{id=" + id + ", customerId=" + customerId + ", balance=" + balance + ", accountType='"
                + accountType + "'}";
    }
}
