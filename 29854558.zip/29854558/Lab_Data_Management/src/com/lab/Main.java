package com.lab;

import com.lab.dao.ExperimentDAO;
import com.lab.dao.ResearcherDAO;
import com.lab.dao.SampleDAO;
import com.lab.model.Experiment;
import com.lab.model.Researcher;
import com.lab.model.Sample;

import java.sql.Date;
import java.util.Scanner;

public class Main {
    private static final ExperimentDAO experimentDAO = new ExperimentDAO();
    private static final SampleDAO sampleDAO = new SampleDAO();
    private static final ResearcherDAO researcherDAO = new ResearcherDAO();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Experiment Management");
            System.out.println("2. Sample Management");
            System.out.println("3. Researcher Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageExperiments(scanner);
                    break;
                case 2:
                    manageSamples(scanner);
                    break;
                case 3:
                    manageResearchers(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageExperiments(Scanner scanner) {
        System.out.println("1. Add Experiment");
        System.out.println("2. View Experiment");
        System.out.println("3. Update Experiment");
        System.out.println("4. Delete Experiment");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addExperiment(scanner);
                break;
            case 2:
                viewExperiment(scanner);
                break;
            case 3:
                updateExperiment(scanner);
                break;
            case 4:
                deleteExperiment(scanner);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addExperiment(Scanner scanner) {
        Experiment experiment = new Experiment();
        System.out.print("Enter name: ");
        experiment.setName(scanner.nextLine());
        System.out.print("Enter description: ");
        experiment.setDescription(scanner.nextLine());
        System.out.print("Enter start date (yyyy-mm-dd): ");
        experiment.setStartDate(Date.valueOf(scanner.nextLine()));
        System.out.print("Enter end date (yyyy-mm-dd): ");
        experiment.setEndDate(Date.valueOf(scanner.nextLine()));
        experimentDAO.addExperiment(experiment);
        System.out.println("Experiment added.");
    }

    private static void viewExperiment(Scanner scanner) {
        System.out.print("Enter experiment ID: ");
        int id = scanner.nextInt();
        Experiment experiment = experimentDAO.getExperiment(id);
        if (experiment != null) {
            System.out.println("ID: " + experiment.getExperimentId());
            System.out.println("Name: " + experiment.getName());
            System.out.println("Description: " + experiment.getDescription());
            System.out.println("Start Date: " + experiment.getStartDate());
            System.out.println("End Date: " + experiment.getEndDate());
        } else {
            System.out.println("Experiment not found.");
        }
    }

    private static void updateExperiment(Scanner scanner) {
        System.out.print("Enter experiment ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Experiment experiment = experimentDAO.getExperiment(id);
        if (experiment != null) {
            System.out.print("Enter new name (current: " + experiment.getName() + "): ");
            experiment.setName(scanner.nextLine());
            System.out.print("Enter new description (current: " + experiment.getDescription() + "): ");
            experiment.setDescription(scanner.nextLine());
            System.out.print("Enter new start date (current: " + experiment.getStartDate() + "): ");
            experiment.setStartDate(Date.valueOf(scanner.nextLine()));
            System.out.print("Enter new end date (current: " + experiment.getEndDate() + "): ");
            experiment.setEndDate(Date.valueOf(scanner.nextLine()));
            experimentDAO.updateExperiment(experiment);
            System.out.println("Experiment updated.");
        } else {
            System.out.println("Experiment not found.");
        }
    }

    private static void deleteExperiment(Scanner scanner) {
        System.out.print("Enter experiment ID: ");
        int id = scanner.nextInt();
        experimentDAO.deleteExperiment(id);
        System.out.println("Experiment deleted.");
    }

    private static void manageSamples(Scanner scanner) {
        System.out.println("1. Add Sample");
        System.out.println("2. View Sample");
        System.out.println("3. Update Sample");
        System.out.println("4. Delete Sample");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addSample(scanner);
                break;
            case 2:
                viewSample(scanner);
                break;
            case 3:
                updateSample(scanner);
                break;
            case 4:
                deleteSample(scanner);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addSample(Scanner scanner) {
        Sample sample = new Sample();
        System.out.print("Enter experiment ID: ");
        sample.setExperimentId(scanner.nextInt());
        scanner.nextLine(); // Consume newline
        System.out.print("Enter name: ");
        sample.setName(scanner.nextLine());
        System.out.print("Enter type: ");
        sample.setType(scanner.nextLine());
        System.out.print("Enter quantity: ");
        sample.setQuantity(scanner.nextInt());
        sampleDAO.addSample(sample);
        System.out.println("Sample added.");
    }

    private static void viewSample(Scanner scanner) {
        System.out.print("Enter sample ID: ");
        int id = scanner.nextInt();
        Sample sample = sampleDAO.getSample(id);
        if (sample != null) {
            System.out.println("ID: " + sample.getSampleId());
            System.out.println("Experiment ID: " + sample.getExperimentId());
            System.out.println("Name: " + sample.getName());
            System.out.println("Type: " + sample.getType());
            System.out.println("Quantity: " + sample.getQuantity());
        } else {
            System.out.println("Sample not found.");
        }
    }

    private static void updateSample(Scanner scanner) {
        System.out.print("Enter sample ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Sample sample = sampleDAO.getSample(id);
        if (sample != null) {
            System.out.print("Enter new experiment ID (current: " + sample.getExperimentId() + "): ");
            sample.setExperimentId(scanner.nextInt());
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new name (current: " + sample.getName() + "): ");
            sample.setName(scanner.nextLine());
            System.out.print("Enter new type (current: " + sample.getType() + "): ");
            sample.setType(scanner.nextLine());
            System.out.print("Enter new quantity (current: " + sample.getQuantity() + "): ");
            sample.setQuantity(scanner.nextInt());
            sampleDAO.updateSample(sample);
            System.out.println("Sample updated.");
        } else {
            System.out.println("Sample not found.");
        }
    }

    private static void deleteSample(Scanner scanner) {
        System.out.print("Enter sample ID: ");
        int id = scanner.nextInt();
        sampleDAO.deleteSample(id);
        System.out.println("Sample deleted.");
    }

    private static void manageResearchers(Scanner scanner) {
        System.out.println("1. Add Researcher");
        System.out.println("2. View Researcher");
        System.out.println("3. Update Researcher");
        System.out.println("4. Delete Researcher");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addResearcher(scanner);
                break;
            case 2:
                viewResearcher(scanner);
                break;
            case 3:
                updateResearcher(scanner);
                break;
            case 4:
                deleteResearcher(scanner);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addResearcher(Scanner scanner) {
        Researcher researcher = new Researcher();
        System.out.print("Enter name: ");
        researcher.setName(scanner.nextLine());
        System.out.print("Enter email: ");
        researcher.setEmail(scanner.nextLine());
        System.out.print("Enter phone number: ");
        researcher.setPhoneNumber(scanner.nextLine());
        System.out.print("Enter specialization: ");
        researcher.setSpecialization(scanner.nextLine());
        researcherDAO.addResearcher(researcher);
        System.out.println("Researcher added.");
    }

    private static void viewResearcher(Scanner scanner) {
        System.out.print("Enter researcher ID: ");
        int id = scanner.nextInt();
        Researcher researcher = researcherDAO.getResearcher(id);
        if (researcher != null) {
            System.out.println("ID: " + researcher.getResearcherId());
            System.out.println("Name: " + researcher.getName());
            System.out.println("Email: " + researcher.getEmail());
            System.out.println("Phone Number: " + researcher.getPhoneNumber());
            System.out.println("Specialization: " + researcher.getSpecialization());
        } else {
            System.out.println("Researcher not found.");
        }
    }

    private static void updateResearcher(Scanner scanner) {
        System.out.print("Enter researcher ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        Researcher researcher = researcherDAO.getResearcher(id);
        if (researcher != null) {
            System.out.print("Enter new name (current: " + researcher.getName() + "): ");
            researcher.setName(scanner.nextLine());
            System.out.print("Enter new email (current: " + researcher.getEmail() + "): ");
            researcher.setEmail(scanner.nextLine());
            System.out.print("Enter new phone number (current: " + researcher.getPhoneNumber() + "): ");
            researcher.setPhoneNumber(scanner.nextLine());
            System.out.print("Enter new specialization (current: " + researcher.getSpecialization() + "): ");
            researcher.setSpecialization(scanner.nextLine());
            researcherDAO.updateResearcher(researcher);
            System.out.println("Researcher updated.");
        } else {
            System.out.println("Researcher not found.");
        }
    }

    private static void deleteResearcher(Scanner scanner) {
        System.out.print("Enter researcher ID: ");
        int id = scanner.nextInt();
        researcherDAO.deleteResearcher(id);
        System.out.println("Researcher deleted.");
    }
}
