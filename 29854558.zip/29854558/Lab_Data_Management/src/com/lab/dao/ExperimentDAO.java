package com.lab.dao;

import com.lab.model.Experiment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExperimentDAO {

    public void addExperiment(Experiment experiment) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Experiment (name, description, start_date, end_date) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, experiment.getName());
            ps.setString(2, experiment.getDescription());
            ps.setDate(3, experiment.getStartDate());
            ps.setDate(4, experiment.getEndDate());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Experiment getExperiment(int experimentId) {
        Experiment experiment = null;
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Experiment WHERE experiment_id = ?")) {
            ps.setInt(1, experimentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getDate("start_date"));
                experiment.setEndDate(rs.getDate("end_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiment;
    }

    public void updateExperiment(Experiment experiment) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE Experiment SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?")) {
            ps.setString(1, experiment.getName());
            ps.setString(2, experiment.getDescription());
            ps.setDate(3, experiment.getStartDate());
            ps.setDate(4, experiment.getEndDate());
            ps.setInt(5, experiment.getExperimentId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteExperiment(int experimentId) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Experiment WHERE experiment_id = ?")) {
            ps.setInt(1, experimentId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Experiment> getAllExperiments() {
        List<Experiment> experiments = new ArrayList<>();
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Experiment")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Experiment experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getDate("start_date"));
                experiment.setEndDate(rs.getDate("end_date"));
                experiments.add(experiment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }
}
