package com.lab.dao;

import com.lab.model.Sample;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SampleDAO {

    public void addSample(Sample sample) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Sample (experiment_id, name, type, quantity) VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, sample.getExperimentId());
            ps.setString(2, sample.getName());
            ps.setString(3, sample.getType());
            ps.setInt(4, sample.getQuantity());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Sample getSample(int sampleId) {
        Sample sample = null;
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Sample WHERE sample_id = ?")) {
            ps.setInt(1, sampleId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sample;
    }

    public void updateSample(Sample sample) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE Sample SET experiment_id = ?, name = ?, type = ?, quantity = ? WHERE sample_id = ?")) {
            ps.setInt(1, sample.getExperimentId());
            ps.setString(2, sample.getName());
            ps.setString(3, sample.getType());
            ps.setInt(4, sample.getQuantity());
            ps.setInt(5, sample.getSampleId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSample(int sampleId) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Sample WHERE sample_id = ?")) {
            ps.setInt(1, sampleId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Sample> getAllSamples() {
        List<Sample> samples = new ArrayList<>();
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Sample")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Sample sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
                samples.add(sample);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return samples;
    }
}
