package com.lab.dao;

import com.lab.model.Researcher;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResearcherDAO {

    public void addResearcher(Researcher researcher) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO Researcher (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, researcher.getName());
            ps.setString(2, researcher.getEmail());
            ps.setString(3, researcher.getPhoneNumber());
            ps.setString(4, researcher.getSpecialization());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Researcher getResearcher(int researcherId) {
        Researcher researcher = null;
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Researcher WHERE researcher_id = ?")) {
            ps.setInt(1, researcherId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return researcher;
    }

    public void updateResearcher(Researcher researcher) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE Researcher SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?")) {
            ps.setString(1, researcher.getName());
            ps.setString(2, researcher.getEmail());
            ps.setString(3, researcher.getPhoneNumber());
            ps.setString(4, researcher.getSpecialization());
            ps.setInt(5, researcher.getResearcherId());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteResearcher(int researcherId) {
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM Researcher WHERE researcher_id = ?")) {
            ps.setInt(1, researcherId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Researcher> getAllResearchers() {
        List<Researcher> researchers = new ArrayList<>();
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM Researcher")) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Researcher researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
                researchers.add(researcher);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return researchers;
    }
}
