create database lab_manage;
show databases;
USE lab_manage;



CREATE TABLE Experiment (
    experiment_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE
);

CREATE TABLE Sample (
    sample_id INT AUTO_INCREMENT PRIMARY KEY,
    experiment_id INT,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(255),
    quantity INT,
    FOREIGN KEY (experiment_id) REFERENCES Experiment(experiment_id)
);

CREATE TABLE Researcher (
    researcher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone_number VARCHAR(15),
    specialization VARCHAR(255)
);





-- Insert data into Experiment table
INSERT INTO Experiment (name, description, start_date, end_date) VALUES
('Gene Mapping', 'Mapping genes related to disease resistance', '2023-01-10', '2023-03-15'),
('Protein Analysis', 'Analyzing protein structures', '2023-02-01', '2023-05-20'),
('Cell Culture', 'Culturing cells for testing drug efficacy', '2023-03-05', '2023-06-30'),
('DNA Sequencing', 'Sequencing DNA samples', '2023-04-10', '2023-07-25'),
('Virus Research', 'Studying virus behavior', '2023-05-15', '2023-08-20');

-- Insert data into Sample table
INSERT INTO Sample (experiment_id, name, type, quantity) VALUES
(1, 'Sample A1', 'Blood', 10),
(1, 'Sample A2', 'Tissue', 5),
(2, 'Sample B1', 'Protein', 20),
(3, 'Sample C1', 'Cell', 15),
(4, 'Sample D1', 'DNA', 25);

-- Insert data into Researcher table
INSERT INTO Researcher (name, email, phone_number, specialization) VALUES
('Dr. Alice Smith', 'alice.smith@lab.com', '123-456-7890', 'Genetics'),
('Dr. Bob Johnson', 'bob.johnson@lab.com', '234-567-8901', 'Proteomics'),
('Dr. Carol White', 'carol.white@lab.com', '345-678-9012', 'Cell Biology'),
('Dr. David Brown', 'david.brown@lab.com', '456-789-0123', 'Bioinformatics'),
('Dr. Eve Green', 'eve.green@lab.com', '567-890-1234', 'Virology');



select *from researcher;
select *from sample;
select *from experiment;


