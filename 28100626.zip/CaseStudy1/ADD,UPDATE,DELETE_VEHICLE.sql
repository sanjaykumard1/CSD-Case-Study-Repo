--add,update,delete
-- Add vehicle procedure
CREATE OR REPLACE PROCEDURE AddVehicle(
    p_Make IN VARCHAR2,
    p_Model IN VARCHAR2,
    p_Year IN NUMBER,
    p_LicensePlate IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
    v_Count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_Count FROM Vehicles WHERE LICENSE_PLATE = p_LicensePlate;
    IF v_Count = 0 THEN
        INSERT INTO Vehicles (VEHICLE_ID, MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS)
        VALUES (Vehicles_SEQ.NEXTVAL, p_Make, p_Model, p_Year, p_LicensePlate, p_Status);
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Vehicle with License Plate ' || p_LicensePlate || ' already exists.');
    END IF;
END;
/

-- Update vehicle procedure
CREATE OR REPLACE PROCEDURE UpdateVehicle(
    p_VehicleID IN NUMBER,
    p_Make IN VARCHAR2,
    p_Model IN VARCHAR2,
    p_Year IN NUMBER,
    p_LicensePlate IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    UPDATE Vehicles
    SET MAKE = p_Make,
        MODEL = p_Model,
        YEAR = p_Year,
        LICENSE_PLATE = p_LicensePlate,
        STATUS = p_Status
    WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

-- Delete vehicle procedure
CREATE OR REPLACE PROCEDURE DeleteVehicle(
    p_VehicleID IN NUMBER
) IS
BEGIN
    DELETE FROM Trips WHERE VEHICLE_ID = p_VehicleID;
    DELETE FROM Maintenance WHERE VEHICLE_ID = p_VehicleID;
    DELETE FROM Vehicles WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

-- Search vehicle procedure
CREATE OR REPLACE PROCEDURE SearchVehicle(
    p_VehicleID IN NUMBER
) IS
    v_Make Vehicles.MAKE%TYPE;
    v_Model Vehicles.MODEL%TYPE;
    v_Year Vehicles.YEAR%TYPE;
    v_LicensePlate Vehicles.LICENSE_PLATE%TYPE;
    v_Status Vehicles.STATUS%TYPE;
BEGIN
    SELECT MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS
    INTO v_Make, v_Model, v_Year, v_LicensePlate, v_Status
    FROM Vehicles
    WHERE VEHICLE_ID = p_VehicleID;

    DBMS_OUTPUT.PUT_LINE('Vehicle ID: ' || p_VehicleID);
    DBMS_OUTPUT.PUT_LINE('Make: ' || v_Make);
    DBMS_OUTPUT.PUT_LINE('Model: ' || v_Model);
    DBMS_OUTPUT.PUT_LINE('Year: ' || v_Year);
    DBMS_OUTPUT.PUT_LINE('License Plate: ' || v_LicensePlate);
    DBMS_OUTPUT.PUT_LINE('Status: ' || v_Status);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Vehicle with ID ' || p_VehicleID || ' not found.');
END;
/
SELECT * FROM Vehicles;

--Queries
-- Add a vehicle
BEGIN
    AddVehicle('Honda', 'Accord', 2024, 'DEF9876', 'Active');
END;
/
SELECT * FROM Vehicles;

-- Update a vehicle
BEGIN
    UpdateVehicle(3, 'Honda', 'Civic', 2024, 'GHI5432', 'Active');
END;
/

-- Delete a vehicle
BEGIN
    DeleteVehicle(3);
END;
/
SELECT * FROM Vehicles;

-- Search for a vehicle
BEGIN
    SearchVehicle(1);
    SearchVehicle(2);
END;
/
SELECT * FROM Vehicles;
