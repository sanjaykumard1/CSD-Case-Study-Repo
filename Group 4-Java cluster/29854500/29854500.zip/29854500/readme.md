This project is a Java-based console application for managing events, participants, and registrations using JDBC with MySQL.

Features
1. Event Management: Add, view, update, and delete events.
2. Participant Management: Add, view, update, and delete participants.
3. Registration Management: Register participants for events, view registration details, update registrations, and cancel registrations.
4. Database Integration: Uses JDBC for database interactions with MySQL.
5. Menu-Based Interface: User-friendly console menu for easy navigation.

Database Schema
The project uses the following database schema:

1.Event Table:
event_id (Primary Key)
name
date
location
description
capacity


2.Participant Table:
participant_id (Primary Key)
name
email
phone_number


3.Registration Table:
registration_id (Primary Key)
event_id (Foreign Key references Event Table)
participant_id (Foreign Key references Participant Table)
registration_date
status (registered/cancelled)

Usage
Upon running the application, you will see a menu with options to manage events, participants, and registrations.
Follow the on-screen prompts to perform actions such as adding events, registering participants, etc.
Technologies Used
Java
JDBC (Java Database Connectivity)
MySQL