package EventManagement;

import java.sql.*;
import java.util.Scanner;

public class Event {
    public static void manageEvents(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Event Management");
            System.out.println("1. Add a new event");
            System.out.println("2. View event details");
            System.out.println("3. Update event information");
            System.out.println("4. Delete an event");
            System.out.println("0. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addEvent(conn);
                    break;
                case 2:
                    viewEventDetails(conn);
                    break;
                case 3:
                    updateEvent(conn);
                    break;
                case 4:
                    deleteEvent(conn);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    private static void addEvent(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter event description: ");
        String description = scanner.nextLine();
        System.out.print("Enter event capacity: ");
        int capacity = scanner.nextInt();

        String sql = "INSERT INTO Event (name, date, location, description, capacity) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, date);
            pstmt.setString(3, location);
            pstmt.setString(4, description);
            pstmt.setInt(5, capacity);
            pstmt.executeUpdate();
            System.out.println("Event added successfully!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void viewEventDetails(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter event ID to view details: ");
        int eventId = scanner.nextInt();

        String sql = "SELECT * FROM Event WHERE event_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Event ID: " + rs.getInt("event_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Date: " + rs.getDate("date"));
                System.out.println("Location: " + rs.getString("location"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Capacity: " + rs.getInt("capacity"));
            } else {
                System.out.println("Event not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void updateEvent(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter event ID to update: ");
        int eventId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.print("Enter new event name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new event date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Enter new event location: ");
        String location = scanner.nextLine();
        System.out.print("Enter new event description: ");
        String description = scanner.nextLine();
        System.out.print("Enter new event capacity: ");
        int capacity = scanner.nextInt();

        String sql = "UPDATE Event SET name = ?, date = ?, location = ?, description = ?, capacity = ? WHERE event_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, date);
            pstmt.setString(3, location);
            pstmt.setString(4, description);
            pstmt.setInt(5, capacity);
            pstmt.setInt(6, eventId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Event updated successfully!");
            } else {
                System.out.println("Event not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void deleteEvent(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter event ID to delete: ");
        int eventId = scanner.nextInt();

        String sql = "DELETE FROM Event WHERE event_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Event deleted successfully!");
            } else {
                System.out.println("Event not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

