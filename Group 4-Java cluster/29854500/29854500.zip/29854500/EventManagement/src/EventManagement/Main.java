package EventManagement;

import java.sql.*;
import java.util.Scanner;

public class Main {
    private static Connection connect() {
        // Load database connection details from properties file
        String url = "jdbc:mysql://localhost:3307/EventManagementSystem";
        String user = "root";
        String password = "root123"; // Replace with your MySQL root password
        Connection conn = null;

        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Event Management System");
            System.out.println("1. Manage Events");
            System.out.println("2. Manage Participants");
            System.out.println("3. Manage Registrations");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Event.manageEvents(connect());
                    break;
                case 2:
                    Participant.manageParticipants(connect());
                    break;
                case 3:
                    Registration.manageRegistrations(connect());
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }
}

