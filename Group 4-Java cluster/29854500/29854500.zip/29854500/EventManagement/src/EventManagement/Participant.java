package EventManagement;

import java.sql.*;
import java.util.Scanner;

public class Participant {
    public static void manageParticipants(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Participant Management");
            System.out.println("1. Add a new participant");
            System.out.println("2. View participant details");
            System.out.println("3. Update participant information");
            System.out.println("4. Delete a participant");
            System.out.println("0. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addParticipant(conn);
                    break;
                case 2:
                    viewParticipantDetails(conn);
                    break;
                case 3:
                    updateParticipant(conn);
                    break;
                case 4:
                    deleteParticipant(conn);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    private static void addParticipant(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter participant name: ");
        String name = scanner.nextLine();
        System.out.print("Enter participant email: ");
        String email = scanner.nextLine();
        System.out.print("Enter participant phone number: ");
        String phoneNumber = scanner.nextLine();

        String sql = "INSERT INTO Participant (name, email, phone_number) VALUES (?, ?, ?)";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.executeUpdate();
            System.out.println("Participant added successfully!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void viewParticipantDetails(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter participant ID to view details: ");
        int participantId = scanner.nextInt();

        String sql = "SELECT * FROM Participant WHERE participant_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, participantId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Participant not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void updateParticipant(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter participant ID to update: ");
        int participantId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.print("Enter new participant name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new participant email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new participant phone number: ");
        String phoneNumber = scanner.nextLine();

        String sql = "UPDATE Participant SET name = ?, email = ?, phone_number = ? WHERE participant_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setInt(4, participantId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Participant updated successfully!");
            } else {
                System.out.println("Participant not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void deleteParticipant(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter participant ID to delete: ");
        int participantId = scanner.nextInt();

        String sql = "DELETE FROM Participant WHERE participant_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, participantId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Participant deleted successfully!");
            } else {
                System.out.println("Participant not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}

