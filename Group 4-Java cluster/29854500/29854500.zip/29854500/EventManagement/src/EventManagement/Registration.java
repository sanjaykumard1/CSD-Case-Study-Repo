package EventManagement;

import java.sql.*;
import java.util.Scanner;

public class Registration {
    public static void manageRegistrations(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Registration Management");
            System.out.println("1. Register a participant for an event");
            System.out.println("2. View registration details");
            System.out.println("3. Update registration information");
            System.out.println("4. Cancel a registration");
            System.out.println("0. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerParticipant(conn);
                    break;
                case 2:
                    viewRegistrationDetails(conn);
                    break;
                case 3:
                    updateRegistration(conn);
                    break;
                case 4:
                    cancelRegistration(conn);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    private static void registerParticipant(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter event ID: ");
        int eventId = scanner.nextInt();
        System.out.print("Enter participant ID: ");
        int participantId = scanner.nextInt();
        System.out.print("Enter registration date (YYYY-MM-DD): ");
        String registrationDate = scanner.next();

        // Check event capacity before registration
        String checkCapacitySql = "SELECT capacity FROM Event WHERE event_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(checkCapacitySql)) {
            pstmt.setInt(1, eventId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int capacity = rs.getInt("capacity");
                if (capacity <= 0) {
                    System.out.println("Event is full. Cannot register.");
                    return;
                }
            } else {
                System.out.println("Event not found.");
                return;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return;
        }

        String sql = "INSERT INTO Registration (event_id, participant_id, registration_date, status) VALUES (?, ?, ?, 'registered')";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            pstmt.setInt(2, participantId);
            pstmt.setString(3, registrationDate);
            pstmt.executeUpdate();

            // Decrease event capacity
            String updateCapacitySql = "UPDATE Event SET capacity = capacity - 1 WHERE event_id = ?";
            try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateCapacitySql)) {
                pstmtUpdate.setInt(1, eventId);
                pstmtUpdate.executeUpdate();
            }

            System.out.println("Participant registered successfully!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void viewRegistrationDetails(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter registration ID to view details: ");
        int registrationId = scanner.nextInt();

        String sql = "SELECT * FROM Registration WHERE registration_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, registrationId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Registration ID: " + rs.getInt("registration_id"));
                System.out.println("Event ID: " + rs.getInt("event_id"));
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Registration Date: " + rs.getDate("registration_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Registration not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void updateRegistration(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter registration ID to update: ");
        int registrationId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.print("Enter new event ID: ");
        int eventId = scanner.nextInt();
        System.out.print("Enter new participant ID: ");
        int participantId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline
        System.out.print("Enter new registration date (YYYY-MM-DD): ");
        String registrationDate = scanner.nextLine();

        String sql = "UPDATE Registration SET event_id = ?, participant_id = ?, registration_date = ? WHERE registration_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, eventId);
            pstmt.setInt(2, participantId);
            pstmt.setString(3, registrationDate);
            pstmt.setInt(4, registrationId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                System.out.println("Registration updated successfully!");
            } else {
                System.out.println("Registration not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void cancelRegistration(Connection conn) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter registration ID to cancel: ");
        int registrationId = scanner.nextInt();

        // Get event_id before cancellation for capacity update
        int eventId = 0;
        String getEventIdSql = "SELECT event_id FROM Registration WHERE registration_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(getEventIdSql)) {
            pstmt.setInt(1, registrationId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                eventId = rs.getInt("event_id");
            } else {
                System.out.println("Registration not found.");
                return;
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return;
        }

        String sql = "UPDATE Registration SET status = 'cancelled' WHERE registration_id = ?";

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, registrationId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                // Increase event capacity
                String updateCapacitySql = "UPDATE Event SET capacity = capacity + 1 WHERE event_id = ?";
                try (PreparedStatement pstmtUpdate = conn.prepareStatement(updateCapacitySql)) {
                    pstmtUpdate.setInt(1, eventId);
                    pstmtUpdate.executeUpdate();
                }
                System.out.println("Registration cancelled successfully!");
            } else {
                System.out.println("Registration not found.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
