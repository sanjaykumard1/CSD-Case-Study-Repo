/**
 * 
 */
/**
 * 
 */
module LibraryCatalog {
	requires java.sql;
}