package com.casestudy.library.dao;

import com.casestudy.library.database.DatabaseConnection;
import com.casestudy.library.models.Book;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

    public void addBook(Book book) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
//            // Check if the author exists
//            String checkAuthorQuery = "SELECT COUNT(*) FROM author WHERE author_id = ?";
//            try (PreparedStatement checkAuthorStatement = connection.prepareStatement(checkAuthorQuery)) {
//                checkAuthorStatement.setInt(1, book.getAuthorId());
//                ResultSet resultSet = checkAuthorStatement.executeQuery();
//                if (resultSet.next() && resultSet.getInt(1) == 0) {
//                    throw new SQLException("Author with ID " + book.getAuthorId() + " does not exist.");
//                }
//            }

            // Insert the book
            String query = "INSERT INTO book (title, author_id, ISBN, quantity_available) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, book.getTitle());
                statement.setInt(2, book.getAuthorId());
                statement.setString(3, book.getISBN());
                statement.setInt(4, book.getQuantityAvailable());
                statement.executeUpdate();
            }
        }
    }

    public void updateBook(Book book) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the book exists
            String checkBookQuery = "SELECT COUNT(*) FROM book WHERE book_id = ?";
            try (PreparedStatement checkBookStatement = connection.prepareStatement(checkBookQuery)) {
                checkBookStatement.setInt(1, book.getBookId());
                ResultSet resultSet = checkBookStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Book with ID " + book.getBookId() + " does not exist.");
                }
            }

            // Update the book
            String query = "UPDATE book SET title = ?, author_id = ?, ISBN = ?, quantity_available = ? WHERE book_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, book.getTitle());
                statement.setInt(2, book.getAuthorId());
                statement.setString(3, book.getISBN());
                statement.setInt(4, book.getQuantityAvailable());
                statement.setInt(5, book.getBookId());
                statement.executeUpdate();
            }
        }
    }

    public void deleteBook(int bookId) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the book exists
            String checkBookQuery = "SELECT COUNT(*) FROM book WHERE book_id = ?";
            try (PreparedStatement checkBookStatement = connection.prepareStatement(checkBookQuery)) {
                checkBookStatement.setInt(1, bookId);
                ResultSet resultSet = checkBookStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Book with ID " + bookId + " does not exist.");
                }
            }

            // Delete the book
            String query = "DELETE FROM book WHERE book_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, bookId);
                statement.executeUpdate();
            }
        }
    }

    public List<Book> getAllBooks() throws ClassNotFoundException, SQLException {
        List<Book> books = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM book");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Book book = new Book();
                book.setBookId(resultSet.getInt("book_id"));
                book.setTitle(resultSet.getString("title"));
                book.setAuthorId(resultSet.getInt("author_id"));
                book.setISBN(resultSet.getString("ISBN"));
                book.setQuantityAvailable(resultSet.getInt("quantity_available"));
                books.add(book);
            }
        }
        return books;
    }

    public Book getBookById(int bookId) throws ClassNotFoundException, SQLException {
        Book book = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM book WHERE book_id = ?")) {
            statement.setInt(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    book = new Book();
                    book.setBookId(resultSet.getInt("book_id"));
                    book.setTitle(resultSet.getString("title"));
                    book.setAuthorId(resultSet.getInt("author_id"));
                    book.setISBN(resultSet.getString("ISBN"));
                    book.setQuantityAvailable(resultSet.getInt("quantity_available"));
                }
            }
        }
        return book;
    }
}
