package com.casestudy.library.dao;

import com.casestudy.library.database.DatabaseConnection;
import com.casestudy.library.models.BorrowingHistory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BorrowingHistoryDAO {

    public void issueBook(int bookId, int memberId) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the book exists
            String checkBookQuery = "SELECT COUNT(*) FROM book WHERE book_id = ?";
            try (PreparedStatement checkBookStatement = connection.prepareStatement(checkBookQuery)) {
                checkBookStatement.setInt(1, bookId);
                ResultSet resultSet = checkBookStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Book with ID " + bookId + " does not exist.");
                }
            }

            // Check if the member exists
            String checkMemberQuery = "SELECT COUNT(*) FROM library_member WHERE member_id = ?";
            try (PreparedStatement checkMemberStatement = connection.prepareStatement(checkMemberQuery)) {
                checkMemberStatement.setInt(1, memberId);
                ResultSet resultSet = checkMemberStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Library member with ID " + memberId + " does not exist.");
                }
            }

            // Issue the book
            String query = "INSERT INTO borrowing_history (book_id, member_id, issue_date) VALUES (?, ?, CURDATE())";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, bookId);
                statement.setInt(2, memberId);
                statement.executeUpdate();
            }

            // Decrease quantity available of the book
            String updateQuery = "UPDATE book SET quantity_available = quantity_available - 1 WHERE book_id = ?";
            try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                updateStatement.setInt(1, bookId);
                updateStatement.executeUpdate();
            }
        }
    }

    public void returnBook(int bookId, int memberId) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the book is borrowed by the member
            String checkBorrowingQuery = "SELECT COUNT(*) FROM borrowing_history WHERE book_id = ? AND member_id = ?";
            try (PreparedStatement checkBorrowingStatement = connection.prepareStatement(checkBorrowingQuery)) {
                checkBorrowingStatement.setInt(1, bookId);
                checkBorrowingStatement.setInt(2, memberId);
                ResultSet resultSet = checkBorrowingStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Book with ID " + bookId + " is not borrowed by member with ID " + memberId);
                }
            }

            // Return the book
            String query = "UPDATE borrowing_history SET return_date = CURDATE() WHERE book_id = ? AND member_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, bookId);
                statement.setInt(2, memberId);
                statement.executeUpdate();
            }

            // Increase quantity available of the book
            String updateQuery = "UPDATE book SET quantity_available = quantity_available + 1 WHERE book_id = ?";
            try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                updateStatement.setInt(1, bookId);
                updateStatement.executeUpdate();
            }
        }
    }

    public List<BorrowingHistory> getBorrowingHistoryByMemberId(int memberId) throws ClassNotFoundException, SQLException {
        List<BorrowingHistory> borrowingHistories = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM borrowing_history WHERE member_id = ?");
             ResultSet resultSet = statement.executeQuery()) {
            statement.setInt(1, memberId);
            while (resultSet.next()) {
                BorrowingHistory borrowingHistory = new BorrowingHistory();
                borrowingHistory.setBorrowingId(resultSet.getInt("borrowing_id"));
                borrowingHistory.setBookId(resultSet.getInt("book_id"));
                borrowingHistory.setMemberId(resultSet.getInt("member_id"));
                borrowingHistory.setIssueDate(resultSet.getDate("issue_date"));
                borrowingHistory.setReturnDate(resultSet.getDate("return_date"));
                borrowingHistories.add(borrowingHistory);
            }
        }
        return borrowingHistories;
    }
}
