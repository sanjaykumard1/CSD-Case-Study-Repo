package com.casestudy.library.dao;

import com.casestudy.library.database.DatabaseConnection;
import com.casestudy.library.models.LibraryMember;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibraryMemberDAO {

    public void addLibraryMember(LibraryMember member) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO library_member (name, address, phone_number, email) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, member.getName());
                statement.setString(2, member.getAddress());
                statement.setString(3, member.getPhoneNumber());
                statement.setString(4, member.getEmail());
                statement.executeUpdate();
            }
        }
    }

    public void updateLibraryMember(LibraryMember member) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the member exists
            String checkMemberQuery = "SELECT COUNT(*) FROM library_member WHERE member_id = ?";
            try (PreparedStatement checkMemberStatement = connection.prepareStatement(checkMemberQuery)) {
                checkMemberStatement.setInt(1, member.getMemberId());
                ResultSet resultSet = checkMemberStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Library member with ID " + member.getMemberId() + " does not exist.");
                }
            }

            // Update the member
            String query = "UPDATE library_member SET name = ?, address = ?, phone_number = ?, email = ? WHERE member_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, member.getName());
                statement.setString(2, member.getAddress());
                statement.setString(3, member.getPhoneNumber());
                statement.setString(4, member.getEmail());
                statement.setInt(5, member.getMemberId());
                statement.executeUpdate();
            }
        }
    }

    public void deleteLibraryMember(int memberId) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the member exists
            String checkMemberQuery = "SELECT COUNT(*) FROM library_member WHERE member_id = ?";
            try (PreparedStatement checkMemberStatement = connection.prepareStatement(checkMemberQuery)) {
                checkMemberStatement.setInt(1, memberId);
                ResultSet resultSet = checkMemberStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Library member with ID " + memberId + " does not exist.");
                }
            }

            // Delete the member
            String query = "DELETE FROM library_member WHERE member_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, memberId);
                statement.executeUpdate();
            }
        }
    }

    public List<LibraryMember> getAllLibraryMembers() throws ClassNotFoundException, SQLException {
        List<LibraryMember> members = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM library_member");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                LibraryMember member = new LibraryMember();
                member.setMemberId(resultSet.getInt("member_id"));
                member.setName(resultSet.getString("name"));
                member.setAddress(resultSet.getString("address"));
                member.setPhoneNumber(resultSet.getString("phone_number"));
                member.setEmail(resultSet.getString("email"));
                members.add(member);
            }
        }
        return members;
    }

    public LibraryMember getLibraryMemberById(int memberId) throws ClassNotFoundException, SQLException {
        LibraryMember member = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM library_member WHERE member_id = ?")) {
            statement.setInt(1, memberId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    member = new LibraryMember();
                    member.setMemberId(resultSet.getInt("member_id"));
                    member.setName(resultSet.getString("name"));
                    member.setAddress(resultSet.getString("address"));
                    member.setPhoneNumber(resultSet.getString("phone_number"));
                    member.setEmail(resultSet.getString("email"));
                }
            }
        }
        return member;
    }
}
