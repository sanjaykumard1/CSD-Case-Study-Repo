package com.casestudy.library;

import com.casestudy.library.dao.*;
import com.casestudy.library.models.*;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class LibraryManagementSystem {
    private static final Scanner scanner = new Scanner(System.in);
    private static final BookDAO bookDAO = new BookDAO();
    private static final AuthorDAO authorDAO = new AuthorDAO();
    private static final LibraryMemberDAO memberDAO = new LibraryMemberDAO();
    private static final BorrowingHistoryDAO borrowingHistoryDAO = new BorrowingHistoryDAO();

    public static void main(String[] args) {
        displayMenu();
    }

    private static void displayMenu() {
        while (true) {
            System.out.println("\n=== Library Management System Menu ===");
            System.out.println("1. Manage Books");
            System.out.println("2. Manage Authors");
            System.out.println("3. Manage Library Members");
            System.out.println("4. Borrow and Return Books");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageBooks();
                    break;
                case 2:
                    manageAuthors();
                    break;
                case 3:
                    manageLibraryMembers();
                    break;
                case 4:
                    borrowAndReturnBooks();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    private static void manageBooks() {
        while (true) {
            System.out.println("\n=== Manage Books Menu ===");
            System.out.println("1. Add a New Book");
            System.out.println("2. Update Book Information");
            System.out.println("3. Delete a Book");
            System.out.println("4. View All Books");
            System.out.println("5. Go Back");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewBook();
                    break;
                case 2:
                    updateBook();
                    break;
                case 3:
                    deleteBook();
                    break;
                case 4:
                    viewAllBooks();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    private static void addNewBook() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author ID: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter ISBN: ");
        String ISBN = scanner.nextLine();
        System.out.print("Enter quantity available: ");
        int quantityAvailable = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Book book = new Book();
        book.setTitle(title);
        book.setAuthorId(authorId);
        book.setISBN(ISBN);
        book.setQuantityAvailable(quantityAvailable);

        try {
            bookDAO.addBook(book);
            System.out.println("Book added successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error adding book: " + e.getMessage());
        }
    }

    private static void updateBook() {
        System.out.print("Enter book ID to update: ");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            Book book = bookDAO.getBookById(bookId);
            if (book != null) {
                System.out.println("Current Details: " + book);
                System.out.print("Enter new title (or enter to keep current): ");
                String newTitle = scanner.nextLine();
                if (!newTitle.trim().isEmpty()) {
                    book.setTitle(newTitle);
                }
                System.out.print("Enter new author ID (or enter to keep current): ");
                String newAuthorIdStr = scanner.nextLine();
                if (!newAuthorIdStr.trim().isEmpty()) {
                    int newAuthorId = Integer.parseInt(newAuthorIdStr);
                    book.setAuthorId(newAuthorId);
                }
                System.out.print("Enter new ISBN (or enter to keep current): ");
                String newISBN = scanner.nextLine();
                if (!newISBN.trim().isEmpty()) {
                    book.setISBN(newISBN);
                }
                System.out.print("Enter new quantity available (or enter to keep current): ");
                String newQuantityAvailableStr = scanner.nextLine();
                if (!newQuantityAvailableStr.trim().isEmpty()) {
                    int newQuantityAvailable = Integer.parseInt(newQuantityAvailableStr);
                    book.setQuantityAvailable(newQuantityAvailable);
                }

                bookDAO.updateBook(book);
                System.out.println("Book updated successfully.");
            } else {
                System.out.println("Book with ID " + bookId + " not found.");
            }
        } catch (ClassNotFoundException | SQLException | NumberFormatException e) {
            System.out.println("Error updating book: " + e.getMessage());
        }
    }

    private static void deleteBook() {
        System.out.print("Enter book ID to delete: ");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            bookDAO.deleteBook(bookId);
            System.out.println("Book deleted successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error deleting book: " + e.getMessage());
        }
    }

    private static void viewAllBooks() {
        try {
            List<Book> books = bookDAO.getAllBooks();
            if (books.isEmpty()) {
                System.out.println("No books found.");
            } else {
                System.out.println("\n=== All Books ===");
                for (Book book : books) {
                    System.out.println(book);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error fetching books: " + e.getMessage());
        }
    }

    private static void manageAuthors() {
        while (true) {
            System.out.println("\n=== Manage Authors Menu ===");
            System.out.println("1. Add a New Author");
            System.out.println("2. Update Author Information");
            System.out.println("3. Delete an Author");
            System.out.println("4. View All Authors");
            System.out.println("5. Go Back");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewAuthor();
                    break;
                case 2:
                    updateAuthor();
                    break;
                case 3:
                    deleteAuthor();
                    break;
                case 4:
                    viewAllAuthors();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    private static void addNewAuthor() {
        System.out.print("Enter author name: ");
        String name = scanner.nextLine();
        System.out.print("Enter author biography: ");
        String biography = scanner.nextLine();

        Author author = new Author();
        author.setName(name);
        author.setBiography(biography);

        try {
            authorDAO.addAuthor(author);
            System.out.println("Author added successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error adding author: " + e.getMessage());
        }
    }

    private static void updateAuthor() {
        System.out.print("Enter author ID to update: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            Author author = authorDAO.getAuthorById(authorId);
            if (author != null) {
                System.out.println("Current Details: " + author);
                System.out.print("Enter new author name (or enter to keep current): ");
                String newName = scanner.nextLine();
                if (!newName.trim().isEmpty()) {
                    author.setName(newName);
                }
                System.out.print("Enter new author biography (or enter to keep current): ");
                String newBiography = scanner.nextLine();
                if (!newBiography.trim().isEmpty()) {
                    author.setBiography(newBiography);
                }

                authorDAO.updateAuthor(author);
                System.out.println("Author updated successfully.");
            } else {
                System.out.println("Author with ID " + authorId + " not found.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error updating author: " + e.getMessage());
        }
    }

    private static void deleteAuthor() {
        System.out.print("Enter author ID to delete: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            authorDAO.deleteAuthor(authorId);
            System.out.println("Author deleted successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error deleting author: " + e.getMessage());
        }
    }

    private static void viewAllAuthors() {
        try {
            List<Author> authors = authorDAO.getAllAuthors();
            if (authors.isEmpty()) {
                System.out.println("No authors found.");
            } else {
                System.out.println("\n=== All Authors ===");
                for (Author author : authors) {
                    System.out.println(author);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error fetching authors: " + e.getMessage());
        }
    }

    private static void manageLibraryMembers() {
        while (true) {
            System.out.println("\n=== Manage Library Members Menu ===");
            System.out.println("1. Add a New Library Member");
            System.out.println("2. Update Library Member Information");
            System.out.println("3. Delete a Library Member");
            System.out.println("4. View All Library Members");
            System.out.println("5. Go Back");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewLibraryMember();
                    break;
                case 2:
                    updateLibraryMember();
                    break;
                case 3:
                    deleteLibraryMember();
                    break;
                case 4:
                    viewAllLibraryMembers();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    private static void addNewLibraryMember() {
        System.out.print("Enter member name: ");
        String name = scanner.nextLine();
        System.out.print("Enter member address: ");
        String address = scanner.nextLine();
        System.out.print("Enter member phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter member email: ");
        String email = scanner.nextLine();

        LibraryMember member = new LibraryMember();
        member.setName(name);
        member.setAddress(address);
        member.setPhoneNumber(phoneNumber);
        member.setEmail(email);

        try {
            memberDAO.addLibraryMember(member);
            System.out.println("Library member added successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error adding library member: " + e.getMessage());
        }
    }

    private static void updateLibraryMember() {
        System.out.print("Enter member ID to update: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            LibraryMember member = memberDAO.getLibraryMemberById(memberId);
            if (member != null) {
                System.out.println("Current Details: " + member);
                System.out.print("Enter new member name (or enter to keep current): ");
                String newName = scanner.nextLine();
                if (!newName.trim().isEmpty()) {
                    member.setName(newName);
                }
                System.out.print("Enter new member address (or enter to keep current): ");
                String newAddress = scanner.nextLine();
                if (!newAddress.trim().isEmpty()) {
                    member.setAddress(newAddress);
                }
                System.out.print("Enter new member phone number (or enter to keep current): ");
                String newPhoneNumber = scanner.nextLine();
                if (!newPhoneNumber.trim().isEmpty()) {
                    member.setPhoneNumber(newPhoneNumber);
                }
                System.out.print("Enter new member email (or enter to keep current): ");
                String newEmail = scanner.nextLine();
                if (!newEmail.trim().isEmpty()) {
                    member.setEmail(newEmail);
                }

                memberDAO.updateLibraryMember(member);
                System.out.println("Library member updated successfully.");
            } else {
                System.out.println("Library member with ID " + memberId + " not found.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error updating library member: " + e.getMessage());
        }
    }

    private static void deleteLibraryMember() {
        System.out.print("Enter member ID to delete: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            memberDAO.deleteLibraryMember(memberId);
            System.out.println("Library member deleted successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error deleting library member: " + e.getMessage());
        }
    }

    private static void viewAllLibraryMembers() {
        try {
            List<LibraryMember> members = memberDAO.getAllLibraryMembers();
            if (members.isEmpty()) {
                System.out.println("No library members found.");
            } else {
                System.out.println("\n=== All Library Members ===");
                for (LibraryMember member : members) {
                    System.out.println(member);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error fetching library members: " + e.getMessage());
        }
    }

    private static void borrowAndReturnBooks() {
        while (true) {
            System.out.println("\n=== Borrow and Return Books Menu ===");
            System.out.println("1. Issue a Book");
            System.out.println("2. Return a Book");
            System.out.println("3. View Borrowing History for a Member");
            System.out.println("4. Go Back");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    issueBook();
                    break;
                case 2:
                    returnBook();
                    break;
                case 3:
                    viewBorrowingHistory();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }
    }

    private static void issueBook() {
        System.out.print("Enter book ID to borrow: ");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            borrowingHistoryDAO.issueBook(bookId, memberId);
            System.out.println("Book issued successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error issuing book: " + e.getMessage());
        }
    }

    private static void returnBook() {
        System.out.print("Enter book ID to return: ");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            borrowingHistoryDAO.returnBook(bookId, memberId);
            System.out.println("Book returned successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error returning book: " + e.getMessage());
        }
    }

    private static void viewBorrowingHistory() {
        System.out.print("Enter member ID to view borrowing history: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            List<BorrowingHistory> borrowingHistories = borrowingHistoryDAO.getBorrowingHistoryByMemberId(memberId);
            if (borrowingHistories.isEmpty()) {
                System.out.println("No borrowing history found for member ID " + memberId);
            } else {
                System.out.println("\n=== Borrowing History for Member ID " + memberId + " ===");
                for (BorrowingHistory history : borrowingHistories) {
                    System.out.println(history);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error fetching borrowing history: " + e.getMessage());
        }
    }
}
