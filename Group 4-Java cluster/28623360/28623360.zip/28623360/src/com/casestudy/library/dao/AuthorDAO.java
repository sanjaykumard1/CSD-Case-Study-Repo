package com.casestudy.library.dao;

import com.casestudy.library.database.DatabaseConnection;
import com.casestudy.library.models.Author;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AuthorDAO {

    public void addAuthor(Author author) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO author (name, biography) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, author.getName());
                statement.setString(2, author.getBiography());
                statement.executeUpdate();
            }
        }
    }

    public void updateAuthor(Author author) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the author exists
            String checkAuthorQuery = "SELECT COUNT(*) FROM author WHERE author_id = ?";
            try (PreparedStatement checkAuthorStatement = connection.prepareStatement(checkAuthorQuery)) {
                checkAuthorStatement.setInt(1, author.getAuthorId());
                ResultSet resultSet = checkAuthorStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Author with ID " + author.getAuthorId() + " does not exist.");
                }
            }

            // Update the author
            String query = "UPDATE author SET name = ?, biography = ? WHERE author_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, author.getName());
                statement.setString(2, author.getBiography());
                statement.setInt(3, author.getAuthorId());
                statement.executeUpdate();
            }
        }
    }

    public void deleteAuthor(int authorId) throws ClassNotFoundException, SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if the author exists
            String checkAuthorQuery = "SELECT COUNT(*) FROM author WHERE author_id = ?";
            try (PreparedStatement checkAuthorStatement = connection.prepareStatement(checkAuthorQuery)) {
                checkAuthorStatement.setInt(1, authorId);
                ResultSet resultSet = checkAuthorStatement.executeQuery();
                if (resultSet.next() && resultSet.getInt(1) == 0) {
                    throw new SQLException("Author with ID " + authorId + " does not exist.");
                }
            }

            // Delete the author
            String query = "DELETE FROM author WHERE author_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, authorId);
                statement.executeUpdate();
            }
        }
    }

    public List<Author> getAllAuthors() throws ClassNotFoundException, SQLException {
        List<Author> authors = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM author");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Author author = new Author();
                author.setAuthorId(resultSet.getInt("author_id"));
                author.setName(resultSet.getString("name"));
                author.setBiography(resultSet.getString("biography"));
                authors.add(author);
            }
        }
        return authors;
    }

    public Author getAuthorById(int authorId) throws ClassNotFoundException, SQLException {
        Author author = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM author WHERE author_id = ?")) {
            statement.setInt(1, authorId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    author = new Author();
                    author.setAuthorId(resultSet.getInt("author_id"));
                    author.setName(resultSet.getString("name"));
                    author.setBiography(resultSet.getString("biography"));
                }
            }
        }
        return author;
    }
}
