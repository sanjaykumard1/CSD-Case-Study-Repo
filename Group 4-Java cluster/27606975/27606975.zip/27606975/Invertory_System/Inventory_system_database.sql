create database Inventory_System;
use Inventory_System;

CREATE TABLE Product_table (
    product_id INT  AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    price DECIMAL(10, 2) NOT NULL,
    quantity_in_stock INT NOT NULL
);

select * from Supplier_table;

CREATE TABLE Supplier_table (
    supplier_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_information VARCHAR(255),
    address VARCHAR(255)
);

CREATE TABLE Order_table (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    supplier_id INT,
    order_date DATE,
    quantity INT,
    status ENUM('placed', 'canceled'),
    FOREIGN KEY (product_id) REFERENCES Product_table(product_id),
    FOREIGN KEY (supplier_id) REFERENCES Supplier_table(supplier_id)
);




