Setup Instructions
Install MySQL Installer: Download and install MySQL Installer on your device from here.

Install IntelliJ IDEA: Download and install IntelliJ IDEA on your device from here.

Download JDBC MySQL Connector: Download the MySQL Connector JAR file compatible with your device from here.





Usage Instructions
Create a Database: Open the MySQL Command Prompt and create a database named jdbc_db.

Create a New Project in IntelliJ IDEA:
Open IntelliJ IDEA.
Click on New Project.


Add MySQL Connector JAR to Your Project:
Right-click on the src folder within your project.
Go to Open Module Settings (or press F4).
Select Modules in the Project Structure window.
Click on the Dependencies tab.
Click the + icon, choose JARs or directories, and select the MySQL Connector JAR file you downloaded.



Run Your Application:
In IntelliJ IDEA, create a new class under your project.
Use this class to write and run your console-based application, simulating the laboratory information management system.

