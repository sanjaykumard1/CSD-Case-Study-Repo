package Inventory_System;

import java.sql.*;
import java.util.Scanner;

public class Order {
    private Connection connection;
    private Scanner scanner;

    public Order(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void placeOrder() {
        System.out.println("Enter Order ID: ");
        int order_id = scanner.nextInt();
        System.out.println("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.println("Enter supplier ID: ");
        int supplierId = scanner.nextInt();
        System.out.println("Enter order quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter order date (YYYY-MM-DD): ");
        String orderDate = scanner.nextLine();

        try {
            String query = "INSERT INTO Order_table(order_id, product_id, supplier_id, order_date, quantity, status) VALUES(?, ?, ?, ?, ?, 'placed')";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, order_id);
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, supplierId);
            preparedStatement.setDate(4, Date.valueOf(orderDate));
            preparedStatement.setInt(5, quantity);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Order placed successfully!!");
            } else {
                System.out.println("Failed to place order!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewOrderDetails() {
        System.out.println("Enter order ID to view: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Order_table WHERE order_id = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, orderId);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println();
            System.out.println("Order details: ");
            System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            System.out.println("| Order ID | Product ID | Supplier ID | Order Date  | Quantity |  Status  |");
            System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            if (resultSet.next()) {
                int orderID = resultSet.getInt("order_id");
                int productId = resultSet.getInt("product_id");
                int supplierId = resultSet.getInt("supplier_id");
                Date orderDate = resultSet.getDate("order_date");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");
                System.out.printf("|%-10d|%-11d|%-13d|%-13s|%-10d|%-10s|\n", orderID, productId, supplierId, orderDate, quantity, status);
                System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            } else {
                System.out.println("Order not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cancelOrder() {
        System.out.println("Enter order ID to cancel: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            String query = "UPDATE Order_table SET status = 'canceled' WHERE order_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, orderId);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Order canceled successfully!!");
            } else {
                System.out.println("Failed to cancel order!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void listOrdersForProduct() {
        System.out.println("Enter product ID to list orders: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Order_table WHERE product_id = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productId);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("Order details for product ID " + productId + ": ");
            System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            System.out.println("| Order ID | Product ID | Supplier ID | Order Date  | Quantity |  Status  |");
            System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            while (resultSet.next()) {
                int orderId = resultSet.getInt("order_id");
                int supplierId = resultSet.getInt("supplier_id");
                Date orderDate = resultSet.getDate("order_date");
                int quantity = resultSet.getInt("quantity");
                String status = resultSet.getString("status");
                System.out.printf("|%-10d|%-11d|%-13d|%-13s|%-10d|%-10s|\n", orderId, productId, supplierId, orderDate, quantity, status);
                System.out.println("+----------+-----------+-------------+-------------+----------+----------+");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

