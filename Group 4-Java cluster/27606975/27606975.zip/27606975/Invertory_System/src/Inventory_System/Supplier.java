package Inventory_System;

import java.sql.*;
import java.util.Scanner;

public class Supplier {
    private Connection connection;
    private Scanner scanner;


    public Supplier(Connection connection, Scanner scanner){
        this.connection = connection;
        this.scanner = scanner;
    }


    public void addSupplier(){
        System.out.println("Enter Supplier Id: ");
        int supplier_id = scanner.nextInt();
        System.out.println("Enter supplier name: ");
        String name = scanner.nextLine();
       System.out.println("Enter contact information: ");
       String contact_information = scanner.nextLine();
        System.out.println("Enter supplier address: ");
        String address = scanner.nextLine();


        try {
            String query = "insert into Supplier_table(supplier_id,name,contact_information,address) values(?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, supplier_id);
           preparedStatement.setString(2, name);
           preparedStatement.setString(3, contact_information);
           preparedStatement.setString(4, address);
            int affectedRows = preparedStatement.executeUpdate();
            if(affectedRows > 0){
                System.out.println("Supplier added successfully!!");
            }else {
                System.out.println("Failed to add supplier!");
            }

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void viewSupplier(){
        String query = "select * from Supplier_table";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println();
            System.out.println("Supplier details: ");
            System.out.println("+------------+---------------+---------------------+---------------+");
            System.out.println("|Supplier Id| |Supplier Name| |Contact Information| |  address     | ");
            System.out.println("+------------+---------------+---------------------+---------------+");
            while(resultSet.next()){
                int supplierId = resultSet.getInt("supplier_id");
                String supplierName = resultSet.getString("name");
                String contact_information = resultSet.getString("contact_information");
                String address = resultSet.getString("address");
                System.out.printf("|%-13s|%-15s|%-21s|%-13s|\n",supplierId,supplierName,contact_information,address);
                System.out.println("+------------+--------------+----------------------+---------------+");

            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }


    public void updateSupplier() {
        System.out.println("Enter supplier ID to update: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter new supplier name: ");
        String name = scanner.nextLine();
        System.out.println("Enter new contact information: ");
        String contact_information = scanner.nextLine();
        System.out.println("Enter new supplier address: ");
        String address = scanner.nextLine();

        try {
            String query = "UPDATE Supplier_table SET name = ?, contact_information = ?, address = ? WHERE supplier_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, contact_information);
            preparedStatement.setString(3, address);
            preparedStatement.setInt(4, supplierId);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Supplier updated successfully!!");
            } else {
                System.out.println("Failed to update supplier!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSupplier() {
        System.out.println("Enter supplier ID to delete: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            String query = "DELETE FROM Supplier_table WHERE supplier_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, supplierId);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Supplier deleted successfully!!");
            } else {
                System.out.println("Failed to delete supplier!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}



