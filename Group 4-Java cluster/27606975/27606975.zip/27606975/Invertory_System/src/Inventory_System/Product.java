package Inventory_System;

import java.sql.*;
import java.util.Scanner;

public class Product {
    private Connection connection;
    private Scanner scanner;


    public Product(Connection connection, Scanner scanner){
        this.connection = connection;
        this.scanner = scanner;
    }


    public void addProduct(){
        System.out.println("Enter product id: ");
        int product_id = scanner.nextInt();
        System.out.println("Enter product name: ");
        String name = scanner.nextLine();
        System.out.println("Enter product category: ");
        String category = scanner.nextLine();
        System.out.println("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter product quantity: ");
        int quantity_in_stock = scanner.nextInt();

        try {
            String query = "insert into Product_table(product_id, name,category,price,quantity_in_stock) VALUES(?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, product_id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, category);
            preparedStatement.setDouble(4, price);
            preparedStatement.setInt(5, quantity_in_stock);
            int affectedRows = preparedStatement.executeUpdate();
            if(affectedRows > 0){
                System.out.println("Product added successfully!!");
            }else {
                System.out.println("Failed to add product!");
            }

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void viewProduct(){
        String query = "select * from Product_table";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println();
            System.out.println("Product details: ");
            System.out.println("+------------+--------------+------------------+---------------+------------------+");
            System.out.println("|Product Id| |Product Name| |Product Category| |Product Price| |Product Quantity   | ");
            System.out.println("+------------+--------------+------------------+---------------+------------------+");
            while(resultSet.next()){
                int productId = resultSet.getInt("Product_id");
                String productName = resultSet.getString("name");
                String category = resultSet.getString("category");
                double price = resultSet.getDouble("price");
                int quantity = resultSet.getInt("quantity_in_stock");
                System.out.printf("|%-12s|%-14s|%-20s|%-16s|%-16s|\n", productId, productName, category, price, quantity);
                System.out.println("+------------+--------------+------------------+---------------+------------------+");

            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }


    public void updateProduct() {
        System.out.println("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter new product name: ");
        String name = scanner.nextLine();
        System.out.println("Enter new product category: ");
        String category = scanner.nextLine();
        System.out.println("Enter new product price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter new product quantity: ");
        int quantity_in_stock = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            String query = "UPDATE Product_table SET name = ?, category = ?, price = ?, quantity_in_stock = ? WHERE Product_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, category);
            preparedStatement.setDouble(3, price);
            preparedStatement.setInt(4, quantity_in_stock);
            preparedStatement.setInt(5, productId);
            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Product updated successfully!!");
            } else {
                System.out.println("Failed to update product!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

        public void deleteProduct() {
            System.out.println("Enter product ID to delete: ");
            int productId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                String query = "DELETE FROM Product_table WHERE Product_id = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, productId);
                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Product deleted successfully!!");
                } else {
                    System.out.println("Failed to delete product!");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

}


