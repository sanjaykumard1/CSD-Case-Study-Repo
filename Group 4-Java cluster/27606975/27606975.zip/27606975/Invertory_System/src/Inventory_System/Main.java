package Inventory_System;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static final String url = "jdbc:mysql://localhost:3306/inventory_system";
    private static final String username = "root";
    private static final String password = "Priti@1125*";

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);
        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            Product productManager = new Product(connection, scanner);
            Supplier supplierManager = new Supplier(connection, scanner);
            Order orderManager = new Order(connection, scanner);

            while (true) {
                System.out.println("INVENTORY SYSTEM: ");
                System.out.println("1. Product Management");
                System.out.println("2. Supplier Management");
                System.out.println("3. Order Management");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        manageProducts(productManager);
                        break;
                    case 2:
                        manageSuppliers(supplierManager);
                        break;
                    case 3:
                        manageOrders(orderManager);
                        break;
                    case 4:
                        System.out.println("Exiting the system. Goodbye!");
                        scanner.close();
                        connection.close();
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageProducts(Product productManager) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Product Management");
            System.out.println("1. Add a new product");
            System.out.println("2. View product details");
            System.out.println("3. Update product information");
            System.out.println("4. Delete a product");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    productManager.addProduct();
                    break;
                case 2:
                    productManager.viewProduct();
                    break;
                case 3:
                    productManager.updateProduct();
                    break;
                case 4:
                    productManager.deleteProduct();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void manageSuppliers(Supplier supplierManager) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Supplier Management");
            System.out.println("1. Add a new supplier");
            System.out.println("2. View supplier details");
            System.out.println("3. Update supplier information");
            System.out.println("4. Delete a supplier");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    supplierManager.addSupplier();
                    break;
                case 2:
                    supplierManager.viewSupplier();
                    break;
                case 3:
                    supplierManager.updateSupplier();
                    break;
                case 4:
                    supplierManager.deleteSupplier();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void manageOrders(Order orderManager) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Order Management");
            System.out.println("1. Place an order for a product");
            System.out.println("2. View order details");
            System.out.println("3. Cancel an order");
            System.out.println("4. List all orders for a specific product");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    orderManager.placeOrder();
                    break;
                case 2:
                    orderManager.viewOrderDetails();
                    break;
                case 3:
                    orderManager.cancelOrder();
                    break;
                case 4:
                    orderManager.listOrdersForProduct();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}




