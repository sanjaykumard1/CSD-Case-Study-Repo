package dao;
import dbconnection.DatabaseConnection;
import models.Animal;

import java.sql.*;

public class AnimalDAO {

    public void addAnimal(Animal animal) {
        String query = "INSERT INTO Animal (name, species, age, adoption_status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, animal.getName());
                    stmt.setString(2, animal.getSpecies());
                    stmt.setInt(3, animal.getAge());
                    stmt.setString(4, animal.getAdoptionStatus());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing insert: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public Animal getAnimal(int animalId) {
        String query = "SELECT * FROM Animal WHERE animal_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, animalId);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        Animal animal = new Animal();
                        animal.setAnimalId(rs.getInt("animal_id"));
                        animal.setName(rs.getString("name"));
                        animal.setSpecies(rs.getString("species"));
                        animal.setAge(rs.getInt("age"));
                        animal.setAdoptionStatus(rs.getString("adoption_status"));
                        return animal;
                    }
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing query: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error getting animal: " + e.getMessage());
        }
        return null;
    }


    public void updateAnimal(Animal animal) {
        String query = "UPDATE Animal SET name = ?, species = ?, age = ?, adoption_status = ? WHERE animal_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, animal.getName());
                    stmt.setString(2, animal.getSpecies());
                    stmt.setInt(3, animal.getAge());
                    stmt.setString(4, animal.getAdoptionStatus());
                    stmt.setInt(5, animal.getAnimalId());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing update: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public void deleteAnimal(int animalId) {
        String query = "DELETE FROM Animal WHERE animal_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, animalId);
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing delete: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }

}
