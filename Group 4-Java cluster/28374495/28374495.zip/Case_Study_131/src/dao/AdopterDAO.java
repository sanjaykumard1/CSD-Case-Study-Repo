package dao;

import dbconnection.DatabaseConnection;
import models.Adopter;
import java.sql.*;

public class AdopterDAO {
    public void addAdopter(Adopter adopter) {
        String query = "INSERT INTO Adopter (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, adopter.getName());
                    stmt.setString(2, adopter.getEmail());
                    stmt.setString(3, adopter.getPhoneNumber());
                    stmt.setString(4, adopter.getAddress());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing insert: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public Adopter getAdopter(int adopterId) {
        String query = "SELECT * FROM Adopter WHERE adopter_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, adopterId);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        Adopter adopter = new Adopter();
                        adopter.setAdopterId(rs.getInt("adopter_id"));
                        adopter.setName(rs.getString("name"));
                        adopter.setEmail(rs.getString("email"));
                        adopter.setPhoneNumber(rs.getString("phone_number"));
                        adopter.setAddress(rs.getString("address"));
                        return adopter;
                    }
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing query: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
        return null;
    }


    public void updateAdopter(Adopter adopter) {
        String query = "UPDATE Adopter SET name = ?, email = ?, phone_number = ?, address = ? WHERE adopter_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, adopter.getName());
                    stmt.setString(2, adopter.getEmail());
                    stmt.setString(3, adopter.getPhoneNumber());
                    stmt.setString(4, adopter.getAddress());
                    stmt.setInt(5, adopter.getAdopterId());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing update: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public void deleteAdopter(int adopterId) {
        String query = "DELETE FROM Adopter WHERE adopter_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, adopterId);
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing delete: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }

}
