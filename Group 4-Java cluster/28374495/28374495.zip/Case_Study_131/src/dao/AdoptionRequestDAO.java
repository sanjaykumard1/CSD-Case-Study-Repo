package dao;
import dbconnection.DatabaseConnection;
import models.AdoptionRequest;

import java.sql.*;

public class AdoptionRequestDAO {
    public void addAdoptionRequest(AdoptionRequest request) {
        String query = "INSERT INTO AdoptionRequest (animal_id, adopter_id, request_date, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, request.getAnimalId());
                    stmt.setInt(2, request.getAdopterId());
                    stmt.setDate(3, new java.sql.Date(request.getRequestDate().getTime()));
                    stmt.setString(4, request.getStatus());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing insert: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public AdoptionRequest getAdoptionRequest(int requestId) {
        String query = "SELECT * FROM AdoptionRequest WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, requestId);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        AdoptionRequest request = new AdoptionRequest();
                        request.setRequestId(rs.getInt("request_id"));
                        request.setAnimalId(rs.getInt("animal_id"));
                        request.setAdopterId(rs.getInt("adopter_id"));
                        request.setRequestDate(rs.getDate("request_date"));
                        request.setStatus(rs.getString("status"));
                        return request;
                    }
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing query: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
        return null;
    }


    public void updateAdoptionRequest(AdoptionRequest request) {
        String query = "UPDATE AdoptionRequest SET animal_id = ?, adopter_id = ?, request_date = ?, status = ? WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, request.getAnimalId());
                    stmt.setInt(2, request.getAdopterId());
                    stmt.setDate(3, new java.sql.Date(request.getRequestDate().getTime()));
                    stmt.setString(4, request.getStatus());
                    stmt.setInt(5, request.getRequestId());
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing update: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }


    public void deleteAdoptionRequest(int requestId) {
        String query = "DELETE FROM AdoptionRequest WHERE request_id = ?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn != null) {
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setInt(1, requestId);
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    System.out.println("Error preparing statement or executing delete: " + e.getMessage());
                }
            } else {
                System.err.println("Failed to obtain database connection.");
            }
        } catch (SQLException e) {
            System.out.println("Error obtaining database connection: " + e.getMessage());
        }
    }

}
