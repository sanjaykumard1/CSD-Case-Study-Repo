
import dao.AnimalDAO;
import dao.AdopterDAO;
import dao.AdoptionRequestDAO;
import models.Animal;
import models.AdoptionRequest;
import models.Adopter;

import java.util.Scanner;

public class PetAdoptionCenter {

    private final static AnimalDAO animalDAO = new AnimalDAO();
    private final static AdopterDAO adopterDAO = new AdopterDAO();
    private final static AdoptionRequestDAO adoptionRequestDAO = new AdoptionRequestDAO();
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Pet Adoption Center Management System");
            System.out.println("1. Manage Animals");
            System.out.println("2. Manage Adopters");
            System.out.println("3. Manage Adoption Requests");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    manageAnimals(scanner);
                    break;
                case 2:
                    manageAdopters(scanner);
                    break;
                case 3:
                    manageAdoptionRequests(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageAnimals(Scanner scanner) {
        while (true) {
            System.out.println("\nAnimal Management");
            System.out.println("1. Add Animal");
            System.out.println("2. View Animal");
            System.out.println("3. Update Animal");
            System.out.println("4. Delete Animal");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    addAnimal(scanner);
                    break;
                case 2:
                    viewAnimal(scanner);
                    break;
                case 3:
                    updateAnimal(scanner);
                    break;
                case 4:
                    deleteAnimal(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addAnimal(Scanner scanner) {
        System.out.print("Enter animal name: ");
        String name = scanner.nextLine();
        System.out.print("Enter animal species: ");
        String species = scanner.nextLine();
        System.out.print("Enter animal age: ");
        int age = scanner.nextInt();
        scanner.nextLine();  // consume newline
        System.out.print("Enter adoption status: ");
        String status = scanner.nextLine();

        Animal animal = new Animal();
        animal.setName(name);
        animal.setSpecies(species);
        animal.setAge(age);
        animal.setAdoptionStatus(status);
        animalDAO.addAnimal(animal);
        System.out.println("Animal added successfully.");
    }

    private static void viewAnimal(Scanner scanner) {
        System.out.print("Enter animal ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Animal animal = animalDAO.getAnimal(id);
        if (animal != null) {
            System.out.println("Animal ID: " + animal.getAnimalId());
            System.out.println("Name: " + animal.getName());
            System.out.println("Species: " + animal.getSpecies());
            System.out.println("Age: " + animal.getAge());
            System.out.println("Adoption Status: " + animal.getAdoptionStatus());
        } else {
            System.out.println("Animal not found.");
        }
    }

    private static void updateAnimal(Scanner scanner) {
        System.out.print("Enter animal ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Animal animal = animalDAO.getAnimal(id);
        if (animal != null) {
            System.out.print("Enter new name (current: " + animal.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new species (current: " + animal.getSpecies() + "): ");
            String species = scanner.nextLine();
            System.out.print("Enter new age (current: " + animal.getAge() + "): ");
            int age = scanner.nextInt();
            scanner.nextLine();  // consume newline
            System.out.print("Enter new adoption status (current: " + animal.getAdoptionStatus() + "): ");
            String status = scanner.nextLine();

            animal.setName(name);
            animal.setSpecies(species);
            animal.setAge(age);
            animal.setAdoptionStatus(status);
            animalDAO.updateAnimal(animal);
            System.out.println("Animal updated successfully.");
        } else {
            System.out.println("Animal not found.");
        }
    }

    private static void deleteAnimal(Scanner scanner) {
        System.out.print("Enter animal ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        animalDAO.deleteAnimal(id);
        System.out.println("Animal deleted successfully.");
    }

    private static void manageAdopters(Scanner scanner) {
        while (true) {
            System.out.println("\nAdopter Management");
            System.out.println("1. Add Adopter");
            System.out.println("2. View Adopter");
            System.out.println("3. Update Adopter");
            System.out.println("4. Delete Adopter");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    addAdopter(scanner);
                    break;
                case 2:
                    viewAdopter(scanner);
                    break;
                case 3:
                    updateAdopter(scanner);
                    break;
                case 4:
                    deleteAdopter(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addAdopter(Scanner scanner) {
        System.out.print("Enter adopter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter adopter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter adopter phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter adopter address: ");
        String address = scanner.nextLine();

        Adopter adopter = new Adopter();
        adopter.setName(name);
        adopter.setEmail(email);
        adopter.setPhoneNumber(phoneNumber);
        adopter.setAddress(address);
        adopterDAO.addAdopter(adopter);
        System.out.println("Adopter added successfully.");
    }

    private static void viewAdopter(Scanner scanner) {
        System.out.print("Enter adopter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Adopter adopter = adopterDAO.getAdopter(id);
        if (adopter != null) {
            System.out.println("Adopter ID: " + adopter.getAdopterId());
            System.out.println("Name: " + adopter.getName());
            System.out.println("Email: " + adopter.getEmail());
            System.out.println("Phone Number: " + adopter.getPhoneNumber());
            System.out.println("Address: " + adopter.getAddress());
        } else {
            System.out.println("Adopter not found.");
        }
    }

    private static void updateAdopter(Scanner scanner) {
        System.out.print("Enter adopter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        Adopter adopter = adopterDAO.getAdopter(id);
        if (adopter != null) {
            System.out.print("Enter new name (current: " + adopter.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new email (current: " + adopter.getEmail() + "): ");
            String email = scanner.nextLine();
            System.out.print("Enter new phone number (current: " + adopter.getPhoneNumber() + "): ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new address (current: " + adopter.getAddress() + "): ");
            String address = scanner.nextLine();

            adopter.setName(name);
            adopter.setEmail(email);
            adopter.setPhoneNumber(phoneNumber);
            adopter.setAddress(address);
            adopterDAO.updateAdopter(adopter);
            System.out.println("Adopter updated successfully.");
        } else {
            System.out.println("Adopter not found.");
        }
    }

    private static void deleteAdopter(Scanner scanner) {
        System.out.print("Enter adopter ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // consume newline
        adopterDAO.deleteAdopter(id);
        System.out.println("Adopter deleted successfully.");
    }

    private static void manageAdoptionRequests(Scanner scanner) {
        while (true) {
            System.out.println("\nAdoption Request Management");
            System.out.println("1. Add Adoption Request");
            System.out.println("2. View Adoption Request");
            System.out.println("3. Update Adoption Request");
            System.out.println("4. Delete Adoption Request");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // consume newline

            switch (choice) {
                case 1:
                    addAdoptionRequest(scanner);
                    break;
                case 2:
                    viewAdoptionRequest(scanner);
                    break;
                case 3:
                    updateAdoptionRequest(scanner);
                    break;
                case 4:
                    deleteAdoptionRequest(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addAdoptionRequest(Scanner scanner) {
        System.out.print("Enter animal ID: ");
        int animalId = scanner.nextInt();
        System.out.print("Enter adopter ID: ");
        int adopterId = scanner.nextInt();
        scanner.nextLine();  // consume newline
        System.out.print("Enter request date (YYYY-MM-DD): ");
        String requestDateStr = scanner.nextLine();
        System.out.print("Enter status: ");
        String status = scanner.nextLine();

        AdoptionRequest request = new AdoptionRequest();
        request.setAnimalId(animalId);
        request.setAdopterId(adopterId);
        request.setRequestDate(java.sql.Date.valueOf(requestDateStr));
        request.setStatus(status);
        adoptionRequestDAO.addAdoptionRequest(request);
        System.out.println("Adoption request added successfully.");
    }

    private static void viewAdoptionRequest(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();  // consume newline
        AdoptionRequest request = adoptionRequestDAO.getAdoptionRequest(requestId);
        if (request != null) {
            System.out.println("Request ID: " + request.getRequestId());
            System.out.println("Animal ID: " + request.getAnimalId());
            System.out.println("Adopter ID: " + request.getAdopterId());
            System.out.println("Request Date: " + request.getRequestDate());
            System.out.println("Status: " + request.getStatus());
        } else {
            System.out.println("Adoption request not found.");
        }
    }

    private static void updateAdoptionRequest(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();  // consume newline
        AdoptionRequest request = adoptionRequestDAO.getAdoptionRequest(requestId);
        if (request != null) {
            System.out.print("Enter new animal ID (current: " + request.getAnimalId() + "): ");
            int animalId = scanner.nextInt();
            System.out.print("Enter new adopter ID (current: " + request.getAdopterId() + "): ");
            int adopterId = scanner.nextInt();
            scanner.nextLine();  // consume newline
            System.out.print("Enter new request date (current: " + request.getRequestDate() + " YYYY-MM-DD): ");
            String requestDateStr = scanner.nextLine();
            System.out.print("Enter new status (current: " + request.getStatus() + "): ");
            String status = scanner.nextLine();

            request.setAnimalId(animalId);
            request.setAdopterId(adopterId);
            request.setRequestDate(java.sql.Date.valueOf(requestDateStr));
            request.setStatus(status);
            adoptionRequestDAO.updateAdoptionRequest(request);
            System.out.println("Adoption request updated successfully.");
        } else {
            System.out.println("Adoption request not found.");
        }
    }

    private static void deleteAdoptionRequest(Scanner scanner) {
        System.out.print("Enter request ID: ");
        int requestId = scanner.nextInt();
        scanner.nextLine();  // consume newline
        adoptionRequestDAO.deleteAdoptionRequest(requestId);
        System.out.println("Adoption request deleted successfully.");
    }
}

