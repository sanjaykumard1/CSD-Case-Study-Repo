import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws Exception {

        String URL = "jdbc:mysql://localhost:3306/PetAdoptionCenter";
        String USER = "root";
        String PASSWORD = "@Anurag123";
        String sql = "select name from animal";

        Connection con = DriverManager.getConnection(URL,USER,PASSWORD);
        Statement st = con.createStatement();
        ResultSet rs= st.executeQuery(sql);
        rs.next();
        String name = rs.getString(1);
        System.out.println(name);
    }
}