# Pet Adoption Center Management System

## Overview
The Pet Adoption Center Management System is a menu-based console application developed using Core Java, MySQL, and JDBC. The application simulates a pet adoption center management system, allowing users to manage animals, potential adopters, and adoption requests.

## Features
1. **Animal Management**
    - Add a new animal
    - View animal details
    - Update animal information
    - Delete an animal

2. **Adopter Management**
    - Register a new potential adopter
    - View adopter details
    - Update adopter information
    - Delete an adopter

3. **Adoption Request Management**
    - Submit a new adoption request
    - View adoption request details
    - Update request status
    - Cancel an adoption request

## Database Schema
### Animal Table
| Column Name      | Data Type      | Constraints       |
|------------------|----------------|-------------------|
| animal_id        | INT            | PRIMARY KEY       |
| name             | VARCHAR(50)    |                   |
| species          | VARCHAR(50)    |                   |
| age              | INT            |                   |
| adoption_status  | VARCHAR(20)    |                   |

### Adopter Table
| Column Name      | Data Type      | Constraints       |
|------------------|----------------|-------------------|
| adopter_id       | INT            | PRIMARY KEY       |
| name             | VARCHAR(50)    |                   |
| email            | VARCHAR(50)    |                   |
| phone_number     | VARCHAR(15)    |                   |
| address          | VARCHAR(100)   |                   |

### Adoption Request Table
| Column Name      | Data Type      | Constraints       |
|------------------|----------------|-------------------|
| request_id       | INT            | PRIMARY KEY       |
| animal_id        | INT            | FOREIGN KEY       |
| adopter_id       | INT            | FOREIGN KEY       |
| request_date     | DATE           |                   |
| status           | VARCHAR(20)    |                   |

## Prerequisites
- Java Development Kit (JDK) 8 or higher
- MySQL Database
- JDBC Driver for MySQL

## Setup
1. **Clone the repository:**
    ```bash
    git clone https://github.com/yourusername/pet-adoption-center.git
    cd pet-adoption-center
    ```

2. **Create the MySQL database and tables:**
    ```sql
    CREATE DATABASE pet_adoption_center;
    USE pet_adoption_center;

    CREATE TABLE Animal (
        animal_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50),
        species VARCHAR(50),
        age INT,
        adoption_status VARCHAR(20)
    );

    CREATE TABLE Adopter (
        adopter_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50),
        email VARCHAR(50),
        phone_number VARCHAR(15),
        address VARCHAR(100)
    );

    CREATE TABLE AdoptionRequest (
        request_id INT AUTO_INCREMENT PRIMARY KEY,
        animal_id INT,
        adopter_id INT,
        request_date DATE,
        status VARCHAR(20),
        FOREIGN KEY (animal_id) REFERENCES Animal(animal_id) ON DELETE CASCADE,
        FOREIGN KEY (adopter_id) REFERENCES Adopter(adopter_id) ON DELETE CASCADE
    );
    ```

3. **Add some dummy data:**
    ```sql
    INSERT INTO Animal (name, species, age, adoption_status) VALUES
    ('Max', 'Dog', 3, 'Available'),
    ('Bella', 'Cat', 2, 'Available'),
    ('Charlie', 'Rabbit', 1, 'Adopted');

    INSERT INTO Adopter (name, email, phone_number, address) VALUES
    ('John Doe', 'john@example.com', '1234567890', '123 Elm Street'),
    ('Jane Smith', 'jane@example.com', '0987654321', '456 Oak Avenue');

    INSERT INTO AdoptionRequest (animal_id, adopter_id, request_date, status) VALUES
    (1, 1, '2023-07-10', 'Submitted'),
    (2, 2, '2023-07-11', 'Approved');
    ```

4. **Update the database connection in `DatabaseConnection.java`:**
    ```java
    public class DatabaseConnection {
        private static final String URL = "jdbc:mysql://localhost:3306/pet_adoption_center";
        private static final String USER = "root";  // Update with your MySQL username
        private static final String PASSWORD = "password";  // Update with your MySQL password

        public static Connection getConnection() {
            try {
                return DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Failed to connect to the database", e);
            }
        }
    }
    ```

5. **Compile and run the application:**
    ```bash
    javac -d bin src/*.java
    java -cp bin:lib/mysql-connector-java-8.0.26.jar Main
    ```

## Usage
Follow the on-screen prompts to manage animals, adopters, and adoption requests. You can add, view, update, and delete records as needed.


