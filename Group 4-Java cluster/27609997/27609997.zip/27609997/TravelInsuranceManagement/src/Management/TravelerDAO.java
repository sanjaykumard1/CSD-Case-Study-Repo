package Management;
import java.sql.*;
public class TravelerDAO 
{
	public void addTraveler(Traveler traveler) throws SQLException 
	{
        String query = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, traveler.getName());
            preparedStatement.setString(2, traveler.getEmail());
            preparedStatement.setString(3, traveler.getPhone_number());
            preparedStatement.setString(4, traveler.getAddress());
            preparedStatement.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }

    public Traveler getTraveler(int traveler_id) throws SQLException {
        String query = "SELECT * FROM Traveler WHERE traveler_id = ?";
        try  
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, traveler_id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                Traveler traveler = new Traveler();
                traveler.setTraveler_id(resultSet.getInt("traveler_id"));
                traveler.setName(resultSet.getString("name"));
                traveler.setEmail(resultSet.getString("email"));
                traveler.setPhone_number(resultSet.getString("phone_number"));
                traveler.setAddress(resultSet.getString("address"));
                return traveler;
            }
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
        return null;
    }

    public void updateTraveler(Traveler traveler) throws SQLException {
        String query = "UPDATE Traveler SET name = ?, email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, traveler.getName());
            preparedStatement.setString(2, traveler.getEmail());
            preparedStatement.setString(3, traveler.getPhone_number());
            preparedStatement.setString(4, traveler.getAddress());
            preparedStatement.setInt(5, traveler.getTraveler_id());
            preparedStatement.executeUpdate();
            
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }

    public void deleteTraveler(int traveler_id) throws SQLException {
        String query = "DELETE FROM Traveler WHERE traveler_id = ?";
        try 
        {
        	Connection connection = DbConnection.getConnection(); 
        	PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, traveler_id);
            preparedStatement.executeUpdate();
        }
        catch(Exception e)
        {
        	System.out.println("connection failed");
        }
    }

}
