import java.sql.*;
import java.util.Date;

public class MatchManager {
    public void scheduleMatch(int team1Id, int team2Id, Date matchDate, String venue) {
        String sql = "INSERT INTO Match (team1_id, team2_id, match_date, venue) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, team1Id);
            statement.setInt(2, team2Id);
            statement.setDate(3, new java.sql.Date(matchDate.getTime()));
            statement.setString(4, venue);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewMatch(int matchId) {
        String sql = "SELECT * FROM Match WHERE match_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, matchId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Match ID: " + resultSet.getInt("match_id"));
                System.out.println("Team 1 ID: " + resultSet.getInt("team1_id"));
                System.out.println("Team 2 ID: " + resultSet.getInt("team2_id"));
                System.out.println("Match Date: " + resultSet.getDate("match_date"));
                System.out.println("Venue: " + resultSet.getString("venue"));
                System.out.println("Result: " + resultSet.getString("result"));
            } else {
                System.out.println("Match not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMatch(int matchId, int team1Id, int team2Id, Date matchDate, String venue, String result) {
        String sql = "UPDATE Match SET team1_id = ?, team2_id = ?, match_date = ?, venue = ?, result = ? WHERE match_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, team1Id);
            statement.setInt(2, team2Id);
            statement.setDate(3, new java.sql.Date(matchDate.getTime()));
            statement.setString(4, venue);
            statement.setString(5, result);
            statement.setInt(6, matchId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void recordMatchResult(int matchId, String result) {
        String sql = "UPDATE Match SET result = ? WHERE match_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, result);
            statement.setInt(2, matchId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
