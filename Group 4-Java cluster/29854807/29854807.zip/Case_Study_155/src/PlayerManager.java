import java.sql.*;

public class PlayerManager {
    public void addPlayer(String name, int age, int teamId, String position) {
        String sql = "INSERT INTO Player (name, age, team_id, position) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setInt(3, teamId);
            statement.setString(4, position);
            statement.executeUpdate();
            updateTotalPlayers(teamId, 1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPlayer(int playerId) {
        String sql = "SELECT * FROM Player WHERE player_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, playerId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Player ID: " + resultSet.getInt("player_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Age: " + resultSet.getInt("age"));
                System.out.println("Team ID: " + resultSet.getInt("team_id"));
                System.out.println("Position: " + resultSet.getString("position"));
            } else {
                System.out.println("Player not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePlayer(int playerId, String name, int age, int teamId, String position) {
        String sql = "UPDATE Player SET name = ?, age = ?, team_id = ?, position = ? WHERE player_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setInt(2, age);
            statement.setInt(3, teamId);
            statement.setString(4, position);
            statement.setInt(5, playerId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePlayer(int playerId) {
        int teamId = getTeamId(playerId);
        if (teamId != -1) {
            String sql = "DELETE FROM Player WHERE player_id = ?";
            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, playerId);
                statement.executeUpdate();
                updateTotalPlayers(teamId, -1);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private int getTeamId(int playerId) {
        String sql = "SELECT team_id FROM Player WHERE player_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, playerId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("team_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private void updateTotalPlayers(int teamId, int change) {
        String sql = "UPDATE Team SET total_players = total_players + ? WHERE team_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, change);
            statement.setInt(2, teamId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
