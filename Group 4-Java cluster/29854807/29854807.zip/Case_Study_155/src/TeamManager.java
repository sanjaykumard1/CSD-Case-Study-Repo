import java.sql.*;

public class TeamManager {
    public void addTeam(String name, String coach, String captain, int totalPlayers) {
        String sql = "INSERT INTO Team (name, coach, captain, total_players) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, coach);
            statement.setString(3, captain);
            statement.setInt(4, totalPlayers);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewTeam(int teamId) {
        String sql = "SELECT * FROM Team WHERE team_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, teamId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Team ID: " + resultSet.getInt("team_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Coach: " + resultSet.getString("coach"));
                System.out.println("Captain: " + resultSet.getString("captain"));
                System.out.println("Total Players: " + resultSet.getInt("total_players"));
            } else {
                System.out.println("Team not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTeam(int teamId, String name, String coach, String captain, int totalPlayers) {
        String sql = "UPDATE Team SET name = ?, coach = ?, captain = ?, total_players = ? WHERE team_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, coach);
            statement.setString(3, captain);
            statement.setInt(4, totalPlayers);
            statement.setInt(5, teamId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteTeam(int teamId) {
        String sql = "DELETE FROM Team WHERE team_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, teamId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
