import java.util.Scanner;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TeamManager teamManager = new TeamManager();
        PlayerManager playerManager = new PlayerManager();
        MatchManager matchManager = new MatchManager();

        while (true) {
            System.out.println("Sports Tournament Management System");
            System.out.println("1. Manage Teams");
            System.out.println("2. Manage Players");
            System.out.println("3. Manage Matches");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageTeams(scanner, teamManager);
                    break;
                case 2:
                    managePlayers(scanner, playerManager);
                    break;
                case 3:
                    manageMatches(scanner, matchManager);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageTeams(Scanner scanner, TeamManager teamManager) {
        System.out.println("Team Management");
        System.out.println("1. Add Team");
        System.out.println("2. View Team");
        System.out.println("3. Update Team");
        System.out.println("4. Delete Team");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter team name: ");
                String name = scanner.nextLine();
                System.out.print("Enter coach name: ");
                String coach = scanner.nextLine();
                System.out.print("Enter captain name: ");
                String captain = scanner.nextLine();
                System.out.print("Enter total players: ");
                int totalPlayers = scanner.nextInt();
                teamManager.addTeam(name, coach, captain, totalPlayers);
                break;
            case 2:
                System.out.print("Enter team ID: ");
                int teamId = scanner.nextInt();
                teamManager.viewTeam(teamId);
                break;
            case 3:
                System.out.print("Enter team ID: ");
                teamId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter team name: ");
                name = scanner.nextLine();
                System.out.print("Enter coach name: ");
                coach = scanner.nextLine();
                System.out.print("Enter captain name: ");
                captain = scanner.nextLine();
                System.out.print("Enter total players: ");
                totalPlayers = scanner.nextInt();
                teamManager.updateTeam(teamId, name, coach, captain, totalPlayers);
                break;
            case 4:
                System.out.print("Enter team ID: ");
                teamId = scanner.nextInt();
                teamManager.deleteTeam(teamId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void managePlayers(Scanner scanner, PlayerManager playerManager) {
        System.out.println("Player Management");
        System.out.println("1. Add Player");
        System.out.println("2. View Player");
        System.out.println("3. Update Player");
        System.out.println("4. Delete Player");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter player name: ");
                String name = scanner.nextLine();
                System.out.print("Enter age: ");
                int age = scanner.nextInt();
                System.out.print("Enter team ID: ");
                int teamId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter position: ");
                String position = scanner.nextLine();
                playerManager.addPlayer(name, age, teamId, position);
                break;
            case 2:
                System.out.print("Enter player ID: ");
                int playerId = scanner.nextInt();
                playerManager.viewPlayer(playerId);
                break;
            case 3:
                System.out.print("Enter player ID: ");
                playerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter player name: ");
                name = scanner.nextLine();
                System.out.print("Enter age: ");
                age = scanner.nextInt();
                System.out.print("Enter team ID: ");
                teamId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter position: ");
                position = scanner.nextLine();
                playerManager.updatePlayer(playerId, name, age, teamId, position);
                break;
            case 4:
                System.out.print("Enter player ID: ");
                playerId = scanner.nextInt();
                playerManager.deletePlayer(playerId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void manageMatches(Scanner scanner, MatchManager matchManager) {
        System.out.println("Match Management");
        System.out.println("1. Schedule Match");
        System.out.println("2. View Match");
        System.out.println("3. Update Match");
        System.out.println("4. Record Match Result");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter team 1 ID: ");
                int team1Id = scanner.nextInt();
                System.out.print("Enter team 2 ID: ");
                int team2Id = scanner.nextInt();
                System.out.print("Enter match date (yyyy-mm-dd): ");
                String matchDateStr = scanner.next();
                Date matchDate = java.sql.Date.valueOf(matchDateStr);
                scanner.nextLine();  // Consume newline
                System.out.print("Enter venue: ");
                String venue = scanner.nextLine();
                matchManager.scheduleMatch(team1Id, team2Id, matchDate, venue);
                break;
            case 2:
                System.out.print("Enter match ID: ");
                int matchId = scanner.nextInt();
                matchManager.viewMatch(matchId);
                break;
            case 3:
                System.out.print("Enter match ID: ");
                matchId = scanner.nextInt();
                System.out.print("Enter team 1 ID: ");
                team1Id = scanner.nextInt();
                System.out.print("Enter team 2 ID: ");
                team2Id = scanner.nextInt();
                System.out.print("Enter match date (yyyy-mm-dd): ");
                matchDateStr = scanner.next();
                matchDate = java.sql.Date.valueOf(matchDateStr);
                scanner.nextLine();  // Consume newline
                System.out.print("Enter venue: ");
                venue = scanner.nextLine();
                System.out.print("Enter result: ");
                String result = scanner.nextLine();
                matchManager.updateMatch(matchId, team1Id, team2Id, matchDate, venue, result);
                break;
            case 4:
                System.out.print("Enter match ID: ");
                matchId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter result: ");
                result = scanner.nextLine();
                matchManager.recordMatchResult(matchId, result);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
