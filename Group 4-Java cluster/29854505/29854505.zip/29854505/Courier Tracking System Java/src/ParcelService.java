import java.util.List;

public class ParcelService {
    private final ParcelDAO parcelDAO = new ParcelDAO();

    public void createParcel(Parcel parcel) {
        parcelDAO.createParcel(parcel);
    }

    public Parcel getParcelByTrackingNumber(String trackingNumber) {
        return parcelDAO.getParcelByTrackingNumber(trackingNumber);
    }

    public void updateParcelStatus(String trackingNumber, String status, String deliveryHistory) {
        parcelDAO.updateParcelStatus(trackingNumber, status, deliveryHistory);
    }

    public void deleteParcel(String trackingNumber) {
        parcelDAO.deleteParcel(trackingNumber);
    }

    public List<Parcel> getAllParcels() {
        return parcelDAO.getAllParcels();
    }

    public int calculateEstimatedDeliveryTime(String trackingNumber) {
        return parcelDAO.calculateEstimatedDeliveryTime(trackingNumber);
    }
}
