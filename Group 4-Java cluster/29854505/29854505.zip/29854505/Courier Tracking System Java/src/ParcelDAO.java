import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Data access objects
public class ParcelDAO {

    // Create a new parcel
    public void createParcel(Parcel parcel) {
        String query = "INSERT INTO Parcel (tracking_number, sender_name, sender_address, recipient_name, recipient_address, current_status, delivery_history) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, parcel.getTrackingNumber());
            stmt.setString(2, parcel.getSenderName());
            stmt.setString(3, parcel.getSenderAddress());
            stmt.setString(4, parcel.getRecipientName());
            stmt.setString(5, parcel.getRecipientAddress());
            stmt.setString(6, parcel.getCurrentStatus());
            stmt.setString(7, parcel.getDeliveryHistory());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read parcel by tracking number
    public Parcel getParcelByTrackingNumber(String trackingNumber) {
        Parcel parcel = null;
        String query = "SELECT * FROM Parcel WHERE tracking_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, trackingNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                parcel = new Parcel();
                parcel.setParcelId(rs.getInt("parcel_id"));
                parcel.setTrackingNumber(rs.getString("tracking_number"));
                parcel.setSenderName(rs.getString("sender_name"));
                parcel.setSenderAddress(rs.getString("sender_address"));
                parcel.setRecipientName(rs.getString("recipient_name"));
                parcel.setRecipientAddress(rs.getString("recipient_address"));
                parcel.setCurrentStatus(rs.getString("current_status"));
                parcel.setDeliveryHistory(rs.getString("delivery_history"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return parcel;
    }

    // Update parcel status
    public void updateParcelStatus(String trackingNumber, String status, String deliveryHistory) {
        String query = "UPDATE Parcel SET current_status = ?, delivery_history = ? WHERE tracking_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, status);
            stmt.setString(2, deliveryHistory);
            stmt.setString(3, trackingNumber);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete parcel by tracking number
    public void deleteParcel(String trackingNumber) {
        String query = "DELETE FROM Parcel WHERE tracking_number = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, trackingNumber);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // List all parcels
    public List<Parcel> getAllParcels() {
        List<Parcel> parcels = new ArrayList<>();
        String query = "SELECT * FROM Parcel";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Parcel parcel = new Parcel();
                parcel.setParcelId(rs.getInt("parcel_id"));
                parcel.setTrackingNumber(rs.getString("tracking_number"));
                parcel.setSenderName(rs.getString("sender_name"));
                parcel.setSenderAddress(rs.getString("sender_address"));
                parcel.setRecipientName(rs.getString("recipient_name"));
                parcel.setRecipientAddress(rs.getString("recipient_address"));
                parcel.setCurrentStatus(rs.getString("current_status"));
                parcel.setDeliveryHistory(rs.getString("delivery_history"));
                parcels.add(parcel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return parcels;
    }

    // Calculate estimated delivery time
    public int calculateEstimatedDeliveryTime(String trackingNumber) {
        int estimatedDays = 0;
        Parcel parcel = getParcelByTrackingNumber(trackingNumber);

        if (parcel != null) {
            // Dummy calculation based on distance left and assumed speed
            int distanceLeft = parcel.getDistanceLeft();
            int speed = 50; // Assuming 50 km per day

            if (speed > 0) {
                estimatedDays = distanceLeft / speed;
            }
        } else {
            System.out.println("Parcel not found with tracking number: " + trackingNumber);
        }

        return estimatedDays;
    }

}
