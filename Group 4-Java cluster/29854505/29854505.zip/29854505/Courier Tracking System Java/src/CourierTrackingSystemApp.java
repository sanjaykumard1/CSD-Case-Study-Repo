import java.util.List;
import java.util.Scanner;

public class CourierTrackingSystemApp {
    private static final ParcelService parcelService = new ParcelService();
    private static final CustomerService customerService = new CustomerService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Courier Tracking System Menu:");
            System.out.println("1. Parcel Tracking");
            System.out.println("2. Delivery Status Management");
            System.out.println("3. Customer Information Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    parcelTrackingMenu(scanner);
                    break;
                case 2:
                    deliveryStatusManagementMenu(scanner);
                    break;
                case 3:
                    customerInformationManagementMenu(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void parcelTrackingMenu(Scanner scanner) {
        System.out.println("Parcel Tracking Menu:");
        System.out.println("1. Track Parcel");
        System.out.println("2. View All Parcels");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter tracking number: ");
                String trackingNumber = scanner.nextLine();
                Parcel parcel = parcelService.getParcelByTrackingNumber(trackingNumber);
                if (parcel != null) {
                    System.out.println("Parcel Details:");
                    System.out.println(parcel);
                } else {
                    System.out.println("Parcel not found.");
                }
                break;
            case 2:
                System.out.println("All Parcels:");
                List<Parcel> parcels = parcelService.getAllParcels();
                if (!parcels.isEmpty()) {
                    for (Parcel p : parcels) {
                        System.out.println(p);
                    }
                } else {
                    System.out.println("No parcels found.");
                }
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void deliveryStatusManagementMenu(Scanner scanner) {
        System.out.println("Delivery Status Management Menu:");
        System.out.println("1. Update Parcel Status");
        System.out.println("2. Calculate Estimated Delivery Time");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter tracking number: ");
                String trackingNumber = scanner.nextLine();
                System.out.print("Enter new status: ");
                String status = scanner.nextLine();
                System.out.print("Enter delivery history: ");
                String deliveryHistory = scanner.nextLine();
                parcelService.updateParcelStatus(trackingNumber, status, deliveryHistory);
                break;
            case 2:
                System.out.print("Enter tracking number: ");
                String trackingNum = scanner.nextLine();
                int days = parcelService.calculateEstimatedDeliveryTime(trackingNum);
                System.out.println("Estimated delivery time: " + days + " days.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void customerInformationManagementMenu(Scanner scanner) {
        System.out.println("Customer Information Management Menu:");
        System.out.println("1. Register New Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete Customer Account");
        System.out.println("5. View All Customers");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter customer name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phone = scanner.nextLine();
                Customer customer = new Customer(name, email, phone);
                customerService.registerCustomer(customer);
                break;
            case 2:
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine();
                Customer cust = customerService.getCustomerById(customerId);
                if (cust != null) {
                    System.out.println("Customer Details:");
                    System.out.println(cust);
                } else {
                    System.out.println("Customer not found.");
                }
                break;
            case 3:
                System.out.print("Enter customer ID: ");
                int custId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new customer name: ");
                String newName = scanner.nextLine();
                System.out.print("Enter new email: ");
                String newEmail = scanner.nextLine();
                System.out.print("Enter new phone number: ");
                String newPhone = scanner.nextLine();
                Customer updatedCustomer = new Customer(custId, newName, newEmail, newPhone);
                customerService.updateCustomer(updatedCustomer);
                break;
            case 4:
                System.out.print("Enter customer ID: ");
                int delCustomerId = scanner.nextInt();
                scanner.nextLine();
                customerService.deleteCustomer(delCustomerId);
                break;
            case 5:
                System.out.println("All Customers:");
                List<Customer> customers = customerService.getAllCustomers();
                if (!customers.isEmpty()) {
                    for (Customer c : customers) {
                        System.out.println(c);
                    }
                } else {
                    System.out.println("No customers found.");
                }
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
