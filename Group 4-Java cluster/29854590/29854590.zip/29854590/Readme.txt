Gym Management System

Objective:

The Gym Management System is a console-based application that allows users to manage gym members, trainers, and class schedules efficiently. The application provides functionalities for adding, viewing, updating, and deleting members, trainers, and class schedules.

Software and Installations Required for the Project:

1. Java Development Kit (JDK)
2. MySQL Server
3. MySQL Connector/J
4. Integrated Development Environment (IDE)

Steps:

1. Create the MySQL Database and Tables:

CREATE DATABASE gymmanagement;

USE gymmanagement;

CREATE TABLE member (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_number VARCHAR(15),
    email VARCHAR(255),
    membership_type VARCHAR(50)
);

CREATE TABLE trainer (
    trainer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    contact_number VARCHAR(15),
    email VARCHAR(255),
    speciality VARCHAR(255)
);

CREATE TABLE classschedule (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(255) NOT NULL,
    trainer_id INT,
    day_of_week VARCHAR(50),
    start_time TIME,
    end_time TIME,
    FOREIGN KEY (trainer_id) REFERENCES trainer(trainer_id)
);

2. Configure the Database Connection:
Update the database connection details in GymManagementSystem.java:

String jdbcURL = "jdbc:mysql://localhost:3306/GymManagement";
String username = "root";
String password = "Root@123";

3. Add MySQL Connector/J to the Project:

For Eclipse:

Right-click on the project.
Go to Build Path -> Configure Build Path.
Click on Libraries and then Add External JARs.
Select the MySQL Connector/J JAR file.


4. Database Schema
The database consists of three tables: member, trainer, and classschedule.

Member Table:
Column	             Type	     Constraints
member_id	      INT	     PRIMARY KEY
name	          VARCHAR(255)	      NOT NULL
contact_number	  VARCHAR(15)	
email	          VARCHAR(255)	
membership_type	  VARCHAR(50)	

Trainer Table:
Column	             Type	     Constraints
trainer_id	      INT	     PRIMARY KEY
name	          VARCHAR(255)	      NOT NULL
contact_number	  VARCHAR(15)	
email	          VARCHAR(255)	
speciality	  VARCHAR(255)	

Class Schedule Table:

Column	             Type	     Constraints
schedule_id	      INT	     PRIMARY KEY
class_name	  VARCHAR(255)	      NOT NULL
trainer_id	      INT	     FOREIGN KEY
day_of_week	  VARCHAR(50)	
start_time	     TIME	
end_time	     TIME	

Execution of the Project:

Steps to Run the Application:

1. Compile the Java Code: Open your IDE and import the project. Ensure that the MySQL Connector/J is added to your project libraries.
2. Run the Main Class: Execute the GymManagementSystem class to start the console-based application.

Using the Application:

Menu Navigation:

Follow the prompts to navigate through the menu options to manage members, trainers, and class schedules.

Sample Workflow:

Register a new member.
Add a new trainer.
Create a class schedule.
View member and trainer details.
Update or delete member, trainer, or class schedule information as needed.
Error Handling:

The application handles exceptions gracefully and provides user-friendly error messages.