package Gym;

import java.sql.*;
import java.util.Scanner;

public class GymManagementSystem {
    
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/GymManagement";
        String username = "root";
        String password = "Root@123";

        try (Connection connection = DriverManager.getConnection(jdbcURL, username, password)) {
            System.out.println("Connected to the database successfully!");

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Gym Management System");
                System.out.println("1. Register New Member");
                System.out.println("2. View Member Details");
                System.out.println("3. Update Member Information");
                System.out.println("4. Delete Member");
                System.out.println("5. Add New Trainer");
                System.out.println("6. View Trainer Details");
                System.out.println("7. Update Trainer Information");
                System.out.println("8. Delete Trainer");
                System.out.println("9. Create Class Schedule");
                System.out.println("10. View Class Schedules");
                System.out.println("11. Update Class Schedule");
                System.out.println("12. Cancel Class");
                System.out.println("0. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        registerMember(connection, scanner);
                        break;
                    case 2:
                        viewMemberDetails(connection, scanner);
                        break;
                    case 3:
                        updateMember(connection, scanner);
                        break;
                    case 4:
                        deleteMember(connection, scanner);
                        break;
                    case 5:
                        addTrainer(connection, scanner);
                        break;
                    case 6:
                        viewTrainerDetails(connection, scanner);
                        break;
                    case 7:
                        updateTrainer(connection, scanner);
                        break;
                    case 8:
                        deleteTrainer(connection, scanner);
                        break;
                    case 9:
                        createClassSchedule(connection, scanner);
                        break;
                    case 10:
                        viewClassSchedules(connection);
                        break;
                    case 11:
                        updateClassSchedule(connection, scanner);
                        break;
                    case 12:
                        cancelClass(connection, scanner);
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error connecting to the database");
            e.printStackTrace();
        }
    }

    // Member Management
    public static void registerMember(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter membership type: ");
        String membershipType = scanner.nextLine();

        String sql = "INSERT INTO Member (name, contact_number, email, membership_type) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, contactNumber);
            statement.setString(3, email);
            statement.setString(4, membershipType);
            statement.executeUpdate();
            System.out.println("Member registered successfully.");
        }
    }

    public static void viewMemberDetails(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();

        String sql = "SELECT * FROM Member WHERE member_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, memberId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    System.out.println("ID: " + resultSet.getInt("member_id"));
                    System.out.println("Name: " + resultSet.getString("name"));
                    System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                    System.out.println("Email: " + resultSet.getString("email"));
                    System.out.println("Membership Type: " + resultSet.getString("membership_type"));
                } else {
                    System.out.println("Member not found.");
                }
            }
        }
    }

    public static void updateMember(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new membership type: ");
        String membershipType = scanner.nextLine();

        String sql = "UPDATE Member SET name = ?, contact_number = ?, email = ?, membership_type = ? WHERE member_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, contactNumber);
            statement.setString(3, email);
            statement.setString(4, membershipType);
            statement.setInt(5, memberId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Member information updated successfully.");
            } else {
                System.out.println("Member not found.");
            }
        }
    }

    public static void deleteMember(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();

        String sql = "DELETE FROM Member WHERE member_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, memberId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Member deleted successfully.");
            } else {
                System.out.println("Member not found.");
            }
        }
    }

    // Trainer Management
    public static void addTrainer(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter speciality: ");
        String speciality = scanner.nextLine();

        String sql = "INSERT INTO Trainer (name, contact_number, email, speciality) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, contactNumber);
            statement.setString(3, email);
            statement.setString(4, speciality);
            statement.executeUpdate();
            System.out.println("Trainer added successfully.");
        }
    }

    public static void viewTrainerDetails(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter trainer ID: ");
        int trainerId = scanner.nextInt();

        String sql = "SELECT * FROM Trainer WHERE trainer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, trainerId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    System.out.println("ID: " + resultSet.getInt("trainer_id"));
                    System.out.println("Name: " + resultSet.getString("name"));
                    System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                    System.out.println("Email: " + resultSet.getString("email"));
                    System.out.println("Speciality: " + resultSet.getString("speciality"));
                } else {
                    System.out.println("Trainer not found.");
                }
            }
        }
    }

    public static void updateTrainer(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter trainer ID: ");
        int trainerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new speciality: ");
        String speciality = scanner.nextLine();

        String sql = "UPDATE Trainer SET name = ?, contact_number = ?, email = ?, speciality = ? WHERE trainer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, name);
            statement.setString(2, contactNumber);
            statement.setString(3, email);
            statement.setString(4, speciality);
            statement.setInt(5, trainerId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Trainer information updated successfully.");
            } else {
                System.out.println("Trainer not found.");
            }
        }
    }

    public static void deleteTrainer(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter trainer ID: ");
        int trainerId = scanner.nextInt();

        String sql = "DELETE FROM Trainer WHERE trainer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, trainerId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Trainer deleted successfully.");
            } else {
                System.out.println("Trainer not found.");
            }
        }
    }

    // Class Schedule Management
    public static void createClassSchedule(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter class name: ");
        String className = scanner.nextLine();
        System.out.print("Enter trainer ID: ");
        int trainerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter day of week: ");
        String dayOfWeek = scanner.nextLine();
        System.out.print("Enter start time (HH:MM:SS): ");
        String startTime = scanner.nextLine();
        System.out.print("Enter end time (HH:MM:SS): ");
        String endTime = scanner.nextLine();

        String sql = "INSERT INTO ClassSchedule (class_name, trainer_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, className);
            statement.setInt(2, trainerId);
            statement.setString(3, dayOfWeek);
            statement.setString(4, startTime);
            statement.setString(5, endTime);
            statement.executeUpdate();
            System.out.println("Class schedule created successfully.");
        }
    }

    public static void viewClassSchedules(Connection connection) throws SQLException {
        String sql = "SELECT * FROM ClassSchedule";
        try (Statement statement = connection.createStatement()) {
            try (ResultSet resultSet = statement.executeQuery(sql)) {
                while (resultSet.next()) {
                    System.out.println("Schedule ID: " + resultSet.getInt("schedule_id"));
                    System.out.println("Class Name: " + resultSet.getString("class_name"));
                    System.out.println("Trainer ID: " + resultSet.getInt("trainer_id"));
                    System.out.println("Day of Week: " + resultSet.getString("day_of_week"));
                    System.out.println("Start Time: " + resultSet.getString("start_time"));
                    System.out.println("End Time: " + resultSet.getString("end_time"));
                    System.out.println();
                }
            }
        }
    }

    public static void updateClassSchedule(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter schedule ID: ");
        int scheduleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new class name: ");
        String className = scanner.nextLine();
        System.out.print("Enter new trainer ID: ");
        int trainerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new day of week: ");
        String dayOfWeek = scanner.nextLine();
        System.out.print("Enter new start time (HH:MM:SS): ");
        String startTime = scanner.nextLine();
        System.out.print("Enter new end time (HH:MM:SS): ");
        String endTime = scanner.nextLine();

        String sql = "UPDATE ClassSchedule SET class_name = ?, trainer_id = ?, day_of_week = ?, start_time = ?, end_time = ? WHERE schedule_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, className);
            statement.setInt(2, trainerId);
            statement.setString(3, dayOfWeek);
            statement.setString(4, startTime);
            statement.setString(5, endTime);
            statement.setInt(6, scheduleId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Class schedule updated successfully.");
            } else {
                System.out.println("Class schedule not found.");
            }
        }
    }

    public static void cancelClass(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter schedule ID: ");
        int scheduleId = scanner.nextInt();

        String sql = "DELETE FROM ClassSchedule WHERE schedule_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, scheduleId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Class cancelled successfully.");
            } else {
                System.out.println("Class schedule not found.");
            }
        }
    }
}