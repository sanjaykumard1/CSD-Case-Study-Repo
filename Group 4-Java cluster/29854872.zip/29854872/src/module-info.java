/**
 * 
 */
/**
 * 
 */
module Student_Information_System_App {
	requires java.sql;
}