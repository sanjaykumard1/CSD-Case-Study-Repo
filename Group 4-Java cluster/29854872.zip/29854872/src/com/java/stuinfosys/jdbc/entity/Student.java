package com.java.stuinfosys.jdbc.entity;

import java.sql.Date;

public class Student {
	
	private int studentId;
	private String name;
	private Date date_of_birth;
	private String email;
	private String phoneNumber;

	public Student() {
	}

	public Student(int studentId, String name, Date date_of_birth, String email, String phoneNumber) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.date_of_birth = date_of_birth;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "Student Id =" + studentId + ", Name=" + name + ", Date_of_birth=" + date_of_birth + ", Email="
				+ email + ", PhoneNumber=" + phoneNumber;
	}

}
