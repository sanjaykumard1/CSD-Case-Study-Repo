package com.java.stuinfosys.jdbc;


import java.sql.SQLException;
import java.util.Scanner;

public class Application {

	public static void main(String[] args) throws SQLException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Student Information System");
		while (true) {
			System.out.println("\n1.Student Management");
			System.out.println("2.Course Management");
			System.out.println("3.Enrollment Management");
			System.out.println("4.Exit\n");
			
			System.out.print("Enter your choice : ");
			int choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				StudentManagement sm = new StudentManagement();
				sm.studentManagement();
				break;
			case 2:
				CourseManagement cm=new CourseManagement();
				cm.courseManagement();
				break;
			case 3:
				EnrollmentManagement em=new EnrollmentManagement();
				em.enrollmentManagement();
				break;
			case 4:
				System.out.println("\nExiting the system.....");
				return;
			default:
				System.out.println("Invalid Input");
			}
		}
	}

}
