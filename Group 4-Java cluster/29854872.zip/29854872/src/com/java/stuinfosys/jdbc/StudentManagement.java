package com.java.stuinfosys.jdbc;

import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.java.stuinfosys.jdbc.dao.StudentDao;
import com.java.stuinfosys.jdbc.entity.Student;

public class StudentManagement {
    
	public static boolean isValidDate(String date) {
        try {
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        java.util.Date utilDate = sdf.parse(date);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
	
	public void studentManagement() throws SQLException {
		Scanner sc = new Scanner(System.in);
		
		StudentDao student_dao=new StudentDao();
		Student student = new Student();
		
			while(true) {
				System.out.println("\n1.Add a new student");
				System.out.println("2.View student details");
				System.out.println("3.Update student information");
				System.out.println("4.Delete a student");
				System.out.println("5.Exit\n");
				System.out.print("Enter your choice : ");
				int choice = sc.nextInt();
				
				switch(choice) {
					case 1:
						System.out.print("Enter Student id: ");
						student.setStudentId(sc.nextInt());
						
						System.out.print("Enter Student name: ");
						student.setName(sc.next());
												
						System.out.print("Enter Date of birth in (yyyy-mm-dd) format: ");
						String date=sc.next();
						if (!isValidDate(date)) {
				            System.out.println("The date is invalid.");
				            break;
				        }
						student.setDate_of_birth(Date.valueOf(date));
						
						System.out.print("Enter Email: ");
						student.setEmail(sc.next());;
						
						System.out.print("Enter phone number: ");
						student.setPhoneNumber(sc.next());
						
						student_dao.createStudent(student);
						break;
						
					case 2:
						  List<Student> allStudents = student_dao.getAllStudents(); 
						  System.out.println("\nAll Students:"); 
						  for(Student studentDetails : allStudents) {
							  System.out.println(studentDetails);
						  }
						  break;
						  
					case 3:
						System.out.print("Enter Student id: ");
						student.setStudentId(sc.nextInt());
						
						System.out.print("Enter Student name: ");
						student.setName(sc.next());
												
						System.out.print("Enter Date of birth in (yyyy-mm-dd) format: ");
						String dob=sc.next();
						if (!isValidDate(dob)) {
				            System.out.println("The date is invalid.");
				            break;
				        }
						student.setDate_of_birth(Date.valueOf(dob));
						
						System.out.print("Enter Email: ");
						student.setEmail(sc.next());;
						
						System.out.print("Enter phone number: ");
						student.setPhoneNumber(sc.next());
						
						student_dao.updateStudent(student);
						break;
						
					case 4:
						System.out.print("Enter Student id: ");
						int id = sc.nextInt();
						student_dao.deleteStudent(id);
						break;
						  
					case 5:
						System.out.println("\nExiting the Student Management.....");
						return;
						
					default:
						System.out.println("Invalid Input");
			}
		}
	}
}
