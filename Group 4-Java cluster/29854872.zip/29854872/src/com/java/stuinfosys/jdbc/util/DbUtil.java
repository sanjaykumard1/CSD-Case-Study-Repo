package com.java.stuinfosys.jdbc.util;


import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	private static Connection connection = null;
	private static String url = "jdbc:mysql://localhost:3306/student_information_system";
	private static String username = "root";
	private static String password = "QW12!@qw";

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection(url, username, password);
			// System.out.println("Connection Done");
		} catch (Exception e) {
			System.out.println("Connection Not Created : " + e);
		}
		return connection;
	}
//	public static void main(String[] args) {
//		System.out.println(DbUtil.getConnection());
//	}
}

