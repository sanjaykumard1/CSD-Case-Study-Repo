package com.java.stuinfosys.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.stuinfosys.jdbc.entity.Course;
import com.java.stuinfosys.jdbc.util.DbUtil;

public class CourseDao {
	
	private Connection connection=DbUtil.getConnection();

	public void createCourse(Course course) {
		
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO courses VALUES(?,?,?,?)");
			ps.setInt(1, course.getCourseId());
			ps.setString(2, course.getCourseName());
			ps.setString(3, course.getInstructor());
			ps.setInt(4, course.getCredits());
			ps.executeUpdate();
			ps.close();	
			System.out.println("Course details added successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM courses");
            while (resultSet.next()) {
            	Course course = new Course();
            	course.setCourseId(resultSet.getInt("course_id"));
            	course.setCourseName(resultSet.getString("course_name"));
            	course.setInstructor(resultSet.getString("instructor"));
            	course.setCredits(resultSet.getInt("credits"));
                courses.add(course);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }
	
	public void updateCourse(Course course) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("UPDATE courses SET course_name = ?, instructor = ?, credits = ?  WHERE course_id = ?");
			ps.setString(1, course.getCourseName());
			ps.setString(2, course.getInstructor());
			ps.setInt(3, course.getCredits());
			ps.setInt(4, course.getCourseId());
			ps.executeUpdate();
			ps.close();	
			System.out.println("Course details updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteCourse(int courseId) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("DELETE FROM courses WHERE course_id=?");
            ps.setInt(1, courseId);
            ps.executeUpdate();
            ps.close();
            System.out.println("Course details deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
      }
	}
}
