package com.java.stuinfosys.jdbc.entity;

public class Course {
	
	private int courseId;
	private String courseName;
	private String instructor;
	private int credits;
	
	public Course() {
	}

	public Course(int courseId, String courseName, String instructor, int credits) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.instructor = instructor;
		this.credits = credits;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}

	public int getCredits() {
		return credits;
	}

	public void setCredits(int credits) {
		this.credits = credits;
	}

	@Override
	public String toString() {
		return "CourseId=" + courseId + ", Course Name=" + courseName + ", Instructor=" + instructor
				+ ", Credits=" + credits;
	}
	
}
