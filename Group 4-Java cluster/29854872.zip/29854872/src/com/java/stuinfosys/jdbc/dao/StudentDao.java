package com.java.stuinfosys.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.stuinfosys.jdbc.entity.Student;
import com.java.stuinfosys.jdbc.util.DbUtil;

public class StudentDao{
	
	private Connection connection=DbUtil.getConnection();

	public void createStudent(Student student) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO students VALUES(?,?,?,?,?)");
			ps.setInt(1, student.getStudentId());
			ps.setString(2, student.getName());
			ps.setDate(3, student.getDate_of_birth());
			ps.setString(4, student.getEmail());
			ps.setString(5, student.getPhoneNumber());
			ps.executeUpdate();
			ps.close();	
			System.out.println("Student details added successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM students");
            while (resultSet.next()) {
            	Student student = new Student();
            	student.setStudentId(resultSet.getInt("student_id"));
            	student.setName(resultSet.getString("name"));
            	student.setDate_of_birth(resultSet.getDate("date_of_birth"));
            	student.setEmail(resultSet.getString("email"));
            	student.setPhoneNumber(resultSet.getString("phone_number"));
                students.add(student);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
	
	public void updateStudent(Student student) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("UPDATE students SET name = ?, date_of_birth = ?, email = ?, phone_number = ? WHERE student_id = ?");
			ps.setString(1, student.getName());
			ps.setDate(2, student.getDate_of_birth());
			ps.setString(3, student.getEmail());
			ps.setString(4, student.getPhoneNumber());
			ps.setInt(5, student.getStudentId());
			ps.executeUpdate();
			ps.close();	
			System.out.println("Student details updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteStudent(int studentId) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("DELETE FROM students WHERE student_id=?");
            ps.setInt(1, studentId);
            ps.executeUpdate();
            ps.close();
			System.out.println("Student details deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
      }
	}
}
