package com.java.stuinfosys.jdbc;

import java.sql.Date;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.java.stuinfosys.jdbc.dao.EnrollmentDao;
import com.java.stuinfosys.jdbc.entity.Enrollment;

public class EnrollmentManagement {
	public static boolean isValidDate(String date) {
        try {
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
	        java.util.Date utilDate = sdf.parse(date);
        } catch (Exception e) {
            return false;
        }
        return true;
    }
	
	public void enrollmentManagement() throws SQLException {
		Scanner sc = new Scanner(System.in);
		
		EnrollmentDao enrollment_dao=new EnrollmentDao();
		Enrollment enrollment = new Enrollment();
		
			while(true) {
				System.out.println("\n1.Enroll in a course");
				System.out.println("2.View enrollment details");
				System.out.println("3.Cancel enrollment");
				System.out.println("4.List all students enrolled in a specific course");
				System.out.println("5.Exit\n");
				System.out.print("Enter your choice : ");
				int choice = sc.nextInt();
				
				switch(choice) {
					case 1:
						System.out.print("Enter Enrollment id: ");
						enrollment.setEnrollmentId(sc.nextInt());
						
						System.out.print("Enter Student id: ");
						enrollment.setStudentId(sc.nextInt());
						
						System.out.print("Enter Course id: ");
						enrollment.setCourseId(sc.nextInt());
	
						System.out.print("Enter Enrollment date in (yyyy-mm-dd) format: ");
						String date=sc.next();
						if (!isValidDate(date)) {
				            System.out.println("The date is invalid.");
				            break;
				        }
						enrollment.setEnrollmentDate(Date.valueOf(date));
						enrollment_dao.createEnrollment(enrollment);
						break;
						
					
					case 2:
						List<Enrollment> allEnrollments = enrollment_dao.getAllEnrollments();
						System.out.println("\nAll Enrollments:");
						for (Enrollment enrollmentDetails : allEnrollments) {
							System.out.println(enrollmentDetails);
						}
						break;

					case 3:
						System.out.print("Enter Enrollment id: ");
						int id = sc.nextInt();
						enrollment_dao.cancelEnrollment(id);
						break;
					case 4:
						System.out.print("Enter course id: ");
						int course_id = sc.nextInt();
						List<Enrollment> CourseEnrollments = enrollment_dao.getCourseEnrollments(course_id);
						System.out.println("\nCourse Enrollments:");
						for (Enrollment enrollmentDetails : CourseEnrollments) {
							System.out.println(enrollmentDetails);
						}
						break;
					case 5:
						System.out.println("\nExiting the Enrollment Management.....");
						return;
						
					default:
						System.out.println("Invalid Input");
			}
		}
	}
}
