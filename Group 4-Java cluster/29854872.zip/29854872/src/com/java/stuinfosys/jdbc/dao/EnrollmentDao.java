package com.java.stuinfosys.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.stuinfosys.jdbc.entity.Enrollment;
import com.java.stuinfosys.jdbc.entity.Student;
import com.java.stuinfosys.jdbc.util.DbUtil;

public class EnrollmentDao {
	private Connection connection=DbUtil.getConnection();

	public void createEnrollment(Enrollment enrollment) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO enrollments VALUES(?,?,?,?)");
			ps.setInt(1, enrollment.getEnrollmentId());
			ps.setInt(2, enrollment.getStudentId());
			ps.setInt(3, enrollment.getCourseId());
			ps.setDate(4, enrollment.getEnrollmentDate());
			ps.executeUpdate();
			ps.close();	
			System.out.println("Course enrolled successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<Enrollment> getAllEnrollments() {
        List<Enrollment> enrollments = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM enrollments");
            while (resultSet.next()) {
            	Enrollment enrollment = new Enrollment();
            	enrollment.setEnrollmentId(resultSet.getInt("enrollment_id"));
            	enrollment.setStudentId(resultSet.getInt("student_id"));
            	enrollment.setCourseId(resultSet.getInt("course_id"));
            	enrollment.setEnrollmentDate(resultSet.getDate("enrollment_date"));
            	enrollments.add(enrollment);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enrollments;
    }
	
	public void cancelEnrollment(int enrollmentId) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("DELETE FROM enrollments WHERE enrollment_id=?");
            ps.setInt(1, enrollmentId);
            ps.executeUpdate();
            ps.close();
			System.out.println("Enrollment cancelled");
        } catch (SQLException e) {
            e.printStackTrace();
      }
	}
	
	public List<Enrollment> getCourseEnrollments(int courseId) {
        List<Enrollment> enrollments = new ArrayList<>();
        PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("SELECT * FROM enrollments where course_id = ?");
            ps.setInt(1,courseId);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
            	Enrollment enrollment = new Enrollment();
            	enrollment.setEnrollmentId(resultSet.getInt("enrollment_id"));
            	enrollment.setStudentId(resultSet.getInt("student_id"));
            	enrollment.setCourseId(resultSet.getInt("course_id"));
            	enrollment.setEnrollmentDate(resultSet.getDate("enrollment_date"));
            	enrollments.add(enrollment);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enrollments;
    }

}
