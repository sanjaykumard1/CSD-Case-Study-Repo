package com.java.stuinfosys.jdbc;


import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.stuinfosys.jdbc.dao.CourseDao;
import com.java.stuinfosys.jdbc.entity.Course;

public class CourseManagement {
	
	public void courseManagement() throws SQLException {
		Scanner sc = new Scanner(System.in);
		
		CourseDao course_dao=new CourseDao();
		Course course = new Course();
		
			while(true) {
				System.out.println("\n1.Add a new course");
				System.out.println("2.View course details");
				System.out.println("3.Update course information");
				System.out.println("4.Delete a course");
				System.out.println("5.Exit\n");
				System.out.print("Enter your choice : ");
				int choice = sc.nextInt();
				
				switch(choice) {
				
					case 1:
						System.out.print("Enter Course id: ");
						course.setCourseId(sc.nextInt());
						
						System.out.print("Enter Course name: ");
						course.setCourseName(sc.next());
						
						System.out.print("Enter Instructor: ");
						course.setInstructor(sc.next());
						
						System.out.print("Enter Credits: ");
						course.setCredits(sc.nextInt());
						
						course_dao.createCourse(course);
						break;
						
					case 2:
						  List<Course> allCourses = course_dao.getAllCourses();
						  System.out.println("\nAll Courses:"); 
						  for(Course courseDetails : allCourses) {
						  System.out.println(courseDetails); 
						  }
						 
						  break;
						  
						case 3:
							System.out.print("Enter Course id: ");
							course.setCourseId(sc.nextInt());
							
							System.out.print("Enter Course name: ");
							course.setCourseName(sc.next());
							
							System.out.print("Enter Instructor: ");
							course.setInstructor(sc.next());
							
							System.out.print("Enter Credits: ");
							course.setCredits(sc.nextInt());
							
							course_dao.updateCourse(course);
								 
						break;
						
					case 4:
						  System.out.print("Enter Course id: "); 
						  int id = sc.nextInt();
						  course_dao.deleteCourse(id);
						break;
						  
					case 5:
						System.out.println("\nExiting the Course Management.....");
						return;
						
					default:
						System.out.println("Invalid Input");
			}
		}	
	}
}
