package com.cts.dbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
public class DataBaseService {
	public static Connection conn;

	private static Connection createconn() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/hms?autoReconnect=true&useSSL=false", "root", "12345678");
		System.out.println("successful connection");
		
		return conn;
	}
	
	public static Connection getconn() throws ClassNotFoundException, SQLException
	{
		if(conn==null)
		{
			return createconn();
		}
		
		return conn;
	}

}

