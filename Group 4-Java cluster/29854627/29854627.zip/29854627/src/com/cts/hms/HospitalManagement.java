package com.cts.hms;
import java.util.Scanner;

import com.cts.dbs.DataBaseService;

import java.sql.*;
public class HospitalManagement {

	public static void main(String[] args)throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection conn= DataBaseService.getconn();
		Patient p=new Patient(conn);
		Doctor d= new Doctor(conn);
		MedicalRecord m= new MedicalRecord(conn);
		Scanner sc= new Scanner(System.in);
		
		while(true)

		{
			System.out.println("1. Register Patient");
			System.out.println("2. View Patient");
			System.out.println("3. Update Patient");
			System.out.println("4. Delete Patient");
			System.out.println("5. Register Doctor");
			System.out.println("6. View Doctor");
			System.out.println("7. Update Doctor");
			System.out.println("8. Delete Doctor");
			System.out.println("9. Add a medical Record");
			System.out.println("10. View Medical Record");
			System.out.println("11. Update Medical Record");
			System.out.println("12. Delete Medical Record");
			
			System.out.println("Enter your choice");
			
			int i=sc.nextInt();
			
			switch(i)
			{
			case 1:
				p.registerPatient();
				break;
			case 2:
				p.viewPatient();
				break;
			case 3:
				p.updatePatient();
				break;
			case 4:
				p.deletePatient();
				break;
			case 5:
				d.registerDoctor();
				break;
			case 6:
				d.viewDoctor();
				break;
			case 7:
				d.updateDoctor();
				break;
			case 8:
				d.deleteDoctor();
				break;
			case 9:
				m.addMedicalRecord();
				break;
			case 10:
				m.viewMedicalRecord();
				break;
			case 11:
				m.updateMedicalRecord();
				break;
			case 12:
				m.deleteMedicalRecord();
				break;
			default:
				System.out.println("Enter valid character");
				break;
			}
			
		}
		

	}

}
