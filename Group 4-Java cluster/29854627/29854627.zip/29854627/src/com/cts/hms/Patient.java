package com.cts.hms;
import java.util.*;
import java.util.Date;
import java.text.*;
import java.lang.*;

import com.cts.dbs.DataBaseService;

import java.sql.*;

public class Patient  {
	private Connection conn;
	public Patient(Connection conn) throws ClassNotFoundException, SQLException
	{
		this.conn=DataBaseService.getconn();
	}
	Scanner sc=new Scanner(System.in);
	
	public void registerPatient() throws SQLException 
	{
		
		System.out.println("Enter Patient Id");
		int num=sc.nextInt();
		
		System.out.println("Enter Patient Name");
		String name=sc.next(); 
		
		
		System.out.println("Enter dob");
		String dob=sc.next();
		
		
			//Date d=DateFormat.getDateInstance().parse(dob);
		
		
		System.out.println("Enter gender");
		String gender=sc.next();
		
		System.out.println("Entet Address");
		String address= sc.next();
		
		java.sql.Date d= java.sql.Date.valueOf(dob);
		
		String q= "insert into patient(patient_id,name,date_of_birth,gender,address) values (?,?,?,?,?)";
		
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, num);
		p.setString(2, name);
		p.setDate(3, d);
		p.setString(4, gender);
		p.setString(5, address);
		
		p.execute();
		
	}
	
	public void viewPatient() throws SQLException
	{
		System.out.println("Enter id");
		int id=sc.nextInt();
		String q="select * from patient where patient_id=?";
		
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		ResultSet rs=p.executeQuery();
		
		while(rs.next())
		{
			System.out.println("Patient id : "+ rs.getInt(1));
			System.out.println("Patient name : "+ rs.getString(2));
			System.out.println("Date of Birth: "+rs.getString(3));
			System.out.println("gender : "+rs.getString(4));
			System.out.println("add : "+rs.getString(5));
		}
		
		
	}
	
	public void updatePatient() throws SQLException
	{
		System.out.println("Enter id");
		int id=sc.nextInt();
		System.out.println("Enter patient name");
		String n=sc.next();
		System.out.println("Enter gender");
		String g=sc.next();
		System.out.println("Enter address");
		String add=sc.next();
		//String q="UPDATE patient SET name=?, gender=?, address=? WHERE patient_id=?";
		PreparedStatement p= conn.prepareStatement("update patient set name =? , gender= ? , address= ? where patient_id= ?");
		p.setString(1, n);
		p.setString(2, g);
		p.setString(3, add);
		p.setInt(4, id);
		p.executeUpdate();
		
	}
	
	public void deletePatient() throws SQLException
	{
		
		System.out.println("Enter patient id");
		int id=sc.nextInt();
		
		String q="delete from patient where patient_id=?";
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		p.execute();
		
	}
	

}
