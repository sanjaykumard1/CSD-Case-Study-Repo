package com.cts.hms;

import java.util.Scanner;

import com.cts.dbs.DataBaseService;

import java.sql.*;

public class MedicalRecord {

	private Connection conn;
	public MedicalRecord(Connection conn) throws ClassNotFoundException, SQLException
	{
		this.conn=DataBaseService.getconn();
	}
	Scanner sc=new Scanner(System.in);
	
	public void addMedicalRecord() throws SQLException
	{
		System.out.println("Enter record number");
		int rno=sc.nextInt();
		
		System.out.println("Enter patient_ref_id");
		int pid=sc.nextInt();
		
		System.out.println("Enter doctor_ref_id");
		int did=sc.nextInt();
		
		System.out.println("Enter date");
		String d=sc.next();
		
		System.out.println("Enter diagnosis");
		String diag=sc.next();
		
		System.out.println("Enter treatement");
		String t=sc.next();
		
		java.sql.Date date= java.sql.Date.valueOf(d);
		
		String q= "insert into medical_record(record_id,patient_ref_id,doctor_ref_id,date_of,diagnosis,treatment) values (?,?,?,?,?,?)";
		
		PreparedStatement p= conn.prepareStatement(q);
		p.setInt(1, rno);
		p.setInt(2, pid);
		p.setInt(3, did);
		p.setDate(4, date);
		p.setString(5, diag);
		p.setString(6, t);
		
		p.execute();
}
	
	public void viewMedicalRecord() throws SQLException
	{
		System.out.println("Enter id");
		int id=sc.nextInt();
		
		String q="select * from medical_record where record_id=?";
		
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		ResultSet rs=p.executeQuery();
		
		while(rs.next())
		{
			System.out.println("Record id : "+ rs.getInt(1));
			System.out.println("patient id : "+ rs.getInt(2));
			System.out.println("doctor id : "+rs.getInt(3));
			System.out.println("date : "+rs.getDate(4));
			System.out.println("diagnosis : "+rs.getString(5));
			System.out.println("Treatment : "+rs.getString(6));
		}
				
	}
	
	public void updateMedicalRecord() throws SQLException
	{
		System.out.println("Enter record id :");
		int id=sc.nextInt();
		System.out.println("Enter patient id number");
		int pid= sc.nextInt();
		System.out.println("Enter doctor id number");
		int did=sc.nextInt();
		System.out.println("Enter date");
		String d=sc.next();
		
		System.out.println("Enter diagnosis");
		String diag=sc.next();
		System.out.println("Enter Treatment");
		String treat=sc.next();
		
		java.sql.Date date= java.sql.Date.valueOf(d);
			String q="update medical_record set patient_ref_id =?,doctor_ref_id=?, date_of=?, diagnosis=?, treatment=? where record_id=?";
		PreparedStatement p= conn.prepareStatement(q);
		p.setInt(1, pid);
		p.setInt(2, did);
		p.setDate(3, date);
		p.setString(4, diag);
		p.setString(5, treat);
		p.setInt(6, id);
		
		p.executeUpdate();
	}
	
	public void deleteMedicalRecord() throws SQLException
	{
		System.out.println("Enter medical record id");
		int id=sc.nextInt();
		
		String q="delete from medical_record where record_id=?";
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		p.execute();
	}
		
	
}
