package com.cts.hms;
import java.util.*;
import java.util.Date;

import com.cts.dbs.DataBaseService;

import java.text.*;
import java.lang.*;
import java.sql.*;
public class Doctor {
	private Connection conn;
	public Doctor(Connection conn) throws ClassNotFoundException, SQLException
	{
		this.conn=DataBaseService.getconn();
	}
Scanner sc=new Scanner(System.in);
	
	public void registerDoctor() throws SQLException 
	{
		System.out.println("Enter Doctor Id");
		int num=sc.nextInt();
		
		System.out.println("Enter Doctor Name");
		String name=sc.next(); 
		
		System.out.println("Enter specialization");
		String specialization=sc.next();
		
		System.out.println("Enter contact number");
		int contact=sc.nextInt();
		
		System.out.println("Entet email Address");
		String address= sc.next();
		
		String q= "insert into doctor(doctor_id,name,specialization,contact_number,email) values (?,?,?,?,?)";
		
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, num);
		p.setString(2, name);
		p.setString(3, specialization);
		p.setInt(4, contact);
		p.setString(5, address);
		
		p.execute();
		
		
		
	}
	
	public void viewDoctor() throws SQLException
	{
		System.out.println("Enter id");
		int id=sc.nextInt();
		
		String q="select * from doctor where doctor_id=?";
		
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		ResultSet rs=p.executeQuery();
		
		while(rs.next())
		{
			System.out.println("Patient id : "+ rs.getInt(1));
			System.out.println("Doctor name : "+ rs.getString(2));
			System.out.println("Specialization : "+rs.getString(3));
			System.out.println("Contact Number : "+rs.getInt(4));
			System.out.println("address : "+rs.getString(5));
		}
				
	}
	
	public void updateDoctor() throws SQLException
	{
		System.out.println("Enter id");
		int id=sc.nextInt();
		System.out.println("Enter Doctor name");
		String n=sc.next();
		System.out.println("Enter Specialization");
		String g=sc.next();
		System.out.println("Enter mobile number");
		int c=sc.nextInt();
		System.out.println("Enter email address");
		String add=sc.next();
		//String q="UPDATE patient SET name=?, gender=?, address=? WHERE patient_id=?";
		PreparedStatement p= conn.prepareStatement("update doctor set name =? , specialization= ? , contact_number=?, email= ? where doctor_id= ?");
		p.setString(1, n);
		p.setString(2, g);
		p.setInt(3, c);
		p.setString(4, add);
		p.setInt(5, id);
		p.executeUpdate();
		
	}
	
	public void deleteDoctor() throws SQLException
	{
		System.out.println("Enter doctor id");
		int id=sc.nextInt();
		
		String q="delete from doctor where doctor_id=?";
		PreparedStatement p=conn.prepareStatement(q);
		p.setInt(1, id);
		p.execute();
	}
}
