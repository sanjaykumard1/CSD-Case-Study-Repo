package Bank;

import java.sql.*;
import java.util.Scanner;

public class BankingSystem {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/banking_system";
    private static final String USER = "root";
    private static final String PASS = "root";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                showMenu();
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        addCustomerAccount(conn, scanner);
                        break;
                    case 2:
                        viewAccountDetails(conn, scanner);
                        break;
                    case 3:
                        updateAccountInformation(conn, scanner);
                        break;
                    case 4:
                        closeAccount(conn, scanner);
                        break;
                    case 5:
                        depositFunds(conn, scanner);
                        break;
                    case 6:
                        withdrawFunds(conn, scanner);
                        break;
                    case 7:
                        transferFunds(conn, scanner);
                        break;
                    case 8:
                        viewTransactionHistory(conn, scanner);
                        break;
                    case 9:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void showMenu() {
        System.out.println("\nBanking System Menu:");
        System.out.println("1. Add New Customer Account");
        System.out.println("2. View Account Details");
        System.out.println("3. Update Account Information");
        System.out.println("4. Close Account");
        System.out.println("5. Deposit Funds");
        System.out.println("6. Withdraw Funds");
        System.out.println("7. Transfer Funds");
        System.out.println("8. View Transaction History");
        System.out.println("9. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addCustomerAccount(Connection conn, Scanner scanner) {
        try {
            String name;
            boolean isUnique = false;

            while (!isUnique) {
                System.out.print("Enter customer name: ");
                name = scanner.next();

                String checkSql = "SELECT COUNT(*) FROM Customer WHERE name = ?";
                PreparedStatement checkStmt = conn.prepareStatement(checkSql);
                checkStmt.setString(1, name);
                ResultSet checkRs = checkStmt.executeQuery();
                checkRs.next();

                if (checkRs.getInt(1) > 0) {
                    System.out.println("Customer name already exists. Please choose a different name.");
                } else {
                    isUnique = true;

                    // Insert customer and retrieve customer_id
                    String sql = "INSERT INTO Customer (name) VALUES (?)";
                    PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                    pstmt.setString(1, name);
                    pstmt.executeUpdate();

                    ResultSet rs = pstmt.getGeneratedKeys();
                    if (rs.next()) {
                        int customerId = rs.getInt(1);
                        System.out.print("Enter account type (Savings/Checking): ");
                        String accountType = scanner.next();
                        System.out.print("Enter initial balance: ");
                        double balance = scanner.nextDouble();

                        sql = "INSERT INTO Account (customer_id, account_type, balance) VALUES (?, ?, ?)";
                        pstmt = conn.prepareStatement(sql);
                        pstmt.setInt(1, customerId);
                        pstmt.setString(2, accountType);
                        pstmt.setDouble(3, balance);
                        pstmt.executeUpdate();

                        System.out.println("Account created successfully!");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAccountDetails(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter customer name: ");
            String customerName = scanner.next();
            System.out.print("Enter account type (Savings/Checking): ");
            String accountType = scanner.next();

            String sql = "SELECT a.account_id, c.name, a.account_type, a.balance " +
                         "FROM Account a JOIN Customer c ON a.customer_id = c.customer_id " +
                         "WHERE c.name = ? AND a.account_type = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, customerName);
            pstmt.setString(2, accountType);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Account ID: " + rs.getInt("account_id"));
                System.out.println("Customer Name: " + rs.getString("name"));
                System.out.println("Account Type: " + rs.getString("account_type"));
                System.out.println("Balance: " + rs.getDouble("balance"));
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAccountInformation(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter account ID: ");
            int accountId = scanner.nextInt();

            System.out.println("What would you like to update?");
            System.out.println("1. Customer Name");
            System.out.println("2. Account Type");
            System.out.print("Enter your choice: ");
            int updateChoice = scanner.nextInt();

            String sql;
            PreparedStatement pstmt;

            switch (updateChoice) {
                case 1:
                    System.out.print("Enter new customer name: ");
                    String newName = scanner.next();

                    sql = "UPDATE Customer SET name = ? WHERE customer_id = (SELECT customer_id FROM Account WHERE account_id = ?)";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1, newName);
                    pstmt.setInt(2, accountId);
                    pstmt.executeUpdate();

                    System.out.println("Customer name updated successfully!");
                    break;

                case 2:
                    System.out.print("Enter new account type (Savings/Checking): ");
                    String newAccountType = scanner.next();

                    sql = "UPDATE Account SET account_type = ? WHERE account_id = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1, newAccountType);
                    pstmt.setInt(2, accountId);
                    pstmt.executeUpdate();

                    System.out.println("Account type updated successfully!");
                    break;

                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void closeAccount(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter account ID: ");
            int accountId = scanner.nextInt();

            String sql = "DELETE FROM Account WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Account closed successfully!");
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void depositFunds(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter account ID: ");
            int accountId = scanner.nextInt();
            System.out.print("Enter amount to deposit: ");
            double amount = scanner.nextDouble();

            String sql = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, accountId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                sql = "SELECT balance FROM Account WHERE account_id = ?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, accountId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    double newBalance = rs.getDouble("balance");
                    System.out.println("Deposit successful! New balance: " + newBalance);
                }

                sql = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Deposit', ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, accountId);
                pstmt.setDouble(2, amount);
                pstmt.executeUpdate();
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void withdrawFunds(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter account ID: ");
            int accountId = scanner.nextInt();
            System.out.print("Enter amount to withdraw: ");
            double amount = scanner.nextDouble();

            String sql = "SELECT balance FROM Account WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                if (currentBalance >= amount) {
                    sql = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, accountId);
                    pstmt.executeUpdate();

                    sql = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Withdrawal', ?)";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, accountId);
                    pstmt.setDouble(2, amount);
                    pstmt.executeUpdate();

                    double newBalance = currentBalance - amount;
                    System.out.println("Withdrawal successful! New balance: " + newBalance);
                } else {
                    System.out.println("Insufficient balance.");
                }
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void transferFunds(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter source account ID: ");
            int sourceAccountId = scanner.nextInt();
            System.out.print("Enter target account ID: ");
            int targetAccountId = scanner.nextInt();
            System.out.print("Enter amount to transfer: ");
            double amount = scanner.nextDouble();

            String sql = "SELECT balance FROM Account WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, sourceAccountId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                if (currentBalance >= amount) {
                    sql = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, sourceAccountId);
                    pstmt.executeUpdate();

                    sql = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, targetAccountId);
                    pstmt.executeUpdate();

                    sql = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Transfer', ?)";
                    pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, sourceAccountId);
                    pstmt.setDouble(2, amount);
                    pstmt.executeUpdate();

                    pstmt.setInt(1, targetAccountId);
                    pstmt.executeUpdate();

                    double newBalance = currentBalance - amount;
                    System.out.println("Transfer successful! New balance of source account: " + newBalance);
                } else {
                    System.out.println("Insufficient balance.");
                }
            } else {
                System.out.println("Source account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewTransactionHistory(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter account ID: ");
            int accountId = scanner.nextInt();

            String sql = "SELECT transaction_id, transaction_type, amount, transaction_date FROM Transaction WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Transaction Type: " + rs.getString("transaction_type"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("Date: " + rs.getTimestamp("transaction_date"));
                System.out.println("-----------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
