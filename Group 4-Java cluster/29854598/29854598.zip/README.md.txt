
---

# Basic Accounting System

## Objective

The **Basic Accounting System** is a menu-based console application designed to assess proficiency in Core Java, MySQL, and JDBC. This application simulates a basic banking system for managing customer accounts and handling transactions.

## Functionalities

### 1. Account Management

- **Add New Customer Account:** Create new accounts for customers.
- **View Account Details:** Retrieve and display details of existing accounts.
- **Update Account Information:** Modify account details as needed.
- **Close Account:** Deactivate or close customer accounts.

### 2. Transaction Management

- **Deposit Funds:** Add money to a customer�s account.
- **Withdraw Funds:** Remove money from a customer�s account.
- **Transfer Funds:** Move money between different accounts.
- **View Transaction History:** Display a log of transactions for a specific account.

## Database Schema

### 1. Customer Table

| Column        | Type           | Description                      |
|---------------|----------------|----------------------------------|
| `customer_id`  | INT, Primary Key | Unique identifier for the customer |
| `name`         | VARCHAR        | Name of the customer             |
| `email`        | VARCHAR        | Email address of the customer    |

### 2. Account Table

| Column         | Type           | Description                              |
|----------------|----------------|------------------------------------------|
| `account_id`    | INT, Primary Key| Unique identifier for the account       |
| `customer_id`   | INT, Foreign Key | References `Customer Table`            |
| `account_type`  | VARCHAR        | Type of account (Savings, Checking)     |
| `balance`       | DECIMAL         | Current balance of the account          |

### 3. Transaction Table

| Column            | Type           | Description                              |
|-------------------|----------------|------------------------------------------|
| `transaction_id`  | INT, Primary Key| Unique identifier for the transaction   |
| `account_id`       | INT, Foreign Key | References `Account Table`             |
| `transaction_type`| VARCHAR        | Type of transaction (Deposit, Withdrawal, Transfer) |
| `amount`           | DECIMAL         | Amount of the transaction                |
| `transaction_date`| DATE           | Date of the transaction                  |

## Requirements

- **Develop a Menu-Based Console Application:** Create a user interface using Core Java.
- **Use JDBC for Database Interactions:** Implement database operations to manage customer accounts and transactions.
- **Implement Menu Options:** Provide options for account management and transaction processing.
- **Exception Handling:** Ensure robust exception handling and provide clear error messages.
- **Code Quality:** Maintain clean, well-documented, and properly formatted code. Follow standard Java coding conventions.

## Installation

### Prerequisites

Before you start, make sure you have the following installed:

- **Java Development Kit (JDK) 8 or later:** Download and install from [Oracle](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html) or [OpenJDK](https://openjdk.java.net/install/)
- **MySQL Database Server:** Download and install from [MySQL](https://dev.mysql.com/downloads/mysql/)
- **MySQL Workbench:** Download from [MySQL Workbench](https://dev.mysql.com/downloads/workbench/) for managing your MySQL databases.
- **Oracle IDE:** You can use [Eclipse](https://www.eclipse.org/downloads/) or [IntelliJ IDEA](https://www.jetbrains.com/idea/download/) as your Java development environment.
- **MySQL Connector/J:** Download from [MySQL Connector/J](https://dev.mysql.com/downloads/connector/j/) and add it to your project's classpath.

### Clone the Repository

Clone the repository to your local machine using the following command:

```bash
git clone https://github.com/yourusername/basic-accounting-system.git
```

### Set Up the MySQL Database

1. **Create a Database:**

   Open MySQL Workbench or connect to MySQL via command line and create a new database:

   ```sql
   CREATE DATABASE banking;
   ```

2. **Create the Tables:**

   Run the following SQL commands to create the `Customer`, `Account`, and `Transaction` tables:

   ```sql
   USE banking;

   CREATE TABLE Customer (
       customer_id INT AUTO_INCREMENT PRIMARY KEY,
       name VARCHAR(100),
       email VARCHAR(100) UNIQUE
   );

   CREATE TABLE Account (
       account_id INT AUTO_INCREMENT PRIMARY KEY,
       customer_id INT,
       account_type VARCHAR(50),
       balance DECIMAL(15, 2),
       FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
   );

   CREATE TABLE Transaction (
       transaction_id INT AUTO_INCREMENT PRIMARY KEY,
       account_id INT,
       transaction_type VARCHAR(50),
       amount DECIMAL(15, 2),
       transaction_date DATE,
       FOREIGN KEY (account_id) REFERENCES Account(account_id)
   );
   ```

3. **Configure JDBC Settings:**

   Open the `src/main/resources/db.properties` file and update the MySQL database connection settings:

   ```properties
   jdbc.url=jdbc:mysql://localhost:3306/banking
   jdbc.username=your_mysql_username
   jdbc.password=your_mysql_password
   ```

   Make sure `mysql-connector-java-x.x.xx.jar` (Connector/J) is added to your project's classpath. You can do this through your IDE or by placing the JAR file in your project's `lib` directory and adding it to the build path.

### Build and Run the Application

1. **Compile the Source Code:**

   Navigate to the project directory and compile the Java source files:

   ```bash
   cd basic-accounting-system
   javac -cp "lib/mysql-connector-java-x.x.xx.jar" -d bin src/main/java/com/yourusername/*.java
   ```

2. **Run the Application:**

   Execute the main class from the `bin` directory:

   ```bash
   java -cp "bin;lib/mysql-connector-java-x.x.xx.jar" com.yourusername.Main
   ```

   Replace `com.yourusername.Main` with the fully qualified name of your main class.

### Code Overview

Here's a brief overview of the project's main classes:

- **`Main.java`**: The entry point of the application. It presents a menu to the user and handles the menu choices by invoking methods from other classes.
  
- **`Customer.java`**: Manages customer data. Contains methods for adding new customers and checking if a customer exists.

- **`Account.java`**: Manages account data. Contains methods for adding, viewing, updating, and closing accounts.

- **`Transactions.java`**: Handles transaction operations. Contains methods for depositing, withdrawing, transferring funds, and viewing transaction history.

### Code Examples

Here's how the main methods are structured:

**`Main.java`**

```java
public class Main {
    public static void main(String[] args) {
        // Main method implementation
    }

    private static void addNewCustomerAccount(Scanner scanner) {
        // Method for adding a new customer and account
    }

    private static void viewAccountDetails(Scanner scanner) {
        // Method for viewing account details
    }

    // Other methods for update, close, deposit, withdraw, transfer, and transaction history
}
```

**`Customer.java`**

```java
public class Customer {
    public static int addCustomer(String name, String email) throws SQLException {
        // Method for adding a new customer
    }

    public static boolean isCustomerExists(int customerId) throws SQLException {
        // Method for checking if a customer exists
    }
}
```

**`Account.java`**

```java
public class Account {
    public static int addAccount(int customerId, String accountType, double initialBalance) throws SQLException {
        // Method for adding a new account
    }

    public static void viewAccountDetails(int accountId) throws SQLException {
        // Method for viewing account details
    }

    public static void updateAccount(int accountId, String accountType, double balance) throws SQLException {
        // Method for updating account details
    }

    public static void closeAccount(int accountId) throws SQLException {
        // Method for closing an account
    }

    public static boolean isAccountExists(int accountId) throws SQLException {
        // Method for checking if an account exists
    }
}
```

**`Transactions.java`**

```java
public class Transactions {
    public static void deposit(int accountId, double amount) throws SQLException {
        // Method for depositing funds
    }

    public static void withdraw(int accountId, double amount) throws SQLException {
        // Method for withdrawing funds
    }

    public static void transfer(int fromAccountId, int toAccountId, double amount) throws SQLException {
        // Method for transferring funds
    }

    public static void viewTransactionHistory(int accountId) throws SQLException {
        // Method for viewing transaction history
    }
}
```

## Usage

Once the application is running, you can use the console menu to:

- Add new customer accounts.
- View details of existing accounts.
- Update or close accounts.
- Deposit or withdraw funds.
- Transfer funds between accounts.
- View the transaction history for an account.

