/**
 * 
 */
/**
 * 
 */
module project {
	requires java.sql;
}