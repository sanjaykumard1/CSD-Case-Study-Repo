package project;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.sql.*;

public class Account {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/banking";
    private static final String JDBC_USER = "root"; // Update with your MySQL username
    private static final String JDBC_PASSWORD = "Pranathi@10";  // Update with your MySQL password
    
    private static Connection connection;

    static {
        try {
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int addAccount(int customerId, String accountType, double initialBalance) throws SQLException {
        String query = "INSERT INTO Account (customer_id, account_type, balance) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, customerId);
            stmt.setString(2, accountType);
            stmt.setDouble(3, initialBalance);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);  // Return the new account's ID
            } else {
                throw new SQLException("Failed to get account ID.");
            }
        }
    }

    public static void viewAccountDetails(int accountId) throws SQLException {
        String query = "SELECT a.account_id, c.name, c.email, a.account_type, a.balance " +
                       "FROM Account a JOIN Customer c ON a.customer_id = c.customer_id WHERE a.account_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Account ID: " + rs.getInt("account_id"));
                System.out.println("Customer Name: " + rs.getString("name"));
                System.out.println("Customer Email: " + rs.getString("email"));
                System.out.println("Account Type: " + rs.getString("account_type"));
                System.out.println("Balance: $" + rs.getDouble("balance"));
            } else {
                System.out.println("No account found with the provided ID.");
            }
        }
    }

    public static void updateAccount(int accountId, String accountType, double balance) throws SQLException {
        String query = "UPDATE Account SET account_type = ?, balance = ? WHERE account_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, accountType);
            stmt.setDouble(2, balance);
            stmt.setInt(3, accountId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Account updated successfully.");
            } else {
                System.out.println("No account found with the provided ID.");
            }
        }
    }

    public static void closeAccount(int accountId) throws SQLException {
        // Start transaction
        connection.setAutoCommit(false);
        try {
            // Delete all transactions associated with the account
            String deleteTransactionsQuery = "DELETE FROM Transaction WHERE account_id = ?";
            try (PreparedStatement deleteTransactionsStmt = connection.prepareStatement(deleteTransactionsQuery)) {
                deleteTransactionsStmt.setInt(1, accountId);
                deleteTransactionsStmt.executeUpdate();
            }

            // Delete the account
            String deleteAccountQuery = "DELETE FROM Account WHERE account_id = ?";
            try (PreparedStatement deleteAccountStmt = connection.prepareStatement(deleteAccountQuery)) {
                deleteAccountStmt.setInt(1, accountId);
                int rowsDeleted = deleteAccountStmt.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Account closed successfully.");
                } else {
                    System.out.println("No account found with the provided ID.");
                }
            }

            // Commit transaction
            connection.commit();
        } catch (SQLException e) {
            // Rollback transaction in case of error
            connection.rollback();
            throw e; // Rethrow the exception to be handled by the caller
        } finally {
            connection.setAutoCommit(true);  // Restore default commit behavior
        }
    }

    public static boolean isAccountExists(int accountId) throws SQLException {
        String query = "SELECT 1 FROM Account WHERE account_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
}
