package project;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.*;

public class Transactions {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/banking";
    private static final String JDBC_USER = "root"; // Update with your MySQL username
    private static final String JDBC_PASSWORD = "Pranathi@10";  // Update with your MySQL password
    
    private static Connection connection;

    static {
        try {
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deposit(int accountId, double amount) throws SQLException {
        String updateAccountQuery = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
        try (PreparedStatement updateAccountStmt = connection.prepareStatement(updateAccountQuery)) {
            updateAccountStmt.setDouble(1, amount);
            updateAccountStmt.setInt(2, accountId);
            int rowsUpdated = updateAccountStmt.executeUpdate();
            if (rowsUpdated > 0) {
                recordTransaction(accountId, "Deposit", amount);
                System.out.println("Deposit successful.");
            } else {
                System.out.println("No account found with the provided ID.");
            }
        }
    }

    public static void withdraw(int accountId, double amount) throws SQLException {
        String checkBalanceQuery = "SELECT balance FROM Account WHERE account_id = ?";
        try (PreparedStatement checkBalanceStmt = connection.prepareStatement(checkBalanceQuery)) {
            checkBalanceStmt.setInt(1, accountId);
            ResultSet rs = checkBalanceStmt.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance >= amount) {
                    String updateAccountQuery = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
                    try (PreparedStatement updateAccountStmt = connection.prepareStatement(updateAccountQuery)) {
                        updateAccountStmt.setDouble(1, amount);
                        updateAccountStmt.setInt(2, accountId);
                        updateAccountStmt.executeUpdate();
                        recordTransaction(accountId, "Withdrawal", amount);
                        System.out.println("Withdrawal successful.");
                    }
                } else {
                    System.out.println("Insufficient funds.");
                }
            } else {
                System.out.println("No account found with the provided ID.");
            }
        }
    }

    public static void transfer(int fromAccountId, int toAccountId, double amount) throws SQLException {
        String checkBalanceQuery = "SELECT balance FROM Account WHERE account_id = ?";
        try (PreparedStatement checkBalanceStmt = connection.prepareStatement(checkBalanceQuery)) {
            checkBalanceStmt.setInt(1, fromAccountId);
            ResultSet rs = checkBalanceStmt.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance >= amount) {
                    String updateFromAccountQuery = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
                    try (PreparedStatement updateFromAccountStmt = connection.prepareStatement(updateFromAccountQuery)) {
                        updateFromAccountStmt.setDouble(1, amount);
                        updateFromAccountStmt.setInt(2, fromAccountId);
                        updateFromAccountStmt.executeUpdate();
                    }

                    String updateToAccountQuery = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
                    try (PreparedStatement updateToAccountStmt = connection.prepareStatement(updateToAccountQuery)) {
                        updateToAccountStmt.setDouble(1, amount);
                        updateToAccountStmt.setInt(2, toAccountId);
                        updateToAccountStmt.executeUpdate();
                    }

                    recordTransaction(fromAccountId, "Transfer", -amount);
                    recordTransaction(toAccountId, "Transfer", amount);
                    System.out.println("Transfer successful.");
                } else {
                    System.out.println("Insufficient funds.");
                }
            } else {
                System.out.println("No account found with the provided ID.");
            }
        }
    }

    private static void recordTransaction(int accountId, String transactionType, double amount) throws SQLException {
        String query = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            stmt.setString(2, transactionType);
            stmt.setDouble(3, amount);
            stmt.executeUpdate();
        }
    }

    public static void viewTransactionHistory(int accountId) throws SQLException {
        String query = "SELECT transaction_id, transaction_type, amount, transaction_date " +
                       "FROM Transaction WHERE account_id = ? ORDER BY transaction_date DESC";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, accountId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Transaction Type: " + rs.getString("transaction_type"));
                System.out.println("Amount: $" + rs.getDouble("amount"));
                System.out.println("Transaction Date: " + rs.getTimestamp("transaction_date"));
                System.out.println();
            }
        }
    }
}
