package project;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("\n--- Banking System Menu ---");
            System.out.println("1. Add New Customer Account");
            System.out.println("2. View Account Details");
            System.out.println("3. Update Account Information");
            System.out.println("4. Close Account");
            System.out.println("5. Deposit Funds");
            System.out.println("6. Withdraw Funds");
            System.out.println("7. Transfer Funds");
            System.out.println("8. View Transaction History");
            System.out.println("9. Exit");
            System.out.print("Select an option: ");

            int choice;
            try {
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();  // Clear the invalid input
                continue;
            }

            switch (choice) {
                case 1:
                    addNewCustomerAccount(scanner);
                    break;
                case 2:
                    viewAccountDetails(scanner);
                    break;
                case 3:
                    updateAccountInformation(scanner);
                    break;
                case 4:
                    closeAccount(scanner);
                    break;
                case 5:
                    depositFunds(scanner);
                    break;
                case 6:
                    withdrawFunds(scanner);
                    break;
                case 7:
                    transferFunds(scanner);
                    break;
                case 8:
                    viewTransactionHistory(scanner);
                    break;
                case 9:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void addNewCustomerAccount(Scanner scanner) {
        try {
            System.out.print("Enter customer name: ");
            String name = scanner.nextLine();
            System.out.print("Enter customer email: ");
            String email = scanner.nextLine();
            System.out.print("Enter account type (Savings/Checking): ");
            String accountType = scanner.nextLine();
            System.out.print("Enter initial deposit amount: ");
            double balance = scanner.nextDouble();
            scanner.nextLine();  // Consume newline

            int customerId = Customer.addCustomer(name, email);
            int accountId = Account.addAccount(customerId, accountType, balance);
            System.out.println("Customer and Account created successfully. Account ID: " + accountId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAccountDetails(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            Account.viewAccountDetails(accountId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAccountInformation(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new account type (Savings/Checking): ");
        String accountType = scanner.nextLine();
        System.out.print("Enter new balance: ");
        double balance = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        try {
            Account.updateAccount(accountId, accountType, balance);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void closeAccount(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            Account.closeAccount(accountId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void depositFunds(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        System.out.print("Enter deposit amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        try {
            Transactions.deposit(accountId, amount);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void withdrawFunds(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        System.out.print("Enter withdrawal amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        try {
            Transactions.withdraw(accountId, amount);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void transferFunds(Scanner scanner) {
        System.out.print("Enter source account ID: ");
        int fromAccountId = scanner.nextInt();
        System.out.print("Enter destination account ID: ");
        int toAccountId = scanner.nextInt();
        System.out.print("Enter transfer amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        try {
            Transactions.transfer(fromAccountId, toAccountId, amount);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewTransactionHistory(Scanner scanner) {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            Transactions.viewTransactionHistory(accountId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
