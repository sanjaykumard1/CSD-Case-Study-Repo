package project;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.*;

public class Customer {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/banking";
    private static final String JDBC_USER = "root"; // Update with your MySQL username
    private static final String JDBC_PASSWORD = "Pranathi@10";  // Update with your MySQL password
    
    private static Connection connection;

    static {
        try {
            connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static int addCustomer(String name, String email) throws SQLException {
        String query = "INSERT INTO Customer (name, email) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);  // Return the new customer's ID
            } else {
                throw new SQLException("Failed to get customer ID.");
            }
        }
    }

    public static boolean isCustomerExists(int customerId) throws SQLException {
        String query = "SELECT 1 FROM Customer WHERE customer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }
}
