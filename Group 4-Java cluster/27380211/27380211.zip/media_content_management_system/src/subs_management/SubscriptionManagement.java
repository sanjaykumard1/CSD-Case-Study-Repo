package subs_management;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SubscriptionManagement {
    private static Scanner scanner = new Scanner(System.in);

    public static void manageSubscriptions() {
        while (true) {
            System.out.println("Subscription Management");
            System.out.println("1. Create New Subscription");
            System.out.println("2. View Subscription Details");
            System.out.println("3. Update Subscription Information");
            System.out.println("4. Cancel Subscription");
            System.out.println("5. Go Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addSubscription();
                    break;
                case 2:
                    viewSubscription();
                    break;
                case 3:
                    updateSubscription();
                    break;
                case 4:
                    cancelSubscription();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addSubscription() {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter content ID: ");
        int contentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter subscription date (YYYY-MM-DD): ");
        String subscriptionDate = scanner.nextLine();
        System.out.print("Enter expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();
        System.out.print("Enter status (active/inactive): ");
        String status = scanner.nextLine();

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "INSERT INTO Subscription (user_id, content_id, subscription_date, expiry_date, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, contentId);
            stmt.setDate(3, Date.valueOf(subscriptionDate));
            stmt.setDate(4, Date.valueOf(expiryDate));
            stmt.setString(5, status);
            stmt.executeUpdate();
            System.out.println("Subscription created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewSubscription() {
        System.out.print("Enter subscription ID: ");
        int subscriptionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "SELECT * FROM Subscription WHERE subscription_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, subscriptionId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("User ID: " + rs.getInt("user_id"));
                System.out.println("Content ID: " + rs.getInt("content_id"));
                System.out.println("Subscription Date: " + rs.getDate("subscription_date"));
                System.out.println("Expiry Date: " + rs.getDate("expiry_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateSubscription() {
        System.out.print("Enter subscription ID: ");
        int subscriptionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new content ID: ");
        int contentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new subscription date (YYYY-MM-DD): ");
        String subscriptionDate = scanner.nextLine();
        System.out.print("Enter new expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();
        System.out.print("Enter new status (active/inactive): ");
        String status = scanner.nextLine();

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "UPDATE Subscription SET user_id = ?, content_id = ?, subscription_date = ?, expiry_date = ?, status = ? WHERE subscription_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, contentId);
            stmt.setDate(3, Date.valueOf(subscriptionDate));
            stmt.setDate(4, Date.valueOf(expiryDate));
            stmt.setString(5, status);
            stmt.setInt(6, subscriptionId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Subscription updated successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void cancelSubscription() {
        System.out.print("Enter subscription ID: ");
        int subscriptionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "DELETE FROM Subscription WHERE subscription_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, subscriptionId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Subscription cancelled successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
