/**
 * 
 */
/**
 * 
 */
module media_content_management_system {
	requires java.sql;
}