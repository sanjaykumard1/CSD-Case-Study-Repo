package main;
import java.util.Scanner;

public class MediaContentManagementSystem {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Media Content Management System");
            System.out.println("1. Media Content Management");
            System.out.println("2. User Management");
            System.out.println("3. Subscription Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    content_management.ContentManagement.manageContent();
                    break;
                case 2:
                    user_management.UserManagement.manageUsers();
                    break;
                case 3:
                    subs_management.SubscriptionManagement.manageSubscriptions();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
