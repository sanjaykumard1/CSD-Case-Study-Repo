package content_management;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ContentManagement {
    private static Scanner scanner = new Scanner(System.in);

    public static void manageContent() {
        while (true) {
            System.out.println("Media Content Management");
            System.out.println("1. Add New Media Content");
            System.out.println("2. View Media Content Details");
            System.out.println("3. Update Media Content Information");
            System.out.println("4. Delete Media Content");
            System.out.println("5. Go Back");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addMediaContent();
                    break;
                case 2:
                    viewMediaContent();
                    break;
                case 3:
                    updateMediaContent();
                    break;
                case 4:
                    deleteMediaContent();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addMediaContent() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter release date (YYYY-MM-DD): ");
        String releaseDate = scanner.nextLine();
        System.out.print("Enter content type (e.g., movie, series, documentary): ");
        String contentType = scanner.nextLine();

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "INSERT INTO Content (title, description, genre, release_date, content_type) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setString(3, genre);
            stmt.setDate(4, Date.valueOf(releaseDate));
            stmt.setString(5, contentType);
            stmt.executeUpdate();
            System.out.println("Media content added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewMediaContent() {
        System.out.print("Enter content ID: ");
        int contentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "SELECT * FROM Content WHERE content_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, contentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Genre: " + rs.getString("genre"));
                System.out.println("Release Date: " + rs.getDate("release_date"));
                System.out.println("Content Type: " + rs.getString("content_type"));
            } else {
                System.out.println("Content not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateMediaContent() {
        System.out.print("Enter content ID: ");
        int contentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new description: ");
        String description = scanner.nextLine();
        System.out.print("Enter new genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter new release date (YYYY-MM-DD): ");
        String releaseDate = scanner.nextLine();
        System.out.print("Enter new content type: ");
        String contentType = scanner.nextLine();

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "UPDATE Content SET title = ?, description = ?, genre = ?, release_date = ?, content_type = ? WHERE content_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setString(3, genre);
            stmt.setDate(4, Date.valueOf(releaseDate));
            stmt.setString(5, contentType);
            stmt.setInt(6, contentId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Media content updated successfully.");
            } else {
                System.out.println("Content not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteMediaContent() {
        System.out.print("Enter content ID: ");
        int contentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection conn = utilities.jdbc_connection.getConnection()) {
            String sql = "DELETE FROM Content WHERE content_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, contentId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Media content deleted successfully.");
            } else {
                System.out.println("Content not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
