package utilities;

import java.sql.*;

public class jdbc_connection {
	private static Connection connection = null;
	private static String url = "jdbc:mysql://localhost:3306/media_management";
	private static String username = "root";
	private static String password = "password";

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("Connection Done");
		} catch (Exception e) {
			System.out.println("Connection Not Createted : " + e);
		}
		return connection;
	}
	public static void main(String[] args) {
		System.out.println(jdbc_connection.getConnection());
	}
}