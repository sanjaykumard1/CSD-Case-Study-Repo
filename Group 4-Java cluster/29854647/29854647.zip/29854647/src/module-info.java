/**
 * 
 */
/**
 * 
 */
module Consumer_Electronics_Store_Management_System {
	requires java.sql;
}