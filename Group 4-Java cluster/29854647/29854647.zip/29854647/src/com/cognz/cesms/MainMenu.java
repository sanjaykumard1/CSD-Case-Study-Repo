package com.cognz.cesms;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Product Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Order Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = 0;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }
            switch (choice) {
                case 1:
                    productManagementMenu(scanner);
                    break;
                case 2:
                    customerManagementMenu(scanner);
                    break;
                case 3:
                    orderManagementMenu(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the application...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void productManagementMenu(Scanner scanner) {
        while (true) {
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = 0;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
                continue;
            }
            switch (choice) {
                case 1:
                    ProductManagement.addProduct(scanner);
                    break;
                case 2:
                    ProductManagement.viewProduct(scanner);
                    break;
                case 3:
                    ProductManagement.updateProduct(scanner);
                    break;
                case 4:
                    ProductManagement.deleteProduct(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void customerManagementMenu(Scanner scanner) {
        while (true) {
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = 0;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); 
                continue;
            }
            switch (choice) {
                case 1:
                    CustomerManagement.addCustomer(scanner);
                    break;
                case 2:
                    CustomerManagement.viewCustomer(scanner);
                    break;
                case 3:
                    CustomerManagement.updateCustomer(scanner);
                    break;
                case 4:
                    CustomerManagement.deleteCustomer(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void orderManagementMenu(Scanner scanner) {
        while (true) {
            System.out.println("1. Place Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = 0;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                continue;
            }
            switch (choice) {
                case 1:
                    OrderManagement.placeOrder(scanner);
                    break;
                case 2:
                    OrderManagement.viewOrder(scanner);
                    break;
                case 3:
                    OrderManagement.updateOrder(scanner);
                    break;
                case 4:
                    OrderManagement.cancelOrder(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
