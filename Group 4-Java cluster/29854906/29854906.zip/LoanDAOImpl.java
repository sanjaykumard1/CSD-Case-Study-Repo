package lib;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



public class LoanDAOImpl implements LoanDAO{
	private static Scanner sc = new Scanner(System.in);

	public void issueBook() {
			try(Connection con = DBConnection.getConnection()){
				
//				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

				
				System.out.println("\nENTER BOOK ID: ");
				int bookId = sc.nextInt();
				System.out.println("\nENTER MEMBER ID: ");
				int memberId = sc.nextInt();
				sc.nextLine();
				System.out.println("\nENTER ISSUE DATE(yyyy-mm-dd): ");
				String issueDate = sc.nextLine();
//				Date date = formatter.parse(issueDate);

			
				
				String sql = "INSERT INTO Loan(book_id, member_id, issue_date, status) VALUES (?, ?, ?, 'issued')";
				
				PreparedStatement p = con.prepareStatement(sql);
				
				p.setInt(1, bookId);
				p.setInt(2, memberId);
				p.setDate(3, Date.valueOf(issueDate));
//				p.setDate(3, date);
				
				int rows = p.executeUpdate();
				
				if(rows>0) {
					System.out.println("\nBOOK ISSUED SUCCESSFULLY!");
					updateBookQuantity(con, bookId, -1);  
//					 reducing the quantity of the book
				}
				else {
					System.out.println("\nBOOK COULD NOT BE ISSUED!");
				}
			}
			catch(SQLException ex) {
				ex.printStackTrace();
			}
	}
	
	
	public void loanDetails() {
		
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER LOAN ID: ");
			int loanId = sc.nextInt();
			
			String sql = "SELECT * FROM Loan WHERE loan_id = ?";
			
			PreparedStatement p = con.prepareStatement(sql);
			
			p.setInt(1, loanId);
			
			ResultSet r = p.executeQuery();
			
			if(r.next()) {
				System.out.println("\n---------------------\n");
				System.out.println("LOAN ID: "+r.getInt("loan_id"));
				System.out.println("MEMBER ID: "+r.getInt("member_id"));
				System.out.println("BOOK ID: "+r.getInt("book_id"));
				System.out.println("RETURN DATE: "+r.getString("return_date"));
				System.out.println("ISSUE DATE: "+r.getString("issue_date"));
				System.out.println("STATUS: "+r.getString("status"));
				System.out.println("\n---------------------\n");
			}else {
				System.out.println("\nLOAN DETAILS COULDN'T BE FOUND WITH LOAN ID: "+loanId);
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
		
	}
	
	
	public void listAllLoansForMember() {
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER THE MEMBER ID: ");
			int memberId = sc.nextInt();
			
			String sql = "SELECT * FROM Loan WHERE member_id = ?";
			
			PreparedStatement p = con.prepareStatement(sql);
			
			p.setInt(1, memberId);
			
			ResultSet r = p.executeQuery();
			boolean hasLoans = false;
			
			while(r.next()) {
				hasLoans  = true;
				System.out.println("\n---------------------\n");
				System.out.println("LOAN ID: "+r.getInt("loan_id"));
				System.out.println("MEMBER ID: "+r.getInt("member_id"));
				System.out.println("BOOK ID: "+r.getInt("book_id"));
				System.out.println("RETURN DATE: "+r.getString("return_date"));
				System.out.println("ISSUE DATE: "+r.getString("issue_date"));
				System.out.println("STATUS: "+r.getString("status"));
				System.out.println("\n---------------------\n");			
				}
		
			if(!hasLoans) {
				System.out.println("\nNO LOANS FOUND FOR MEMEBR WITH ID "+memberId);
			}
		}		
		
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void returnBook() {
		try(Connection con = DBConnection.getConnection()){
			
			System.out.println("\nENTER THE LOAN ID: ");
			int loanId = sc.nextInt();
			System.out.println("\nENTER THE BOOK ID");
			int bookId = sc.nextInt();
			sc.nextLine();
			System.out.println("\nENTER THE RETURN DATE(yyyy-mm-dd): ");
			String returnDate = sc.nextLine();
			
			sc.nextLine();
			
			String sql = "UPDATE Loan SET return_date = ?, status = 'returned' WHERE loan_id = ?";
			
			PreparedStatement p = con.prepareStatement(sql);
			
			p.setDate(1, Date.valueOf(returnDate));
			p.setInt(2, loanId);
			
			int rows = p.executeUpdate();
			
			if(rows>0) {
				System.out.println("\nBOOK RETURNED SUCCESSFULLY!");
				updateBookQuantity(con, bookId, 1);
			}
			else {
				System.out.println("\nBOOK RETURN UNSUCCESSFUL!");
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	public static void updateBookQuantity(Connection con, int bookId, int quantityChange) throws SQLException {
		
//		updating the quantity of the book corresponding to the issuance/returning of book
		String sql = "UPDATE Book SET quantity = quantity+? where book_id = ?";
		
		PreparedStatement p = con.prepareStatement(sql);
		
		p.setInt(1, quantityChange);
		p.setInt(2, bookId);
		p.executeUpdate();
		
	}
}
