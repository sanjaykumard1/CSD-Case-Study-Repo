package lib;

//import java.sql.Connection;
//import java.sql.Date;
//import java.sql.PreparedStatement;
import java.sql.*;
import java.util.Scanner;

public class MemberDAOImpl implements MemberDAO{
	
	private static Scanner sc = new Scanner(System.in);
	public void registerMember() {
		
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER MEMBER NAME: ");
			String name = sc.nextLine();
			System.out.println("\nENTER EMAIL ID: ");
			String email = sc.nextLine();
			System.out.println("\nENTER PHONE NUMBER: ");
			String phone = sc.nextLine();
			System.out.println("\nENTER THE MEMBERSHIP DATE (YYYY-MM-DD): ");
			String membershipDate = sc.nextLine();
			
			String sql = "INSERT INTO Member (name, email, phone_no, membership_date) VALUES (?,?,?,?)";
			
			PreparedStatement p = con.prepareStatement(sql);
			p.setString(1, name);
			p.setString(2, email);
			p.setString(3, phone);
			p.setDate(4, Date.valueOf(membershipDate));
			
			
			int rows = p.executeUpdate();
			
			if(rows>0) {
				System.out.println("\nA NEWLY REGISTERED MEMBER IS ADDED SUCCESSFULLY!");
			}else {
				System.out.println("\nCOULDN'T ADD NEW MEMBER!");
			}

		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void viewMemberDetails() {
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER MEMBER ID: ");
			int memberId = sc.nextInt();
			
			String sql = "SELECT * FROM Member WHERE member_id = ?";
			PreparedStatement p = con.prepareStatement(sql);
			p.setInt(1, memberId);
			
			ResultSet r = p.executeQuery();
			
			if(r.next()) {
				System.out.println("\nMEMBER NAME: "+r.getString("name"));
				System.out.println("PHONE NUMBER: "+r.getString("phone_no"));
				System.out.println("EMAIL ID: "+r.getString("email"));
				System.out.println("MEMBERSHIP DATE: "+r.getDate("membership_date"));
			}else {
				System.out.println("\nCOULDN'T FIND MEMBER DETAILS WITH ID: "+memberId);
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void updateMemberInformation() {
		
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER ID OF MEMBER TO BE UPDATED: ");
			int memberId = sc.nextInt();
			sc.nextLine();
			

			System.out.println("\nENTER THE NEW NAME: ");
			String name = sc.nextLine();
			System.out.println("\nENTER THE NEW EMAIL: ");
			String email = sc.nextLine();
			System.out.println("\nENTER THE NEW PHONE NUMBER: ");
			String phone = sc.nextLine();	
//			sc.nextLine();
			System.out.println("\nENTER THE NEW MEMBERSHIP DATE (YYYY-MM-DD): ");
			String membershipDate = sc.nextLine();
			
			int r = -1;
			
//			String sql = "UPDATE Member SET name=?, email=?, phone_no=?, membership_date=? WHERE member_id=?";
			StringBuilder sql = new StringBuilder("UPDATE Member SET ");
			boolean first = true;
			
			if(!name.isEmpty()) {
				sql.append("name = ? ");
				first = false;
			}
			if(!email.isEmpty()) {
				if(!first) {
					sql.append(", ");
				}
				sql.append("email = ?");
				first = false;
			}
			if(!phone.isEmpty()) {
				if(!first) {
					sql.append(", ");
				}
				sql.append("phone_no = ?");
				first = false;
			}
			if(!membershipDate.isEmpty()) {
				if(!first) {
					sql.append(", ");
				}
				sql.append("membership_date = ?");
			}
			sql.append(" WHERE member_id = ?");
			
			PreparedStatement p = con.prepareStatement(sql.toString());
			int id = 1;
			
//			p.setString(1, name);
//			p.setString(2,  email);
//			p.setString(3,  phone);
//			p.setDate(4, Date.valueOf(membershipDate));
//			p.setInt(5, memberId);
			
			if(!name.isEmpty()) {
				p.setString(id++, name);
			}
			if(!email.isEmpty()) {
				p.setString(id++, email);
			}
			if(!phone.isEmpty()) {
				p.setString(id++, phone);
			}
			if(!membershipDate.isEmpty()) {
				p.setDate(id++, Date.valueOf(membershipDate));
			}
			p.setInt(id, memberId);
			
			r = p.executeUpdate();
			
			if(r>0) {
				System.out.println("\nROW UPDATED SUCCESFULLY!");
			}else {
				System.out.println("\nCOULDN'T UPDATE ROW!");
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	public void deleteMember() {
		
		try(Connection con = DBConnection.getConnection()){
			
			System.out.println("\nENTER THE ID OF THE MEMBER TO BE DELETED: ");
			int memberId = sc.nextInt();
			
			String sql = "DELETE FROM Member where member_id = ?";
			int r = -1;
			
			PreparedStatement p = con.prepareStatement(sql);
			
			p.setInt(1, memberId);
			
			r = p.executeUpdate();
			
			if(r>0) {
				System.out.println("\nROW DELETED SUCCESSFULLY!");
			}else {
				System.out.println("\nROW WITH ID "+memberId+" COULDN'T BE DELETED!");
			}
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
}
