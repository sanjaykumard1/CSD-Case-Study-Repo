package lib;

public interface MemberDAO {
	public void registerMember();
	public void viewMemberDetails();
	public void updateMemberInformation();
	public void deleteMember();
}
