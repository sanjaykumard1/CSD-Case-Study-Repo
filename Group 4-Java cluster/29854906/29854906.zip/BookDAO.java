package lib;

public interface BookDAO {
	public void addBook();
	public void viewBookDetails();
	public void updateBookInformation();
	public void deleteBook();
}
