package lib;

import java.util.Scanner;

public class LibrarySystem {
	
	private static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		

		while(true) {
			System.out.println("\n---------------------\n");
			System.out.println("\n\nLIBRARY SYSTEM");
			System.out.println("Choose an option:");
			System.out.println("1. BOOK MANAGEMENT");
			System.out.println("2. MEMBER MANAGEMENT");
			System.out.println("3. LOAN MANAGEMENT");
			System.out.println("4. EXIT");
			int choice = sc.nextInt();
			System.out.println("\n---------------------\n");

			sc.nextLine();
			
			switch(choice) {
			
			case 1 : manageBooks();
			break;
			
			case 2 : manageMembers();
			break;
			
			case 3 : manageLoans();
			break;
			
			case 4 : System.exit(0);
			break;
			
			default : System.out.println("\nINVALID CHOICE!");
			}

		}
	}
	
	
	private static void manageBooks() {
		
		BookDAOImpl ob = new BookDAOImpl();
		
		while(true) {
			System.out.println("\n---------------------\n");
			System.out.println("\n\nBOOK MANAGEMENT");
			System.out.println("Choose an option:");
			System.out.println("1. ADD BOOK");
			System.out.println("2. VIEW BOOK DETAILS");
			System.out.println("3. UPDATE BOOK INFORMATION");
			System.out.println("4. DELETE BOOK");
			System.out.println("5. MAIN MENU");
			int choice = sc.nextInt();
			System.out.println("\n---------------------\n");

			sc.nextLine();
			
			switch(choice) {
			
			case 1 : ob.addBook();
			break;
			
			case 2 : ob.viewBookDetails();
			break;
			
			case 3 : ob.updateBookInformation();
			break;
			
			case 4 : ob.deleteBook();
			break;
			
			case 5 :
				return;
				
			default: System.out.println("\nINVALID OPTION!");
			}
		}
	}
	
	public static void manageMembers() {
		
		MemberDAOImpl ob = new MemberDAOImpl();
		
		while(true) {
			System.out.println("\n---------------------\n");
			System.out.println("\n\nMEMBER MANAGEMENT");
			System.out.println("Choose an option:");
			System.out.println("1. REGISTER MEMBER");
			System.out.println("2. VIEW MEMBER DETAILS");
			System.out.println("3. UPDATE MEMBER INFORMATION");
			System.out.println("4. DELETE MEMBER");
			System.out.println("5. MAIN MENU");
			int choice = sc.nextInt();
			System.out.println("\n---------------------\n");

			
			sc.nextLine();
			
			switch(choice) {
			
			case 1 : ob.registerMember();
			break;
			
			case 2 : ob.viewMemberDetails();
			break;
			
			case 3 : ob.updateMemberInformation();
			break;
			
			case 4 : ob.deleteMember();
			break;
			
			case 5 :
				return;
				
			default: System.out.println("\nINVALID OPTION!");
			}

		}
	}
	
	public static void manageLoans() {
		
		LoanDAOImpl ob = new LoanDAOImpl();
		
		while(true) {
			System.out.println("\n---------------------\n");
			System.out.println("\n\nLOAN MANAGEMENT");
			System.out.println("Choose an option:");
			System.out.println("1. ISSUE BOOK");
			System.out.println("2. RETURN BOOK");
			System.out.println("3. VIEW LOAN DETAILS");
			System.out.println("4. LIST ALL LOANS FOR A MEMBER");
			System.out.println("5. MAIN MENU");
			int choice = sc.nextInt();
			System.out.println("\n---------------------\n");

			sc.nextLine();
			
			switch(choice) {
			
			case 1 : ob.issueBook();
			break;
			
			case 2 : ob.returnBook();
			break;
			
			case 3 : ob.loanDetails();
			break;
			
			case 4 : ob.listAllLoansForMember();
			break;
			
			case 5 :
				return;
				
			default: System.out.println("\nINVALID OPTION!");
			}
		}

	}
}
