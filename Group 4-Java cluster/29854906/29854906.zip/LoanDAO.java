package lib;

public interface LoanDAO {
	public void issueBook();
	public void loanDetails();
	public void listAllLoansForMember();
	public void returnBook();
}
