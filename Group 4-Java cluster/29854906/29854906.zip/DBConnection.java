package lib;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
import java.sql.*;

public class DBConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/LibraryDB";
	private static final String USER = "root";
	private static final String PASSWORD = "3Umbrellas@";
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
	
	
}

//public class DBConnection{
//	Connection c;
//	Statement s;
//	
//	public DBConnection() {
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//			c = DriverManager.getConnection("jdbc:mysql://localhost:3306/LibraryDB", "root", "3Umbrellas@");
//			s = c.createStatement();
//		}
//		catch(Exception e) {
//			System.out.println(e);
//		}
//	}
//}