package lib;

import java.util.*;
import java.sql.*;
import java.sql.Date;

public class BookDAOImpl implements BookDAO{
	private static Scanner sc = new Scanner(System.in);
	
	
	public void addBook() {
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER BOOK TITLE: ");
			String title = sc.nextLine();
			System.out.println("\nENTER BOOK AUTHOR: ");
			String author = sc.nextLine();
			System.out.println("\nENTER BOOK GENRE: ");
			String genre = sc.nextLine();
			System.out.println("\nENTER PUBLICATION YEAR: ");
			int year = sc.nextInt();
			System.out.println("\nENTER QUANTITY: ");
			int quantity = sc.nextInt();
			
			sc.nextLine();
			
			
			String sql = "INSERT INTO BOOK (title, author, genre, publication_year, quantity) VALUES (?,?,?,?,?)";
			PreparedStatement s = con.prepareStatement(sql);
			
			s.setString(1, title);
			s.setString(2, author);
			s.setString(3, genre);
			s.setInt(4,  year);
			s.setInt(5,  quantity);
			
			int rows = s.executeUpdate();
			if(rows>0) {
				System.out.println("\nA NEW BOOK HAS BEEN ADDED SUCCESSFULLY!");
			}
			
		}
		catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	
	public void viewBookDetails() {
		try(Connection con = DBConnection.getConnection()){
			System.out.println("\nENTER BOOK ID: ");
			int bookId = sc.nextInt();
			
			sc.nextLine();
			
			String sql = "SELECT * FROM Book WHERE book_id = ?";
			PreparedStatement s = con.prepareStatement(sql);
			s.setInt(1, bookId);
			
			ResultSet rs = s.executeQuery();
			
			if(rs.next()) {
				System.out.println("BOOK ID: "+rs.getInt("book_id"));
				System.out.println("TITLE: "+rs.getString("title"));
				System.out.println("AUTHOR: "+rs.getString("author"));
				System.out.println("GENRE: "+rs.getString("genre"));
				System.out.println("PUBLICATION YEAR: "+rs.getInt("publication_year"));
				System.out.println("QUANTITY: "+rs.getInt("quantity"));
				
			}else {
				System.out.println("\nBOOK NOT FOUND WITH ID: "+bookId);
			}
		}
			catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
	
	
	
	
	public void updateBookInformation() {
		
		
		try(Connection con = DBConnection.getConnection()){
			
			System.out.println("\nENTER BOOK ID TO FOR UPDATION");
			int bookId = sc.nextInt();
			sc.nextLine();
			
			System.out.println("\nENTER THE NEW BOOK TITLE: ");
			String title = sc.nextLine();
			System.out.println("\nENTER THE NEW BOOK AUTHOR: ");
			String author = sc.nextLine();
			System.out.println("\nENTER THE NEW BOOK GENRE: ");
			String genre = sc.nextLine();
			System.out.println("\nENTER THE NEW PUBLICATION YEAR: ");
			String yearInput = sc.nextLine();
			System.out.println("\nENTER THE NEW QUANTITY: ");
			String quantityInput = sc.nextLine();
			
			int r = -1;
			
			
			
			sc.nextLine();
								
//			String sql = "UPDATE Book SET title=?, author=?, genre=?, publication_year=?, quantity=? where book_id=?";
			StringBuilder sql = new StringBuilder("UPDATE Book SET ");
			boolean first = true;
		
			if(!title.isEmpty()) {
				sql.append("title = ?");
				first = false;
			}
			if(!author.isEmpty()) {
				if(!first) {
					sql.append(", ");
				}
				sql.append("author = ?");
				first = false;
			}
			if(!genre.isEmpty()) {
				if(!first) {
					sql.append(", ");
				}
				sql.append("genre = ?");
				first = false;
			}
			if(!yearInput.isEmpty()) {
				int year = Integer.parseInt(yearInput);
				if(year>0) {
					if(!first) {
						sql.append(", ");
					}
					sql.append("publication_year = ?");
					first = false;
				}
			}
			if(!quantityInput.isEmpty()) {
				int quantity = Integer.parseInt(yearInput);
				if(quantity>0) {
					if(!first) {
						sql.append(", ");
					}
					sql.append("quantity = ?");
				}
			}
			
			sql.append("WHERE book_id = ?");
			
			PreparedStatement p = con.prepareStatement(sql.toString());
			int id = 1;
//			p.setString(1, title);
//			p.setString(2, author);
//			p.setString(3, genre);
//			p.setInt(4, year);
//			p.setInt(5, quantity);
//				
			if(!title.isEmpty()) {
				p.setString(id++, title);
			}
			if(!author.isEmpty()) {
				p.setString(id++, author);
			}
			if(!genre.isEmpty()) {
				p.setString(id++, genre);
			}
			if(!yearInput.isEmpty()) {
				int year = Integer.parseInt(yearInput);
				if(year>0) {
					p.setInt(id++, year);
				}
			}
			if(!quantityInput.isEmpty()) {
				int quantity = Integer.parseInt(yearInput);
				if(quantity>0) {
					p.setInt(id++, quantity);
				}
			}
			p.setInt(id, bookId);
			
			r = p.executeUpdate();
			
			if(r==-1) {
				System.out.println("\nBOOK DETAILS COULDN'T BE UPDATED!");
				}
			else {
				System.out.println("\nBOOK DETAILS WITH ID "+bookId+" UPDATED!");
				}
			}
			catch(SQLException ex) {
				System.out.println(ex);
			}
		}
		
		
		
	public void deleteBook() {
		
		
		try(Connection con = DBConnection.getConnection()){
			
			System.out.println("\nENTER THE BOOK ID TO BE DELETED ");
			int bookId = sc.nextInt();
			
			String sql = "DELETE FROM Book where book_id=?";
			int r = -1;
			
			PreparedStatement p = con.prepareStatement(sql);
			p.setInt(1, bookId);
			
			r = p.executeUpdate();
			
			if(r==-1) {
				System.out.println("\nDELETE UNSUCCESSFUL!");
			}
			else {
				System.out.println("\nSUCCESSFULLY DELETED!");
			}
		}
		catch(SQLException ex) {
			System.out.println(ex);
		}
	}
}
