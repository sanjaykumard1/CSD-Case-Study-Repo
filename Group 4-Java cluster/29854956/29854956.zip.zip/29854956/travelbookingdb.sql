USE TravelBookingDB;

CREATE TABLE Destination (
    destination_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    description TEXT,
    price_per_day DECIMAL(10, 2) NOT NULL
);
CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL,
	address VARCHAR(255) NOT NULL
);

CREATE TABLE Booking (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    destination_id INT NOT NULL,
    customer_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_cost DECIMAL(10, 2) NOT NULL,
    status ENUM('confirmed', 'cancelled') NOT NULL,
    FOREIGN KEY (destination_id) REFERENCES Destination(destination_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

select*from travelbookingdb.booking;