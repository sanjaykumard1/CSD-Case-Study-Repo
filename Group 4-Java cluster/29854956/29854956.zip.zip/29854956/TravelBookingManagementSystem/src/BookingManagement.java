import java.sql.*;
import java.util.Scanner;

public class BookingManagement {

    public void createBooking() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter destination ID: ");
        int destinationId = scanner.nextInt();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter booking date (YYYY-MM-DD): ");
        String bookingDate = scanner.nextLine();
        System.out.print("Enter start date (YYYY-MM-DD): ");
        String startDate = scanner.nextLine();
        System.out.print("Enter end date (YYYY-MM-DD): ");
        String endDate = scanner.nextLine();

        String query = "SELECT price_per_day FROM Destination WHERE destination_id = ?";
        double pricePerDay = 0.0;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, destinationId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                pricePerDay = rs.getDouble("price_per_day");
            } else {
                System.out.println("Destination not found.");
                return;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching destination: " + e.getMessage());
            return;
        }

        long days = java.time.LocalDate.parse(startDate).until(java.time.LocalDate.parse(endDate)).getDays();
        double totalCost = days * pricePerDay;

        query = "INSERT INTO Booking (destination_id, customer_id, booking_date, start_date, end_date, total_cost, status) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, destinationId);
            pstmt.setInt(2, customerId);
            pstmt.setDate(3, Date.valueOf(bookingDate));
            pstmt.setDate(4, Date.valueOf(startDate));
            pstmt.setDate(5, Date.valueOf(endDate));
            pstmt.setDouble(6, totalCost);
            pstmt.setString(7, "confirmed");
            pstmt.executeUpdate();
            System.out.println("Booking created successfully.");
        } catch (SQLException e) {
            System.err.println("Error creating booking: " + e.getMessage());
        }
    }

    public void viewBookingDetails() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter booking ID: ");
        int id = scanner.nextInt();

        String query = "SELECT * FROM Booking WHERE booking_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("booking_id"));
                System.out.println("Destination ID: " + rs.getInt("destination_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Booking Date: " + rs.getDate("booking_date"));
                System.out.println("Start Date: " + rs.getDate("start_date"));
                System.out.println("End Date: " + rs.getDate("end_date"));
                System.out.println("Total Cost: " + rs.getDouble("total_cost"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Booking not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing booking: " + e.getMessage());
        }
    }

    public void updateBooking() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter booking ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new destination ID: ");
        int destinationId = scanner.nextInt();
        System.out.print("Enter new customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new start date (YYYY-MM-DD): ");
        String startDate = scanner.nextLine();
        System.out.print("Enter new end date (YYYY-MM-DD): ");
        String endDate = scanner.nextLine();

        String query = "SELECT price_per_day FROM Destination WHERE destination_id = ?";
        double pricePerDay = 0.0;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, destinationId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                pricePerDay = rs.getDouble("price_per_day");
            } else {
                System.out.println("Destination not found.");
                return;
            }
        } catch (SQLException e) {
            System.err.println("Error fetching destination: " + e.getMessage());
            return;
        }

        long days = java.time.LocalDate.parse(startDate).until(java.time.LocalDate.parse(endDate)).getDays();
        double totalCost = days * pricePerDay;

        query = "UPDATE Booking SET destination_id = ?, customer_id = ?, start_date = ?, end_date = ?, total_cost = ? WHERE booking_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, destinationId);
            pstmt.setInt(2, customerId);
            pstmt.setDate(3, Date.valueOf(startDate));
            pstmt.setDate(4, Date.valueOf(endDate));
            pstmt.setDouble(5, totalCost);
            pstmt.setInt(6, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Booking updated successfully.");
            } else {
                System.out.println("Booking not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating booking: " + e.getMessage());
        }
    }

    public void cancelBooking() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter booking ID: ");
        int id = scanner.nextInt();

        String query = "UPDATE Booking SET status = 'cancelled' WHERE booking_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Booking cancelled successfully.");
            } else {
                System.out.println("Booking not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error cancelling booking: " + e.getMessage());
        }
    }
}
