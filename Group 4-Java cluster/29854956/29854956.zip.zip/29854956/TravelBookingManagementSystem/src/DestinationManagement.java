import java.sql.*;
import java.util.Scanner;

public class DestinationManagement {

    public void addDestination() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter destination name: ");
        String name = scanner.nextLine();
        System.out.print("Enter location: ");
        String location = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        System.out.print("Enter price per day: ");
        double pricePerDay = scanner.nextDouble();

        String query = "INSERT INTO Destination (name, location, description, price_per_day) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, location);
            pstmt.setString(3, description);
            pstmt.setDouble(4, pricePerDay);
            pstmt.executeUpdate();
            System.out.println("Destination added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding destination: " + e.getMessage());
        }
    }

    public void viewDestinationDetails() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter destination ID: ");
        int id = scanner.nextInt();

        String query = "SELECT * FROM Destination WHERE destination_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("ID: " + rs.getInt("destination_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Location: " + rs.getString("location"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price per day: " + rs.getDouble("price_per_day"));
            } else {
                System.out.println("Destination not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing destination: " + e.getMessage());
        }
    }

    public void updateDestination() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter destination ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new location: ");
        String location = scanner.nextLine();
        System.out.print("Enter new description: ");
        String description = scanner.nextLine();
        System.out.print("Enter new price per day: ");
        double pricePerDay = scanner.nextDouble();

        String query = "UPDATE Destination SET name = ?, location = ?, description = ?, price_per_day = ? WHERE destination_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, location);
            pstmt.setString(3, description);
            pstmt.setDouble(4, pricePerDay);
            pstmt.setInt(5, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Destination updated successfully.");
            } else {
                System.out.println("Destination not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating destination: " + e.getMessage());
        }
    }

    public void deleteDestination() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter destination ID: ");
        int id = scanner.nextInt();

        String query = "DELETE FROM Destination WHERE destination_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Destination deleted successfully.");
            } else {
                System.out.println("Destination not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting destination: " + e.getMessage());
        }
    }
}

