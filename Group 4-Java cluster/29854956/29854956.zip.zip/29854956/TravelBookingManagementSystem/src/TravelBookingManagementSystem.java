import java.util.Scanner;

public class TravelBookingManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DestinationManagement destinationManagement = new DestinationManagement();
        CustomerManagement customerManagement = new CustomerManagement();
        BookingManagement bookingManagement = new BookingManagement();

        while (true) {
            System.out.println("Welcome to the Travel Booking Management System");
            System.out.println("1. Manage Destinations");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Bookings");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageDestinations(destinationManagement, scanner);
                    break;
                case 2:
                    manageCustomers(customerManagement, scanner);
                    break;
                case 3:
                    manageBookings(bookingManagement, scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void manageDestinations(DestinationManagement destinationManagement, Scanner scanner) {
        System.out.println("Destination Management");
        System.out.println("1. Add Destination");
        System.out.println("2. View Destination Details");
        System.out.println("3. Update Destination");
        System.out.println("4. Delete Destination");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                destinationManagement.addDestination();
                break;
            case 2:
                destinationManagement.viewDestinationDetails();
                break;
            case 3:
                destinationManagement.updateDestination();
                break;
            case 4:
                destinationManagement.deleteDestination();
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }

    private static void manageCustomers(CustomerManagement customerManagement, Scanner scanner) {
        System.out.println("Customer Management");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                customerManagement.addCustomer();
                break;
            case 2:
                customerManagement.viewCustomerDetails();
                break;
            case 3:
                customerManagement.updateCustomer();
                break;
            case 4:
                customerManagement.deleteCustomer();
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }

    private static void manageBookings(BookingManagement bookingManagement, Scanner scanner) {
        System.out.println("Booking Management");
        System.out.println("1. Create Booking");
        System.out.println("2. View Booking Details");
        System.out.println("3. Update Booking");
        System.out.println("4. Cancel Booking");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                bookingManagement.createBooking();
                break;
            case 2:
                bookingManagement.viewBookingDetails();
                break;
            case 3:
                bookingManagement.updateBooking();
                break;
            case 4:
                bookingManagement.cancelBooking();
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }
}
