# Transportation and Logistics Management System

## Overview
This is a menu-based console application developed in Core Java that simulates a transportation and logistics management system. It allows users to manage shipments, vehicles, and drivers using MySQL and JDBC for database interactions.

## Features
1. **Shipment Management:**
   - Add a new shipment
   - View shipment details
   - Update shipment information
   - Delete a shipment

2. **Vehicle Management:**
   - Add a new vehicle
   - View vehicle details
   - Update vehicle information
   - Delete a vehicle

3. **Driver Management:**
   - Add a new driver
   - View driver details
   - Update driver information
   - Delete a driver

## Database Schema
### Shipment Table:
- `shipment_id` (Primary Key)
- `description`
- `origin`
- `destination`
- `status` (in-transit/delivered)
- `delivery_date`

### Vehicle Table:
- `vehicle_id` (Primary Key)
- `make`
- `model`
- `year`
- `capacity`

### Driver Table:
- `driver_id` (Primary Key)
- `name`
- `email`
- `phone_number`
- `license_number`

## Setup Instructions

### Prerequisites
- Java Development Kit (JDK) 8 or higher
- MySQL Server
- MySQL Connector/J (JDBC driver)

### Steps

 **Clone the Repository:**
   
   git clone https://github.com/your-username/transportation-logistics-management-system.git
   cd transportation-logistics-management-system

 **Set Up MySQL Database:**

Start your MySQL server.
Create a new database named logistics_management.
Create the required tables:
sql
Copy code
CREATE DATABASE logistics_management;

USE logistics_management;

CREATE TABLE Shipment (
    shipment_id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255),
    origin VARCHAR(255),
    destination VARCHAR(255),
    status VARCHAR(50),
    delivery_date DATE
);

CREATE TABLE Vehicle (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(255),
    model VARCHAR(255),
    year INT,
    capacity INT
);

CREATE TABLE Driver (
    driver_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone_number VARCHAR(15),
    license_number VARCHAR(50)
);

**Configure Database Connection:**

Open the DatabaseConnection.java file in the com.logistics package.
Update the USER and PASSWORD fields with your MySQL credentials.
java
Copy code
private static final String USER = "yourUsername"; // Replace with your MySQL username
private static final String PASSWORD = "yourPassword"; // Replace with your MySQL password

**Add MySQL Connector/J to Your Project:**

Download the MySQL Connector/J from MySQL Connector/J.
Add the JAR file to your project's build path.
In Eclipse:

Right-click on your project in the Project Explorer.
Select Build Path -> Configure Build Path.
Go to the Libraries tab and click on Add External JARs.
Navigate to the location where you downloaded the MySQL Connector/J, select the JAR file, and click Open.
Click Apply and Close.
Compile and Run:

Compile the Java files.
Run the Main class to start the application.
Usage Instructions
Run the application.
Use the main menu to navigate to the desired management section (Shipments, Vehicles, Drivers).
Follow the prompts to add, view, update, or delete records.
Exception Handling
The application includes basic exception handling to manage SQL exceptions and provide user-friendly error messages.

Code Conventions
The code follows standard Java coding conventions and is well-documented with comments for clarity.


Thank you for using the Transportation and Logistics Management System!