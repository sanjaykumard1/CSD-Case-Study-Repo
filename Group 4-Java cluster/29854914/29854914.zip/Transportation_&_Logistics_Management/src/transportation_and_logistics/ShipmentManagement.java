package transportation_and_logistics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ShipmentManagement {
    public static void addShipment() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter description:");
            String description = scanner.nextLine();
            System.out.println("Enter origin:");
            String origin = scanner.nextLine();
            System.out.println("Enter destination:");
            String destination = scanner.nextLine();
            System.out.println("Enter status (in-transit/delivered):");
            String status = scanner.nextLine();
            System.out.println("Enter delivery date (YYYY-MM-DD):");
            String deliveryDate = scanner.nextLine();

            String query = "INSERT INTO shipment (description, origin, destination, status, delivery_date) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, description);
            stmt.setString(2, origin);
            stmt.setString(3, destination);
            stmt.setString(4, status);
            stmt.setString(5, deliveryDate);

            stmt.executeUpdate();
            System.out.println("Shipment added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewShipment() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter shipment ID to view details:");
            int shipmentId = scanner.nextInt();

            String query = "SELECT * FROM shipment WHERE shipment_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, shipmentId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Shipment ID: " + rs.getInt("shipment_id"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Origin: " + rs.getString("origin"));
                System.out.println("Destination: " + rs.getString("destination"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("Delivery Date: " + rs.getDate("delivery_date"));
            } else {
                System.out.println("Shipment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateShipment() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter shipment ID to update:");
            int shipmentId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            System.out.println("Enter new description:");
            String description = scanner.nextLine();
            System.out.println("Enter new origin:");
            String origin = scanner.nextLine();
            System.out.println("Enter new destination:");
            String destination = scanner.nextLine();
            System.out.println("Enter new status (in-transit/delivered):");
            String status = scanner.nextLine();
            System.out.println("Enter new delivery date (YYYY-MM-DD):");
            String deliveryDate = scanner.nextLine();

            String query = "UPDATE shipment SET description = ?, origin = ?, destination = ?, status = ?, delivery_date = ? WHERE shipment_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, description);
            stmt.setString(2, origin);
            stmt.setString(3, destination);
            stmt.setString(4, status);
            stmt.setString(5, deliveryDate);
            stmt.setInt(6, shipmentId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Shipment updated successfully!");
            } else {
                System.out.println("Shipment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteShipment() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter shipment ID to delete:");
            int shipmentId = scanner.nextInt();

            String query = "DELETE FROM shipment WHERE shipment_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, shipmentId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Shipment deleted successfully!");
            } else {
                System.out.println("Shipment not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}