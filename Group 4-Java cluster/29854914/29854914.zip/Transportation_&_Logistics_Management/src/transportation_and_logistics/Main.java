package transportation_and_logistics;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nTransportation and Logistics Management System");
            System.out.println("1. Shipment Management");
            System.out.println("2. Vehicle Management");
            System.out.println("3. Driver Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    shipmentMenu();
                    break;
                case 2:
                    vehicleMenu();
                    break;
                case 3:
                    driverMenu();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void shipmentMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nShipment Management");
        System.out.println("1. Add Shipment");
        System.out.println("2. View Shipment");
        System.out.println("3. Update Shipment");
        System.out.println("4. Delete Shipment");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                ShipmentManagement.addShipment();
                break;
            case 2:
                ShipmentManagement.viewShipment();
                break;
            case 3:
                ShipmentManagement.updateShipment();
                break;
            case 4:
                ShipmentManagement.deleteShipment();
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void vehicleMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nVehicle Management");
        System.out.println("1. Add Vehicle");
        System.out.println("2. View Vehicle");
        System.out.println("3. Update Vehicle");
        System.out.println("4. Delete Vehicle");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                VehicleManagement.addVehicle();
                break;
            case 2:
                VehicleManagement.viewVehicle();
                break;
            case 3:
                VehicleManagement.updateVehicle();
                break;
            case 4:
                VehicleManagement.deleteVehicle();
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void driverMenu() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nDriver Management");
        System.out.println("1. Add Driver");
        System.out.println("2. View Driver");
        System.out.println("3. Update Driver");
        System.out.println("4. Delete Driver");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                DriverManagement.addDriver();
                break;
            case 2:
                DriverManagement.viewDriver();
                break;
            case 3:
                DriverManagement.updateDriver();
                break;
            case 4:
                DriverManagement.deleteDriver();
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}