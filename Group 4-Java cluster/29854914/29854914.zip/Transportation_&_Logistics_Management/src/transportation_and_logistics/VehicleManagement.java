package transportation_and_logistics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class VehicleManagement {
    public static void addVehicle() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter make:");
            String make = scanner.nextLine();
            System.out.println("Enter model:");
            String model = scanner.nextLine();
            System.out.println("Enter year:");
            int year = scanner.nextInt();
            System.out.println("Enter capacity:");
            int capacity = scanner.nextInt();

            String query = "INSERT INTO vehicle (make, model, year, capacity) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, make);
            stmt.setString(2, model);
            stmt.setInt(3, year);
            stmt.setInt(4, capacity);

            stmt.executeUpdate();
            System.out.println("Vehicle added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewVehicle() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter vehicle ID to view details:");
            int vehicleId = scanner.nextInt();

            String query = "SELECT * FROM vehicle WHERE vehicle_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, vehicleId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Make: " + rs.getString("make"));
                System.out.println("Model: " + rs.getString("model"));
                System.out.println("Year: " + rs.getInt("year"));
                System.out.println("Capacity: " + rs.getInt("capacity"));
            } else {
                System.out.println("Vehicle not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateVehicle() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter vehicle ID to update:");
            int vehicleId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            System.out.println("Enter new make:");
            String make = scanner.nextLine();
            System.out.println("Enter new model:");
            String model = scanner.nextLine();
            System.out.println("Enter new year:");
            int year = scanner.nextInt();
            System.out.println("Enter new capacity:");
            int capacity = scanner.nextInt();

            String query = "UPDATE vehicle SET make = ?, model = ?, year = ?, capacity = ? WHERE vehicle_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, make);
            stmt.setString(2, model);
            stmt.setInt(3, year);
            stmt.setInt(4, capacity);
            stmt.setInt(5, vehicleId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Vehicle updated successfully!");
            } else {
                System.out.println("Vehicle not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteVehicle() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter vehicle ID to delete:");
            int vehicleId = scanner.nextInt();

            String query = "DELETE FROM vehicle WHERE vehicle_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, vehicleId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Vehicle deleted successfully!");
            } else {
                System.out.println("Vehicle not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}