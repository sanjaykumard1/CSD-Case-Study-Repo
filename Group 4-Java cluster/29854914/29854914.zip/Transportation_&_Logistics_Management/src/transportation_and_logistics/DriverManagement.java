package transportation_and_logistics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DriverManagement {
    public static void addDriver() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter name:");
            String name = scanner.nextLine();
            System.out.println("Enter email:");
            String email = scanner.nextLine();
            System.out.println("Enter phone number:");
            String phoneNumber = scanner.nextLine();
            System.out.println("Enter license number:");
            String licenseNumber = scanner.nextLine();

            String query = "INSERT INTO driver (name, email, phone_number, license_number) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, licenseNumber);

            stmt.executeUpdate();
            System.out.println("Driver added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewDriver() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter driver ID to view details:");
            int driverId = scanner.nextInt();

            String query = "SELECT * FROM driver WHERE driver_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, driverId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Driver ID: " + rs.getInt("driver_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("License Number: " + rs.getString("license_number"));
            } else {
                System.out.println("Driver not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateDriver() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter driver ID to update:");
            int driverId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            System.out.println("Enter new name:");
            String name = scanner.nextLine();
            System.out.println("Enter new email:");
            String email = scanner.nextLine();
            System.out.println("Enter new phone number:");
            String phoneNumber = scanner.nextLine();
            System.out.println("Enter new license number:");
            String licenseNumber = scanner.nextLine();

            String query = "UPDATE driver SET name = ?, email = ?, phone_number = ?, license_number = ? WHERE driver_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, licenseNumber);
            stmt.setInt(5, driverId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Driver updated successfully!");
            } else {
                System.out.println("Driver not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteDriver() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter driver ID to delete:");
            int driverId = scanner.nextInt();

            String query = "DELETE FROM driver WHERE driver_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, driverId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Driver deleted successfully!");
            } else {
                System.out.println("Driver not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}