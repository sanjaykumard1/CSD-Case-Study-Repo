package main.dao;
import main.db.Dbconnection;
import main.model.Order;
import main.model.OrderItem;
import main.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class OrderDAO {
	public void placeOrder(Order order) {
        String orderQuery = "INSERT INTO `Order` (customer_id, order_date, status) VALUES (?, ?, ?)";
        String orderItemQuery = "INSERT INTO OrderItems (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        try (Connection connection = Dbconnection.getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement orderStatement = connection.prepareStatement(orderQuery, Statement.RETURN_GENERATED_KEYS)) {
                orderStatement.setInt(1, order.getCustomerId());
                orderStatement.setDate(2, new Date(order.getOrderDate().getTime()));
                orderStatement.setString(3, order.getStatus());
                orderStatement.executeUpdate();

                ResultSet generatedKeys = orderStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int orderId = generatedKeys.getInt(1);
                    try (PreparedStatement orderItemStatement = connection.prepareStatement(orderItemQuery)) {
                        for (OrderItem orderItem : order.getOrderItems()) {
                            orderItemStatement.setInt(1, orderId);
                            orderItemStatement.setInt(2, orderItem.getProductId());
                            orderItemStatement.setInt(3, orderItem.getQuantity());
                            orderItemStatement.setDouble(4, orderItem.getPrice());
                            orderItemStatement.executeUpdate();
                        }
                    }
                }
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Order getOrder(int orderId) {
        String orderQuery = "SELECT * FROM `Order` WHERE order_id = ?";
        String orderItemQuery = "SELECT * FROM OrderItems WHERE order_id = ?";
        try (Connection connection = Dbconnection.getConnection()) {
            try (PreparedStatement orderStatement = connection.prepareStatement(orderQuery)) {
                orderStatement.setInt(1, orderId);
                ResultSet orderResultSet = orderStatement.executeQuery();
                if (orderResultSet.next()) {
                    Order order = new Order();
                    order.setOrderId(orderResultSet.getInt("order_id"));
                    order.setCustomerId(orderResultSet.getInt("customer_id"));
                    order.setOrderDate(orderResultSet.getDate("order_date"));
                    order.setStatus(orderResultSet.getString("status"));

                    try (PreparedStatement orderItemStatement = connection.prepareStatement(orderItemQuery)) {
                        orderItemStatement.setInt(1, orderId);
                        ResultSet orderItemResultSet = orderItemStatement.executeQuery();
                        List<OrderItem> orderItems = new ArrayList<>();
                        while (orderItemResultSet.next()) {
                            OrderItem orderItem = new OrderItem();
                            orderItem.setOrderItemId(orderItemResultSet.getInt("order_item_id"));
                            orderItem.setOrderId(orderItemResultSet.getInt("order_id"));
                            orderItem.setProductId(orderItemResultSet.getInt("product_id"));
                            orderItem.setQuantity(orderItemResultSet.getInt("quantity"));
                            orderItem.setPrice(orderItemResultSet.getDouble("price"));
                            orderItems.add(orderItem);
                        }
                        order.setOrderItems(orderItems);
                    }
                    return order;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateOrderStatus(int orderId, String status) {
        String query = "UPDATE `Order` SET status = ? WHERE order_id = ?";
        try (Connection connection = Dbconnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, status);
            preparedStatement.setInt(2, orderId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void cancelOrder(int orderId) {
        updateOrderStatus(orderId, "Cancelled");
    }

    public List<Order> getAllOrders() {
        List<Order> orders = new ArrayList<>();
        String orderQuery = "SELECT * FROM `Order`";
        String orderItemQuery = "SELECT * FROM OrderItems WHERE order_id = ?";
        try (Connection connection = Dbconnection.getConnection();
             Statement orderStatement = connection.createStatement();
             ResultSet orderResultSet = orderStatement.executeQuery(orderQuery)) {
            while (orderResultSet.next()) {
                Order order = new Order();
                order.setOrderId(orderResultSet.getInt("order_id"));
                order.setCustomerId(orderResultSet.getInt("customer_id"));
                order.setOrderDate(orderResultSet.getDate("order_date"));
                order.setStatus(orderResultSet.getString("status"));

                try (PreparedStatement orderItemStatement = connection.prepareStatement(orderItemQuery)) {
                    orderItemStatement.setInt(1, order.getOrderId());
                    ResultSet orderItemResultSet = orderItemStatement.executeQuery();
                    List<OrderItem> orderItems = new ArrayList<>();
                    while (orderItemResultSet.next()) {
                        OrderItem orderItem = new OrderItem();
                        orderItem.setOrderItemId(orderItemResultSet.getInt("order_item_id"));
                        orderItem.setOrderId(orderItemResultSet.getInt("order_id"));
                        orderItem.setProductId(orderItemResultSet.getInt("product_id"));
                        orderItem.setQuantity(orderItemResultSet.getInt("quantity"));
                        orderItem.setPrice(orderItemResultSet.getDouble("price"));
                        orderItems.add(orderItem);
                    }
                    order.setOrderItems(orderItems);
                }
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}

	