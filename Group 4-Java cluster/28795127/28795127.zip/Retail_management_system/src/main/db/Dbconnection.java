package main.db;

import java.sql.Connection;
import java.sql.DriverManager;


public class Dbconnection {

		// TODO Auto-generated method stub
		public static Connection connection = null;
		private static String url = "jdbc:mysql://localhost:3306/online_retail";
		private static String username = "root";
		private static String password = "arthi2411";

		public static Connection getConnection() {
			try {
				connection = DriverManager.getConnection(url, username, password);
				System.out.println("Connection Done");
			} catch (Exception e) {
				System.out.println("Connection Not Createted : " + e);
			}
			return connection;
	   }

	}



