package src;

import main.dao.OrderDAO;
import main.dao.ProductDAO;
import main.model.Order;
import main.model.OrderItem;
import main.model.Product;
import main.dao.CustomerDAO;
import main.model.Customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
	private static final Scanner scanner = new Scanner(System.in);
    private static final ProductDAO productDAO = new ProductDAO();
    private static final OrderDAO orderDAO = new OrderDAO();
    private static final CustomerDAO customerDAO = new CustomerDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Orders");
            System.out.println("3. Exit");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageOrders();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

   
    private static void manageProducts() {
        while (true) {
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. View All Products");
            System.out.println("6. Back to Main Menu");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewProduct();
                    break;
                case 3:
                    updateProduct();
                    break;
                case 4:
                    deleteProduct();
                    break;
                case 5:
                    viewAllProducts();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addProduct() {
        System.out.println("Enter product name: ");
        String name = scanner.next();
        System.out.println("Enter product description: ");
        String description = scanner.next();
        System.out.println("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter stock quantity: ");
        int stockQuantity = scanner.nextInt();

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setStockQuantity(stockQuantity);

        productDAO.addProduct(product);
        System.out.println("Product added successfully.");
    }

    private static void viewProduct() {
        System.out.println("Enter product ID: ");
        int productId = scanner.nextInt();
        Product product = productDAO.getProduct(productId);
        if (product != null) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Name: " + product.getName());
            System.out.println("Description: " + product.getDescription());
            System.out.println("Price: " + product.getPrice());
            System.out.println("Stock Quantity: " + product.getStockQuantity());
        } else {
            System.out.println("Product not found.");
        }
    }

    private static void updateProduct() {
        System.out.println("Enter product ID: ");
        int productId = scanner.nextInt();
        Product product = productDAO.getProduct(productId);
        if (product != null) {
            System.out.println("Enter new name: ");
            product.setName(scanner.next());
            System.out.println("Enter new description: ");
            product.setDescription(scanner.next());
            System.out.println("Enter new price: ");
            product.setPrice(scanner.nextDouble());
            System.out.println("Enter new stock quantity: ");
            product.setStockQuantity(scanner.nextInt());

            productDAO.updateProduct(product);
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }

    private static void deleteProduct() {
        System.out.println("Enter product ID: ");
        int productId = scanner.nextInt();
        productDAO.deleteProduct(productId);
        System.out.println("Product deleted successfully.");
    }

    private static void viewAllProducts() {
        List<Product> products = productDAO.getAllProducts();
        for (Product product : products) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Name: " + product.getName());
            System.out.println("Description: " + product.getDescription());
            System.out.println("Price: " + product.getPrice());
            System.out.println("Stock Quantity: " + product.getStockQuantity());
            System.out.println("-----------------------------");
        }
    }

    private static void manageOrders() {
        while (true) {
            System.out.println("1. Place Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order Status");
            System.out.println("4. Cancel Order");
            System.out.println("5. View All Orders");
            System.out.println("6. Back to Main Menu");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    placeOrder();
                    break;
                case 2:
                    viewOrder();
                    break;
                case 3:
                    updateOrderStatus();
                    break;
                case 4:
                    cancelOrder();
                    break;
                case 5:
                    viewAllOrders();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void placeOrder() {
        System.out.println("Enter customer ID (or type 'new' to add a new customer): ");
        String input = scanner.next();
        
        int customerId;
        if (input.equalsIgnoreCase("new")) {
            customerId = addNewCustomer(); // Method to add a new customer
        } else {
            customerId = Integer.parseInt(input);
            if (!customerDAO.customerExists(customerId)) {
                System.out.println("Customer not found. Please add the customer first.");
                return; // Exit if customer doesn't exist
            }
        }

        Date orderDate = new Date();
        String status = "Processing";

        List<OrderItem> orderItems = new ArrayList<>();
        while (true) {
            System.out.println("Enter product ID: ");
            int productId = scanner.nextInt();
            System.out.println("Enter quantity: ");
            int quantity = scanner.nextInt();

            Product product = productDAO.getProduct(productId);
            if (product != null) {
                OrderItem orderItem = new OrderItem();
                orderItem.setProductId(productId);
                orderItem.setQuantity(quantity);
                orderItem.setPrice(product.getPrice() * quantity);
                orderItems.add(orderItem);
            } else {
                System.out.println("Product not found.");
            }

            System.out.println("Do you want to add more items to the order? (yes/no): ");
            String choice = scanner.next();
            if (!choice.equalsIgnoreCase("yes")) {
                break;
            }
        }

        Order order = new Order();
        order.setCustomerId(customerId);
        order.setOrderDate(orderDate);
        order.setStatus(status);
        order.setOrderItems(orderItems);

        orderDAO.placeOrder(order);
        System.out.println("Order placed successfully.");
    }

    private static int addNewCustomer() {
        System.out.println("Enter customer name: ");
        String name = scanner.next();
        System.out.println("Enter customer email: ");
        String email = scanner.next();
        System.out.println("Enter customer phone: ");
        String phone = scanner.next();
        System.out.println("Enter customer address: ");
        String address = scanner.next();

        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhone(phone);
        customer.setAddress(address);

        customerDAO.addCustomer(customer);
        System.out.println("Customer added successfully.");

        // Assuming the addCustomer method sets the customer ID after insertion
        return customer.getCustomerId(); // Return the new customer's ID
    }

    private static void viewOrder() {
        System.out.println("Enter order ID: ");
        int orderId = scanner.nextInt();
        Order order = orderDAO.getOrder(orderId);
        if (order != null) {
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Customer ID: " + order.getCustomerId());
            System.out.println("Order Date: " + order.getOrderDate());
            System.out.println("Status: " + order.getStatus());
            System.out.println("Order Items:");
            for (OrderItem orderItem : order.getOrderItems()) {
                System.out.println("    Product ID: " + orderItem.getProductId());
                System.out.println("    Quantity: " + orderItem.getQuantity());
                System.out.println("    Price: " + orderItem.getPrice());
                System.out.println("    ----------------------");
            }
        } else {
            System.out.println("Order not found.");
        }
    }

    private static void updateOrderStatus() {
        System.out.println("Enter order ID: ");
        int orderId = scanner.nextInt();
        System.out.println("Enter new status (Processing, Shipped, Delivered, Cancelled): ");
        String status = scanner.next();

        orderDAO.updateOrderStatus(orderId, status);
        System.out.println("Order status updated successfully.");
    }

    private static void cancelOrder() {
        System.out.println("Enter order ID: ");
        int orderId = scanner.nextInt();
        orderDAO.cancelOrder(orderId);
        System.out.println("Order cancelled successfully.");
    }

    private static void viewAllOrders() {
        List<Order> orders = orderDAO.getAllOrders();
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId());
            System.out.println("Customer ID: " + order.getCustomerId());
            System.out.println("Order Date: " + order.getOrderDate());
            System.out.println("Status: " + order.getStatus());
            System.out.println("Order Items:");
            for (OrderItem orderItem : order.getOrderItems()) {
                System.out.println("    Product ID: " + orderItem.getProductId());
                System.out.println("    Quantity: " + orderItem.getQuantity());
                System.out.println("    Price: " + orderItem.getPrice());
                System.out.println("    ----------------------");
            }
        }
    }
}

	