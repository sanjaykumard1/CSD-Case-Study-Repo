import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductService productService = new ProductService();
        SalesService salesService = new SalesService();  
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add Product");
            System.out.println("2. View Product Details");
            System.out.println("3. Update Product Information");
            System.out.println("4. Delete Product");
            System.out.println("5. Display List of Products");
            System.out.println("6. Record Sale");
            System.out.println("7. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    productService.addProduct();
                    break;
                case 2:
                    productService.viewProductDetails();
                    break;
                case 3:
                    productService.updateProduct();
                    break;
                case 4:
                    productService.deleteProduct();
                    break;
                case 5:
                    productService.displayProducts();
                    break;
                case 6:
                    salesService.recordSale();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}