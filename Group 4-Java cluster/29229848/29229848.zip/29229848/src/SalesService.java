import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;

public class SalesService {
    private Scanner scanner = new Scanner(System.in);

    public void recordSale() {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter quantity sold: ");
        int quantitySold = scanner.nextInt();
        
        try (Connection conn = DatabaseUtil.getConnection()) {
            String query = "SELECT price, quantity_in_stock FROM Product WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int quantityInStock = rs.getInt("quantity_in_stock");
                if (quantityInStock < quantitySold) {
                    System.out.println("Insufficient stock.");
                    return;
                }
                
                double price = rs.getDouble("price");
                double totalAmount = price * quantitySold;
                query = "INSERT INTO Sale (product_id, sale_date, quantity_sold, total_amount) VALUES (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, productId);
                pstmt.setDate(2, Date.valueOf(LocalDate.now()));
                pstmt.setInt(3, quantitySold);
                pstmt.setDouble(4, totalAmount);
                pstmt.executeUpdate();
                query = "UPDATE Product SET quantity_in_stock = quantity_in_stock - ? WHERE product_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, quantitySold);
                pstmt.setInt(2, productId);
                pstmt.executeUpdate();
                
                System.out.println("Sale recorded successfully.");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}