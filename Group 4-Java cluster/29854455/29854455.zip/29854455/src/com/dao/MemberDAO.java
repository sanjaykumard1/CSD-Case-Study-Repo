package com.dao;
import java.sql.SQLException;
import java.util.List;
import com.model.Member;

public interface MemberDAO {
	boolean insertMember(Member member) throws SQLException;
	List<Member> listAllMembers() throws SQLException;
	boolean deleteMember(Member member) throws SQLException ;
	boolean updateMember(Member member) throws SQLException;
	Member getMember(int member_id) throws SQLException;
	
}
