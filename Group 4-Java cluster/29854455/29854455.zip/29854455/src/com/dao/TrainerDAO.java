package com.dao;

import com.model.Member;

import java.sql.SQLException;
import java.util.List;
import com.model.Trainer;

public interface TrainerDAO {
    boolean insertTrainer(Trainer trainer) throws SQLException;
    List<Trainer> listAllTrainer() throws SQLException;
    boolean deleteTrainer(Trainer trainer) throws SQLException ;
    boolean updateTrainer(Trainer trainer)throws SQLException;
    Trainer getTrainer(int trainer_id) throws SQLException;
}
