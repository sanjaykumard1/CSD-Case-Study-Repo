package com.dao;

import com.db.DBConnection;
import com.model.MembershipPlan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MembershipPlanDAOimpl implements MembershipPlanDAO {

    @Override
    public boolean insertMembershipPlan(MembershipPlan membershipPlan) throws SQLException {
        Connection conn = DBConnection.getDBConn();
        String sql = "INSERT INTO membershipPlan (plan_id, name, duration_months, price_per_month) VALUES (?, ?, ?, ?)";

        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, membershipPlan.getPlan_id());
        statement.setString(2, membershipPlan.getName());
        statement.setInt(3, membershipPlan.getDuration_months());
        statement.setInt(4, membershipPlan.getPrice_per_month());

        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowInserted;
    }

    @Override
    public List<MembershipPlan> listAllMembershipPlan() throws SQLException {
        List<MembershipPlan> listMembershipPlan = new ArrayList<>();

        String sql = "SELECT * FROM membershipPlan";

        Connection conn = DBConnection.getDBConn();
        Statement statement = conn.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int plan_id = resultSet.getInt("plan_id");
            String name = resultSet.getString("name");
            int duration_months = resultSet.getInt("duration_months");
            int price_per_month = resultSet.getInt("price_per_month");

            MembershipPlan membershipPlan = new MembershipPlan(plan_id, name, duration_months, price_per_month);
            listMembershipPlan.add(membershipPlan);
        }

        resultSet.close();
        statement.close();
        DBConnection.dbClose();

        return listMembershipPlan;
    }

    @Override
    public boolean deleteMembershipPlan(MembershipPlan membershipPlan) throws SQLException {
        String sql = "DELETE FROM membershipPlan WHERE plan_id = ?";

        Connection conn = DBConnection.getDBConn();
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, membershipPlan.getPlan_id());

        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowDeleted;
    }

    @Override
    public boolean updateMembershipPlan(MembershipPlan membershipPlan) throws SQLException {
        String sql = "UPDATE membershipPlan SET name = ?, duration_months = ?, price_per_month = ? WHERE plan_id = ?";
        Connection conn = DBConnection.getDBConn();

        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, membershipPlan.getName());
        statement.setInt(2, membershipPlan.getDuration_months());
        statement.setInt(3, membershipPlan.getPrice_per_month());
        statement.setInt(4, membershipPlan.getPlan_id());

        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowUpdated;
    }

    @Override
    public MembershipPlan getMembershipPlan(int plan_id) throws SQLException {
        MembershipPlan membershipPlan = null;
        String sql = "SELECT * FROM membershipPlan WHERE plan_id = ?";

        Connection conn = DBConnection.getDBConn();
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, plan_id);

        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String name = resultSet.getString("name");
            int duration_months = resultSet.getInt("duration_months");
            int price_per_month = resultSet.getInt("price_per_month");

            membershipPlan = new MembershipPlan(plan_id, name, duration_months, price_per_month);
        }

        resultSet.close();
        statement.close();
        DBConnection.dbClose();

        return membershipPlan;
    }
}
