package com.dao;
import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.db.DBConnection;
import com.model.Member;

public class MemberDAOimpl implements MemberDAO {
	@Override
    public boolean insertMember(Member member) throws SQLException {
	    	Connection conn=DBConnection.getDBConn();
	        String sql = "INSERT INTO member (member_id, name , email , phone_number,address,start_date , plan_id) VALUES (?, ?, ?, ?, ?,?,?)";
	        
	        
	        PreparedStatement statement = conn.prepareStatement(sql);
	        statement.setInt(1, member.getMember_id());
	        statement.setString(2, member.getName());
	        statement.setString(3, member.getEmail());
	        statement.setString(4, member.getPhone_number());
	        statement.setString(5, member.getAddress());
	        statement.setDate(6, new java.sql.Date(member.getStart_date().getTime()));
	        statement.setInt(7, member.getPlan_id());
	         
	        boolean rowInserted = statement.executeUpdate() > 0;
	        statement.close();
	        DBConnection.dbClose();
	        return rowInserted;
	    }
	     
	    public List<Member> listAllMembers() throws SQLException {
	        List<Member> listMember = new ArrayList<>();
	         
	        String sql = "SELECT * FROM member";
	         
	        Connection conn=DBConnection.getDBConn();
	         
	        Statement statement =conn.createStatement();
	        ResultSet resultSet = statement.executeQuery(sql);
	         
	        while (resultSet.next()) {
	            int member_id = resultSet.getInt("member_id");
	            String name = resultSet.getString("name");
	            String email = resultSet.getString("email");
	            String phone_number = resultSet.getString("phone_number");
	            String address = resultSet.getString("address");
	            int plan_id = resultSet.getInt("plan_id");
	            Date start_date = resultSet.getDate("start_date");
	             
	            Member member = new Member (member_id, name, email, phone_number , address,plan_id , start_date);
	            listMember.add(member);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        DBConnection.dbClose();
	         
	        return listMember;
	    }
	     
	    public boolean deleteMember(Member member) throws SQLException {
	        String sql = "DELETE FROM member where member_id = ?";
	         
	        Connection conn=DBConnection.getDBConn();
	         
	        PreparedStatement statement = conn.prepareStatement(sql);
	        statement.setInt(1, member.getMember_id());
	         
	        boolean rowDeleted = statement.executeUpdate() > 0;
	        statement.close();
	        DBConnection.dbClose();
	        return rowDeleted;     
	    }
	     
	    public boolean updateMember(Member member) throws SQLException {
	        String sql = "UPDATE member SET name=?, email = ?, phone_number = ? ,address = ?" ;
	        sql += " WHERE member_id = ?";
	        Connection conn=DBConnection.getDBConn();
	         
	        PreparedStatement statement = conn.prepareStatement(sql);
	        
	        statement.setString(1, member.getName());
	        statement.setString(2, member.getEmail());
	        statement.setString(3, member.getPhone_number());
	        statement.setString(4, member.getAddress());
	        statement.setInt(5, member.getMember_id());
	         
	        boolean rowUpdated = statement.executeUpdate() > 0;
	        statement.close();
	        DBConnection.dbClose();
	        return rowUpdated;     
	    }
	     
	    public Member getMember(int member_id) throws SQLException {
	        Member member = null;
	        String sql = "SELECT * FROM member WHERE member_id = ?";
	         
	        Connection conn=DBConnection.getDBConn();
	         
	        PreparedStatement statement = conn.prepareStatement(sql);
	        statement.setInt(1, member_id);
	         
	        ResultSet resultSet = statement.executeQuery();
	         
	        if (resultSet.next()) {
	            String name = resultSet.getString("name");
	            String email = resultSet.getString("email");
	            String phone_number = resultSet.getString("phone_number");
	            String address = resultSet.getString("address");
	            int plan_id = resultSet.getInt("plan_id");
	            Date start_date = resultSet.getDate("start_date"); 
	            
	            member = new Member(member_id , name , email , phone_number , address , plan_id , start_date);
	        }
	         
	        resultSet.close();
	        statement.close();
	         
	        return member;
	    }
}
