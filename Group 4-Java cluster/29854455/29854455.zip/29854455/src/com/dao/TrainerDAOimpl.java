package com.dao;

import com.db.DBConnection;
import com.model.Trainer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class TrainerDAOimpl implements TrainerDAO {
    @Override
    public boolean insertTrainer(Trainer trainer) throws SQLException {
        Connection conn = DBConnection.getDBConn();
        String sql = "INSERT INTO trainer (trainer_id, name, email, phone_number , specialty) VALUES (?, ?, ?, ? ,?)";

        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, trainer.getTrainer_id());
        statement.setString(2, trainer.getName());
        statement.setString(3, trainer.getEmail());
        statement.setString(4, trainer.getPhoneNumber());
        statement.setString(5, trainer.getSpeciality());

        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowInserted;
    }

    @Override
    public List<Trainer> listAllTrainer() throws SQLException {
        List<Trainer> listTrainer = new ArrayList<>();

        String sql = "SELECT * FROM trainer";

        Connection conn = DBConnection.getDBConn();
        Statement statement = conn.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int trainer_id = resultSet.getInt("trainer_id");
            String name = resultSet.getString("name");
            String email = resultSet.getString("email");
            String phone_number = resultSet.getString("phone_number");
            String specialty = resultSet.getString("specialty");
            Trainer trainer = new Trainer(trainer_id, name, email, phone_number, specialty);
            listTrainer.add(trainer);
        }

        resultSet.close();
        statement.close();
        DBConnection.dbClose();

        return listTrainer;
    }

    @Override
    public boolean deleteTrainer(Trainer trainer) throws SQLException {
        String sql = "DELETE FROM trainer WHERE trainer_id = ?";

        Connection conn = DBConnection.getDBConn();
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, trainer.getTrainer_id());

        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowDeleted;
    }

    @Override
    public boolean updateTrainer(Trainer trainer) throws SQLException {
        String sql = "UPDATE trainer SET name = ?, email = ?, phone_number = ? , specialty = ? WHERE plan_id = ?";
        Connection conn = DBConnection.getDBConn();

        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, trainer.getName());
        statement.setString(2, trainer.getEmail());
        statement.setString(3, trainer.getPhoneNumber());
        statement.setString(4, trainer.getSpeciality());

        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();
        DBConnection.dbClose();
        return rowUpdated;
    }

    @Override
    public Trainer getTrainer(int trainer_id) throws SQLException {
        Trainer trainer = null;
        String sql = "SELECT * FROM trainer WHERE trainer_id = ?";

        Connection conn = DBConnection.getDBConn();
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setInt(1, trainer_id);

        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String name = resultSet.getString("name");
            String email = resultSet.getString("email");
            String phone_number = resultSet.getString("phone_number");
            String specialty = resultSet.getString("specialty");
            trainer = new Trainer(trainer_id, name, email, phone_number, specialty);
        }

        resultSet.close();
        statement.close();
        DBConnection.dbClose();

        return trainer;
    }
}
