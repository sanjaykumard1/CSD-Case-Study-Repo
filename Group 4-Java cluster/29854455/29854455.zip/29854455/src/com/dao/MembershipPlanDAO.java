package com.dao;

import com.model.MembershipPlan;

import java.sql.SQLException;
import java.util.List;

public interface MembershipPlanDAO {
    boolean insertMembershipPlan(MembershipPlan membershipPlan) throws SQLException;
    List<MembershipPlan> listAllMembershipPlan() throws SQLException;
    boolean deleteMembershipPlan(MembershipPlan membershipPlan) throws SQLException ;
    boolean updateMembershipPlan(MembershipPlan membershipPlan) throws SQLException;
    MembershipPlan getMembershipPlan(int member_id) throws SQLException;
}
