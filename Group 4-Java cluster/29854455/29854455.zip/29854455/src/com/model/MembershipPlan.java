package com.model;

public class MembershipPlan {
    private int plan_id;
    private String name;
    private int duration_months;
    private int price_per_month;
    public MembershipPlan(int plan_id , String name , int duration_months , int price_per_month)
    {
        this.plan_id = plan_id;
        this.name = name;
        this.duration_months = duration_months;
        this.price_per_month = price_per_month;
    }
    public MembershipPlan() {
        super();
    }

    public int getPlan_id() {
        return plan_id;
    }

    public void setPlan_id(int plan_id) {
        this.plan_id = plan_id;
    }

    public String getName(){return name;}

    public void setName(String name) {
        this.name = name;
    }

    public int getDuration_months() {
        return duration_months;
    }

    public void setDuration_months(int duration_months) {
        this.duration_months = duration_months;
    }

    public int getPrice_per_month() {
        return price_per_month;
    }

    public void setPrice_per_month() {
        this.price_per_month = price_per_month;
    }
    @Override
    public String toString() {
        return "MembershipPlan [plan_id=" + plan_id + ", name =" + name + ", duration_months=" + duration_months
                + ", price_per_month=" + price_per_month+"]";
    }

}
