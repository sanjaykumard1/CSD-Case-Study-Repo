package com.model;
public class Trainer {
    private int trainer_id;
    private String name;
    private String email;
    private String phone_number;
    private String speciality;

    public Trainer(int trainer_id, String name, String email, String phone_number, String speciality) {
        this.trainer_id = trainer_id;
        this.name = name;
        this.email = email;
        this.phone_number = phone_number;
        this.speciality = speciality;
    }

    public Trainer() {
    }

    public int getTrainer_id() {
        return trainer_id;
    }

    public void setTrainer_id(int trainer_id) {
        this.trainer_id = trainer_id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for phoneNumber
    public String getPhoneNumber() {
        return phone_number;
    }

    // Setter for phoneNumber
    public void setPhoneNumber(String phoneNumber) {
        this.phone_number = phoneNumber;
    }

    // Getter for speciality
    public String getSpeciality() {
        return speciality;
    }

    // Setter for speciality
    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    // toString method
    @Override
    public String toString() {
        return "Trainer[" +
                "trainer_id=" + trainer_id +
                ", name='" + name  +
                ", email='" + email  +
                ", phoneNumber='" + phone_number  +
                ", speciality='" + speciality +
                ']';
    }
}
