package com.model;	
import java.util.Date;

import com.dao.MemberDAO;
public class Member  {
	 private int member_id; 
	 private String name;  
	 private String email; 
	 private String  phone_number;  
	 private String address;
	 private int plan_id ;
	 private Date start_date;
	  
	 public Member() {
			super();
			
		}

		public Member(int member_id, String name, String email, String phone_number, String address,int plan_id ,Date start_date ) {
			super();
			this.member_id = member_id;
			this.name = name;
			this.email = email;
			this.phone_number = phone_number;
			this.address = address;
			this.plan_id = plan_id;
			this.start_date =start_date;
		}

		public int getMember_id() {
			return member_id;
		}

		public void setMember_id(int member_id) {
			this.member_id = member_id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPhone_number() {
			return phone_number;
		}

		public void setPhone_number(String phone_number) {
			this.phone_number = phone_number;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}
		public int getPlan_id() {
			return plan_id;
		}

		public void setPlan_id(int plan_id) {
			this.plan_id = plan_id;
		}
		public Date getStart_date() {
			return start_date;
		}

		public void setStart_date(Date start_date) {
			this.start_date = start_date;
		}

		@Override
		public String toString() {
			return "Member [member_id=" + member_id + ", name =" + name + ", email=" + email
					+ ", phone_number=" + phone_number + ", address=" + address+ ",plan_id="+plan_id +",start_date="+start_date +"]";
		} 
	 
}
