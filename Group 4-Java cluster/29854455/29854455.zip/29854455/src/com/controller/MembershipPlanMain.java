package com.controller;

import com.model.Member;
import com.model.MembershipPlan;
import com.service.MembershipPlanService;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class MembershipPlanMain {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        MembershipPlanService membershipPlanservice=new MembershipPlanService();
        while(true)
        {
            System.out.println("Press 1. Create Membership Plan");
            System.out.println("Press 2. View All Membership Plan");
            System.out.println("Press 3. Update Membership Plan");
            System.out.println("Press 4. Delete Membership Plan");
            System.out.println("Press 5. Generate cost");
            System.out.println("Press 0. Exit");
            System.out.println();
            System.out.println("Enter your choice");
            int input=s.nextInt();
            if(input==0)
            {
                System.out.println("Exiting,Thank you");
                break;
            }
            switch(input)
            {
                case 1:
                    System.out.println("Create Membership Plan");
                    System.out.println("Enter  plan id");
                    int plan_id=s.nextInt();
                    System.out.println("Enter plan name ");
                    String name=s.next();
                    System.out.println("Enter plan duration");
                    int duration_months=s.nextInt();
                    System.out.println("Enter price per month");
                    int price_per_month=s.nextInt();

                    try {
                        membershipPlanservice.insertMembershipPlan(plan_id , name , duration_months , price_per_month);;
                        System.out.println("Membership plan added");

                    }
                    catch (SQLException e1) {
                        System.out.println(e1.getMessage());
                    }

                    break;
                case 2:
                    System.out.println("");
                    try {
                        List<MembershipPlan> list = membershipPlanservice.listAllMembershipPlan();
                        System.out.println("**************************List of all accounts********************************");
                        System.out.println();;
                        System.out.println();
                        System.out.println(" plan_id\t "+" name\t "+" duration_months\t "+"price_per_month");
                        for(MembershipPlan a:list)
                        {
                            System.out.println("    "+a.getPlan_id()+"\t\t"+a.getName()+"\t   "+a.getDuration_months()+"\t"+a.getPrice_per_month());
                        }
                        System.out.println("******************************************************************************");
                        System.out.println();
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        System.out.println("Update Membership Plan");
                        System.out.println("Enter plan id");
                        plan_id = s.nextInt();
                        System.out.println("Enter plan name");
                        name=s.next();
                        System.out.println("Enter duration");
                        duration_months=s.nextInt();
                        System.out.println("Enter price per month");
                        price_per_month=s.nextInt();

                        MembershipPlan membershipPlan = new MembershipPlan();
                        membershipPlanservice.updateMembershipPlan(membershipPlan);
                        System.out.println("Data Updated Successfully");
                        ;
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    try
                    {
                        System.out.println("Delete Membership plan");
                        System.out.println("Enter plan id");
                        plan_id = s.nextInt();
                        membershipPlanservice.deleteMembershipPlan((plan_id));
                        System.out.println("Deleted Successfully");
                    }
                    catch (SQLException e) {
                        System.out.println(e.getMessage());
                        break;
                    }
                case 5:
                    try
                    {
                        System.out.println("Membership cost");
                        System.out.println();
                        System.out.println("Enter plan id");
                        plan_id = s.nextInt();
                        System.out.println("cost is : "+membershipPlanservice.cost((plan_id)));
                    }
                    catch (SQLException e) {
                        System.out.println(e.getMessage());
                        break;
                    }
                default:
                    System.out.println("Invalid Input");
                    break;
            }
        }
        s.close();
    }
}
