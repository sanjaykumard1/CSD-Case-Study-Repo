package com.controller;
import java.util.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
import com.model.Member;
import com.service.MemberService;


public class MemberMain {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        MemberService memberservice=new MemberService();
        Date current_date = new Date();
        while(true)
        {
            System.out.println("Press 1. Create Member");
            System.out.println("Press 2. View All Member");
            System.out.println("Press 3. Update Member");
            System.out.println("Press 4. Delete Member");
            System.out.println("Press 5. View Membership Status");
            System.out.println("Press 6. Renew Membership");
            System.out.println("Press 0. Exit");
            System.out.println();
            System.out.println("Enter your choice");
            int input=s.nextInt();
            if(input==0)
            {
                System.out.println("Exiting,Thank you");
                break;
            }
            switch(input)
            {
                case 1:
                    System.out.println("Create Account");
                    System.out.println("Enter  id");
                    int memberid=s.nextInt();
                    System.out.println("Enter your name ");
                    String name=s.next();
                    System.out.println("Enter your email address");
                    String email=s.next();
                    System.out.println("Enter your phone number");
                    String number=s.next();
                    System.out.println("Enter your address");
                    String address=s.next();
                    System.out.println("Enter  plan_id");
                    int planid=s.nextInt();
                    Date start_date = new Date();

                    try {
                        memberservice.insertMember(memberid, name, email, number, address, planid, start_date);;
                        System.out.println("Member added");

                    }
                    catch (SQLException e1) {
                        System.out.println(e1.getMessage());
                    }

                    break;
                case 2:
                    System.out.println("");
                    try {
                        List<Member> list = memberservice.listAllMembers();
                        System.out.println("**************************List of all accounts********************************");
                        System.out.println();
                        System.out.println("**************************"+ current_date+" ********************************");
                        System.out.println();
                        System.out.println(" Member_id\t "+" name\t "+" email\t "+"phone_number"+"\taddress " + "\t plan_id" + "\t start_date");
                        for(Member a:list)
                        {
                            System.out.println("    "+a.getMember_id()+"\t\t"+a.getName()+"\t   "+a.getEmail()+"\t"+a.getPhone_number()+a.getAddress()+"\t"+a.getPlan_id()+"\t"+a.getStart_date()+"\t");
                        }
                        System.out.println("******************************************************************************");
                        System.out.println();
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        System.out.println("Update Account Information");
                        System.out.println("Enter  id");
                        memberid=s.nextInt();
                        planid = memberservice.getMember(memberid).getPlan_id();
                        start_date = memberservice.getMember(memberid).getStart_date();
                        System.out.println("Enter your name ");
                        name=s.next();
                        System.out.println("Enter your email address");
                        email=s.next();
                        System.out.println("Enter your phone number");
                        number=s.next();
                        System.out.println("Enter your address");
                        address=s.next();
                        Member members = new Member(memberid , name , email , number , address,planid , start_date);
                        memberservice.updateMember(members);
                        System.out.println("Data Updated Successfully");
                        ;
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    try
                    {
                        System.out.println("Delete Account");
                        System.out.println("Enter  id");
                        memberid = s.nextInt();
                        memberservice.deleteMember((memberid));
                        System.out.println("Deleted Successfully");
                    }
                    catch (SQLException e) {
                        System.out.println(e.getMessage());
                        break;
                    }
                case 5:
                    System.out.println("Membership Status");
                    System.out.println();
                    System.out.println("Enter  id");
                    memberid = s.nextInt();
                    System.out.println(memberservice.MembershipStatus(memberid));break;
                case 6:
                    System.out.println("Renew Membership");
                    try {
                        System.out.println();
                        System.out.println("Enter  id");
                        memberid = s.nextInt();
                        memberservice.renewMembership(memberid);
                        System.out.println("Membershipe Renewed!!!");
                    }
                    catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }break;
                default:
                    System.out.println("Invalid Input");
                    break;
            }
        }
        s.close();
    }

}

