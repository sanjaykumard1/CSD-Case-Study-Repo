package com.controller;;
import com.model.Trainer;
import com.service.TrainerService;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
public class TrainerMain {
    public static void main(String[] args) {
        {
            Scanner s=new Scanner(System.in);
            TrainerService trainerservice=new TrainerService();
            while(true)
            {
                System.out.println("Press 1. Create new Trainer");
                System.out.println("Press 2. View All Trainer");
                System.out.println("Press 3. Update Trainer");
                System.out.println("Press 4. Delete Trainer");
                System.out.println("Press 0. Exit");
                System.out.println();
                System.out.println("Enter your choice");
                int input=s.nextInt();
                if(input==0)
                {
                    System.out.println("Exiting,Thank you");
                    break;
                }
                switch(input)
                {
                    case 1:
                        System.out.println("Create new Trainer");
                        System.out.println("Enter  trainer id");
                        int trainer_id=s.nextInt();
                        System.out.println("Enter trainer name ");
                        String name=s.next();
                        System.out.println("Enter email");
                        String email = s.next();
                        System.out.println("Enter phone number");
                        String phone_number = s.next();
                        System.out.println("specialty");
                        String specialty = s.next();

                        try {
                            trainerservice.insertTrainer(trainer_id , name , email , phone_number , specialty);;
                            System.out.println("Membership plan added");

                        }
                        catch (SQLException e1) {
                            System.out.println(e1.getMessage());
                        }

                        break;
                    case 2:
                        System.out.println("");
                        try {
                            List<Trainer> list = trainerservice.listAllTrainer();
                            System.out.println("**************************List of all accounts********************************");
                            System.out.println();;
                            System.out.println();
                            System.out.println(" plan_id\t "+" name\t "+" duration_months\t "+"price_per_month");
                            for(Trainer a:list)
                            {
                                System.out.println("    "+a.getTrainer_id()+"\t\t"+a.getName()+"\t   "+a.getEmail()+"\t "+a.getPhoneNumber()+"\t"+a.getSpeciality());
                            }
                            System.out.println("******************************************************************************");
                            System.out.println();
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    case 3:
                        try {
                            System.out.println("Update Trainer");
                            System.out.println("Enter trainer id");
                            trainer_id = s.nextInt();
                            System.out.println("Enter trainer name");
                            name=s.next();
                            System.out.println("Enter email");
                            email=s.next();
                            System.out.println("Enter phone number");
                            phone_number=s.next();
                            System.out.println("Enter specialty");
                            specialty=s.next();

                            Trainer trainer= new Trainer();
                            trainerservice.updateTrainer(trainer);
                            System.out.println("Data Updated Successfully");
                            ;
                        } catch (SQLException e) {
                            System.out.println(e.getMessage());
                        }
                        break;
                    case 4:
                        try
                        {
                            System.out.println("Delete Trainer");
                            System.out.println("Enter trainer id");
                            trainer_id = s.nextInt();
                            trainerservice.deleteTrainer((trainer_id));
                            System.out.println("Deleted Successfully");
                        }
                        catch (SQLException e) {
                            System.out.println(e.getMessage());
                            break;
                        }
                    default:
                        System.out.println("Invalid Input");
                        break;
                }
            }
            s.close();
        }
    }
}
