package com.controller;
import com.service.MemberService;
import com.service.MembershipPlanService;
import com.service.TrainerService;

import java.util.Scanner;
public class GymApp {
    public static void main(String[] args) {
        System.out.println("**************************************** Gym-APP ****************************************");
        System.out.println();
        System.out.println("Press 1. Member View");
        System.out.println("Press 2. Membership view");
        System.out.println("Press 3. Trainer view");


        Scanner s=new Scanner(System.in);
        TrainerService trainerService=new TrainerService();
        MembershipPlanService membershipPlanService = new MembershipPlanService();
        MemberService memberService = new MemberService();

        int input=s.nextInt();
        switch(input)
        {
            case 1:
                System.out.println("Welcome to member view");
                    MemberMain.main(args);
                break;
            case 2:
                System.out.println("Welcome to membership plan view");
                MembershipPlanMain.main(args);
                break;
            case 3:
                System.out.println("Welcome to trainer view");
                TrainerMain.main(args);
                break;
            default:
                System.out.println("Invalid Input");
                break;
        }
        s.close();
    }
    }

