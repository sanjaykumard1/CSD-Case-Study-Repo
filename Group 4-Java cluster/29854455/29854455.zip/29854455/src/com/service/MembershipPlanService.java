package com.service;

import com.dao.MembershipPlanDAO;
import com.dao.MembershipPlanDAOimpl;
import com.model.MembershipPlan;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class MembershipPlanService {

    MembershipPlanDAO membershipPlandao = new MembershipPlanDAOimpl();
    public void insertMembershipPlan(int plan_id ,String name , int duration_months , int price_per_month) throws SQLException {
        MembershipPlan membershipPlan = new MembershipPlan(plan_id , name , duration_months , price_per_month);
        membershipPlandao.insertMembershipPlan(membershipPlan);
    }
    public List<MembershipPlan> listAllMembershipPlan() throws SQLException{
        return membershipPlandao.listAllMembershipPlan();
    }
    public boolean deleteMembershipPlan(int id) throws SQLException{
        return membershipPlandao.deleteMembershipPlan(getMembershipPlan(id));

    }
    public boolean updateMembershipPlan(MembershipPlan membershipPlan) throws SQLException{
        return membershipPlandao.updateMembershipPlan(membershipPlan);
    }
    public MembershipPlan getMembershipPlan(int member_id) throws SQLException{
        return membershipPlandao.getMembershipPlan(member_id);
    }
    public int cost(int id) throws SQLException {
        return (membershipPlandao.getMembershipPlan(id).getDuration_months())*(membershipPlandao.getMembershipPlan(id).getPrice_per_month());
    }
}
