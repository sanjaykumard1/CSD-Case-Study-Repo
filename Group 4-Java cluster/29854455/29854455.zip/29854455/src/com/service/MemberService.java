package com.service;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Calendar;
import com.dao.MemberDAO;
import com.dao.MemberDAOimpl;
import com.dao.MembershipPlanDAO;
import com.dao.MembershipPlanDAOimpl;
import com.model.Member;
import com.model.MembershipPlan;

public class MemberService {
MemberDAO memberdao = new MemberDAOimpl();
public void insertMember(int id , String name , String email , String phone_number , String address , int plan_id , Date start_date) throws SQLException {
	Member member = new Member(id ,  name ,  email , phone_number ,  address ,plan_id ,  start_date);
	memberdao.insertMember(member);
}
public List<Member> listAllMembers() throws SQLException{
   return memberdao.listAllMembers();
}
 public boolean deleteMember(int id) throws SQLException{
	 return memberdao.deleteMember(getMember(id));
 
 }
 public boolean updateMember(Member member) throws SQLException{
	 return memberdao.updateMember(member);
 }
 public Member getMember(int member_id) throws SQLException{
	 return memberdao.getMember(member_id);
 }
 public Date MembershipValid(Member member) {
	 Date start_date  = member.getStart_date();
	 Date end_date = new Date();
	 Calendar calendar = Calendar.getInstance();
     calendar.setTime(start_date);
     MembershipPlanDAO membershipPlandao = new MembershipPlanDAOimpl();
	int months=0;
	 try {
		 months = (membershipPlandao.getMembershipPlan(member.getPlan_id()).getDuration_months());
	 } catch (SQLException e) {
		 throw new RuntimeException(e);
	 }

	 calendar.add(Calendar.MONTH, months);
	 end_date = calendar.getTime();
     return (end_date);
 }
 public String MembershipStatus(int id)
 {
	 Date current_date = new Date();
	 String status = "Invalid";
	 try {
		 
		Member member = getMember(id);
		Date end_date = MembershipValid(member);
		if(current_date.before(end_date))
		{
			 status = String.format("Valid. Membership expires on: %s", end_date);
			 return status;
		
		}
		{
			 return status; 
		}
	} catch (SQLException e) {

		e.printStackTrace();
	}
	return status;
 }
 public void renewMembership(int id) throws SQLException
 {
	 Member member = getMember(id);
	 Date current_date = new Date();
	 member.setStart_date(current_date);
	 updateMember(member);
 }
}
