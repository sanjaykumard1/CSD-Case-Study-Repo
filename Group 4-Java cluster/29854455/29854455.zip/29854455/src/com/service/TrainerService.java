package com.service;
import com.dao.MembershipPlanDAO;
import com.dao.MembershipPlanDAOimpl;
import com.dao.TrainerDAO;
import com.dao.TrainerDAOimpl;
import com.model.MembershipPlan;
import com.model.Trainer;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
public class TrainerService {
    TrainerDAO trainerdao = new TrainerDAOimpl();
    public void insertTrainer(int trainer_id ,String name , String email , String phone_number , String specialty) throws SQLException {
        Trainer trainer = new Trainer(trainer_id , name , email , phone_number , specialty);
        trainerdao.insertTrainer(trainer);
    }
    public List<Trainer> listAllTrainer() throws SQLException{
        return trainerdao.listAllTrainer();
    }
    public boolean deleteTrainer(int id) throws SQLException{
        return trainerdao.deleteTrainer(getTrainer(id));

    }
    public boolean updateTrainer(Trainer trainer) throws SQLException{
        return trainerdao.updateTrainer(trainer);
    }
    public Trainer getTrainer(int trainer_id) throws SQLException{
        return trainerdao.getTrainer(trainer_id);
    }
}
