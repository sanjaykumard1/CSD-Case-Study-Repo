package com.db;
import java.sql.*;
public class DBConnection {
	
	private static Connection conn;
	public static Connection getDBConn() {
		String usernameDb = "root";
		String passwordDb = "root";
		String urlDb = "jdbc:mysql://localhost:3306/gymdb";
		String driverName = "com.mysql.cj.jdbc.Driver";

		try {
			Class.forName(driverName);
			
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		}

	
		try {
			conn = DriverManager.getConnection(urlDb, usernameDb, passwordDb);
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}

		return conn;
	}

	public static void dbClose() {
		try {
			conn.close();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	    }
	

