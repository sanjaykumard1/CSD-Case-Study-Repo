# Digital Marketplace Console Application

## Setup Instructions

1. Clone the repository:
    ```bash
    git clone https://github.com/Ananth2308/digital-marketplace.git
    ```
2. Open the project in your IDE.
3. Set up the MySQL database and run the SQL scripts provided in the `sql` directory.
4. Update the JDBC configuration in `JDBCUtil.java` with your database credentials.
5. Run the `MarketplaceApp` class to start the application.

## Usage Instructions

1. Follow the on-screen menu to manage products, sellers, and transactions.
2. Choose the appropriate option by entering the corresponding number.

## Requirements

- Java 8 or higher
- MySQL 5.7 or higher
- JDBC Driver for MySQL
