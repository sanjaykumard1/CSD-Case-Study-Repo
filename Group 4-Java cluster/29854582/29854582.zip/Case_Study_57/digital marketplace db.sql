create database DigitalMarketplace;
use DigitalMarketplace;
CREATE TABLE Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    price DECIMAL(10, 2),
    quantity_available INT,
    category VARCHAR(50)
);

CREATE TABLE Seller (
    seller_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    address TEXT,
    phone_number VARCHAR(15)
);

CREATE TABLE Transaction (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    seller_id INT,
    buyer_id INT,
    quantity INT,
    transaction_date DATETIME,
    status VARCHAR(50),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES Seller(seller_id)ON DELETE CASCADE
);
INSERT INTO Product (name, description, price, quantity_available, category) VALUES
('Product 1', 'Description 1', 100.00, 10, 'Category 1'),
('Product 2', 'Description 2', 150.00, 5, 'Category 2'),
('Product 3', 'Description 3', 200.00, 8, 'Category 3'),
('Product 4', 'Description 4', 250.00, 3, 'Category 4'),
('Product 5', 'Description 5', 300.00, 7, 'Category 5');

INSERT INTO Seller (name, email, address, phone_number) VALUES
('Seller 1', 'seller1@example.com', 'Address 1', '1234567890'),
('Seller 2', 'seller2@example.com', 'Address 2', '2345678901'),
('Seller 3', 'seller3@example.com', 'Address 3', '3456789012'),
('Seller 4', 'seller4@example.com', 'Address 4', '4567890123'),
('Seller 5', 'seller5@example.com', 'Address 5', '5678901234');

INSERT INTO Transaction (product_id, seller_id, buyer_id, quantity, transaction_date, status) VALUES
(1, 1, 1, 2, '2023-07-01 10:00:00', 'Completed'),
(2, 2, 2, 1, '2023-07-02 11:00:00', 'Pending'),
(3, 3, 3, 3, '2023-07-03 12:00:00', 'Shipped'),
(4, 4, 4, 4, '2023-07-04 13:00:00', 'Refunded'),
(5, 5, 5, 5, '2023-07-05 14:00:00', 'Completed');

select* from Product;
select * from seller;
select* from Transaction;
-- UPDATE Product SET name = 'product100', description = 'des1', price = 300, quantity_available = 12, category = 'cat1' WHERE product_id = 2;
