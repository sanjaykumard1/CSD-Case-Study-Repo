import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    /**
     * Adds a new transaction to the database.
     * transaction The transaction to be added.
     * throws SQLException If there is an error during the database operation.
     */
    public void addTransaction(Transaction transaction) throws SQLException {
        String query = "INSERT INTO Transaction (product_id, seller_id, buyer_id, quantity, transaction_date, status) VALUES (?, ?, ?, ?, ?, ?)";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, transaction.getProductId());
        ps.setInt(2, transaction.getSellerId());
        ps.setInt(3, transaction.getBuyerId());
        ps.setInt(4, transaction.getQuantity());
        ps.setTimestamp(5, new Timestamp(transaction.getTransactionDate().getTime()));
        ps.setString(6, transaction.getStatus());
        ps.executeUpdate();
    }

    /**
     * Retrieves all transactions from the database.
     * return A list of all transactions.
     * throws SQLException If there is an error during the database operation.
     */
    public List<Transaction> getAllTransactions() throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM Transaction";
        Connection con = JdbcConnection.getConnection();
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        while (rs.next()) {
            Transaction transaction = new Transaction();
            transaction.setTransactionId(rs.getInt("transaction_id"));
            transaction.setProductId(rs.getInt("product_id"));
            transaction.setSellerId(rs.getInt("seller_id"));
            transaction.setBuyerId(rs.getInt("buyer_id"));
            transaction.setQuantity(rs.getInt("quantity"));
            transaction.setTransactionDate(rs.getDate("transaction_date"));
            transaction.setStatus(rs.getString("status"));
            transactions.add(transaction);
        }
        return transactions;
    }

    /**
     * Updates an existing transaction in the database.
     * transaction The transaction to be updated.
     * throws SQLException If there is an error during the database operation.
     */
    public void updateTransaction(Transaction transaction) throws SQLException {
        String query = "UPDATE Transaction SET product_id = ?, seller_id = ?, buyer_id = ?, quantity = ?, transaction_date = ?, status = ? WHERE transaction_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, transaction.getProductId());
        ps.setInt(2, transaction.getSellerId());
        ps.setInt(3, transaction.getBuyerId());
        ps.setInt(4, transaction.getQuantity());
        ps.setTimestamp(5, new Timestamp(transaction.getTransactionDate().getTime()));
        ps.setString(6, transaction.getStatus());
        ps.setInt(7, transaction.getTransactionId());
        ps.executeUpdate();
    }

    /**
     * Deletes a transaction from the database.
     * transaction The transaction to be deleted.
     * throws SQLException If there is an error during the database operation.
     */
    public void deleteTransaction(Transaction transaction) throws SQLException {
        String query = "DELETE FROM Transaction WHERE transaction_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, transaction.getTransactionId());
        ps.executeUpdate();
    }

    /**
     * Retrieves transactions by their ID from the database.
     * transaction The transaction containing the ID to search for.
     * return A list of transactions matching the given ID.
     * throws SQLException If there is an error during the database operation.
     */
    public List<Transaction> getTransactionsById(Transaction transaction) throws SQLException {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM Transaction WHERE transaction_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, transaction.getTransactionId());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Transaction transactionById = new Transaction();
            transactionById.setTransactionId(rs.getInt("transaction_id"));
            transactionById.setProductId(rs.getInt("product_id"));
            transactionById.setSellerId(rs.getInt("seller_id"));
            transactionById.setBuyerId(rs.getInt("buyer_id"));
            transactionById.setQuantity(rs.getInt("quantity"));
            transactionById.setTransactionDate(rs.getDate("transaction_date"));
            transactionById.setStatus(rs.getString("status"));
            transactions.add(transactionById);
        }
        return transactions;
    }
}
