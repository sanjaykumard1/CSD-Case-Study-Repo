import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class DigitalMarketplaceApp {
    private static ProductDAO productDAO = new ProductDAO();
    private static SellerDAO sellerDAO = new SellerDAO();
    private static TransactionDAO transactionDAO = new TransactionDAO();
    private static Scanner scanner = new Scanner(System.in);
// Main function with the list of operations in the menu
    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Sellers");
            System.out.println("3. Manage Transactions");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageSellers();
                    break;
                case 3:
                    manageTransactions();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Manages product-related operations.
     */
    private static void manageProducts() {
        System.out.println("1. Add Product");
        System.out.println("2. View Products");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try {
            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewProducts();
                    break;
                case 3:
                    updateProduct();
                    break;
                case 4:
                    deleteProduct();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Adds a new product.
          */
    private static void addProduct() throws SQLException {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter quantity available: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter product category: ");
        String category = scanner.nextLine();

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        product.setQuantityAvailable(quantity);
        product.setCategory(category);

        productDAO.addproduct(product);
        System.out.println("Product added successfully.");
    }

    /**
     * Views all products.
     */
    private static void viewProducts() throws SQLException {
        for (Product product : productDAO.getAllProducts()) {
            System.out.println(product);
        }
    }

    /**
     * Updates an existing product.
     */
    private static void updateProduct() throws SQLException {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Product product = new Product();
        product.setProductId(productId);

        List<Product> products = productDAO.getProductsById(product);
        if (products.isEmpty()) {
            System.out.println("Product not found.");
            return;
        }

        Product p = products.get(0); // Retrieve the first (and presumably only) product from the list
        System.out.print("Enter new product name (current: " + p.getName() + "): ");
        String name = scanner.nextLine();
        System.out.print("Enter new product description (current: " + p.getDescription() + "): ");
        String description = scanner.nextLine();
        System.out.print("Enter new product price (current: " + p.getPrice() + "): ");
        double price = scanner.nextDouble();
        System.out.print("Enter new quantity available (current: " + p.getQuantityAvailable() + "): ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new product category (current: " + p.getCategory() + "): ");
        String category = scanner.nextLine();

        p.setName(name);
        p.setDescription(description);
        p.setPrice(price);
        p.setQuantityAvailable(quantity);
        p.setCategory(category);

        productDAO.updateProduct(p);
        System.out.println("Product updated successfully.");
    }

    /**
     * Deletes an existing product.
     */
    private static void deleteProduct() throws SQLException {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Product product = new Product();
        product.setProductId(productId);
        productDAO.deleteProduct(product);
        System.out.println("Product deleted successfully.");
    }

    /**
     * Manages seller-related operations.
     */
    private static void manageSellers() {
        System.out.println("1. Add Seller");
        System.out.println("2. View Sellers");
        System.out.println("3. Update Seller");
        System.out.println("4. Delete Seller");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            switch (choice) {
                case 1:
                    addSeller();
                    break;
                case 2:
                    viewSellers();
                    break;
                case 3:
                    updateSeller();
                    break;
                case 4:
                    deleteSeller();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Adds a new seller.
     */
    private static void addSeller() throws SQLException {
        System.out.print("Enter seller name: ");
        String name = scanner.nextLine();
        System.out.print("Enter seller email: ");
        String email = scanner.nextLine();
        System.out.print("Enter seller address: ");
        String address = scanner.nextLine();
        System.out.print("Enter seller phone number: ");
        String phoneNumber = scanner.nextLine();

        Seller seller = new Seller();
        seller.setName(name);
        seller.setEmail(email);
        seller.setAddress(address);
        seller.setPhone_number(phoneNumber);

        sellerDAO.addSeller(seller);
        System.out.println("Seller added successfully.");
    }

    /**
     * Views sellers by ID.
     */
    private static void viewSellers() throws SQLException {
        System.out.println("1. View All Sellers");
        System.out.println("2. View Seller by ID");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (choice == 1) {
            List<Seller> sellers = sellerDAO.getAllSellers();
            if (sellers.isEmpty()) {
                System.out.println("No sellers found.");
            } else {
                for (Seller s : sellers) {
                    System.out.println(s);
                }
            }
        } else if (choice == 2) {
            System.out.print("Enter seller ID to retrieve: ");
            int sellerId = scanner.nextInt();
            scanner.nextLine(); // consume newline

            Seller seller = new Seller();
            seller.setSeller_id(sellerId);

            List<Seller> sellers = sellerDAO.getSellersById(seller);
            if (sellers.isEmpty()) {
                System.out.println("No sellers found with the given ID.");
            } else {
                for (Seller s : sellers) {
                    System.out.println(s);
                }
            }
        } else {
            System.out.println("Invalid choice. Please try again.");
        }
    }

    /**
     * Updates an existing seller.
     */
    private static void updateSeller() throws SQLException {
        System.out.print("Enter seller ID to update: ");
        int sellerId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Seller seller = new Seller();
        seller.setSeller_id(sellerId);

        List<Seller> sellers = sellerDAO.getSellersById(seller);
        if (sellers.isEmpty()) {
            System.out.println("Seller not found.");
            return;
        }

        Seller s = sellers.get(0); // Retrieve the first (and presumably only) seller from the list
        System.out.print("Enter new seller name (current: " + s.getName() + "): ");
        String name = scanner.nextLine();
        System.out.print("Enter new seller email (current: " + s.getEmail() + "): ");
        String email = scanner.nextLine();
        System.out.print("Enter new seller address (current: " + s.getAddress() + "): ");
        String address = scanner.nextLine();
        System.out.print("Enter new seller phone number (current: " + s.getPhone_number() + "): ");
        String phoneNumber = scanner.nextLine();

        s.setName(name);
        s.setEmail(email);
        s.setAddress(address);
        s.setPhone_number(phoneNumber);

        sellerDAO.updateSeller(s);
        System.out.println("Seller updated successfully.");
    }

    /**
     * Deletes an existing seller.
     */
    private static void deleteSeller() throws SQLException {
        System.out.print("Enter seller ID to delete: ");
        int sellerId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Seller seller = new Seller();
        seller.setSeller_id(sellerId);
        sellerDAO.deleteSeller(seller);
        System.out.println("Seller deleted successfully.");
    }

    /**
     * Manages transaction-related operations.
     */
    private static void manageTransactions() {
        System.out.println("1. Add Transaction");
        System.out.println("2. View Transactions");
        System.out.println("3. Update Transaction");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            switch (choice) {
                case 1:
                    addTransaction();
                    break;
                case 2:
                    viewTransactions();
                    break;
                case 3:
                    updateTransaction();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    /**
     * Adds a new transaction.
     */
    private static void addTransaction() throws SQLException {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        System.out.print("Enter seller ID: ");
        int sellerId = scanner.nextInt();
        System.out.print("Enter buyer ID: ");
        int buyerId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter transaction status: ");
        String status = scanner.nextLine();

        Transaction transaction = new Transaction();
        transaction.setProductId(productId);
        transaction.setSellerId(sellerId);
        transaction.setBuyerId(buyerId);
        transaction.setQuantity(quantity);
        transaction.setTransactionDate(new Date());
        transaction.setStatus(status);

        transactionDAO.addTransaction(transaction);
        System.out.println("Transaction added successfully.");
    }

    /**
     * Views transactions by ID.
     */
    private static void viewTransactions() throws SQLException {
        System.out.print("Enter transaction ID to retrieve: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionId);

        List<Transaction> transactions = transactionDAO.getTransactionsById(transaction);
        if (transactions.isEmpty()) {
            System.out.println("No transactions found with the given ID.");
        } else {
            for (Transaction t : transactions) {
                System.out.println(t);
            }
        }
    }

    /**
     * Updates an existing transaction.
     */
    private static void updateTransaction() throws SQLException {
        System.out.print("Enter transaction ID to update: ");
        int transactionId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionId);

        List<Transaction> transactions = transactionDAO.getTransactionsById(transaction);
        if (transactions.isEmpty()) {
            System.out.println("Transaction not found.");
            return;
        }

        Transaction t = transactions.get(0); // Retrieve the first (and presumably only) transaction from the list
        System.out.print("Enter new transaction status (current: " + t.getStatus() + "): ");
        String status = scanner.nextLine();

        t.setStatus(status);

        transactionDAO.updateTransaction(t);
        System.out.println("Transaction status updated successfully.");
    }
}
