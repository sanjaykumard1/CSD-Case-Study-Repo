import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SellerDAO {

    /**
     * Adds a new seller to the database.
     * seller The seller to be added.
     * throws SQLException If there is an error during the database operation.
     */
    public void addSeller(Seller seller) throws SQLException {
        String query = "INSERT INTO Seller (name, email, address, phone_number) VALUES (?, ?, ?, ?)";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, seller.getName());
        ps.setString(2, seller.getEmail());
        ps.setString(3, seller.getAddress());
        ps.setString(4, seller.getPhone_number());
        ps.executeUpdate();
    }

    /**
     * Retrieves all sellers from the database.
     * return A list of all sellers.
     * throws SQLException If there is an error during the database operation.
     */
    public List<Seller> getAllSellers() throws SQLException {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT * FROM Seller";
        Connection con = JdbcConnection.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(query);
        while (rs.next()) {
            Seller seller = new Seller();
            seller.setSeller_id(rs.getInt("seller_id"));
            seller.setName(rs.getString("name"));
            seller.setEmail(rs.getString("email"));
            seller.setAddress(rs.getString("address"));
            seller.setPhone_number(rs.getString("phone_number"));
            sellers.add(seller);
        }
        return sellers;
    }

    /**
     * Updates an existing seller in the database.
     * seller The seller to be updated.
     * throws SQLException If there is an error during the database operation.
     */
    public void updateSeller(Seller seller) throws SQLException {
        String query = "UPDATE Seller SET name = ?, email = ?, address = ?, phone_number = ? WHERE seller_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setString(1, seller.getName());
        ps.setString(2, seller.getEmail());
        ps.setString(3, seller.getAddress());
        ps.setString(4, seller.getPhone_number());
        ps.setInt(5, seller.getSeller_id());
        ps.executeUpdate();
    }

    /**
     * Deletes a seller from the database.
     * seller The seller to be deleted.
     * throws SQLException If there is an error during the database operation.
     */
    public void deleteSeller(Seller seller) throws SQLException {
        String query = "DELETE FROM Seller WHERE seller_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, seller.getSeller_id());
        ps.executeUpdate();
    }

    /**
     * Retrieves a seller by their ID from the database.
     * seller The seller with the ID to search for.
     * return A list of sellers matching the given ID.
     * throws SQLException If there is an error during the database operation.
     */
    public List<Seller> getSellersById(Seller seller) throws SQLException {
        List<Seller> sellers = new ArrayList<>();
        String query = "SELECT * FROM Seller WHERE seller_id = ?";
        Connection con = JdbcConnection.getConnection();
        PreparedStatement ps = con.prepareStatement(query);
        ps.setInt(1, seller.getSeller_id());
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Seller sellerById = new Seller();
            sellerById.setSeller_id(rs.getInt("seller_id"));
            sellerById.setName(rs.getString("name"));
            sellerById.setEmail(rs.getString("email"));
            sellerById.setAddress(rs.getString("address"));
            sellerById.setPhone_number(rs.getString("phone_number"));
            sellers.add(sellerById);
        }
        return sellers;
    }
}
