import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//Class Declaration
public class JdbcConnection {
//	Database Connection Parameters
		private static String Url = "jdbc:mysql://localhost:3306/DigitalMarketplace";
		private static String Username = "root";
		private static String Password = "Ananth@sql";
//		Connection Method
		public static Connection getConnection() throws SQLException {
			return DriverManager.getConnection(Url, Username, Password);
			
		}

	}


