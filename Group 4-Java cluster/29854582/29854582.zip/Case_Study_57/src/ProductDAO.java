import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	/**
     * Adds a new product to the database.
     *  product The product to be added.
     * throws SQLException If there is an error during the database operation.
     */
	
	public void addproduct(Product product) throws SQLException {

		String query = "INSERT INTO Product (name, description, price, quantity_available, category) VALUES (?, ?, ?, ?, ?)";
		Connection con = JdbcConnection.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1,product.getName());
		ps.setString(2, product.getDescription());
		ps.setDouble(3, product.getPrice());
		ps.setInt(4, product.getQuantityAvailable());
		ps.setString(5, product.getCategory());
		ps.executeUpdate();
		
	}
	 /**
     * Retrieves all products from the database.
     * return A list of all products.
     * throws SQLException If there is an error during the database operation.
     */
	
	 public  List<Product> getAllProducts() throws SQLException{
		 List<Product> products = new ArrayList<>();
		 String query = "select * from product";
		 Connection con = JdbcConnection.getConnection();
		 Statement st = con.createStatement();
		 ResultSet rs = st.executeQuery(query);
		 while(rs.next()) {
			 Product product = new Product();
			 product.setProductId(rs.getInt("product_id"));
             product.setName(rs.getString("name"));
             product.setDescription(rs.getString("description"));
             product.setPrice(rs.getDouble("price"));
             product.setQuantityAvailable(rs.getInt("quantity_available"));
             product.setCategory(rs.getString("category"));
             products.add(product);
			 }
		 return products;
	 }
	 /**
	     * Updates an existing product in the database.
	     * 
	     *  product The product to be updated.
	     * throws SQLException If there is an error during the database operation.
	     */
	 public void updateProduct(Product product) throws SQLException {
		    String sql = "UPDATE Product SET name = ?, description = ?, price = ?, quantity_available = ?, category = ? WHERE product_id = ?";
		    
		    	Connection con = JdbcConnection.getConnection(); 
		         PreparedStatement ps = con.prepareStatement(sql);
		        ps.setString(1, product.getName());
		        ps.setString(2, product.getDescription());
		        ps.setDouble(3, product.getPrice());
		        ps.setInt(4, product.getQuantityAvailable());
		        ps.setString(5, product.getCategory());
		        ps.setInt(6, product.getProductId());
		        ps.executeUpdate();
		    
		}
	 
	 /**
	     * Deletes a product from the database.
	     * 
	     * product The product to be deleted.
	     * throws SQLException If there is an error during the database operation.
	     */
		 public void deleteProduct(Product product) throws SQLException {
		 String query = "DELETE FROM Product WHERE product_id = ?";
		 Connection con = JdbcConnection.getConnection();
		 PreparedStatement ps = con.prepareStatement(query);
		 ps.setInt(1,product.getProductId());
		 ps.executeUpdate();
	 }

	 /**
	 * Retrieves a product by its ID from the database.
	 *  product The product with the ID to search for.
	 * return A list of products matching the given ID.
	 * throws SQLException If there is an error during the database operation.
	 */
		 public  List<Product> getProductsById(Product product) throws SQLException{
		 List<Product> products = new ArrayList<>();
		 String query = "SELECT * FROM Product WHERE product_id = ?";
		 Connection con = JdbcConnection.getConnection();
		 PreparedStatement ps = con.prepareStatement(query);
		 ps.setInt(1, product.getProductId());
		 ResultSet rs = ps.executeQuery(query);
		 while(rs.next()) {
			 Product productById = new Product();
			 productById.setProductId(rs.getInt("product_id"));
			 productById.setName(rs.getString("name"));
			 productById.setDescription(rs.getString("description"));
			 productById.setPrice(rs.getDouble("price"));
			 productById.setQuantityAvailable(rs.getInt("quantity_available"));
			 productById.setCategory(rs.getString("category"));
             products.add(productById);
			 }
		 return products;
	 }
	 
}
 