import java.util.Date;
/**
 * Represents Transactions with details like TransactionID, Product Id, Seller Id, Buyer Id, quantity, transactionDate and status.
 */
public class Transaction {
//	Transaction class parameters
	private int transactionId;
    private int productId;
    private int sellerId;
    private int buyerId;
    private int quantity;
    private Date transactionDate;
    private String status;
    
    public Transaction() {}
//    Constructor
	public Transaction(int transactionId, int productId, int sellerId, int buyerId, int quantity, Date transactionDate,String status) {
		this.transactionId = transactionId;
		this.productId = productId;
		this.sellerId = sellerId;
		this.buyerId = buyerId;
		this.quantity = quantity;
		this.transactionDate = transactionDate;
		this.status = status;
	}
//  Getter and setter code
	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", productId=" + productId + ", sellerId=" + sellerId
				+ ", buyerId=" + buyerId + ", quantity=" + quantity + ", transactionDate=" + transactionDate
				+ ", status=" + status + "]";
	}
	
    
    
}
