/**
 * Represents a seller with details like ID, name, email, address, and phone number.
 */
public class Seller {
//	Seller class parameters
	private int seller_id;
	private String name;
	private String email;
	private String address;
	private String phone_number;
	public Seller() {}
//	 Constructor
	public Seller(int seller_id, String name, String email, String address, String phone_number) {
		this.seller_id = seller_id;
		this.name = name;
		this.email = email;
		this.address = address;
		this.phone_number = phone_number;
	}
//	getter and setter code
	public int getSeller_id() {
		return seller_id;
	}
	
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPhone_number() {
		return phone_number;
	}
	
	public void setPhone_number(String number) {
		this.phone_number = number;
	}
	@Override
	public String toString() {
		return "Seller [seller_id=" + seller_id + ", name=" + name + ", email=" + email + ", address=" + address
				+ ", phone_number=" + phone_number + "]";
	}
	
	

}
