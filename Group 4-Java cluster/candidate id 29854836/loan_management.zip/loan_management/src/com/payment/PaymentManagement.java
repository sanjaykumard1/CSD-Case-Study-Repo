package com.payment;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.utils.dbconnection;

public class PaymentManagement {

    public void recordLoanPayment(int loanId, Date paymentDate, double paymentAmount) {
        String query = "INSERT INTO payment (loan_id, payment_date, payment_amount) VALUES (?, ?, ?)";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, loanId);
            ps.setDate(2, paymentDate);
            ps.setDouble(3, paymentAmount);
            ps.executeUpdate();
            System.out.println("Payment recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void calculateInterest(int loanId) {
        String query = "SELECT loan_amount, interest_rate FROM loan WHERE loan_id = ?";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, loanId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                double loanAmount = rs.getDouble("loan_amount");
                double interestRate = rs.getDouble("interest_rate");
                double interest = loanAmount * (interestRate / 100);
                System.out.println("Interest for Loan ID " + loanId + " is: " + interest);
            } else {
                System.out.println("Loan not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPaymentHistory(int loanId) {
        String query = "SELECT * FROM payment WHERE loan_id = ?";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, loanId);
            ResultSet rs = ps.executeQuery();
            List<String> payments = new ArrayList<>();
            while (rs.next()) {
                payments.add("Payment ID: " + rs.getInt("payment_id") + ", Date: " + rs.getDate("payment_date") + ", Amount: " + rs.getDouble("payment_amount"));
            }
            if (payments.isEmpty()) {
                System.out.println("No payment history found for Loan ID " + loanId);
            } else {
                payments.forEach(System.out::println);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

