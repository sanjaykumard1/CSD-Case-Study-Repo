package com.main;

import java.sql.Date;
import com.loan.LoanManagement;
import com.payment.PaymentManagement;
import customer.CustomerManagement;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CustomerManagement customerManagement = new CustomerManagement();
        LoanManagement loanManagement = new LoanManagement();
        PaymentManagement paymentManagement = new PaymentManagement();

        while (true) {
            System.out.println("Loan Management System");
            System.out.println("1. Add New Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Add New Loan");
            System.out.println("4. View Loan Details");
            System.out.println("5. Update Loan Information");
            System.out.println("6. Remove Loan Account");
            System.out.println("7. Record Loan Payment");
            System.out.println("8. Calculate Interest");
            System.out.println("9. View Payment History");
            System.out.println("10. Remove Customer");
            System.out.println("0. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.nextLine();
                    customerManagement.addCustomer(customerName);
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    customerManagement.viewCustomerDetails(customerId);
                    break;
                case 3:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter loan amount: ");
                    double loanAmount = scanner.nextDouble();
                    System.out.print("Enter interest rate: ");
                    double interestRate = scanner.nextDouble();
                    System.out.print("Enter start date (yyyy-mm-dd): ");
                    Date startDate = Date.valueOf(scanner.next());
                    System.out.print("Enter end date (yyyy-mm-dd): ");
                    Date endDate = Date.valueOf(scanner.next());
                    loanManagement.addNewLoan(customerId, loanAmount, interestRate, startDate, endDate);
                    break;
                case 4:
                    System.out.print("Enter loan ID: ");
                    int loanId = scanner.nextInt();
                    loanManagement.viewLoanDetails(loanId);
                    break;
                case 5:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter new loan amount: ");
                    loanAmount = scanner.nextDouble();
                    System.out.print("Enter new interest rate: ");
                    interestRate = scanner.nextDouble();
                    System.out.print("Enter new start date (yyyy-mm-dd): ");
                    startDate = Date.valueOf(scanner.next());
                    System.out.print("Enter new end date (yyyy-mm-dd): ");
                    endDate = Date.valueOf(scanner.next());
                    System.out.print("Enter status (active/closed): ");
                    String status = scanner.next();
                    loanManagement.updateLoanInformation(loanId, customerId, loanAmount, interestRate, startDate, endDate, status);
                    break;
                case 6:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.nextInt();
                    loanManagement.removeLoanAccount(loanId);
                    break;
                case 7:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.nextInt();
                    System.out.print("Enter payment amount: ");
                    double paymentAmount = scanner.nextDouble();
                    System.out.print("Enter payment date (yyyy-mm-dd): ");
                    Date paymentDate = Date.valueOf(scanner.next());
                    paymentManagement.recordLoanPayment(loanId, paymentDate, paymentAmount);
                    break;
                case 8:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.nextInt();
                    paymentManagement.calculateInterest(loanId);
                    break;
                case 9:
                    System.out.print("Enter loan ID: ");
                    loanId = scanner.nextInt();
                    paymentManagement.viewPaymentHistory(loanId);
                    break;
                case 10:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    customerManagement.removeCustomer(customerId);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}

