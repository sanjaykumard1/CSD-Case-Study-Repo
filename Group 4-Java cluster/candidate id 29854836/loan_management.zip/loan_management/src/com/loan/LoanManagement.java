package com.loan;

import java.sql.*;
import com.utils.*;


public class LoanManagement {

    public void addNewLoan(int customerId, double loanAmount, double interestRate, Date startDate, Date endDate) {
        String query = "INSERT INTO loan (customer_id, loan_amount, interest_rate, start_date, end_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customerId);
            ps.setDouble(2, loanAmount);
            ps.setDouble(3, interestRate);
            ps.setDate(4, startDate);
            ps.setDate(5, endDate);
            ps.executeUpdate();
            System.out.println("Loan added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewLoanDetails(int loanId) {
        String query = "SELECT * FROM loan WHERE loan_id = ?";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, loanId);
            ResultSet res = ps.executeQuery();
            if (res.next()) {
                System.out.println("Loan ID: " + res.getInt("loan_id"));
                System.out.println("Customer ID: " + res.getInt("customer_id"));
                System.out.println("Loan Amount: " + res.getDouble("loan_amount"));
                System.out.println("Interest Rate: " + res.getDouble("interest_rate"));
                System.out.println("Start Date: " + res.getDate("start_date"));
                System.out.println("End Date: " + res.getDate("end_date"));
                System.out.println("Status: " + res.getString("loan_status"));
            } else {
                System.out.println("Loan not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateLoanInformation(int loanId, int customerId, double loanAmount, double interestRate, Date startDate, Date endDate, String status) {
        String query = "UPDATE loan SET customer_id = ?, loan_amount = ?, interest_rate = ?, start_date = ?, end_date = ?, loan_status = ? WHERE loan_id = ?";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, customerId);
            ps.setDouble(2, loanAmount);
            ps.setDouble(3, interestRate);
            ps.setDate(4, startDate);
            ps.setDate(5, endDate);
            ps.setString(6, status);
            ps.setInt(7, loanId);
            ps.executeUpdate();
            System.out.println("Loan updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeLoanAccount(int loanId) {
        String query = "DELETE FROM loan WHERE loan_id = ?";
        try (Connection conn = dbconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, loanId);
            ps.executeUpdate();
            System.out.println("Loan removed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

