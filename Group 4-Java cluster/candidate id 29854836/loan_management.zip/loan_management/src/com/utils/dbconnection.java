package com.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class dbconnection {
    private static Connection connection=null;
    private static String url="jdbc:mysql://localhost:3306/loanmanagement";
    private static String username="root";
    private static String password="";

    public static Connection getConnection(){
        try{
            connection= DriverManager.getConnection(url,username,password);
            System.out.println("connection done");
        }catch(Exception e){
            System.out.println("connection not created : "+ e);
        }
        return connection;
    }

}

