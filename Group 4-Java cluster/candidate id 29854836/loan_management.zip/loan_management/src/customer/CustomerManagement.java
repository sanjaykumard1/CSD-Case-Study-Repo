package customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.utils.dbconnection;

public class CustomerManagement {

    // Add a new customer to the database
    public void addCustomer(String customerName) {
        String query = "INSERT INTO customers (customer_name) VALUES (?)";

        try (Connection conn = dbconnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, customerName);
            pstmt.executeUpdate();
            System.out.println("Customer added successfully: " + customerName);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }
    public void viewCustomerDetails(int customerId) {
        String query = "SELECT * FROM customers WHERE customer_id = ?";

        try (Connection conn = dbconnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Customer Name: " + rs.getString("customer_name"));
            } else {
                System.out.println("Customer not found with ID: " + customerId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing customer details: " + e.getMessage());
        }
    }

    // Remove a customer by customer ID
    public void removeCustomer(int customerId) {
        String query = "DELETE FROM customers WHERE customer_id = ?";

        try (Connection conn = dbconnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, customerId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Customer removed successfully: " + customerId);
            } else {
                System.out.println("Customer not found with ID: " + customerId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error removing customer: " + e.getMessage());
        }
    }
}
