/**
 * 
 */
/**
 * 
 */
module studentEnrollmentManagement {
	requires java.sql;
}