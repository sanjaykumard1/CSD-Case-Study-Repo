package com.library.main;

import com.library.dao.AuthorDAO;
import com.library.dao.EBookDAO;
import com.library.dao.UserDAO;
import com.library.model.Author;
import com.library.model.EBook;
import com.library.model.User;

import java.util.List;
import java.util.Scanner;

public class LibraryManagementSystem {

    private static final Scanner scanner = new Scanner(System.in);
    private static final EBookDAO eBookDAO = new EBookDAO();
    private static final AuthorDAO authorDAO = new AuthorDAO();
    private static final UserDAO userDAO = new UserDAO();

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    ebookManagement();
                    break;
                case 2:
                    authorManagement();
                    break;
                case 3:
                    membershipManagement();
                    break;
                case 4:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 4.");
            }
        }
        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. E-Book Management");
        System.out.println("2. Author Management");
        System.out.println("3. Membership Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void ebookManagement() {
        boolean backToMenu = false;
        while (!backToMenu) {
            System.out.println("E-Book Management:");
            System.out.println("1. Add a new e-book");
            System.out.println("2. View e-book details");
            System.out.println("3. Update e-book details");
            System.out.println("4. Delete an e-book");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    addEBook();
                    break;
                case 2:
                    viewEBook();
                    break;
                case 3:
                    updateEBook();
                    break;
                case 4:
                    deleteEBook();
                    break;
                case 5:
                    backToMenu = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 5.");
            }
        }
    }

    private static void addEBook() {
        System.out.println("Enter title: ");
        String title = scanner.nextLine();
        System.out.println("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.println("Enter publication date (YYYY-MM-DD): ");
        String publicationDate = scanner.nextLine();
        System.out.println("Enter author ID: ");
        int authorId = scanner.nextInt();
        System.out.println("Enter available copies: ");
        int availableCopies = scanner.nextInt();

        EBook eBook = new EBook();
        eBook.setTitle(title);
        eBook.setGenre(genre);
        eBook.setPublication_date(publicationDate);
        eBook.setAuthor_id(authorId);
        eBook.setAvailable_copies(availableCopies);

        eBookDAO.addEBook(eBook);
        System.out.println("E-Book added successfully.");
    }

    private static void viewEBook() {
        System.out.println("Enter e-book ID: ");
        int ebookId = scanner.nextInt();
        EBook eBook = eBookDAO.getEBook(ebookId);

        if (eBook != null) {
            System.out.println("E-Book details:");
            System.out.println("ID: " + eBook.getEbook_id());
            System.out.println("Title: " + eBook.getTitle());
            System.out.println("Genre: " + eBook.getGenre());
            System.out.println("Publication Date: " + eBook.getPublication_date());
            System.out.println("Author ID: " + eBook.getAuthor_id());
            System.out.println("Available Copies: " + eBook.getAvailable_copies());
        } else {
            System.out.println("E-Book not found.");
        }
    }

    private static void updateEBook() {
        System.out.println("Enter e-book ID to update: ");
        int ebookId = scanner.nextInt();
        scanner.nextLine(); 

        EBook existingEBook = eBookDAO.getEBook(ebookId);
        if (existingEBook == null) {
            System.out.println("E-Book not found.");
            return;
        }

        System.out.println("Enter new title (press Enter to keep current: " + existingEBook.getTitle() + "): ");
        String title = scanner.nextLine();
        if (!title.isEmpty()) {
            existingEBook.setTitle(title);
        }

        System.out.println("Enter new genre (press Enter to keep current: " + existingEBook.getGenre() + "): ");
        String genre = scanner.nextLine();
        if (!genre.isEmpty()) {
            existingEBook.setGenre(genre);
        }

        System.out.println("Enter new publication date (YYYY-MM-DD) (press Enter to keep current: "
                + existingEBook.getPublication_date() + "): ");
        String publicationDate = scanner.nextLine();
        if (!publicationDate.isEmpty()) {
            existingEBook.setPublication_date(publicationDate);
        }

        System.out.println("Enter new author ID (press Enter to keep current: " + existingEBook.getAuthor_id() + "): ");
        String authorIdStr = scanner.nextLine();
        if (!authorIdStr.isEmpty()) {
            int authorId = Integer.parseInt(authorIdStr);
            existingEBook.setAuthor_id(authorId);
        }

        System.out.println("Enter new available copies (press Enter to keep current: "
                + existingEBook.getAvailable_copies() + "): ");
        String availableCopiesStr = scanner.nextLine();
        if (!availableCopiesStr.isEmpty()) {
            int availableCopies = Integer.parseInt(availableCopiesStr);
            existingEBook.setAvailable_copies(availableCopies);
        }

        boolean updated = eBookDAO.updateEBook(existingEBook);
        if (updated) {
            System.out.println("E-Book updated successfully.");
        } else {
            System.out.println("Failed to update e-book.");
        }
    }

    private static void deleteEBook() {
        System.out.println("Enter e-book ID to delete: ");
        int ebookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        boolean deleted = eBookDAO.deleteEBook(ebookId);
        if (deleted) {
            System.out.println("E-Book deleted successfully.");
        } else {
            System.out.println("Failed to delete e-book. E-Book not found.");
        }
    }

    private static void authorManagement() {
        boolean backToMenu = false;
        while (!backToMenu) {
            System.out.println("Author Management:");
            System.out.println("1. Add a new author");
            System.out.println("2. View author details");
            System.out.println("3. Update author details");
            System.out.println("4. Delete an author");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addAuthor();
                    break;
                case 2:
                    viewAuthor();
                    break;
                case 3:
                    updateAuthor();
                    break;
                case 4:
                    deleteAuthor();
                    break;
                case 5:
                    backToMenu = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 5.");
            }
        }
    }

    private static void addAuthor() {
        System.out.println("Enter author name: ");
        String name = scanner.nextLine();
        System.out.println("Enter author bio: ");
        String bio = scanner.nextLine();
        System.out.println("Enter author nationality: ");
        String nationality = scanner.nextLine();
        System.out.println("Enter author birth date (YYYY-MM-DD): ");
        String birthDate = scanner.nextLine();

        Author author = new Author();
        author.setName(name);
        author.setBio(bio);
        author.setNationality(nationality);
        author.setBirth_date(birthDate);

        authorDAO.addAuthor(author);
        System.out.println("Author added successfully.");
    }

    private static void viewAuthor() {
        System.out.println("Enter author ID: ");
        int authorId = scanner.nextInt();
        Author author = authorDAO.getAuthor(authorId);

        if (author != null) {
            System.out.println("Author details:");
            System.out.println("ID: " + author.getAuthor_id());
            System.out.println("Name: " + author.getName());
            System.out.println("Bio: " + author.getBio());
            System.out.println("Nationality: " + author.getNationality());
            System.out.println("Birth Date: " + author.getBirth_date());
        } else {
            System.out.println("Author not found.");
        }
    }

    private static void updateAuthor() {
        System.out.println("Enter author ID to update: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); 

        Author existingAuthor = authorDAO.getAuthor(authorId);
        if (existingAuthor == null) {
            System.out.println("Author not found.");
            return;
        }

        System.out.println("Enter new name (press Enter to keep current: " + existingAuthor.getName() + "): ");
        String name = scanner.nextLine();
        if (!name.isEmpty()) {
            existingAuthor.setName(name);
        }

        System.out.println("Enter new bio (press Enter to keep current: " + existingAuthor.getBio() + "): ");
        String bio = scanner.nextLine();
        if (!bio.isEmpty()) {
            existingAuthor.setBio(bio);
        }

        System.out.println("Enter new nationality (press Enter to keep current: "
                + existingAuthor.getNationality() + "): ");
        String nationality = scanner.nextLine();
        if (!nationality.isEmpty()) {
            existingAuthor.setNationality(nationality);
        }

        System.out.println("Enter new birth date (YYYY-MM-DD) (press Enter to keep current: "
                + existingAuthor.getBirth_date() + "): ");
        String birthDate = scanner.nextLine();
        if (!birthDate.isEmpty()) {
            existingAuthor.setBirth_date(birthDate);
        }

        boolean updated = authorDAO.updateAuthor(existingAuthor);
        if (updated) {
            System.out.println("Author updated successfully.");
        } else {
            System.out.println("Failed to update author.");
        }
    }

    private static void deleteAuthor() {
        System.out.println("Enter author ID to delete: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); 

        boolean deleted = authorDAO.deleteAuthor(authorId);
        if (deleted) {
            System.out.println("Author deleted successfully.");
        } else {
            System.out.println("Failed to delete author. Author not found.");
        }
    }

    private static void membershipManagement() {
        boolean backToMenu = false;
        while (!backToMenu) {
            System.out.println("Membership Management:");
            System.out.println("1. Register a new user");
            System.out.println("2. View user membership details");
            System.out.println("3. Update user membership details");
            System.out.println("4. Delete a user");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    registerUser();
                    break;
                case 2:
                    viewUser();
                    break;
                case 3:
                    updateUser();
                    break;
                case 4:
                    deleteUser();
                    break;
                case 5:
                    backToMenu = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 5.");
            }
        }
    }

    private static void registerUser() {
        System.out.println("Enter username: ");
        String username = scanner.nextLine();
        System.out.println("Enter email: ");
        String email = scanner.nextLine();
        System.out.println("Enter date of birth (YYYY-MM-DD): ");
        String dateOfBirth = scanner.nextLine();
        System.out.println("Enter membership date (YYYY-MM-DD): ");
        String membershipDate = scanner.nextLine();
        System.out.println("Enter membership status (active/inactive): ");
        String membershipStatus = scanner.nextLine();

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setDate_of_birth(dateOfBirth);
        user.setMembership_date(membershipDate);
        user.setMembership_status(membershipStatus);

        userDAO.addUser(user);
        System.out.println("User registered successfully.");
    }

    private static void viewUser() {
        System.out.println("Enter user ID: ");
        int userId = scanner.nextInt();
        User user = userDAO.getUser(userId);

        if (user != null) {
            System.out.println("User details:");
            System.out.println("ID: " + user.getUser_id());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Date of Birth: " + user.getDate_of_birth());
            System.out.println("Membership Date: " + user.getMembership_date());
            System.out.println("Membership Status: " + user.getMembership_status());
        } else {
            System.out.println("User not found.");
        }
    }

    private static void updateUser() {
        System.out.println("Enter user ID to update: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); 

        User existingUser = userDAO.getUser(userId);
        if (existingUser == null) {
            System.out.println("User not found.");
            return;
        }

        System.out.println("Enter new username (press Enter to keep current: " + existingUser.getUsername() + "): ");
        String username = scanner.nextLine();
        if (!username.isEmpty()) {
            existingUser.setUsername(username);
        }

        System.out.println("Enter new email (press Enter to keep current: " + existingUser.getEmail() + "): ");
        String email = scanner.nextLine();
        if (!email.isEmpty()) {
            existingUser.setEmail(email);
        }

        System.out.println("Enter new date of birth (YYYY-MM-DD) (press Enter to keep current: "
                + existingUser.getDate_of_birth() + "): ");
        String dateOfBirth = scanner.nextLine();
        if (!dateOfBirth.isEmpty()) {
            existingUser.setDate_of_birth(dateOfBirth);
        }

        System.out.println("Enter new membership date (YYYY-MM-DD) (press Enter to keep current: "
                + existingUser.getMembership_date() + "): ");
        String membershipDate = scanner.nextLine();
        if (!membershipDate.isEmpty()) {
            existingUser.setMembership_date(membershipDate);
        }

        System.out.println("Enter new membership status (active/inactive) (press Enter to keep current: "
                + existingUser.getMembership_status() + "): ");
        String membershipStatus = scanner.nextLine();
        if (!membershipStatus.isEmpty()) {
            existingUser.setMembership_status(membershipStatus);
        }

        boolean updated = userDAO.updateUser(existingUser);
        if (updated) {
            System.out.println("User updated successfully.");
        } else {
            System.out.println("Failed to update user.");
        }
    }

    private static void deleteUser() {
        System.out.println("Enter user ID to delete: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); 

        boolean deleted = userDAO.deleteUser(userId);
        if (deleted) {
            System.out.println("User deleted successfully.");
        } else {
            System.out.println("Failed to delete user. User not found.");
        }
    }
}
