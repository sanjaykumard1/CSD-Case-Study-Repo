package com.library.model;

public class EBook {
    private int ebook_id;
    private String title;
    private String genre;
    private String publication_date;
    private int author_id;
    private int available_copies;

    public int getEbook_id() {
        return ebook_id;
    }

    public void setEbook_id(int ebook_id) {
        this.ebook_id = ebook_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPublication_date() {
        return publication_date;
    }

    public void setPublication_date(String publication_date) {
        this.publication_date = publication_date;
    }

    public int getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(int author_id) {
        this.author_id = author_id;
    }

    public int getAvailable_copies() {
        return available_copies;
    }

    public void setAvailable_copies(int available_copies) {
        this.available_copies = available_copies;
    }
}
