package com.library.dao;

import com.library.model.EBook;
import com.library.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EBookDAO {
    private static final String INSERT_EBOOK_SQL = "INSERT INTO EBook (title, genre, publication_date, author_id, available_copies) VALUES (?, ?, ?, ?, ?)";
    private static final String SELECT_EBOOK_BY_ID = "SELECT * FROM EBook WHERE ebook_id=?";
    private static final String SELECT_ALL_EBOOKS = "SELECT * FROM EBook";
    private static final String DELETE_EBOOK_SQL = "DELETE FROM EBook WHERE ebook_id=?";
    private static final String UPDATE_EBOOK_SQL = "UPDATE EBook SET title=?, genre=?, publication_date=?, author_id=?, available_copies=? WHERE ebook_id=?";

    public void addEBook(EBook ebook) {
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_EBOOK_SQL,Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, ebook.getTitle());
            preparedStatement.setString(2, ebook.getGenre());
            preparedStatement.setString(3, ebook.getPublication_date());
            preparedStatement.setInt(4, ebook.getAuthor_id());
            preparedStatement.setInt(5, ebook.getAvailable_copies());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("E-Book added successfully.");
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    ebook.setEbook_id(generatedKeys.getInt(1)); 
                }
            } else {
                System.out.println("Failed to add E-Book.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding E-Book: " + e.getMessage());
        }
    }

    public EBook getEBook(int ebookId) {
        EBook ebook = null;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_EBOOK_BY_ID)) {

            preparedStatement.setInt(1, ebookId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                ebook = new EBook();
                ebook.setEbook_id(resultSet.getInt("ebook_id"));
                ebook.setTitle(resultSet.getString("title"));
                ebook.setGenre(resultSet.getString("genre"));
                ebook.setPublication_date(resultSet.getString("publication_date"));
                ebook.setAuthor_id(resultSet.getInt("author_id"));
                ebook.setAvailable_copies(resultSet.getInt("available_copies"));
            } else {
                System.out.println("E-Book not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching E-Book: " + e.getMessage());
        }
        return ebook;
    }

    public List<EBook> getAllEBooks() {
        List<EBook> ebooks = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_EBOOKS)) {

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                EBook ebook = new EBook();
                ebook.setEbook_id(resultSet.getInt("ebook_id"));
                ebook.setTitle(resultSet.getString("title"));
                ebook.setGenre(resultSet.getString("genre"));
                ebook.setPublication_date(resultSet.getString("publication_date"));
                ebook.setAuthor_id(resultSet.getInt("author_id"));
                ebook.setAvailable_copies(resultSet.getInt("available_copies"));
                ebooks.add(ebook);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching E-Books: " + e.getMessage());
        }
        return ebooks;
    }

    public boolean deleteEBook(int ebookId) {
        boolean deleted = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_EBOOK_SQL)) {

            preparedStatement.setInt(1, ebookId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                deleted = true;
                System.out.println("E-Book deleted successfully.");
            } else {
                System.out.println("E-Book not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting E-Book: " + e.getMessage());
        }
        return deleted;
    }

    public boolean updateEBook(EBook ebook) {
        boolean updated = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_EBOOK_SQL)) {

            preparedStatement.setString(1, ebook.getTitle());
            preparedStatement.setString(2, ebook.getGenre());
            preparedStatement.setString(3, ebook.getPublication_date());
            preparedStatement.setInt(4, ebook.getAuthor_id());
            preparedStatement.setInt(5, ebook.getAvailable_copies());
            preparedStatement.setInt(6, ebook.getEbook_id());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                updated = true;
                System.out.println("E-Book updated successfully.");
            } else {
                System.out.println("E-Book not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating E-Book: " + e.getMessage());
        }
        return updated;
    }
}
