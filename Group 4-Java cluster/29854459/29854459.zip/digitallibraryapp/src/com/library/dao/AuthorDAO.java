package com.library.dao;

import com.library.model.Author;
import com.library.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AuthorDAO {
    private static final String INSERT_AUTHOR_SQL = "INSERT INTO Author (name, bio, nationality, birth_date) VALUES (?, ?, ?, ?)";
    private static final String SELECT_AUTHOR_BY_ID = "SELECT * FROM Author WHERE author_id=?";
    private static final String SELECT_ALL_AUTHORS = "SELECT * FROM Author";
    private static final String DELETE_AUTHOR_SQL = "DELETE FROM Author WHERE author_id=?";
    private static final String UPDATE_AUTHOR_SQL = "UPDATE Author SET name=?, bio=?, nationality=?, birth_date=? WHERE author_id=?";

    public void addAuthor(Author author) {
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_AUTHOR_SQL)) {

            preparedStatement.setString(1, author.getName());
            preparedStatement.setString(2, author.getBio());
            preparedStatement.setString(3, author.getNationality());
            preparedStatement.setString(4, author.getBirth_date());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Author added successfully.");
            } else {
                System.out.println("Failed to add Author.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding Author: " + e.getMessage());
        }
    }

    public Author getAuthor(int authorId) {
        Author author = null;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_AUTHOR_BY_ID)) {

            preparedStatement.setInt(1, authorId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                author = new Author();
                author.setAuthor_id(resultSet.getInt("author_id"));
                author.setName(resultSet.getString("name"));
                author.setBio(resultSet.getString("bio"));
                author.setNationality(resultSet.getString("nationality"));
                author.setBirth_date(resultSet.getString("birth_date"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching Author: " + e.getMessage());
        }
        return author;
    }

    public List<Author> getAllAuthors() {
        List<Author> authors = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_AUTHORS)) {

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Author author = new Author();
                author.setAuthor_id(resultSet.getInt("author_id"));
                author.setName(resultSet.getString("name"));
                author.setBio(resultSet.getString("bio"));
                author.setNationality(resultSet.getString("nationality"));
                author.setBirth_date(resultSet.getString("birth_date"));
                authors.add(author);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching Authors: " + e.getMessage());
        }
        return authors;
    }

    public boolean deleteAuthor(int authorId) {
        boolean deleted = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_AUTHOR_SQL)) {

            preparedStatement.setInt(1, authorId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                deleted = true;
                System.out.println("Author deleted successfully.");
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting Author: " + e.getMessage());
        }
        return deleted;
    }

    public boolean updateAuthor(Author author) {
        boolean updated = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_AUTHOR_SQL)) {

            preparedStatement.setString(1, author.getName());
            preparedStatement.setString(2, author.getBio());
            preparedStatement.setString(3, author.getNationality());
            preparedStatement.setString(4, author.getBirth_date());
            preparedStatement.setInt(5, author.getAuthor_id());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                updated = true;
                System.out.println("Author updated successfully.");
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating Author: " + e.getMessage());
        }
        return updated;
    }
}
