package com.library.dao;

import com.library.model.User;
import com.library.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private static final String INSERT_USER_SQL = "INSERT INTO User (username, email, date_of_birth, membership_date, membership_status) VALUES (?, ?, ?, ?, ?)";
    private static final String SELECT_USER_BY_ID = "SELECT * FROM User WHERE user_id=?";
    private static final String SELECT_ALL_USERS = "SELECT * FROM User";
    private static final String DELETE_USER_SQL = "DELETE FROM User WHERE user_id=?";
    private static final String UPDATE_USER_SQL = "UPDATE User SET username=?, email=?, date_of_birth=?, membership_date=?, membership_status=? WHERE user_id=?";

    public void addUser(User user) {
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_SQL)) {

            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getDate_of_birth());
            preparedStatement.setString(4, user.getMembership_date());
            preparedStatement.setString(5, user.getMembership_status());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User added successfully.");
            } else {
                System.out.println("Failed to add User.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding User: " + e.getMessage());
        }
    }

    public User getUser(int userId) {
        User user = null;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID)) {

            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setUser_id(resultSet.getInt("user_id"));
                user.setUsername(resultSet.getString("username"));
                user.setEmail(resultSet.getString("email"));
                user.setDate_of_birth(resultSet.getString("date_of_birth"));
                user.setMembership_date(resultSet.getString("membership_date"));
                user.setMembership_status(resultSet.getString("membership_status"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching User: " + e.getMessage());
        }
        return user;
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS)) {

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                User user = new User();
                user.setUser_id(resultSet.getInt("user_id"));
                user.setUsername(resultSet.getString("username"));
                user.setEmail(resultSet.getString("email"));
                user.setDate_of_birth(resultSet.getString("date_of_birth"));
                user.setMembership_date(resultSet.getString("membership_date"));
                user.setMembership_status(resultSet.getString("membership_status"));
                users.add(user);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching Users: " + e.getMessage());
        }
        return users;
    }

    public boolean deleteUser(int userId) {
        boolean deleted = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_USER_SQL)) {

            preparedStatement.setInt(1, userId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                deleted = true;
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting User: " + e.getMessage());
        }
        return deleted;
    }

    public boolean updateUser(User user) {
        boolean updated = false;
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_USER_SQL)) {

            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getDate_of_birth());
            preparedStatement.setString(4, user.getMembership_date());
            preparedStatement.setString(5, user.getMembership_status());
            preparedStatement.setInt(6, user.getUser_id());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                updated = true;
                System.out.println("User updated successfully.");
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating User: " + e.getMessage());
        }
        return updated;
    }
}
