Digital Library Management System

Overview

This is a digital library management system built in Java. It allows users to manage e-books, authors, and user memberships. The application interacts with a MySQL database to store and retrieve information.


Features

- Add, view, update, and delete e-books.
- Add, view, update, and delete authors.
- Register new users and view their membership details.

Database Schema

E-Book Table
- ebook_id (Primary Key)
- title
- genre
- publication_date
- author_id (Foreign Key references Author Table)
- available_copies

Author Table
- author_id (Primary Key)
- name
- bio
- nationality
- birth_date

User Table
- user_id (Primary Key)
- username
- email
- date_of_birth
- membership_date
- membership_status (active/inactive)

Setup Instructions

Prerequisites

- Java Development Kit (JDK) installed
- MySQL Server installed and running
- A MySQL client or command-line access to your MySQL server

