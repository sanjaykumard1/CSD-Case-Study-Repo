module digitallibraryapp {
    requires java.sql; 
    exports com.library.model; 
    exports com.library.dao; 
    exports com.library.main; 
}
