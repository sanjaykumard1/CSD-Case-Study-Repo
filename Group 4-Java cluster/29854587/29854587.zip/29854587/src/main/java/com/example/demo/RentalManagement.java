package com.example.demo;

import java.sql.*;
import java.util.Scanner;

public class RentalManagement {
    public static void rentalMenu(Connection connection, Scanner scanner) {
        while(true)
        {
            System.out.println("\nRental Management"); // Menu driven program for rental
            System.out.println("1. Rent a car to a customer");
            System.out.println("2. Return a rented car");
            System.out.println("3. View rental details");
            System.out.println("4. Calculate rental charges");
            System.out.println("5. Go Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    rentCar(connection, scanner);
                    break;
                case 2:
                    returnCar(connection, scanner);
                    break;
                case 3:
                    viewRentalDetails(connection, scanner);
                    break;
                case 4:
                    calculateRentalCharges(connection, scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void rentCar(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter car ID: ");
            int carId = scanner.nextInt();
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter rental start date (YYYY-MM-DD): ");
            String rentalStartDate = scanner.next();
            System.out.print("Enter rental end date (YYYY-MM-DD): ");
            String rentalEndDate = scanner.next();

            String query = "INSERT INTO Rental (car_id, customer_id, rental_start_date, rental_end_date, total_charge) VALUES (?, ?, ?, ?, ?)"; // insert into rental table with the values entered by the user.
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, carId);
            pstmt.setInt(2, customerId);
            pstmt.setDate(3, Date.valueOf(rentalStartDate));
            pstmt.setDate(4, Date.valueOf(rentalEndDate));

            // Calculate total charge
            double totalCharge = calculateTotalCharge(connection, carId, rentalStartDate, rentalEndDate);
            pstmt.setDouble(5, totalCharge);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Car rented successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void returnCar(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter rental ID: ");
            int rentalId = scanner.nextInt();

            String query = "DELETE FROM Rental WHERE rental_id = ?"; // This query is so that when the user has returned the car, it needs to be deleted.
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, rentalId);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Car returned successfully.");
            } else {
                System.out.println("Rental not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewRentalDetails(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter rental ID: ");
            int rentalId = scanner.nextInt();

            String query = "SELECT * FROM Rental WHERE rental_id = ?"; // view the rental details using this query
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, rentalId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Rental ID: " + rs.getInt("rental_id"));
                System.out.println("Car ID: " + rs.getInt("car_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Rental Start Date: " + rs.getDate("rental_start_date"));
                System.out.println("Rental End Date: " + rs.getDate("rental_end_date"));
                System.out.println("Total Charge: " + rs.getDouble("total_charge"));
            } else {
                System.out.println("Rental not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void calculateRentalCharges(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter rental ID: ");
            int rentalId = scanner.nextInt();

            String query = "SELECT car_id, rental_start_date, rental_end_date FROM Rental WHERE rental_id = ?"; //depending upon the rental_id these fields are used to calculate the total charge.
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, rentalId); // used to substitute the ? with the id entered by the user

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int carId = rs.getInt("car_id");
                String rentalStartDate = rs.getString("rental_start_date"); // using result set , the start and end date are stored
                String rentalEndDate = rs.getString("rental_end_date");
                double totalCharge = calculateTotalCharge(connection, carId, rentalStartDate, rentalEndDate); // function used to calculate the charge for renting the car
                System.out.println("Total Charge: " + totalCharge);
            } else {
                System.out.println("Rental not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static double calculateTotalCharge(Connection connection, int carId, String rentalStartDate, String rentalEndDate) {
        double totalCharge = 0.0;
        try {
            String query = "SELECT daily_rate FROM Car WHERE car_id = ?"; // used to get the daily_rate from the table depending upon the car_id.
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, carId); // used to substitute the ? with car_id entered by the user

            ResultSet rs = pstmt.executeQuery(); // store the result of the query in ResultSet
            if (rs.next()) {
                double dailyRate = rs.getDouble("daily_rate"); // get daily rate from result set
                long days = (Date.valueOf(rentalEndDate).getTime() - Date.valueOf(rentalStartDate).getTime()) / (1000 * 60 * 60 * 24); // then we calculate the days by subtracting the end date and start date
                totalCharge = dailyRate * days; // then multiply the daily rate with days to get the total_charge for renting.
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return totalCharge;
    }
}
