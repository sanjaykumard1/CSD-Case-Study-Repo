package com.example.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CarManagement {
    public static void carMenu(Connection conn, Scanner sc)
    {

        while(true)
        {
            System.out.println("\n Car Management System"); // Menu Driven program for Car
            System.out.println("1. Add a new car");
            System.out.println("2. View car details");
            System.out.println("3. Update car information");
            System.out.println("4. Delete a car");
            System.out.println("5. Go back to main menu");
            int choice = sc.nextInt();
            switch (choice)
            {
                case 1:
                {
                    addCar(sc,conn);
                    break;
                }
                case 2:
                {
                    viewCar(sc,conn);
                    break;
                }
                case 3:
                {
                    updateCar(sc,conn);
                    break;
                }
                case 4:
                {
                    deleteCar(sc,conn);
                    break;
                }
                case 5:
                {
                     return;
                }
                default:
                {
                    System.out.println("Invalid Choice");
                }
            }
        }
    }
    public static void addCar(Scanner scanner, Connection connection) {
        try {
            System.out.print("Enter car ID: ");
            int carId = scanner.nextInt();
            scanner.nextLine(); // consume extra line

            String checkSql = "SELECT COUNT(*) FROM car WHERE car_id = ?"; // Query to check if there exists any other row with that car id.
            PreparedStatement checkStmt = connection.prepareStatement(checkSql); // Then execute it using preparedStatement
            checkStmt.setInt(1, carId); // The user input we got , is being set in the place of ? in the query and if there are more ? then it would go 1,2,3,and so on.
            ResultSet rs = checkStmt.executeQuery(); // ResultSet stores the result of the queryexecution in rs.
            rs.next(); // moves the cursor to the first row of the result set
            int count = rs.getInt(1); // method retrieves the value of the first column of the current row of the result set, which is the count of rows where the customer_id matches the given id

            if (count > 0) { //if the count is greater than 0 then it exists
                System.out.println("Car ID already exists!");
                return; // Exit the method
            }

            System.out.print("Enter make: ");
            String make = scanner.nextLine();

            System.out.print("Enter model: ");
            String model = scanner.nextLine();

            System.out.print("Enter year: ");
            int year = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            System.out.print("Enter daily rate: ");
            double dailyRate = scanner.nextDouble();

            String query = "INSERT INTO car (car_id, make, model, year, daily_rate) VALUES (?, ?, ?, ?, ?)"; // Query for insertion of data into the table
            PreparedStatement pstmt = connection.prepareStatement(query); // update the user entered value in the database.
            pstmt.setInt(1, carId);
            pstmt.setString(2, make);
            pstmt.setString(3, model);
            pstmt.setInt(4, year);
            pstmt.setDouble(5, dailyRate);

            int rowsAffected = pstmt.executeUpdate(); // executeUpdate is used to count the no of rows that has been updated
            if (rowsAffected > 0) {
                System.out.println("Car added successfully.");
            } else {
                System.out.println("Error adding car.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewCar(Scanner sc , Connection conn)
    {
        try {
            System.out.println("Enter car id");
            int carId = sc.nextInt();
            String sql = "SELECT * FROM Car WHERE car_id = ?"; // query to display the content from the table in the database
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,carId);
            ResultSet rs = pstmt.executeQuery();
            if(rs.next())
            {
                System.out.println("Car Details :");
                System.out.println("Car ID : " + rs.getInt("car_id"));
                System.out.println("Make : " + rs.getString("make"));
                System.out.println("Model : " + rs.getString("model"));
                System.out.println("Year : " + rs.getInt("year"));
                System.out.println("Rate : " + rs.getDouble("daily_rate"));
            }
            else {
                System.out.println("Car not found!!");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
    public static void updateCar(Scanner sc , Connection conn)
    {
        try {
            System.out.println("Enter car id: ");
            int id = sc.nextInt();

            String checkSql = "SELECT COUNT(*) FROM car WHERE car_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, id);
            ResultSet rs = checkStmt.executeQuery();
            rs.next();
            int count = rs.getInt(1);

            if (count == 0) {
                System.out.println("Car ID already exists!");
                return;
            }
            System.out.println("Enter make of the car: ");
            sc.nextLine();
            String make = sc.nextLine();
            System.out.println("Enter model of the car: ");
            String model = sc.nextLine();
            System.out.println("Enter year: ");
            int year = sc.nextInt();
            System.out.println("Enter Daily rate of the car: ");
            double daily_rate = sc.nextDouble();
            StringBuilder sql = new StringBuilder("UPDATE Car SET make = ? , model = ? , year = ? , daily_rate = ? WHERE car_id = ?"); // query to update the database
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());
            pstmt.setString(1,make);
            pstmt.setString(2,model);
            pstmt.setInt(3,year);
            pstmt.setDouble(4,daily_rate);
            pstmt.setInt(5, id);
            int rowsAffected = pstmt.executeUpdate();
            if(rowsAffected > 0)
            {
                System.out.println("Car Details Updated");
            }
            else
            {
                System.out.println("Car not found");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

    }
    public static void deleteCar(Scanner sc , Connection conn)
    {
        try {
            System.out.println("Enter car id");
            int id = sc.nextInt();
            String sql = "DELETE FROM car where car_id = ?"; // query to delete the car by using the car_id entered by the user
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,id);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Car deleted successfully.");
            } else {
                System.out.println("Car not found.");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}
