package com.example.demo;


import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.util.Scanner;

public class DemoApplication {

	private static final String URL = "jdbc:mysql://localhost:3306/sys"; //MySQL URL which java application connects to and sys is the name of the database being used
	private static final String USER = "root";
	private static final String PASSWORD = "root";

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) { //To test out whether it connects to the database by using DriverManager and Connection
			System.out.println("Connected to the database.");

			while (true) {
				System.out.println("Car Rental Management System"); // Main Menu Driven program
				System.out.println("1. Car Management");
				System.out.println("2. Customer Management");
				System.out.println("3. Rental Management");
				System.out.println("4. Exit");
				int choice = scanner.nextInt();
				scanner.nextLine();

				switch (choice) {
					case 1:
						CarManagement.carMenu(conn, scanner); // points to CarManagement class and carMenu method.
						break;
					case 2:
						CustomerManagement.customerMenu(conn, scanner); // points to customerManagement class and customerMenu method.
						break;
					case 3:
						RentalManagement.rentalMenu(conn, scanner); // points to rentalManagement class and rentalMenu method
						break;
					case 4:
						System.out.println("Exiting...");
						return;
					default:
						System.out.println("Invalid choice. Try again.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}