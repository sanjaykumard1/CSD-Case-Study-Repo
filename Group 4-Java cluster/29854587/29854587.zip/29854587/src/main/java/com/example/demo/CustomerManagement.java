package com.example.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManagement {
    public static void customerMenu(Connection conn , Scanner sc) {
        while(true) {
            //Menu driven program for customers
            System.out.println("1. Add customers ");
            System.out.println("2. View customer details");
            System.out.println("3. Edit/Update customer details");
            System.out.println("4. Delete customer");
            System.out.println("5. Go back to main menu");
            int ch = sc.nextInt();
            switch (ch) {
                case 1: {
                    addCustomers(sc, conn);
                    break;
                }
                case 2: {
                    viewCustomers(sc, conn);
                    break;
                }
                case 3: {
                    editCustomers(sc, conn);
                    break;
                }
                case 4: {
                    deleteCustomer(sc, conn);
                    break;
                }
                case 5: {
                    return;
                }
                default:
                    System.out.println("Invalid choice");

            }
        }
    }
    public static void addCustomers(Scanner sc, Connection conn) {
        try {
            System.out.println("Enter customer id: ");
            int id = sc.nextInt();
            sc.nextLine();
            String checkSql = "SELECT COUNT(*) FROM customer WHERE customer_id = ?"; // Used to check if it already exists by counting the no of rows where customer_id = that entered by the user.
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, id);
            ResultSet rs = checkStmt.executeQuery(); // Store the query result in ResultSet
            rs.next();
            int count = rs.getInt(1);

            if (count > 0) {
                System.out.println("Customer ID already exists!");
                return;
            }

            System.out.println("Enter name: ");
            String name = sc.nextLine();

            System.out.println("Enter email: ");
            String email = sc.nextLine();

            System.out.println("Enter phone number: ");
            String phone = sc.nextLine();

            System.out.println("Enter address: ");
            String address = sc.nextLine();

            String sql = "INSERT INTO customer(customer_id, name, email, phone_number, address) VALUES(?,?,?,?,?)"; // insert values into the table using this query
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, email);
            pstmt.setString(4, phone);
            pstmt.setString(5, address);

            int result = pstmt.executeUpdate();
            if (result > 0) {
                System.out.println("Customer details inserted.");
            } else {
                System.out.println("Error!!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void deleteCustomer(Scanner sc , Connection conn)
        {
            try
            {
                System.out.println("Enter customer id: ");
                int id = sc.nextInt();
                String checkSql = "SELECT COUNT(*) from customer where customer_id = ?"; // Used to check if it already exists by counting the no of rows where customer_id = that entered by the user.
                PreparedStatement stmt = conn.prepareStatement(checkSql);
                stmt.setInt(1,id);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                int count = rs.getInt(1);
                if(count == 0)
                {
                    System.out.println("Customer ID not found");
                }
                String sql = "Delete from customer where customer_id = ?"; // query to delete the customer details depending upon the customer_id.
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1,id);
                int resultQuery = pstmt.executeUpdate();
                if(resultQuery > 0)
                {
                    System.out.println("Customer deleted");
                }
                else
                {
                    System.out.println("Delete unsuccessful");
                }
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
        public static void viewCustomers(Scanner sc , Connection conn)
        {
            try
            {
                System.out.println("Enter customer id: ");
                int id = sc.nextInt();
                String query = "Select * from customer where customer_id = ?"; // display the customer details depending upon the customer_id entered
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setInt(1,id);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next())
                {
                    System.out.println("Customer Details: ");
                    System.out.println("Customer ID: " + rs.getInt(1));
                    System.out.println("Name: " + rs.getString(2));
                    System.out.println("Email: " + rs.getString(3));
                    System.out.println("Phone Number: " +  rs.getString(4));
                    System.out.println("Address: " + rs.getString(5));
                }
                else
                {
                    System.out.println("Customer not found!!");
                }
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
        public static void editCustomers(Scanner sc , Connection conn)
        {
            try {
                System.out.println("Enter customer id: ");
                int id = sc.nextInt();
                sc.nextLine();
                String query = "SELECT COUNT(*) from customer where customer_id = ?"; // Used to check if it already exists by counting the no of rows where customer_id = that entered by the user.
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1,id);
                ResultSet rs = stmt.executeQuery(); // store it in the ResultSet
                rs.next();
                int count = rs.getInt(1);
                if(count == 0)
                {
                    System.out.println("Customer ID not found");
                }
                System.out.println("Enter name: ");
                String name = sc.nextLine();
                System.out.println("Enter email address: ");
                String email = sc.nextLine();
                System.out.println("Enter phone number: ");
                String phone = sc.nextLine();
                System.out.println("Enter address: ");
                String address = sc.nextLine();
                String sql = "UPDATE customer SET name = ?, email = ? , phone_number = ? , address = ? where customer_id = ?"; // update the customer details depending upon the customer_id entered by the user and these ? get replaced with the user input.
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1,name);
                pstmt.setString(2,email);
                pstmt.setString(3,phone);
                pstmt.setString(4,address);
                pstmt.setInt(5,id);
                int result = pstmt.executeUpdate();
                if(result > 0)
                {
                    System.out.println("Customer details updated");
                }
                else {
                    System.out.println("Error in updating the details!");
                }
            }
            catch(SQLException e)
            {
               e.printStackTrace();
            }
        }
    }

