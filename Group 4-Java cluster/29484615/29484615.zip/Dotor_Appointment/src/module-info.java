/**
 * 
 */
/**
 * 
 */
module Dotor_Appointment {
	requires java.sql;
}