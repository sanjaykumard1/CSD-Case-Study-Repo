package train.entity;

import java.sql.Date;
import java.sql.Time;

public class AppointmentScheduling {
	private int appointmentId;
    private int doctorId;
    private int patientId;
    private Date appointmentDate;
    private Time appointmentTime;
	public AppointmentScheduling() {
		super();
	}
	public AppointmentScheduling( int doctorId, int patientId, Date appointmentDate,Time appointmentTime) {
		super();
		this.doctorId = doctorId;
		this.patientId = patientId;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
	}
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public Time getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(Time appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	@Override
	public String toString() {
		return "AppointmentScheduling [appointmentId=" + appointmentId + ", doctorId=" + doctorId + ", patientId="
				+ patientId + ", appointmentDate=" + appointmentDate + ", appointmentTime=" + appointmentTime + "]";
	};
	
    
}
