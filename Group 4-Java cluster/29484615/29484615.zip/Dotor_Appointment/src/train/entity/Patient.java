package train.entity;

import java.sql.Date;

public class Patient {
	private int patientId;
    private String name;
    private Date dateOfBirth;
    private String gender;
    private String contactNumber;
    // Default constructor
    public Patient() {
    	
    }
    // Parameterized constructor
    public Patient( String name, Date dateOfBirth, String gender, String contactNumber) {
		super();
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.contactNumber = contactNumber;
	}
    // Getter and Setter methods
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", name=" + name + ", dateOfBirth=" + dateOfBirth + ", gender="
				+ gender + ", contactNumber=" + contactNumber + "]";
	}

}
