package train.dao;
import train.entity.AppointmentScheduling;
import train.entity.Doctor;
import train.entity.Patient;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import train.DbUtil;


public class AppointmentSchedulingDAO {
	private Connection connection=DbUtil.getConnection();
	private final static String selectAll_patients="select * from Patient";
	private final static String selectAll_doctors="select * from Doctor";
	private final static String Doctor_Availability="select count(*) from Appointment where doctor_id=? and appointment_date=? and appointment_time=?";
	private final static String Patient_Availability="select count(*) from Appointment where patient_id=? and appointment_date=? and appointment_time=?";
	private final static String Schedule_Appointment="INSERT INTO Appointment (doctor_id, patient_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)";
	private final static String update_Appointment="UPDATE Appointment SET doctor_id = ?, patient_id = ?, appointment_date = ?, appointment_time = ? WHERE appointment_id = ?";
	private final static String Select_Appointment="SELECT * FROM Appointment WHERE appointment_id = ?";
	public List<Patient> getALLPatients(){
		 List<Patient> patients = new ArrayList<>();
		 Statement s=null;
		 ResultSet rs=null;
		 try {
			 s=connection.createStatement();
			 rs=s.executeQuery(selectAll_patients);
			 while (rs.next()) {
		           Patient patient = new Patient();
		           patient.setPatientId(rs.getInt("patient_id"));
		           patient.setName(rs.getString("name"));
		           patient.setDateOfBirth(rs.getDate("date_of_birth"));
		           patient.setGender(rs.getString("gender"));
		           patient.setContactNumber(rs.getString("contact_number"));
		           patients.add(patient);
		       }
		 }
		 catch (SQLException e) {
				System.out.println("Select Error : " + e);
				e.printStackTrace();
			}finally {
				try {
					s.close();
				} catch (SQLException e) {			
					e.printStackTrace();
				}
			}
	     return patients;
	}
	public List<Doctor> getALLDoctors(){
		 List<Doctor> doctors = new ArrayList<>();
		 Statement s=null;
		 ResultSet rs=null;
		 try {
			 s=connection.createStatement();
			 rs=s.executeQuery(selectAll_doctors);
			 while (rs.next()) {
		           Doctor doctor = new Doctor();
		           doctor.setDoctorId(rs.getInt("doctor_id"));
		           doctor.setName(rs.getString("name"));
		           doctor.setSpecialization(rs.getString("specialization"));
		           doctor.setContactNumber(rs.getString("contact_number"));
		           doctors.add(doctor);
		       }
		 }
		 catch (SQLException e) {
				System.out.println("Select Error : " + e);
				e.printStackTrace();
			}finally {
				try {
					rs.close();
					s.close();
				} catch (SQLException e) {			
					e.printStackTrace();
				}
			}
	     return doctors;
	}
	
	public AppointmentScheduling getAppointment(int appointmentId) { 
		PreparedStatement ps=null;
		ResultSet rs=null;
		AppointmentScheduling appointment = new AppointmentScheduling();
		try {
			ps=connection.prepareStatement(Select_Appointment);
			ps.setInt(1,appointmentId);
			rs = ps.executeQuery();
			 if (rs.next()) {
	                appointment.setAppointmentId(rs.getInt("appointment_id"));
	                appointment.setDoctorId(rs.getInt("doctor_id"));
	                appointment.setPatientId(rs.getInt("patient_id"));
	                appointment.setAppointmentDate(rs.getDate("appointment_date"));
	                appointment.setAppointmentTime(rs.getTime("appointment_time"));
	            }
		}
		 catch (SQLException e) {
				System.out.println("Avalilability Error : " + e);
				e.printStackTrace();
			}
		finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {			
					e.printStackTrace();
				}
			}
		return appointment;
		
	}
	public int scheduleAppointment(AppointmentScheduling appointment) {
		PreparedStatement ps=null;
		int executeQuery=0;
		try {
			ps= connection.prepareStatement(Schedule_Appointment);
			ps.setInt(1,appointment.getDoctorId());
			ps.setInt(2, appointment.getPatientId());
			ps.setDate(3, appointment.getAppointmentDate());
			ps.setTime(4, appointment.getAppointmentTime());
			ps.executeUpdate();
			System.out.println("Appointment scheduled successfully.");
		}
		catch (SQLException e) {
			System.out.println("Schedule Error : " + e);
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		return executeQuery;
	}
	public int updateAppointment(AppointmentScheduling appointment) {
		PreparedStatement ps=null;
		int executeUpdate=0;
		try {
			ps=connection.prepareStatement(update_Appointment);
			ps.setInt(1, appointment.getDoctorId());
			ps.setInt(2, appointment.getPatientId());
			ps.setDate(3, appointment.getAppointmentDate());
			ps.setTime(4, appointment.getAppointmentTime());
			ps.setInt(5, appointment.getAppointmentId());
			ps.executeUpdate();
			System.out.println("Appointment Updated Successfully");
		}
		catch (SQLException e) {
			System.out.println("Update Error : " + e);
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		return executeUpdate;
	}
	public boolean isDoctorAvailable(int doctorId, Date appointmentDate, Time appointmentTime) {
		PreparedStatement ps=null;
		try {
	    	ps=connection.prepareStatement(Doctor_Availability);
            ps.setInt(1, doctorId);
            ps.setDate(2, appointmentDate);
            ps.setTime(3, appointmentTime);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0;
            }
        }
		catch (SQLException e) {
			System.out.println("Availability Error : " + e);
			e.printStackTrace();
		}
		finally {
				try {
					ps.close();
				} catch (SQLException e) {			
					e.printStackTrace();
				}
			}
        return false;
    }

    public boolean isPatientAvailable(int patientId, Date appointmentDate, Time appointmentTime) {
       PreparedStatement ps=null;
       try {
    	   ps=connection.prepareStatement(Patient_Availability);
            ps.setInt(1, patientId);
            ps.setDate(2, appointmentDate);
            ps.setTime(3, appointmentTime);
            ResultSet rs1 = ps.executeQuery();
            if (rs1.next()) {
                int count = rs1.getInt(1);
                return count == 0;
            }
        } 
       catch (SQLException e) {
			System.out.println("Avalilability Error : " + e);
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
       
        return false;
    }
	
}
