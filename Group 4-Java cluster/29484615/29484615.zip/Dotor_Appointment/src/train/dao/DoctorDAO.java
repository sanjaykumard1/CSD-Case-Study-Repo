package train.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import train.DbUtil;
import train.entity.Doctor;

public class DoctorDAO {
	private Connection connection=DbUtil.getConnection();
	private static final String INSERT_QUERY="INSERT INTO Doctor (name, specialization, contact_number) VALUES (?, ?, ?)";
	private static final String SELECT_Doctor="SELECT * FROM Doctor WHERE doctor_id = ?";
	private static final String UPDATE_Doctor="UPDATE Doctor SET name=?, specialization=?, contact_number=? WHERE doctor_id=?";
	private static final String DELETE_Doctor="Delete from Doctor where doctor_id=?";
	public int addDoctor(Doctor doctor) {
		PreparedStatement ps=null;
		int executeUpdate=0;
		try {
			ps=connection.prepareStatement(INSERT_QUERY);
			ps.setString(1, doctor.getName());
            ps.setString(2, doctor.getSpecialization());
            ps.setString(3, doctor.getContactNumber());
			executeUpdate = ps.executeUpdate();
			System.out.println("Doctor Added Successfully");
		} catch (SQLException e) {
			System.out.println("Insert Error : " + e);
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		return executeUpdate;
    }
	 public Doctor getDoctor(int doctorId) {
		 PreparedStatement ps=null;
		 Doctor doctor=new Doctor();
		 ResultSet rs=null;
		 try {
		 ps=connection.prepareStatement(SELECT_Doctor);
		 ps.setInt(1,doctorId);
		 rs = ps.executeQuery();
         if (rs.next()) {
             doctor.setDoctorId(rs.getInt("doctor_id"));
             doctor.setName(rs.getString("name"));
             doctor.setSpecialization(rs.getString("specialization"));
             doctor.setContactNumber(rs.getString("contact_number"));
         }
		}
		 catch (SQLException e) {
				doctor=null;
				System.out.println("Select error : " +e);
			}finally {
				try {
					rs.close();
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
			return doctor;
	 }
	 public int updateDoctor(Doctor doctor) {
		 PreparedStatement ps=null;
		 int executeUpdate=0;
		 try {
			 ps=connection.prepareStatement(UPDATE_Doctor);
			 ps.setString(1, doctor.getName());
	         ps.setString(2, doctor.getSpecialization());
	         ps.setString(3, doctor.getContactNumber());
	         ps.setInt(4, doctor.getDoctorId());
	         ps.executeUpdate();
	         System.out.println("Doctor updated successfully.");
		 }
		 catch (SQLException e) {
				System.out.println("Update error : " +e);
			}finally {
				try {
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
			return executeUpdate;
		}
	 public int deleteDoctor(int did) {
		 PreparedStatement ps=null;
		 int executeUpdate=0;
		 try {
			 ps=connection.prepareStatement(DELETE_Doctor);
			 ps.setInt(1,did);
			 ps.executeUpdate();
			 System.out.println("Doctor deleted successfully.");
		 }
		 catch (SQLException e) {
				System.out.println("Update error : " +e);
			}finally {
				try {
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
		 return executeUpdate;
	 }
}
