package train.dao;

import train.DbUtil;
import train.entity.Patient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAO {
	private Connection connection=DbUtil.getConnection();
	private static final String INSERT_QUERY="INSERT INTO Patient (name, date_of_birth, gender, contact_number) VALUES (?, ?, ?, ?)";
	private static final String SELECT_Patient="SELECT * FROM Patient WHERE patient_id = ?";
	private static final String UPDATE_Patient="UPDATE Patient SET name=?, date_of_birth=?, gender=?, contact_number=? WHERE patient_id=?";
	private static final String DELETE_Patient="Delete from patient where patient_id=?";
	public int addPatient(Patient patient) {
		PreparedStatement ps=null;
		int executeUpdate=0;
		try {
			ps=connection.prepareStatement(INSERT_QUERY);
			ps.setString(1, patient.getName());
            ps.setDate(2, patient.getDateOfBirth());
            ps.setString(3, patient.getGender());
            ps.setString(4, patient.getContactNumber());
			executeUpdate = ps.executeUpdate();
			System.out.println("Patient Added Successfully");
		} catch (SQLException e) {
			System.out.println("Insert Error : " + e);
			e.printStackTrace();
		}finally {
			try {
				ps.close();
			} catch (SQLException e) {			
				e.printStackTrace();
			}
		}
		return executeUpdate;
    }
	 public Patient getPatient(int patientId) {
		 PreparedStatement ps=null;
		 Patient patient = new Patient();
		 ResultSet rs=null;
		 try {
		 ps=connection.prepareStatement(SELECT_Patient);
		 ps.setInt(1,patientId);
		 rs = ps.executeQuery();
         if (rs.next()) {
             patient.setPatientId(rs.getInt("patient_id"));
             patient.setName(rs.getString("name"));
             patient.setDateOfBirth(rs.getDate("date_of_birth"));
             patient.setGender(rs.getString("gender"));
             patient.setContactNumber(rs.getString("contact_number"));
         }
		}
		 catch (SQLException e) {
				patient=null;
				System.out.println("Select error : " +e);
			}finally {
				try {
					rs.close();
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
			return patient;
	 }
	 public int updatePatient(Patient patient) {
		 PreparedStatement ps=null;
		 int executeUpdate=0;
		 try {
			 ps=connection.prepareStatement(UPDATE_Patient);
			 ps.setString(1, patient.getName());
	         ps.setDate(2, patient.getDateOfBirth());
	         ps.setString(3, patient.getGender());
	         ps.setString(4, patient.getContactNumber());
	         ps.setInt(5, patient.getPatientId());
	         ps.executeUpdate();
	         System.out.println("Patient updated successfully.");
		 }
		 catch (SQLException e) {
				System.out.println("Update error : " +e);
			}finally {
				try {
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
			return executeUpdate;
		}
	 public int deletePatient(int pid) {
		 PreparedStatement ps=null;
		 int executeUpdate=0;
		 try {
			 ps=connection.prepareStatement(DELETE_Patient);
			 ps.setInt(1,pid);
			 ps.executeUpdate();
			 System.out.println("Patient deleted successfully.");
		 }
		 catch (SQLException e) {
				System.out.println("Update error : " +e);
			}finally {
				try {
					ps.close();
				} catch (SQLException e) {
				
					e.printStackTrace();
				}
			}
		 return executeUpdate;
	 }
	 
	 
}
