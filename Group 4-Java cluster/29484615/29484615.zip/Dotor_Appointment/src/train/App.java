package train;

import java.util.*;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import train.dao.DoctorDAO;
import train.dao.PatientDAO;
import train.dao.AppointmentSchedulingDAO;
import train.entity.Doctor;
import train.entity.Patient;
import train.entity.AppointmentScheduling;


public class App {
	public static boolean isValidContactNumber(String contactNumber) {
        // Regex pattern to match a 10-digit number
        String regex = "^[0-9]{10}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contactNumber);
        return matcher.matches();
    }

	public static void main(String[] args) {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		LocalDate currentDate = LocalDate.now();
        Date curr=Date.valueOf(currentDate);
		try (// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in)) {
			while (true) {
			    System.out.println("1. Patient Management");
			    System.out.println("2. Doctor Management");
			    System.out.println("3. Appointment Scheduling");
			    System.out.println("4. Exit");

			    int choice = scanner.nextInt();

			    switch (choice) {
//----------------------Patient Management Switch Case Start-----------------------------------
			        case 1:
			        //----------------------- Call patient management methods------------------
			        	PatientDAO patientDAO = new PatientDAO();
			        	System.out.println("-------Patient Management--------");
			        	System.out.println("1. Add a new patient\r\n"
			        			+ "2. View patient details\r\n"
			        			+ "3. Update patient information\r\n"
			        			+ "4. Delete a patient\r\n"+"5. Exit");
			        	int c= scanner.nextInt();
			        	switch(c) {
			        	case 1:
			        		//call add method
			        		System.out.println("Enter Patient Name:");
			        		String name = reader.readLine();
			                System.out.println("Enter date of birth (YYYY-MM-DD):");
			                String dob = scanner.next();
			                System.out.println("Enter gender (male/female):");
			                String gender = scanner.next();
			                if(!(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female"))){
			                	System.out.println("Invalid gender. It should be 'male' or 'female'.");
			                    break;
			                }
			                System.out.println("Enter contact number:");
			                String contactNumber = scanner.next();
			                if (!App.isValidContactNumber(contactNumber)) {
			                	System.out.println("Invalid contact number. It should be a 10-digit number.");
			                    break;
			                }
			                try {
			                Date d=Date.valueOf(dob);
			                if (d.compareTo(curr)>0){
			                	System.out.println("Invalid Date Provided");
			                	break;
			                }
			                Patient newPatient = new Patient(name, d, gender, contactNumber);
			                patientDAO.addPatient(newPatient);
			                }
			                catch (IllegalArgumentException e) {
			                    System.out.println("Invalid date format: " + dob);
			                    break;
			                }
			                break;
			        	case 2:
			        	//----------------------call view method----------------------------
			        		System.out.println("Enter Patient_ID:");
			        		int patient_Id=scanner.nextInt();
			        		Patient patient=patientDAO.getPatient(patient_Id);
			        		if (patient.getName() != null) {
			                    System.out.println(patient);
			                    System.out.println();
			                } else {
			                    System.out.println("Patient not found.");
			                }
			        		break;
			        	case 3:
			        	//-----------------------call update method---------------------------
			        		System.out.println("Enter Patient_ID:");
			        		int pid=scanner.nextInt();
			        		Patient updatePatient = patientDAO.getPatient(pid);
			                if (updatePatient.getName() != null) {
			                	System.out.print("Enter new name: ");
			                    updatePatient.setName(reader.readLine());
			                    try {
			                    System.out.print("Enter new date of birth (YYYY-MM-DD): ");
			                    Date new_dob=Date.valueOf(scanner.next());
			                    if (new_dob.compareTo(curr)>0){
				                	System.out.println("Invalid Date Provided");
				                	break;
				                }
			                    updatePatient.setDateOfBirth(new_dob);
			                    System.out.print("Enter new gender: ");
			                    gender=scanner.next();
			                    if(!(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female"))){
				                	System.out.println("Invalid gender. It should be 'male' or 'female'.");
				                    break;
				                }
			                    updatePatient.setGender(gender);
			                    System.out.print("Enter new contact number: ");
			                    contactNumber=scanner.next();
			                    if (!App.isValidContactNumber(contactNumber)) {
				                	System.out.println("Invalid contact number. It should be a 10-digit number.");
				                    break;
				                }
			                    updatePatient.setContactNumber(contactNumber);
			                    patientDAO.updatePatient(updatePatient);
			                    }
			                    catch (IllegalArgumentException e) {
				                    System.out.println("Invalid date format. Please provide it in the format of (YYYY-MM-DD) ");
				                    break;
				                }
			                 } 
			                else {
			                     System.out.println("Patient not found.");
			                 }
			        		break;
			        	case 4:
			        	//---------------------call delete method------------------------------------
			        		System.out.println("Enter Patient_ID:");
			        		int del_pid=scanner.nextInt();
			        		Patient deletePatient = patientDAO.getPatient(del_pid);
			        		if (deletePatient.getName() != null) {
			        			patientDAO.deletePatient(del_pid);
			        		}
			        		else {
			        			System.out.println("Patient not found");
			        		}
			        		break;
			        	case 5:
			        		System.exit(0);
			        	default:
			        		System.out.println("Invalid choice.");
			        		break;
			        	}
			            break;
//------------------------------Patient Management Switch case----------------------------------------
			            
			            
			        case 2:
// -----------------------------Doctor management switch case-----------------------------------------
			        	DoctorDAO doctorDAO=new DoctorDAO();
			        	System.out.println("-------Doctor Management--------");
			        	System.out.println("1. Add a new doctor\r\n"
			        			+ "2. View doctor details\r\n"
			        			+ "3. Update doctor information\r\n"
			        			+ "4. Delete a doctor\r\n"+"5.Exit");
			        	int c1= scanner.nextInt();
			        	switch(c1) {
			        	case 1:
			        	//--------------------------call add method for doctors------------------------------------
			        		System.out.println("Enter Doctor Name:");
			        		String name = reader.readLine();
			                System.out.println("Enter Doctor's Specialization:");
			                String specialization = reader.readLine();
			                System.out.println("Enter contact number:");
			                String contact_number = scanner.next();
			                if (!App.isValidContactNumber(contact_number)) {
			                	System.out.println("Invalid contact number. It should be a 10-digit number.");
			                    break;
			                }
			                Doctor doctor=new Doctor(name, specialization, contact_number);
			                doctorDAO.addDoctor(doctor);
			                break;
			        	case 2:
			        	//---------------------------call view method for doctors-------------------------------------
			        		System.out.println("Enter Doctor_ID:");
			        		int doctor_Id=scanner.nextInt();
			        		Doctor doc=doctorDAO.getDoctor(doctor_Id);
			        		if (doc.getName() != null) {
			                    System.out.println(doc);
			                    System.out.println();
			                } else {
			                    System.out.println("Doctor not found.");
			                }
			        		break;
			        	case 3:
			        	//----------------------------call update method for doctors-----------------------------------
			        		System.out.println("Enter Doctor_ID:");
			        		int pid=scanner.nextInt();
			        		Doctor updateDoctor = doctorDAO.getDoctor(pid);
			                if (updateDoctor.getName() != null) {
			                	System.out.println("Enter Doctor new Name:");
				        		updateDoctor.setName(reader.readLine());
				                System.out.println("Enter Doctor's new Specialization:");
				                updateDoctor.setSpecialization(reader.readLine());
				                System.out.println("Enter new contact number:");
				                contact_number=scanner.next();
				                if (!App.isValidContactNumber(contact_number)) {
				                	System.out.println("Invalid contact number. It should be a 10-digit number.");
				                    break;
				                }
				                updateDoctor.setContactNumber(contact_number);
				                doctorDAO.updateDoctor(updateDoctor);
				                
			                }
			                else {
			                	System.out.println("Doctor not found.");
			                }
			                break;
			        	case 4:
			        	//-------------------------------call delete method for doctors------------------------------------
			        		System.out.println("Enter Doctor_ID:");
			        		int del_did=scanner.nextInt();
			        		Doctor deleteDoctor = doctorDAO.getDoctor(del_did);
			        		if (deleteDoctor.getName() != null) {
			        			doctorDAO.deleteDoctor(del_did);
			        		}
			        		else {
			        			System.out.println("Doctor not found");
			        		}
			        		break;
			        	case 5:
			        		System.exit(0);
			        	default:
			        		System.out.println("Invalid choice.");
			        		break;
			        	}
			            break;
//---------------------------End of Doctor Management Switch Case-----------------------------------------------------
			            
			            
			        case 3:
//----------------------------- Start of Appointment Scheduling Switch Case------------------------------------------
			        	AppointmentSchedulingDAO appointmentDAO=new AppointmentSchedulingDAO();
			        	System.out.println("-------Appointment Scheduling--------");
			        	System.out.println("1. Display list of available doctors\r\n"
			        			+ "2. Display list of patients\r\n"
			        			+ "3. Schedule an appointment for a patient with a doctor\r\n"
			        			+ "4. Update the appointment record in the database\r\n"
			        			+"5.Exit");
			        	int c11= scanner.nextInt();
			        	switch(c11) {
			        	case 1:
			        	//---------------------------Display the doctors-------------------------------------------
			        		List<Doctor> allDoctors=appointmentDAO.getALLDoctors();
			        		for (Doctor doctor:allDoctors) {
			        			System.out.println(doctor);
			        		}
			        		break;
			        	case 2:
			        	//----------------------------Display the patients------------------------------------------
			        		List<Patient> allPatients=appointmentDAO.getALLPatients();
			        		for(Patient patient:allPatients) {
			        			System.out.println(patient);
			        		}
			        		break;
			        	case 3:
			        	//-----------------------------Schedule appointment------------------------------------------
			        		System.out.print("Enter Doctor ID: ");
			                int doctorId = scanner.nextInt();
			                DoctorDAO d=new DoctorDAO();
			                if(d.getDoctor(doctorId).getName()==null) {
			                	System.out.println("Invalid Doctor Id");
			                	break;
			                }
			                System.out.print("Enter Patient ID: ");
			                int patientId = scanner.nextInt();
			                PatientDAO p=new PatientDAO();
			                if(p.getPatient(patientId).getName()==null) {
			                	System.out.println("Invalid Patient Id");
			                	break;
			                }
			                System.out.print("Enter Appointment Date (yyyy-mm-dd): ");
			                String dateStr = scanner.next();
			                try {
			                Date appointmentDate = Date.valueOf(dateStr);
			                if (appointmentDate.compareTo(curr)<0){
			                	System.out.println("Invalid Date Provided");
			                	break;
			                }
			                System.out.print("Enter Appointment Time (hh:mm:ss): ");
			                String timeStr = scanner.next();
			                if (!timeStr.matches("^([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)$")) {
			                    System.out.println("Invalid Time Provided. Please enter in hh:mm:ss format (24-hour clock).");
			                    break;
			                }
			                Time appointmentTime = Time.valueOf(timeStr);
			                boolean isDoctorAvailable = appointmentDAO.isDoctorAvailable(doctorId, appointmentDate, appointmentTime);
			                boolean isPatientAvailable = appointmentDAO.isPatientAvailable(patientId, appointmentDate, appointmentTime);
			                if (!isDoctorAvailable) {
			                    System.out.println("Doctor is not available at the selected time.");
			                    break;
			                }

			                if (!isPatientAvailable) {
			                    System.out.println("Patient has an overlapping appointment.");
			                    break;
			                }
			                AppointmentScheduling appointment = new AppointmentScheduling(doctorId,patientId,appointmentDate,appointmentTime);
			                appointmentDAO.scheduleAppointment(appointment);
			                }
			                catch (IllegalArgumentException e) {
			                    System.out.println("Invalid date format: " + dateStr);
			                    break;
			                }
			                break;
			        	case 4:
			        	//---------------------------update the appointment-----------------------------------------
			        		System.out.print("Enter Appointment ID: ");
			        	    int appointmentId = scanner.nextInt();
			        	    AppointmentScheduling appointment1 = appointmentDAO.getAppointment(appointmentId);
			        	    if (appointment1.getAppointmentId() != 0) {
			        		System.out.print("Enter new Doctor ID: ");
			                int newDoctorId = scanner.nextInt();
			                DoctorDAO d1=new DoctorDAO();
			                if(d1.getDoctor(newDoctorId).getName()==null) {
			                	System.out.println("Doctor with the given ID not exist");
			                	break;
			                }
			                System.out.print("Enter new Patient ID: ");
			                int newPatientId = scanner.nextInt();
			                PatientDAO p1=new PatientDAO();
			                if(p1.getPatient(newPatientId).getName()==null) {
			                	System.out.println("Patient with the given id not exist");
			                	break;
			                }
			                System.out.print("Enter new Appointment Date (yyyy-mm-dd): ");
			                String newDateStr = scanner.next();
			                Date newAppointmentDate = Date.valueOf(newDateStr);
			                if (newAppointmentDate.compareTo(curr)<0){
			                	System.out.println("Invalid Date Provided");
			                	break;
			                }
			                System.out.print("Enter new Appointment Time (hh:mm:ss) in 24 hours clock: ");
			                String newTimeStr = scanner.next();
			                if (!newTimeStr.matches("^([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)$")) {
			                    System.out.println("Invalid Time Provided. Please enter in hh:mm:ss format (24-hour clock).");
			                    break;
			                }
			                Time newAppointmentTime = Time.valueOf(newTimeStr);

			                boolean isDoctorAvail = appointmentDAO.isDoctorAvailable(newDoctorId, newAppointmentDate, newAppointmentTime);
			                boolean isPatientAvail= appointmentDAO.isPatientAvailable(newPatientId, newAppointmentDate, newAppointmentTime);

			                if (!isDoctorAvail) {
			                    System.out.println("Doctor is not available at the selected time.");
			                    return;
			                }

			                if (!isPatientAvail) {
			                    System.out.println("Patient has an overlapping appointment.");
			                    return;
			                }
			                appointment1.setDoctorId(newDoctorId);
			                appointment1.setPatientId(newPatientId);
			                appointment1.setAppointmentDate(newAppointmentDate);
			                appointment1.setAppointmentTime(newAppointmentTime);
			                appointmentDAO.updateAppointment(appointment1);
			                } 
			        	else {
			                    System.out.println("Appointment not found.");
			                }
			        	    break;
			        	case 5:
			        		System.exit(0);
			        	}
			            break;
			        case 4:
			            System.exit(0);
			        default:
	                    System.out.println("Invalid choice. Please try again.");
//----------------------End of Appointment Scheduling Switch Case------------------------------------------------
			    }
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}
