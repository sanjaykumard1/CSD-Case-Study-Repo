package train;
import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
	private static Connection connection = null;
	private static String url = "jdbc:mysql://localhost:3306/pega";
	private static String username = "root";
	private static String password = "Hari@24";

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			System.out.println("Connection Not Createted : " + e);
		}
		return connection;
	}
    //public static void main(String[] args) {
    	//System.out.println(DbUtil.getConnection());
    //}
}
