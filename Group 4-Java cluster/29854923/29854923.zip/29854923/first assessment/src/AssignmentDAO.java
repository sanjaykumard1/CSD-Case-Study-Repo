import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDAO {
    public void addAssignment(Assignment assignment) throws SQLException {
        String query = "INSERT INTO Assignment (task_id, member_id, assignment_date) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, assignment.getTaskId());
            stmt.setInt(2, assignment.getMemberId());
            stmt.setDate(3, assignment.getAssignmentDate());
            stmt.executeUpdate();
        }
    }

    public Assignment getAssignment(int assignmentId) throws SQLException {
        String query = "SELECT * FROM Assignment WHERE assignment_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Assignment assignment = new Assignment();
                assignment.setAssignmentId(rs.getInt("assignment_id"));
                assignment.setTaskId(rs.getInt("task_id"));
                assignment.setMemberId(rs.getInt("member_id"));
                assignment.setAssignmentDate(rs.getDate("assignment_date"));
                return assignment;
            }
        }
        return null;
    }

    public void updateAssignment(Assignment assignment) throws SQLException {
        String query = "UPDATE Assignment SET task_id = ?, member_id = ?, assignment_date = ? WHERE assignment_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, assignment.getTaskId());
            stmt.setInt(2, assignment.getMemberId());
            stmt.setDate(3, assignment.getAssignmentDate());
            stmt.setInt(4, assignment.getAssignmentId());
            stmt.executeUpdate();
        }
    }

    public void deleteAssignment(int assignmentId) throws SQLException {
        String query = "DELETE FROM Assignment WHERE assignment_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, assignmentId);
            stmt.executeUpdate();
        }
    }

    public List<Assignment> getAllAssignments() throws SQLException {
        List<Assignment> assignments = new ArrayList<>();
        String query = "SELECT * FROM Assignment";
        try (Connection conn = DatabaseUtil.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Assignment assignment = new Assignment();
                assignment.setAssignmentId(rs.getInt("assignment_id"));
                assignment.setTaskId(rs.getInt("task_id"));
                assignment.setMemberId(rs.getInt("member_id"));
                assignment.setAssignmentDate(rs.getDate("assignment_date"));
                assignments.add(assignment);
            }
        }
        return assignments;
    }
}
