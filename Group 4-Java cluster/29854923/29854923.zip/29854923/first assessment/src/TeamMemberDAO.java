import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeamMemberDAO {
    public void addTeamMember(TeamMember member) throws SQLException {
        String query = "INSERT INTO TeamMember (name, email, role, tasks_assigned) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setString(3, member.getRole());
            stmt.setInt(4, member.getTasksAssigned());
            stmt.executeUpdate();
        }
    }

    public TeamMember getTeamMember(int memberId) throws SQLException {
        String query = "SELECT * FROM TeamMember WHERE member_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                TeamMember member = new TeamMember();
                member.setMemberId(rs.getInt("member_id"));
                member.setName(rs.getString("name"));
                member.setEmail(rs.getString("email"));
                member.setRole(rs.getString("role"));
                member.setTasksAssigned(rs.getInt("tasks_assigned"));
                return member;
            }
        }
        return null;
    }

    public void updateTeamMember(TeamMember member) throws SQLException {
        String query = "UPDATE TeamMember SET name = ?, email = ?, role = ?, tasks_assigned = ? WHERE member_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setString(3, member.getRole());
            stmt.setInt(4, member.getTasksAssigned());
            stmt.setInt(5, member.getMemberId());
            stmt.executeUpdate();
        }
    }

    public void deleteTeamMember(int memberId) throws SQLException {
        String query = "DELETE FROM TeamMember WHERE member_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, memberId);
            stmt.executeUpdate();
        }
    }

    public List<TeamMember> getAllTeamMembers() throws SQLException {
        List<TeamMember> members = new ArrayList<>();
        String query = "SELECT * FROM TeamMember";
        try (Connection conn = DatabaseUtil.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                TeamMember member = new TeamMember();
                member.setMemberId(rs.getInt("member_id"));
                member.setName(rs.getString("name"));
                member.setEmail(rs.getString("email"));
                member.setRole(rs.getString("role"));
                member.setTasksAssigned(rs.getInt("tasks_assigned"));
                members.add(member);
            }
        }
        return members;
    }
}
