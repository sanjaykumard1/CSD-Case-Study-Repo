import java.sql.SQLException;
import java.util.Scanner;

public class TaskManagementApp {
    private static TaskDAO taskDAO = new TaskDAO();
    private static TeamMemberDAO memberDAO = new TeamMemberDAO();
    private static AssignmentDAO assignmentDAO = new AssignmentDAO();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Add Task");
            System.out.println("2. View Task Details");
            System.out.println("3. Update Task");
            System.out.println("4. Delete Task");
            System.out.println("5. Display Available Tasks");
            System.out.println("6. Display Team Members");
            System.out.println("7. Assign Task to Member");
            System.out.println("8. Add Team Member");
            System.out.println("9. Update Team Member");
            System.out.println("10. Delete Team Member");
            System.out.println("11. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1:
                        addTask(scanner);
                        break;
                    case 2:
                        viewTask(scanner);
                        break;
                    case 3:
                        updateTask(scanner);
                        break;
                    case 4:
                        deleteTask(scanner);
                        break;
                    case 5:
                        displayAvailableTasks();
                        break;
                    case 6:
                        displayTeamMembers();
                        break;
                    case 7:
                        assignTask(scanner);
                        break;
                    case 8:
                        addTeamMember(scanner);
                        break;
                    case 9:
                        updateTeamMember(scanner);
                        break;
                    case 10:
                        deleteTeamMember(scanner);
                        break;
                    case 11:
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void addTask(Scanner scanner) throws SQLException {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        Task task = new Task();
        task.setTitle(title);
        task.setDescription(description);
        task.setStatus("Open");
        taskDAO.addTask(task);
        System.out.println("Task added successfully.");
    }

    private static void viewTask(Scanner scanner) throws SQLException {
        System.out.print("Enter task ID: ");
        int taskId = scanner.nextInt();
        Task task = taskDAO.getTask(taskId);
        if (task != null) {
            System.out.println("Task ID: " + task.getTaskId());
            System.out.println("Title: " + task.getTitle());
            System.out.println("Description: " + task.getDescription());
            System.out.println("Status: " + task.getStatus());
        } else {
            System.out.println("Task not found.");
        }
    }

    private static void updateTask(Scanner scanner) throws SQLException {
        System.out.print("Enter task ID: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();
        Task task = taskDAO.getTask(taskId);
        if (task != null) {
            System.out.print("Enter new title: ");
            task.setTitle(scanner.nextLine());
            System.out.print("Enter new description: ");
            task.setDescription(scanner.nextLine());
            System.out.print("Enter new status (Open, In Progress, Completed): ");
            task.setStatus(scanner.nextLine());
            taskDAO.updateTask(task);
            System.out.println("Task updated successfully.");
        } else {
            System.out.println("Task not found.");
        }
    }

    private static void deleteTask(Scanner scanner) throws SQLException {
        System.out.print("Enter task ID: ");
        int taskId = scanner.nextInt();
        taskDAO.deleteTask(taskId);
        System.out.println("Task deleted successfully.");
    }

    private static void displayAvailableTasks() throws SQLException {
        System.out.println("Available Tasks:");
        for (Task task : taskDAO.getAllTasks()) {
            System.out.println(task.getTaskId() + ": " + task.getTitle() + " (" + task.getStatus() + ")");
        }
    }

    private static void displayTeamMembers() throws SQLException {
        System.out.println("Team Members:");
        for (TeamMember member : memberDAO.getAllTeamMembers()) {
            System.out.println(member.getMemberId() + ": " + member.getName() + " (" + member.getRole() + ")");
        }
    }

    private static void assignTask(Scanner scanner) throws SQLException {
        displayAvailableTasks();
        System.out.print("Enter task ID to assign: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();
        Task task = taskDAO.getTask(taskId);
        if (task == null || !"Open".equals(task.getStatus())) {
            System.out.println("Invalid task or task not available.");
            return;
        }

        displayTeamMembers();
        System.out.print("Enter team member ID to assign to: ");
        int memberId = scanner.nextInt();
        scanner.nextLine();
        TeamMember member = memberDAO.getTeamMember(memberId);
        if (member == null) {
            System.out.println("Invalid team member.");
            return;
        }

        Assignment assignment = new Assignment();
        assignment.setTaskId(taskId);
        assignment.setMemberId(memberId);
        assignment.setAssignmentDate(new java.sql.Date(System.currentTimeMillis()));
        assignmentDAO.addAssignment(assignment);

        System.out.println("Task assigned successfully.");
    }

    private static void addTeamMember(Scanner scanner) throws SQLException {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter role: ");
        String role = scanner.nextLine();
        TeamMember member = new TeamMember();
        member.setName(name);
        member.setEmail(email);
        member.setRole(role);
        member.setTasksAssigned(0);
        memberDAO.addTeamMember(member);
        System.out.println("Team member added successfully.");
    }

    private static void updateTeamMember(Scanner scanner) throws SQLException {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        scanner.nextLine();
        TeamMember member = memberDAO.getTeamMember(memberId);
        if (member != null) {
            System.out.print("Enter new name: ");
            member.setName(scanner.nextLine());
            System.out.print("Enter new email: ");
            member.setEmail(scanner.nextLine());
            System.out.print("Enter new role: ");
            member.setRole(scanner.nextLine());
            System.out.print("Enter new tasks assigned: ");
            member.setTasksAssigned(scanner.nextInt());
            scanner.nextLine();
            memberDAO.updateTeamMember(member);
            System.out.println("Team member updated successfully.");
        } else {
            System.out.println("Team member not found.");
        }
    }

    private static void deleteTeamMember(Scanner scanner) throws SQLException {
        System.out.print("Enter member ID: ");
        int memberId = scanner.nextInt();
        memberDAO.deleteTeamMember(memberId);
        System.out.println("Team member deleted successfully.");
    }
}
