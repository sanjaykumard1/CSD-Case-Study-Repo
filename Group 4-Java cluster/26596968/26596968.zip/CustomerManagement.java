import java.sql.*;
import java.util.Scanner;

public class CustomerManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public void registerCustomer() {
        System.out.println("Enter customer name:");
        String name = scanner.nextLine();
        System.out.println("Enter customer email:");
        String email = scanner.nextLine();
        System.out.println("Enter customer phone number:");
        String phone = scanner.nextLine();

        String sql = "INSERT INTO Customer (name, email, phone_number) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.executeUpdate();
            System.out.println("Customer registered successfully.");

        } catch (SQLException e) {
            System.err.println("Error registering customer: " + e.getMessage());
        }
    }

    public void viewCustomerDetails() {
        System.out.println("Enter customer ID:");
        int customerId = scanner.nextInt();

        String sql = "SELECT * FROM Customer WHERE customer_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                } else {
                    System.out.println("No customer found with ID: " + customerId);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error viewing customer details: " + e.getMessage());
        }
    }

    public void updateCustomerInfo() {
        System.out.println("Enter customer ID:");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.println("Enter new name:");
        String name = scanner.nextLine();
        System.out.println("Enter new email:");
        String email = scanner.nextLine();
        System.out.println("Enter new phone number:");
        String phone = scanner.nextLine();

        String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ? WHERE customer_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phone);
            stmt.setInt(4, customerId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("No customer found with ID: " + customerId);
            }

        } catch (SQLException e) {
            System.err.println("Error updating customer: " + e.getMessage());
        }
    }

    public void deleteCustomer() {
        System.out.println("Enter customer ID:");
        int customerId = scanner.nextInt();

        String sql = "DELETE FROM Customer WHERE customer_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, customerId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("No customer found with ID: " + customerId);
            }

        } catch (SQLException e) {
            System.err.println("Error deleting customer: " + e.getMessage());
        }
    }
}
