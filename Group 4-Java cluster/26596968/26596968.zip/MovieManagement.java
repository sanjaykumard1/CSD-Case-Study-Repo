import java.sql.*;
import java.util.Scanner;

public class MovieManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public void addMovie() {
        System.out.println("Enter movie title:");
        String title = scanner.nextLine();
        System.out.println("Enter movie genre:");
        String genre = scanner.nextLine();
        System.out.println("Enter release year:");
        int releaseYear = scanner.nextInt();
        System.out.println("Enter quantity available:");
        int quantity = scanner.nextInt();
        

        String sql = "INSERT INTO Movie (title, genre, release_year, quantity_available) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
   

            statement.setString(1, title);
            statement.setString(2, genre);
            statement.setInt(3, releaseYear);
            statement.setInt(4, quantity);
            statement.executeUpdate();
            System.out.println("Movie added successfully.");

        } catch (SQLException e) {
            System.err.println("Error adding movie: " + e.getMessage());
        }
    }

    public void viewMovieDetails() {
        System.out.println("Enter movie ID:");
        int movieId = scanner.nextInt();

        String sql = "SELECT * FROM Movie WHERE movie_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {

            statement.setInt(1, movieId);
            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Title: " + rs.getString("title"));
                    System.out.println("Genre: " + rs.getString("genre"));
                    System.out.println("Release Year: " + rs.getInt("release_year"));
                    System.out.println("Quantity Available: " + rs.getInt("quantity_available"));
                } else {
                    System.out.println("No movie found with ID: " + movieId);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error viewing movie details: " + e.getMessage());
        }
    }

    public void updateMovieInfo() {
        System.out.println("Enter movie ID:");
        int movieId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.println("Enter new title:");
        String title = scanner.nextLine();
        System.out.println("Enter new genre:");
        String genre = scanner.nextLine();
        System.out.println("Enter new release year:");
        int releaseYear = scanner.nextInt();
        System.out.println("Enter new quantity available:");
        int quantity = scanner.nextInt();

        String sql = "UPDATE Movie SET title = ?, genre = ?, release_year = ?, quantity_available = ? WHERE movie_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, title);
            stmt.setString(2, genre);
            stmt.setInt(3, releaseYear);
            stmt.setInt(4, quantity);
            stmt.setInt(5, movieId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Movie updated successfully.");
            } else {
                System.out.println("No movie found with ID: " + movieId);
            }

        } catch (SQLException e) {
            System.err.println("Error updating movie: " + e.getMessage());
        }
    }

    public void deleteMovie() {
        System.out.println("Enter movie ID:");
        int movieId = scanner.nextInt();

        String deleteSql = "DELETE FROM Movie WHERE movie_id = ?";
        //String countSql = "SELECT COUNT(*) FROM Movie";

        Connection conn = null;
        PreparedStatement deleteStmt = null;
        Statement countStmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseUtil.getConnection();

            
            deleteStmt = conn.prepareStatement(deleteSql);
            deleteStmt.setInt(1, movieId);
            int rowsDeleted = deleteStmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Movie deleted successfully.");
            } else {
                System.out.println("No movie found with ID: " + movieId);
            }


        } catch (SQLException e) {
            System.err.println("Error deleting movie: " + e.getMessage());
        } finally {
            
            try {
                if (rs != null) rs.close();
                if (countStmt != null) countStmt.close();
                if (deleteStmt != null) deleteStmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error closing resources: " + e.getMessage());
            }
        }
    }


}
