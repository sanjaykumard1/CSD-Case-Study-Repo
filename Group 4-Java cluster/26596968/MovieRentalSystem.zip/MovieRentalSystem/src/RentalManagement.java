import java.sql.*;
import java.util.Scanner;

public class RentalManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public void rentMovie() {
        System.out.println("Enter customer ID:");
        int customerId = scanner.nextInt();
        System.out.println("Enter movie ID:");
        int movieId = scanner.nextInt();

        String updateQuantitySql = "UPDATE Movie SET quantity_available = quantity_available - 1 WHERE movie_id = ? AND quantity_available > 0";
        String insertRentalSql = "INSERT INTO Rental (movie_id, customer_id, rental_date) VALUES (?, ?, NOW())";

        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuantitySql);
                 PreparedStatement insertStmt = conn.prepareStatement(insertRentalSql)) {

                updateStmt.setInt(1, movieId);
                int rowsUpdated = updateStmt.executeUpdate();
                if (rowsUpdated > 0) {
                    insertStmt.setInt(1, movieId);
                    insertStmt.setInt(2, customerId);
                    insertStmt.executeUpdate();
                    conn.commit();
                    System.out.println("Movie rented successfully.");
                } else {
                    conn.rollback();
                    System.out.println("Movie is not available.");
                }
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Error renting movie: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }

    public void returnMovie() {
        System.out.println("Enter rental ID:");
        int rentalId = scanner.nextInt();

        String updateQuantitySql = "UPDATE Movie SET quantity_available = quantity_available + 1 WHERE movie_id = (SELECT movie_id FROM Rental WHERE rental_id = ?)";
        String updateRentalSql = "UPDATE Rental SET return_date = NOW() WHERE rental_id = ?";

        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement updateQuantityStmt = conn.prepareStatement(updateQuantitySql);
                 PreparedStatement updateRentalStmt = conn.prepareStatement(updateRentalSql)) {

                updateQuantityStmt.setInt(1, rentalId);
                updateQuantityStmt.executeUpdate();

                updateRentalStmt.setInt(1, rentalId);
                int rowsUpdated = updateRentalStmt.executeUpdate();
                if (rowsUpdated > 0) {
                    conn.commit();
                    System.out.println("Movie returned successfully.");
                } else {
                    conn.rollback();
                    System.out.println("No rental found with ID: " + rentalId);
                }
            } catch (SQLException e) {
                conn.rollback();
                System.err.println("Error returning movie: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }

    public void viewRentalHistory() {
        System.out.println("Enter customer ID:");
        int customerId = scanner.nextInt();

        String sql = "SELECT * FROM Rental WHERE customer_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    System.out.println("Rental ID: " + rs.getInt("rental_id"));
                    System.out.println("Movie ID: " + rs.getInt("movie_id"));
                    System.out.println("Rental Date: " + rs.getDate("rental_date"));
                    System.out.println("Return Date: " + rs.getDate("return_date"));
                    System.out.println("-----------");
                }
            }

        } catch (SQLException e) {
            System.err.println("Error viewing rental history: " + e.getMessage());
        }
    }

    public void listCurrentlyRentedMovies() {
        String sql = "SELECT * FROM Rental WHERE return_date IS NULL";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("Rental ID: " + rs.getInt("rental_id"));
                System.out.println("Movie ID: " + rs.getInt("movie_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Rental Date: " + rs.getDate("rental_date"));
                System.out.println("-----------");
            }

        } catch (SQLException e) {
            System.err.println("Error listing currently rented movies: " + e.getMessage());
        }
    }
}
