
import java.util.Scanner;

public class MovieRentalSystem {
	 private static final Scanner scanner = new Scanner(System.in);
     private static final MovieManagement movieManagement = new MovieManagement();
     private static final CustomerManagement customerManagement = new CustomerManagement();
     private static final RentalManagement rentalManagement = new RentalManagement();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Movie Rental System");
            System.out.println("1. Movie Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Rental Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    movieManagementMenu();
                    break;
                case 2:
                    customerManagementMenu();
                    break;
                case 3:
                    rentalManagementMenu();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void movieManagementMenu() {
        System.out.println("Movie Management");
        System.out.println("1. Add Movie");
        System.out.println("2. View Movie Details");
        System.out.println("3. Update Movie Information");
        System.out.println("4. Delete Movie");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                movieManagement.addMovie();
                break;
            case 2:
                movieManagement.viewMovieDetails();
                break;
            case 3:
                movieManagement.updateMovieInfo();
                break;
            case 4:
                movieManagement.deleteMovie();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void customerManagementMenu() {
        System.out.println("Customer Management");
        System.out.println("1. Register Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete Customer");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                customerManagement.registerCustomer();
                break;
            case 2:
                customerManagement.viewCustomerDetails();
                break;
            case 3:
                customerManagement.updateCustomerInfo();
                break;
            case 4:
                customerManagement.deleteCustomer();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void rentalManagementMenu() {
        System.out.println("Rental Management");
        System.out.println("1. Rent Movie");
        System.out.println("2. Return Movie");
        System.out.println("3. View Rental History");
        System.out.println("4. List Currently Rented Movies");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                rentalManagement.rentMovie();
                break;
            case 2:
                rentalManagement.returnMovie();
                break;
            case 3:
                rentalManagement.viewRentalHistory();
                break;
            case 4:
                rentalManagement.listCurrentlyRentedMovies();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}

