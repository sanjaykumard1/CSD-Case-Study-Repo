package pharmacy;

import java.sql.*;
import java.util.Scanner;

public class MedicineManager {
    public void addMedicine() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO Medicine (medicine_name, quantity_available, unit_price, expiry_date) VALUES (?, ?, ?, ?)")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter medicine name: ");
            String name = scanner.nextLine();
            System.out.print("Enter quantity available: ");
            int quantity = scanner.nextInt();
            System.out.print("Enter unit price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter expiry date (YYYY-MM-DD): ");
            String expiryDate = scanner.next();

            ps.setString(1, name);
            ps.setInt(2, quantity);
            ps.setDouble(3, price);
            ps.setDate(4, Date.valueOf(expiryDate));
            ps.executeUpdate();

            System.out.println("Medicine added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewMedicines() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Medicine")) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("medicine_id"));
                System.out.println("Name: " + rs.getString("medicine_name"));
                System.out.println("Quantity: " + rs.getInt("quantity_available"));
                System.out.println("Price: " + rs.getDouble("unit_price"));
                System.out.println("Expiry Date: " + rs.getDate("expiry_date"));
                System.out.println("---------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMedicine() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE Medicine SET medicine_name = ?, quantity_available = ?, unit_price = ?, expiry_date = ? WHERE medicine_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter medicine ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // consume newline
            System.out.print("Enter new medicine name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new quantity available: ");
            int quantity = scanner.nextInt();
            System.out.print("Enter new unit price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter new expiry date (YYYY-MM-DD): ");
            String expiryDate = scanner.next();

            ps.setString(1, name);
            ps.setInt(2, quantity);
            ps.setDouble(3, price);
            ps.setDate(4, Date.valueOf(expiryDate));
            ps.setInt(5, id);
            ps.executeUpdate();

            System.out.println("Medicine updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMedicine() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "DELETE FROM Medicine WHERE medicine_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter medicine ID to delete: ");
            int id = scanner.nextInt();

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Medicine deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}