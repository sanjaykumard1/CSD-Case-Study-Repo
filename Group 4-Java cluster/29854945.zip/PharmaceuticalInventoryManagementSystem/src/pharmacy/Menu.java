package pharmacy;

import java.util.Scanner;

public class Menu {
    private MedicineManager medicineManager = new MedicineManager();
    private SupplierManager supplierManager = new SupplierManager();
    private OrderManager orderManager = new OrderManager();

    public void showMainMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Pharmaceutical Inventory Management System");
            System.out.println("1. Manage Medicines");
            System.out.println("2. Manage Suppliers");
            System.out.println("3. Manage Orders");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    showMedicineMenu();
                    break;
                case 2:
                    showSupplierMenu();
                    break;
                case 3:
                    showOrderMenu();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void showMedicineMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Medicine Management");
            System.out.println("1. Add Medicine");
            System.out.println("2. View Medicines");
            System.out.println("3. Update Medicine");
            System.out.println("4. Delete Medicine");
            System.out.println("5. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    medicineManager.addMedicine();
                    break;
                case 2:
                    medicineManager.viewMedicines();
                    break;
                case 3:
                    medicineManager.updateMedicine();
                    break;
                case 4:
                    medicineManager.deleteMedicine();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void showSupplierMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Supplier Management");
            System.out.println("1. Add Supplier");
            System.out.println("2. View Suppliers");
            System.out.println("3. Update Supplier");
            System.out.println("4. Delete Supplier");
            System.out.println("5. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    supplierManager.addSupplier();
                    break;
                case 2:
                    supplierManager.viewSuppliers();
                    break;
                case 3:
                    supplierManager.updateSupplier();
                    break;
                case 4:
                    supplierManager.deleteSupplier();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void showOrderMenu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Order Management");
            System.out.println("1. Place Order");
            System.out.println("2. View Orders");
            System.out.println("3. Update Order");
            System.out.println("4. Delete Order");
            System.out.println("5. Calculate Order Cost");
            System.out.println("6. Back to Main Menu");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    orderManager.placeOrder();
                    break;
                case 2:
                    orderManager.viewOrders();
                    break;
                case 3:
                    orderManager.updateOrder();
                    break;
                case 4:
                    orderManager.deleteOrder();
                    break;
                case 5:
                    orderManager.calculateOrderCost();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}

