package pharmacy;

import java.sql.*;
import java.util.Scanner;

public class SupplierManager {
    public void addSupplier() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO Supplier (supplier_name, contact_number, email) VALUES (?, ?, ?)")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter supplier name: ");
            String name = scanner.nextLine();
            System.out.print("Enter contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();

            ps.setString(1, name);
            ps.setString(2, contactNumber);
            ps.setString(3, email);
            ps.executeUpdate();

            System.out.println("Supplier added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSuppliers() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Supplier")) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("supplier_id"));
                System.out.println("Name: " + rs.getString("supplier_name"));
                System.out.println("Contact Number: " + rs.getString("contact_number"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("---------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSupplier() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE Supplier SET supplier_name = ?, contact_number = ?, email = ? WHERE supplier_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter supplier ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // consume newline
            System.out.print("Enter new supplier name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();

            ps.setString(1, name);
            ps.setString(2, contactNumber);
            ps.setString(3, email);
            ps.setInt(4, id);
            ps.executeUpdate();

            System.out.println("Supplier updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSupplier() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "DELETE FROM Supplier WHERE supplier_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter supplier ID to delete: ");
            int id = scanner.nextInt();

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Supplier deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

