package pharmacy;

import java.sql.*;
import java.util.Scanner;

public class OrderManager {
    public void placeOrder() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO `Order` (medicine_id, supplier_id, order_date, delivery_date, order_status) VALUES (?, ?, ?, ?, ?)")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter medicine ID: ");
            int medicineId = scanner.nextInt();
            System.out.print("Enter supplier ID: ");
            int supplierId = scanner.nextInt();
            System.out.print("Enter order date (YYYY-MM-DD): ");
            String orderDate = scanner.next();
            System.out.print("Enter delivery date (YYYY-MM-DD): ");
            String deliveryDate = scanner.next();
            System.out.print("Enter order status: ");
            String status = scanner.next();

            ps.setInt(1, medicineId);
            ps.setInt(2, supplierId);
            ps.setDate(3, Date.valueOf(orderDate));
            ps.setDate(4, Date.valueOf(deliveryDate));
            ps.setString(5, status);
            ps.executeUpdate();

            System.out.println("Order placed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewOrders() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM `Order`")) {

            while (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Medicine ID: " + rs.getInt("medicine_id"));
                System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                System.out.println("Order Date: " + rs.getDate("order_date"));
                System.out.println("Delivery Date: " + rs.getDate("delivery_date"));
                System.out.println("Order Status: " + rs.getString("order_status"));
                System.out.println("---------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateOrder() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE `Order` SET medicine_id = ?, supplier_id = ?, order_date = ?, delivery_date = ?, order_status = ? WHERE order_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter order ID to update: ");
            int orderId = scanner.nextInt();
            System.out.print("Enter new medicine ID: ");
            int medicineId = scanner.nextInt();
            System.out.print("Enter new supplier ID: ");
            int supplierId = scanner.nextInt();
            System.out.print("Enter new order date (YYYY-MM-DD): ");
            String orderDate = scanner.next();
            System.out.print("Enter new delivery date (YYYY-MM-DD): ");
            String deliveryDate = scanner.next();
            System.out.print("Enter new order status: ");
            String status = scanner.next();

            ps.setInt(1, medicineId);
            ps.setInt(2, supplierId);
            ps.setDate(3, Date.valueOf(orderDate));
            ps.setDate(4, Date.valueOf(deliveryDate));
            ps.setString(5, status);
            ps.setInt(6, orderId);
            ps.executeUpdate();

            System.out.println("Order updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteOrder() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "DELETE FROM `Order` WHERE order_id = ?")) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter order ID to delete: ");
            int orderId = scanner.nextInt();

            ps.setInt(1, orderId);
            ps.executeUpdate();

            System.out.println("Order deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void calculateOrderCost() {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT o.order_id, m.medicine_name, o.quantity, m.unit_price, (o.quantity * m.unit_price) AS total_cost " +
                     "FROM `Order` o " +
                     "JOIN Medicine m ON o.medicine_id = m.medicine_id")) {
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Medicine Name: " + rs.getString("medicine_name"));
                System.out.println("Quantity: " + rs.getInt("quantity"));
                System.out.println("Unit Price: " + rs.getDouble("unit_price"));
                System.out.println("Total Cost: " + rs.getDouble("total_cost"));
                System.out.println("---------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
