
# Pharmaceutical Inventory Management System
This console-based application simulates a pharmaceutical inventory management system for a life sciences company. It allows users to manage medicines, suppliers, and orders efficiently. The application is developed using Core Java, MySQL, and JDBC.


## Features

### Medicine Management

- Add new medicines to the inventory
- View medicine details
- Update medicine information
- Delete medicines from the inventory
- Supplier Management

### Register new suppliers
- View supplier details
- Update supplier information
- Delete suppliers

### Order Management
- Place new orders for medicines
- View order details
- Update order status
- Calculate order costs

## Database Schema
#### Medicine Table
medicine_id (Primary Key)
medicine_name
quantity_available
unit_price
expiry_date

#### Supplier Table
supplier_id (Primary Key)
supplier_name
contact_number
email

#### Order Table
order_id (Primary Key)
medicine_id (Foreign Key references Medicine Table)
supplier_id (Foreign Key references Supplier Table)
order_date
delivery_date
order_status
## Setup Instructions

1. Database Setup:
    - Create a MySQL database named productreview.
    - Execute the SQL commands provided in schema.sql to create the necessary tables (Product, Customer, Review, Rating, Improvement).

2. Java Application Setup:
    - Clone this repository to your local machine.
    - Open the project in your preferred Java IDE.

3. Configure Database Connection:
    - Modify the DatabaseConnection.java file to set your MySQL database credentials (URL, USERNAME, PASSWORD).

4. Run the Application:
    - Compile and run the Main.java file to start the console application.
    - Follow the menu options to manage product reviews, ratings, and improvements.
## Setup Instructions

1. Database Setup:
    - Create a MySQL database named productreview.
    - Execute the SQL commands provided in schema.sql to create the necessary tables (Product, Customer, Review, Rating, Improvement).

2. Java Application Setup:
    - Clone this repository to your local machine.
    - Open the project in your preferred Java IDE.

3. Configure Database Connection:
    - Modify the DatabaseConnection.java file to set your MySQL database credentials (URL, USERNAME, PASSWORD).

4. Run the Application:
    - Compile and run the Main.java file to start the console application.
    - Follow the menu options to manage product reviews, ratings, and improvements.

## Usage


Usage Instructions
Upon running the application, you will be presented with a menu-based console interface. The main menu allows you to navigate through different management options:

- Medicine Management

Add, view, update, and delete medicines.

- Supplier Management
Register, view, update, and delete suppliers.

- Order Management
Place, view, update, and calculate order costs.
Exit

- Exit the application.
Navigate through the options by entering the corresponding number and following the prompts.


## Error Handling
The application handles various exceptions to ensure smooth operation and user-friendly error messages. Common exceptions include:

- SQL exceptions for database errors
- Input validation errors for incorrect user inputs
- Null pointer exceptions for missing data