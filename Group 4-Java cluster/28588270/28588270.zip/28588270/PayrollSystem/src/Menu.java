
public class Menu {
	public static void displayMainMenu() {
        System.out.println("Payroll System Menu:");
        System.out.println("1. Employee Management");
        System.out.println("2. Department Management");
        System.out.println("3. Payroll Management");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");
    }

    public static void displayEmployeeMenu() {
        System.out.println("Employee Management Menu:");
        System.out.println("1. Add Employee");
        System.out.println("2. View Employee Details");
        System.out.println("3. Update Employee Information");
        System.out.println("4. Delete Employee");
        System.out.println("5. List All Employees");
        System.out.println("6. Back to Main Menu");
        System.out.print("Choose an option: ");
    }

    public static void displayDepartmentMenu() {
        System.out.println("Department Management Menu:");
        System.out.println("1. Add Department");
        System.out.println("2. View Department Details");
        System.out.println("3. Update Department Information");
        System.out.println("4. Delete Department");
        System.out.println("5. List All Departments");
        System.out.println("6. Back to Main Menu");
        System.out.print("Choose an option: ");
    }

    public static void displayPayrollMenu() {
        System.out.println("Payroll Management Menu:");
        System.out.println("1. Process Payroll for Employee");
        System.out.println("2. View Payroll Details");
        System.out.println("3. Update Payroll Information");
        System.out.println("4. List Payroll History for Employee");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");
    }
}
