import java.sql.*;
import java.util.*;

public class PayrollService {
	public void processPayroll(Payroll payroll) {
        String query = "INSERT INTO Payrolls (employee_id, payment_date, amount) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, payroll.getEmployeeId());
            statement.setDate(2, new java.sql.Date(payroll.getPaymentDate().getTime()));
            statement.setDouble(3, payroll.getAmount());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Payroll getPayroll(int payrollId) {
        String query = "SELECT * FROM Payrolls WHERE payroll_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, payrollId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Payroll payroll = new Payroll();
                payroll.setPayrollId(resultSet.getInt("payroll_id"));
                payroll.setEmployeeId(resultSet.getInt("employee_id"));
                payroll.setPaymentDate(resultSet.getDate("payment_date"));
                payroll.setAmount(resultSet.getDouble("amount"));
                return payroll;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updatePayroll(Payroll payroll) {
        String query = "UPDATE Payrolls SET employee_id = ?, payment_date = ?, amount = ? WHERE payroll_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, payroll.getEmployeeId());
            statement.setDate(2, new java.sql.Date(payroll.getPaymentDate().getTime()));
            statement.setDouble(3, payroll.getAmount());
            statement.setInt(4, payroll.getPayrollId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Payroll> getPayrollHistory(int employeeId) {
        List<Payroll> payrolls = new ArrayList<>();
        String query = "SELECT * FROM Payroll WHERE employee_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, employeeId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Payroll payroll = new Payroll();
                payroll.setPayrollId(resultSet.getInt("payroll_id"));
                payroll.setEmployeeId(resultSet.getInt("employee_id"));
                payroll.setPaymentDate(resultSet.getDate("payment_date"));
                payroll.setAmount(resultSet.getDouble("amount"));
                payrolls.add(payroll);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return payrolls;
    }
}
