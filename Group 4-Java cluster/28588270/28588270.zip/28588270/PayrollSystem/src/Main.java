import java.util.*;
public class Main {
	private static EmployeeService employeeService = new EmployeeService();
    private static DepartmentService departmentService = new DepartmentService();
    private static PayrollService payrollService = new PayrollService();

    static Scanner sc=new Scanner(System.in);
    
    public static void main(String[] args) {
        while (true) {
            Menu.displayMainMenu();
            int choice =sc.nextInt();
            switch (choice) {
                case 1:
                    manageEmployees();
                    break;
                case 2:
                    manageDepartments();
                    break;
                case 3:
                    managePayroll();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageEmployees() {
        while (true) {
            Menu.displayEmployeeMenu();
            int choice =sc.nextInt();
            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    viewEmployeeDetails();
                    break;
                case 3:
                    updateEmployeeInformation();
                    break;
                case 4:
                    deleteEmployee();
                    break;
                case 5:
                    listAllEmployees();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee() {
        System.out.print("Enter name: ");
        sc.nextLine();
        String name = sc.nextLine();
        System.out.print("Enter department ID: ");
        int departmentId = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter designation: ");
        String designation =sc.nextLine();
        System.out.print("Enter salary: ");
        double salary =sc.nextDouble();
        //System.out.println(name+departmentId+designation+salary);

        Employee employee = new Employee();
        employee.setName(name);
        employee.setDepartmentId(departmentId);
        employee.setDesignation(designation);
        employee.setSalary(salary);

        employeeService.addEmployee(employee);
        System.out.println("Employee added successfully.");
    }

    private static void viewEmployeeDetails() {
        System.out.print("Enter employee ID: ");
        int employeeId = sc.nextInt();
        Employee employee = employeeService.getEmployee(employeeId);
        if (employee != null) {
            System.out.println("Employee Details:");
            System.out.println("ID: " + employee.getEmployeeId());
            System.out.println("Name: " + employee.getName());
            System.out.println("Department ID: " + employee.getDepartmentId());
            System.out.println("Designation: " + employee.getDesignation());
            System.out.println("Salary: " + employee.getSalary());
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void updateEmployeeInformation() {
        System.out.print("Enter employee ID: ");
        int employeeId = sc.nextInt();
        Employee employee = employeeService.getEmployee(employeeId);
        if (employee != null) {
            System.out.print("Enter new name: ");
            employee.setName(sc.nextLine());
            System.out.print("Enter new department ID: ");
            employee.setDepartmentId(sc.nextInt());
            System.out.print("Enter new designation: ");
            employee.setDesignation(sc.nextLine());
            System.out.print("Enter new salary: ");
            employee.setSalary(sc.nextDouble());
            employeeService.updateEmployee(employee);
            System.out.println("Employee information updated successfully.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    private static void deleteEmployee() {
        System.out.print("Enter employee ID: ");
        int employeeId = sc.nextInt();
        employeeService.deleteEmployee(employeeId);
        System.out.println("Employee deleted successfully.");
    }

    private static void listAllEmployees() {
        List<Employee> employees = employeeService.getAllEmployees();
        if (!employees.isEmpty()) {
            System.out.println("Employee List:");
            for (Employee employee : employees) {
                System.out.println("ID: " + employee.getEmployeeId() + ", Name: " + employee.getName() +
                        ", Department ID: " + employee.getDepartmentId() + ", Designation: " + employee.getDesignation() +
                        ", Salary: " + employee.getSalary());
            }
        } else {
            System.out.println("No employees found.");
        }
    }

    private static void manageDepartments() {
        while (true) {
            Menu.displayDepartmentMenu();
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    addDepartment();
                    break;
                case 2:
                    viewDepartmentDetails();
                    break;
                case 3:
                    updateDepartmentInformation();
                    break;
                case 4:
                    deleteDepartment();
                    break;
                case 5:
                    listAllDepartments();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addDepartment() {
        System.out.print("Enter department name: ");
        sc.nextLine();
        String name = sc.nextLine();
        System.out.print("Enter location: ");
        String location = sc.nextLine();

        Department department = new Department();
        department.setName(name);
        department.setLocation(location);

        departmentService.addDepartment(department);
        System.out.println("Department added successfully.");
    }

    private static void viewDepartmentDetails() {
        System.out.print("Enter department ID: ");
        int departmentId = sc.nextInt();
        Department department = departmentService.getDepartment(departmentId);
        if (department != null) {
            System.out.println("Department Details:");
            System.out.println("ID: " + department.getDepartmentId());
            System.out.println("Name: " + department.getName());
            System.out.println("Location: " + department.getLocation());
        } else {
            System.out.println("Department not found.");
        }
    }

    private static void updateDepartmentInformation() {
        System.out.print("Enter department ID: ");
        int departmentId = sc.nextInt();
        Department department = departmentService.getDepartment(departmentId);
        if (department != null) {
            System.out.print("Enter new name: ");
            sc.nextLine();
            department.setName(sc.nextLine());
            System.out.print("Enter new location: ");
            department.setLocation(sc.nextLine());
            departmentService.updateDepartment(department);
            System.out.println("Department information updated successfully.");
        } else {
            System.out.println("Department not found.");
        }
    }

    private static void deleteDepartment() {
        System.out.print("Enter department ID: ");
        int departmentId =sc.nextInt();
        departmentService.deleteDepartment(departmentId);
        System.out.println("Department deleted successfully.");
    }

    private static void listAllDepartments() {
        List<Department> departments = departmentService.getAllDepartments();
        if (!departments.isEmpty()) {
            System.out.println("Department List:");
            for (Department department : departments) {
                System.out.println("ID: " + department.getDepartmentId() + ", Name: " + department.getName() +
                        ", Location: " + department.getLocation());
            }
        } else {
            System.out.println("No departments found.");
        }
    }

    private static void managePayroll() {
        while (true) {
            Menu.displayPayrollMenu();
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    processPayroll();
                    break;
                case 2:
                    viewPayrollDetails();
                    break;
                case 3:
                    updatePayrollInformation();
                    break;
                case 4:
                    listPayrollHistory();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void processPayroll() {
        System.out.print("Enter employee ID: ");
        int employeeId = sc.nextInt();
        System.out.print("Enter payment date (YYYY-MM-DD): ");
        String dateStr =sc.nextLine();
        Date paymentDate = java.sql.Date.valueOf(dateStr);
        System.out.print("Enter amount: ");
        double amount = sc.nextDouble();

        Payroll payroll = new Payroll();
        payroll.setEmployeeId(employeeId);
        payroll.setPaymentDate(paymentDate);
        payroll.setAmount(amount);

        payrollService.processPayroll(payroll);
        System.out.println("Payroll processed successfully.");
    }

    private static void viewPayrollDetails() {
        System.out.print("Enter payroll ID: ");
        int payrollId = sc.nextInt();
        Payroll payroll = payrollService.getPayroll(payrollId);
        if (payroll != null) {
            System.out.println("Payroll Details:");
            System.out.println("ID: " + payroll.getPayrollId());
            System.out.println("Employee ID: " + payroll.getEmployeeId());
            System.out.println("Payment Date: " + payroll.getPaymentDate());
            System.out.println("Amount: " + payroll.getAmount());
        } else {
            System.out.println("Payroll not found.");
        }
    }

    private static void updatePayrollInformation() {
        System.out.print("Enter payroll ID: ");
        int payrollId = sc.nextInt();
        Payroll payroll = payrollService.getPayroll(payrollId);
        if (payroll != null) {
            System.out.print("Enter new employee ID: ");
            payroll.setEmployeeId(sc.nextInt());
            System.out.print("Enter new payment date (YYYY-MM-DD): ");
            String dateStr = sc.nextLine();
            payroll.setPaymentDate(java.sql.Date.valueOf(dateStr));
            System.out.print("Enter new amount: ");
            payroll.setAmount(sc.nextDouble());
            payrollService.updatePayroll(payroll);
            System.out.println("Payroll information updated successfully.");
        } else {
            System.out.println("Payroll not found.");
        }
    }

    private static void listPayrollHistory() {
        System.out.print("Enter employee ID: ");
        int employeeId = sc.nextInt();
        List<Payroll> payrolls = payrollService.getPayrollHistory(employeeId);
        if (!payrolls.isEmpty()) {
            System.out.println("Payroll History:");
            for (Payroll payroll : payrolls) {
                System.out.println("ID: " + payroll.getPayrollId() + ", Payment Date: " + payroll.getPaymentDate() +
                        ", Amount: " + payroll.getAmount());
            }
        } else {
            System.out.println("No payroll records found.");
        }
    }
}
