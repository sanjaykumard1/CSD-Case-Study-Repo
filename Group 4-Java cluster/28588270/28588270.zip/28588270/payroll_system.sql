USE payroll_system;

CREATE TABLE Departmentss(
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL
);

CREATE TABLE Employees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    department_id INT,
    designation VARCHAR(255) NOT NULL,
    salary DOUBLE NOT NULL,
    FOREIGN KEY (department_id) REFERENCES Departmentss(department_id) ON DELETE SET NULL
);

CREATE TABLE Payrolls(
    payroll_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT,
    payment_date DATE NOT NULL,
    amount DOUBLE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);