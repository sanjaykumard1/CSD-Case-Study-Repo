
# Movie Rental Management System

## Table of Contents
1. [Introduction](#introduction)
2. [Features](#features)
3. [Languages and Technology Used](#languages-and-technology)
4. [System Requirements](#system-requirements)
5. [Setup Instructions](#setup-instructions)
6. [Database Schema](#database-schema)
7. [Formulas](#formulas)


## Introduction
The Movie Rental Management System is a Java application that allows users to manage movies, customers, and rental operations efficiently. This system uses JDBC for database operations.

## Features
- **Movie Operations:**
  - Add a new movie
  - Update existing movie details
  - Delete a movie from the database
  - View details of all movies

- **Customer Operations:**
  - Add a new customer
  - Update existing customer details
  - Delete a customer from the database
  - View details of all customers

- **Rental Operations:**
  - Rent a movie to a customer
  - Return a rented movie
  - Calculate rental charges
  - View rental details

## Languages and Technology Used
- Java
- MySql
- Jdbc

## System Requirements
 - Java [JDK 8+]
- Eclipse
- MySql
- Jdbc Driver
- MySql Connector


## Setup Instructions
1. Download and install Eclipse in your machine
2. Clone or download the repository
3. Extract all the files and move it in your eclipse directory.Open MRMS Folder.
4. Open MRMS.sql in your MySql workbench.download MySql connector(“mysql-connector-java-8.0.22.jar" )
5. Now Open .classpath file in EHMS folder,in Line - 9 of This file Change the path with the path where your .jar file is being downloaded.
6. Open ConnectionProvider.java file and change the uname(username) and pass(password) variable according the user name and password of your MySql database
7. Now it is ready to Run

## Query
```bash
create table movie(movie_id int PRIMARY KEY, 
title varchar(40),
genre varchar(30),
 release_year date,
 rental_price int);
```

```bash
create table customer(customer_id int primary key auto_increment,
customer_name varchar(30),
email varchar(40) unique not null,
phone_number bigint(10) not null ,
address varchar(50));
```

```bash
create table rental(rental_id int primary key, movie_id int,customer_id int,
rental_start_date date,
rental_end_date date,
total_charge int, 
foreign key(customer_id) references customer(customer_id), 
foreign key(movie_id) references movie(movie_id));
```
## Formulas
To Calculate Rental Charges:
baseCharge+No.of.Days*(0.1*baseCharge)
## Query