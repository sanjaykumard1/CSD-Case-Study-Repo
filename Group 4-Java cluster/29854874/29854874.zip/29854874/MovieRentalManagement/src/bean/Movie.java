package bean;

public class Movie {
	
	private int movieId;
	private String movieName;
	private String movieGenre;
	private int releaseYear;
	private int basePay;
	private boolean availability;
	
	public Movie(int movieId, String movieName, String movieGenre, int releaseYear, int basePay, boolean availability) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieGenre = movieGenre;
		this.releaseYear = releaseYear;
		this.basePay = basePay;
		this.availability = availability;
	}
	public Movie() {
		
	}
	
	
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieGenre() {
		return movieGenre;
	}
	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}
	public int getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		this.releaseYear = releaseYear;
	}
	public int getBasePay() {
		return basePay;
	}
	public void setBasePay(int basePay) {
		this.basePay = basePay;
	}
	public boolean isAvailability() {
		return availability;
	}
	public void setAvailability(boolean availability) {
		this.availability = availability;
	}
	
	
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieGenre=" + movieGenre
				+ ", releaseYear=" + releaseYear + ", basePay=" + basePay + ", availability=" + availability + "]";
	}
	
	
	

}

