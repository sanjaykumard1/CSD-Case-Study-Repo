package bean;



import java.sql.Date;
public class Rental {
private int rental_id;
private int movie_id;
private int customer_id;
private Date rental_start_date;
private Date rental_end_date;
private int totalCharge;

public  Rental() {
	
}

public Rental(int rental_id, int movie_id, int customer_id, Date rental_start_date, Date rental_end_date,
		int totalCharge) {
	super();
	this.rental_id = rental_id;
	this.movie_id = movie_id;
	this.customer_id = customer_id;
	this.rental_start_date = rental_start_date;
	this.rental_end_date = rental_end_date;
	this.totalCharge = totalCharge;
}

public int getRental_id() {
	return rental_id;
}

public void setRental_id(int rental_id) {
	this.rental_id = rental_id;
}

public int getMovie_id() {
	return movie_id;
}

public void setMovie_id(int movie_id) {
	this.movie_id = movie_id;
}

public int getCustomer_id() {
	return customer_id;
}

public void setCustomer_id(int customer_id) {
	this.customer_id = customer_id;
}

public Date getRental_start_date() {
	return rental_start_date;
}

public void setRental_start_date(Date rental_start_date) {
	this.rental_start_date = rental_start_date;
}

public Date getRental_end_date() {
	return rental_end_date;
}

public void setRental_end_date(Date rental_end_date) {
	this.rental_end_date = rental_end_date;
}

public int getTotalCharge() {
	return totalCharge;
}

public void setTotalCharge(int totalCharge) {
	this.totalCharge = totalCharge;
}


}

