package dao;

import bean.Customer;

public interface CustomerDAO {

	public String addCustomer(Customer c);

	public void displayCustomerDetails();
	
	public void displayCustomerDetailsById(int customer_id);
	
	public String updateCustomer(int customer_id,String name);
	
	public String deleteCustomer(int customerId);
	
	public  boolean isValidPhno(String phno) ;
	
	 public  boolean isValid(String email) ;

}
