package dao;


import Connection.DbConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public  class RentalDAOImp implements RentalDAO{


	public void displayRentalDetail() {
		// TODO Auto-generated method stub
		
		String query="Select * from rental;";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				System.out.print("Rental Id     :"+rs.getInt(1)+"  ");
				System.out.print("Movie Id   :"+rs.getInt(2)+" ");
				System.out.print("Customer Id        :"+rs.getInt(3)+"  ");
				System.out.print("Rental Start Date :"+rs.getDate(4)+"  ");
				System.out.print("Rental End Date     :"+rs.getDate(5)+"  ");
				System.out.print("Rental Charges     :"+rs.getInt(6)+"  ");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public String rentMovie(int customerId,int movieId,String startDate) {
		String query="Select availability from movie where movie_id="+movieId;
		String message="Movie not available";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query);
			rs.next();
			boolean availability=rs.getBoolean(1);
			if(availability) {
				String query1="insert into rental(movie_id,customer_id,rental_start_date) values ("+movieId+","+customerId+",'"+startDate+"');";
				st.executeUpdate(query1);
				String query2="update movie set availability=false where movie_id="+movieId;
				st.executeUpdate(query2);
				message="Movie Rented Successfully!!!!";
			}
			return message;
		
	}
		catch(SQLException e) {
			return message;
		}
	}

  
	public String returnMovie(int rentalId,String endDate) {
		String query="Select movie_id from rental where rental_id="+rentalId;
		String query1="update rental set rental_end_date='"+endDate+"' where rental_id="+rentalId;
		String message="Movie cannot be returned";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query);
			rs.next();
			int movie_id=rs.getInt(1);
			st.executeUpdate(query1);
			message="Returned Movie SuccessFully!!!!";
			String query2="update movie set availability=true where movie_id="+movie_id;
			st.executeUpdate(query2);
			
	}
		catch(SQLException e ) {
			return message+ e;
		}
		return message;
	}

	
	public String calculateRentalCharges(int rentalId) {
		String query1="Select r.rental_start_date,r.rental_end_date,m.rental_price from rental as r join movie as m on r.movie_id=m.movie_id where rental_id="+rentalId;
		String message="No such rental exist";
	     int charges=0;
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query1);
			  rs.next();
				Date startDate=rs.getDate(1);
				Date endDate=rs.getDate(2);	
				int base_charge=rs.getInt(3);
			   	if(startDate.equals(endDate)) {
					charges=base_charge;
				}
			   	else {
			   		  
			   		long timeDiff =  Math.abs(endDate.getTime() - startDate.getTime());
			   	    long daysDiff = timeDiff/(1000*60*60*24);
			   	   
			   	    charges=(int)Math.abs(base_charge+daysDiff*(0.1*base_charge));
			   	}
			   	String query="update rental set total_charge="+charges+" where rental_id="+rentalId;
			   	st.executeUpdate(query);
			   	
			message="Amount to be paid: Rs."+charges;
	}
 
		catch(SQLException e) {
			System.out.println(message);
		}
	return  message;
	
}


	public void displayRentalDetailById(int rental_id) {
		// TODO Auto-generated method stub

		String query="Select * from rental where rental_id="+rental_id;
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				System.out.print("Rental Id     :"+rs.getInt(1)+"  ");
				System.out.print("Movie Id   :"+rs.getInt(2)+" ");
				System.out.print("Customer Id        :"+rs.getInt(3)+"  ");
				System.out.print("Rental Start Date :"+rs.getDate(4)+"  ");
				System.out.print("Rental End Date     :"+rs.getDate(5)+"  ");
				System.out.println("Rental Charges     :"+rs.getInt(6)+"  ");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	
}
