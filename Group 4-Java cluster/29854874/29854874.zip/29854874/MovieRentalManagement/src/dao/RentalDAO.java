package dao;

public interface RentalDAO {
	public void displayRentalDetail();
	public void displayRentalDetailById(int rental_id);
	
	public String rentMovie(int customerId,int rentalId,String startDate);
	public String returnMovie(int rentalId,String endDate);
	public String calculateRentalCharges(int rental_id);
}
