package dao;
    
    import bean.Customer;
    import Connection.DbConnection;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.regex.Pattern;

	public class CustomerDAOImp implements CustomerDAO{


		public String addCustomer( Customer c) {
			String query="insert into customer values(null,?,?,?,?);";
			String message="Customer not added";
			Connection con;
			try {
				con = DbConnection.getConnection();
				PreparedStatement ps=con.prepareStatement(query);
				
				ps.setString(1,c.getCustomerName());
				ps.setString(2, c.getEmail());
				ps.setString(3,c.getPhoneNumber());
				ps.setString(4, c.getAddress());
				
			
			    int num=ps.executeUpdate();
			    if(num>0) {
			    	message="Customer added successfully";
			    }
			}
			catch(SQLException e) {
				return message ;
			}
			 return message;
		}


		public void displayCustomerDetails() {
			String query="Select * from customer;";
			Connection con;
			try {
				con = DbConnection.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				while(rs.next()) {
					System.out.print("Customer Id     :"+rs.getInt(1)+"  ");
					System.out.print("Customer Name   :"+rs.getString(2)+" ");
					System.out.print("Email        :"+rs.getString(3)+"  ");
					System.out.println("Phone Number :"+rs.getString(4)+"  ");
					System.out.print("Address        :"+rs.getString(5)+"  ");
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		

		public void displayCustomerDetailsById(int customer_id) {
			String query="Select * from customer where customer_id="+customer_id;
			Connection con;
			try {
				con = DbConnection.getConnection();
				Statement st = con.createStatement();
				ResultSet rs=st.executeQuery(query);
				while(rs.next()) {
					System.out.print("Customer Id     :"+rs.getInt(1)+"  ");
					System.out.print("Customer Name   :"+rs.getString(2)+" ");
					System.out.print("Email        :"+rs.getString(3)+"  ");
					System.out.println("Phone Number :"+rs.getString(4)+"  ");
					System.out.print("Address        :"+rs.getString(5)+"  ");
				}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}


		public String updateCustomer(int customer_id,String name) {
			String query=("update customer set customer_name='"+name+"' where customer_id="+customer_id);
			String message="Unable to update customer";
			Connection con;
			try {
				con = DbConnection.getConnection();
				Statement st=con.createStatement();
				int num=st.executeUpdate(query);
				if(num>0) {
					message="Customer name updated Successfully";
				}	
			}
			catch(SQLException s) {
				return message;
			}
			return message;
		}


		public String deleteCustomer(int customerId) {
			String query=("delete from customer where customer_id="+customerId);
			String message="Unable to delete customer";
			Connection con;
			try {
				con = DbConnection.getConnection();
				Statement st=con.createStatement();
				int num=st.executeUpdate(query);
				if(num>0) {
					message="Customer deleted Successfully";
				}	
			}
			catch(SQLException s) {
				return message;
			}
			return message;
		}
		
		 public  boolean isValid(String email) 
		    { 
		        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
		                            "[a-zA-Z0-9_+&*-]+)*@" + 
		                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
		                            "A-Z]{2,7}$"; 
		                              
		        Pattern pat = Pattern.compile(emailRegex); 
		        if (email == null) 
		            return false; 
		        return pat.matcher(email).matches(); 
		    } 
		 
		 public  boolean isValidPhno(String phno) 
		    { 
			 
			 try {
		        String emailRegex = "[8 9 10][0-9]{9}"; 
		                              
		        Pattern pat = Pattern.compile(emailRegex); 
		        if (phno == null) 
		            return false; 
		        return pat.matcher(phno).matches(); 
			 }
			 catch(Exception e) {
				 return false;
			 }
		    }

		
		}