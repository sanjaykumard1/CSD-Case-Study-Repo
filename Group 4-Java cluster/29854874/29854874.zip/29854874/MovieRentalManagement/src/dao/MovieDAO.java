package dao;

import  bean.Movie;


public interface MovieDAO {
	
		public final String username = "Admin";
		
		public final String password = "1234";

		public  boolean adminLogin(String username, String password);
		
		public String addMovie(int movieId,String movieName,String movieGenre,int releaseYear,
				int baseCharges,boolean availability);

		public void displayMovieDetails();
		
		public String updateMovie(int movieId,String movieName);
		
		public String deleteMovie(int movieId);

		String addMovie(Movie s);

	
}

