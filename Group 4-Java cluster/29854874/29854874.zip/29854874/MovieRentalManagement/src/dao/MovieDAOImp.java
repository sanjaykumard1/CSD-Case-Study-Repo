package dao;

import Connection.DbConnection;
import bean.Movie;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MovieDAOImp implements MovieDAO {
	
  public boolean adminLogin(String username, String password) {
	   boolean result=false;
		
		String message = "Invalid username or password";
		
		if (username.equals(MovieDAO.username) && password.equals(MovieDAO.password)) {
			 message = "Login Successfull";
			 result=true;
		}
		System.out.println(message);
		return result;
	}
	
	public void displayMovieDetails() {
		String query="Select * from movie;";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st = con.createStatement();
			ResultSet rs=st.executeQuery(query);
			while(rs.next()) {
				System.out.print("Movie Id     :"+rs.getInt(1)+"  ");
				System.out.print("Movie Name   :"+rs.getString(2)+" ");
				System.out.print("Genre        :"+rs.getString(3)+"  ");
				System.out.println("Release Year :"+rs.getInt(4)+"  ");
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		 
	}


	public String addMovie(int movieId, String movieName, String movieGenre, int releaseYear, int baseCharges,
			boolean availability) {
		String query="insert into movie values(?,?,?,?,?,?);";
		String message="Movie not added";
		Connection con;
		try {
			con = DbConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1, movieId);
			ps.setString(2, movieName);
			ps.setString(3, movieGenre);
			ps.setInt(4,releaseYear);
			ps.setInt(5, baseCharges);
			ps.setBoolean(6, availability);
		
		    int num=ps.executeUpdate();
		    if(num>0) {
		    	message="Movie added successfully";
		    }
		}
		catch(SQLException e) {
			return message+ e;
		}
		 return message;
		
	}
	
	@Override
	public String addMovie(Movie movie) {
		String query="insert into movie values(null,?,?,?,?,?);";
		String message="Movie not added";
		Connection con;
		try {
			con = DbConnection.getConnection();
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, movie.getMovieName());
			ps.setString(2, movie.getMovieGenre());
			ps.setInt(3,movie.getReleaseYear());
			ps.setInt(4, movie.getBasePay());
			ps.setBoolean(5,movie.isAvailability());
		
		    int num=ps.executeUpdate();
		    if(num>0) {
		    	message="Movie added successfully";
		    }
		}
		catch(SQLException e) {
			return message;
		}
		return message;
		
	}

	@Override
	public String updateMovie(int movieId,String movieName) {
		String query=("update movie set title='"+movieName+"' where movie_id="+movieId);
		String message="Unable to update movie";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st=con.createStatement();
			int num=st.executeUpdate(query);
			if(num>0) {
				message="Movie name updated Successfully";
			}	
		}
		catch(SQLException s) {
			return message;
		}
		return message;
	}

	@Override
	public String deleteMovie(int movieId) {
		String query=("delete from movie where movie_id="+movieId);
		String message="Unable to delete movie";
		Connection con;
		try {
			con = DbConnection.getConnection();
			Statement st=con.createStatement();
			int num=st.executeUpdate(query);
			if(num>0) {
				message="Movie deleted Successfully";
			}	
		}
		catch(SQLException s) {
			return message;
		}
		return message;
}

	
	}
