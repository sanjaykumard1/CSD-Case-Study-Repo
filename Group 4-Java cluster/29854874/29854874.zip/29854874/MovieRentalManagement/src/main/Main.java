package main;

import java.util.Scanner;

import bean.Customer;
import dao.CustomerDAOImp;
import bean.Movie;
import dao.MovieDAOImp;
import bean.Rental;
import dao.RentalDAOImp;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc=new Scanner(System.in);
	     System.out.println("1.Admin Login \n2.Customer Management Login \n3.Rentals\n4.Exit");
	     choice();
	
	}
	
	static MovieDAOImp movie=new MovieDAOImp();
	 static Movie m=new Movie();
	          static void choice() {
	        	  Scanner sc=new Scanner(System.in);
	        	  int choice=0;
	        	  try {
	        		  choice=sc.nextInt();
	        	  }
	        	  catch(Exception e) {
	        		  System.err.print("Input type should be a number");
	        		  sc.close();
	        	  }
	        	  if(choice==1) {
	        		  System.out.println("Welcome Movie Admin!!\nPlease Login to your Account");
	        	     AdminLogin();
	        	  }
	        	  else if(choice==2) {
	        		  System.out.println("Welcome to Customer Management!!");
	        		  CustomerManagement();
	        		  
	        	  }
	        	  else if(choice==3) {
	        		  System.out.println("Welcome Customer!!! ");
	        		  RentalManagement();
	        	  }
	        	  else if(choice==4) {
	        		  System.out.println("Thank you! Visit again!!");
	        		  System.exit(0);
	        	  }
	        	  else {
	        		  System.out.println("Please select a number from below options ");
	        		  System.out.println("1.Admin Login \n2.Customer Login \n3.Exit");
	        		     choice();
	        	  }
	        	  
	          }
		
	         static void AdminLogin() {
	        	  Scanner sc=new Scanner(System.in);
	        	  System.out.print("Enter your username:");
	        	  String username=sc.next();
	        	  System.out.print("Enter your password:");
	        	  String password=sc.next();
	        	  
	      		
	      		boolean result = movie.adminLogin(username,password);

	      		if (result) MovieManagement();
	      		else {
	      			AdminLogin();
	      		}
	      	}
	          
	          static void MovieManagement() {
	        	  Scanner sc=new Scanner(System.in);
	        	  
	        	 
	        	  boolean val=true;
	        	  while(val) {
	        		  System.out.println("Choose one of the options\n1.Add a movie\n2.View all movie details\n3.Update movie name\n4.Delete a movie\n5.Exit");
		        	  int choice=sc.nextInt();
	        	  switch(choice) {
	        	  case 1: {System.out.println("Enter movie name:");
	        	      String movieName=sc.next();
	        	       m.setMovieName(movieName);
	        	       System.out.println("Enter movie genre:");
		        	   String movieGenre=sc.next();
		        	    m.setMovieGenre(movieGenre);
		        	    System.out.println("Enter release year:");
		        	    int year=sc.nextInt();
		        	    m.setReleaseYear(year);
                        System.out.println("Enter base pay:");
		        	    int basePay=sc.nextInt();
		        	    m.setBasePay(basePay);
		        	    System.out.println("Enter availability:");
		        	    boolean availability=sc.nextBoolean();
		        	    m.setAvailability(availability);
	        		    System.out.println (movie.addMovie(m));}
	        		   break;
	        	  case 2:movie.displayMovieDetails();
	        	         break;
	        	  case 3:System.out.println("Enter movie id to be updated:");
	        	       int id=sc.nextInt();
	        	       System.out.println("Enter updated movie name:");
	        	       String movieName=sc.nextLine();
	        	       movieName=sc.nextLine();
	        		  System.out.println( movie.updateMovie(id,movieName));
	        	          break;
	        	  case 4:System.out.println("Enter movie id to be deleted:");
	        		  int movieId=sc.nextInt();
	        		     System.out.println(movie.deleteMovie(movieId));
	        	         break;
	        	  case 5:
	        		  val=false;
	        		  System.out.println("Thank You!!");
	        	        break;
	        	   default: System.out.println("Please select a number from below options");
	        	          MovieManagement();
	        	          break;
	        	            
	        	  } }      
	        	  
	          
	        	  
	          }
	          
	          static CustomerDAOImp customer=new CustomerDAOImp();
	      	   static Customer c=new Customer();
	      	
	          static void CustomerManagement() {
	        	  Scanner sc=new Scanner(System.in);
	        	  boolean val=true;
	        	  while(val) {
	        	  System.out.println("Choose one of the options\n1.Add a customer\n2.View all customer details\n3.View customer details by customer id\n4.Update customer name\n5.Delete a customer\n6.Exit");
	        	  int choice=sc.nextInt();
	        	  switch(choice) {
	        	  case 1: System.out.println("Enter customer name:");
	        	      String customerName=sc.next();
	        	       c.setCustomerName(customerName);
	        	       System.out.println("Enter your email:");
		        	   String customerEmail=sc.next();
		        	   c.setEmail(customerEmail);;
		        	    System.out.println("Enter your phone number:");
		        	    String phno=sc.next();
		        	  if(customer.isValidPhno(phno)) {
		        	    c.setPhoneNumber(phno);}
		        	  else {
		        		  System.out.println("Enter a valid ph.no");
		        		   phno=sc.next();
		        	  }
		        	    System.out.print("Enter your addrress:");
		        	    String address=sc.nextLine();
		        	    address=sc.nextLine();
		        	    c.setAddress(address);
                        
	        		    System.out.println(customer.addCustomer(c));
	        		   break;
	        	  case 2:customer.displayCustomerDetails();
	        	         break;
	        	  case 3:System.out.println("Please Enter the Customer Id:");
	        	        int cid=sc.nextInt();
	        		  customer.displayCustomerDetailsById(cid);
     	                      break;
	        	  case 4:System.out.println("Please enter the Customer Id:");
	        	        int id=sc.nextInt();
	        	     System.out.println("Please enter the name to be updated:");
	        	     String name=sc.next();
	        	     System.out.println(customer.updateCustomer(id,name));
	        	     break;
	        	  case 5:System.out.println("Please Enter the Customer Id:");
	        		     int c_id=sc.nextInt();
	        		     System.out.println(customer.deleteCustomer(c_id));
	        	         break;
	        	  case 6:val=false;
        		  System.out.println("Thank You!!");
      	        break;
	        	          
	        	  default: System.out.print("Please select a number from below options");
    	          CustomerManagement();
    	          break;
	        	  
	          }
	          }
	          }
/**------------------------------------------------------------------------------------------------------------------------------------------------------------------------ */
	           
	           static RentalDAOImp rental=new RentalDAOImp();
	      	   static Rental r=new Rental();
	      	
	           static void RentalManagement() {
	        	  Scanner sc=new Scanner(System.in);
	        	  boolean val=true;
	        	  while(val) {
	        	  System.out.println("Choose one of the options\n1.Rent a movie\n2.Return a rented movie\n3.View rental details\n4.View rental details by Id\n5.Calculate Rental Charges");
	        	  int choice=sc.nextInt();
	        	  switch(choice) {
	        	  case 1: System.out.println("Enter customer id:");
	        	       int cid=sc.nextInt();
	        	       System.out.println("Enter movie id:");
	        	       int mid=sc.nextInt();
	        	       System.out.println("Enter start date(format:'YYYY-MM-DD'):");
	        	       String startDate=sc.next();
	        	        r.setMovie_id(mid);
	        	        r.setCustomer_id(cid);
	        		    System.out.print (rental.rentMovie(cid, mid, startDate));
	        		    break;
	        	  case 2:System.out.println("Enter rental id:");
       	                 int rid=sc.nextInt();
       	                 System.out.println("Enter end date(format:'YYYY-MM-DD'):");
       	       
       	      String ndDate=sc.next();
	        		  System.out.println(rental.returnMovie(rid, ndDate));
	        	         break;
	        	  case 3:rental.displayRentalDetail();
    	                      break;
	        	  case 4:System.out.println("Enter rental id:");
	                 int rid1=sc.nextInt();
	        		  rental.displayRentalDetailById(rid1);
                  break;
	        	  case 5:System.out.println("Enter rental id to calculate charges:");
	                  rid1=sc.nextInt();
	        	     System.out.println(rental.calculateRentalCharges(rid1));;
	        	   break;
	        	          
	        	  } 
	          }
	           }}
	
