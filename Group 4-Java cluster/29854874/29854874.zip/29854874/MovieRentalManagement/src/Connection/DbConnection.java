package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private static final String url="jdbc:mysql://localhost:3306/movieRental";
	private static final String username="root";
	private static final String password="#Akshara24#";

	//Connection obj is returned
	public static Connection getConnection() {
		try {
			return DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			return null;
		}
		
	}
}

