/**
 * 
 */
/**
 * @author Dell
 *
 */
module Databaseconnectivity {
	requires java.sql;
}