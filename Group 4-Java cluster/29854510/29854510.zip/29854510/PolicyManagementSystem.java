import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PolicyManagementSystem {
    private List<Policy> policies;
    private int nextPolicyId;

    // Constructor
    public PolicyManagementSystem() {
        policies = new ArrayList<>();
        nextPolicyId = 1; // Initial policy id starts from 1
    }

    // Method to add a new policy
    public void addPolicy(String policyName, String policyType, double policyPremium) {
        Policy newPolicy = new Policy(nextPolicyId, policyName, policyType, policyPremium);
        policies.add(newPolicy);
        nextPolicyId++;
        System.out.println("Policy added successfully.");
    }

    // Method to view policy details
    public void viewPolicyDetails(int policyId) {
        boolean found = false;
        for (Policy policy : policies) {
            if (policy.getPolicyId() == policyId) {
                System.out.println("Policy details:");
                System.out.println(policy);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Policy with ID " + policyId + " not found.");
        }
    }

    // Method to update policy information
    public void updatePolicy(int policyId, String policyName, String policyType, double policyPremium) {
        for (Policy policy : policies) {
            if (policy.getPolicyId() == policyId) {
                policy.setPolicyName(policyName);
                policy.setPolicyType(policyType);
                policy.setPolicyPremium(policyPremium);
                System.out.println("Policy updated successfully.");
                return;
            }
        }
        System.out.println("Policy with ID " + policyId + " not found. Update failed.");
    }

    // Method to delete a policy
    public void deletePolicy(int policyId) {
        for (Policy policy : policies) {
            if (policy.getPolicyId() == policyId) {
                policies.remove(policy);
                System.out.println("Policy deleted successfully.");
                return;
            }
        }
        System.out.println("Policy with ID " + policyId + " not found. Deletion failed.");
    }

    // Method to display all policies
    public void displayAllPolicies() {
        if (policies.isEmpty()) {
            System.out.println("No policies found.");
        } else {
            System.out.println("List of Policies:");
            for (Policy policy : policies) {
                System.out.println(policy);
            }
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        PolicyManagementSystem policyManagementSystem = new PolicyManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nPolicy Management System");
            System.out.println("1. Add a new policy");
            System.out.println("2. View policy details");
            System.out.println("3. Update policy information");
            System.out.println("4. Delete a policy");
            System.out.println("5. Display all policies");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter policy name: ");
                    String policyName = scanner.nextLine();
                    System.out.print("Enter policy type: ");
                    String policyType = scanner.nextLine();
                    System.out.print("Enter policy premium: ");
                    double policyPremium = scanner.nextDouble();
                    policyManagementSystem.addPolicy(policyName, policyType, policyPremium);
                    break;
                case 2:
                    System.out.print("Enter policy ID to view details: ");
                    int policyIdToView = scanner.nextInt();
                    policyManagementSystem.viewPolicyDetails(policyIdToView);
                    break;
                case 3:
                    System.out.print("Enter policy ID to update: ");
                    int policyIdToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character
                    System.out.print("Enter new policy name: ");
                    policyName = scanner.nextLine();
                    System.out.print("Enter new policy type: ");
                    policyType = scanner.nextLine();
                    System.out.print("Enter new policy premium: ");
                    policyPremium = scanner.nextDouble();
                    policyManagementSystem.updatePolicy(policyIdToUpdate, policyName, policyType, policyPremium);
                    break;
                case 4:
                    System.out.print("Enter policy ID to delete: ");
                    int policyIdToDelete = scanner.nextInt();
                    policyManagementSystem.deletePolicy(policyIdToDelete);
                    break;
                case 5:
                    policyManagementSystem.displayAllPolicies();
                    break;
                case 6:
                    System.out.println("Exiting Policy Management System. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 6.");
            }
        }
    }
}
