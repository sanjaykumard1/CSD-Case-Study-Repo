import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ClaimManagementSystem {
    private List<Claim> claims;
    private int nextClaimId;

    // Constructor
    public ClaimManagementSystem() {
        claims = new ArrayList<>();
        nextClaimId = 1; // Initial claim id starts from 1
    }

    // Method to submit a new claim
    public void submitClaim(String claimDescription, double claimAmount) {
        Claim newClaim = new Claim(nextClaimId, claimDescription, claimAmount);
        claims.add(newClaim);
        nextClaimId++;
        System.out.println("Claim submitted successfully.");
    }

    // Method to view claim details
    public void viewClaimDetails(int claimId) {
        boolean found = false;
        for (Claim claim : claims) {
            if (claim.getClaimId() == claimId) {
                System.out.println("Claim details:");
                System.out.println(claim);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Claim with ID " + claimId + " not found.");
        }
    }

    // Method to update claim information
    public void updateClaim(int claimId, String claimDescription, double claimAmount) {
        for (Claim claim : claims) {
            if (claim.getClaimId() == claimId) {
                claim.setClaimDescription(claimDescription);
                claim.setClaimAmount(claimAmount);
                System.out.println("Claim information updated successfully.");
                return;
            }
        }
        System.out.println("Claim with ID " + claimId + " not found. Update failed.");
    }

    // Method to delete a claim
    public void deleteClaim(int claimId) {
        for (Claim claim : claims) {
            if (claim.getClaimId() == claimId) {
                claims.remove(claim);
                System.out.println("Claim deleted successfully.");
                return;
            }
        }
        System.out.println("Claim with ID " + claimId + " not found. Deletion failed.");
    }

    // Method to display all claims
    public void displayAllClaims() {
        if (claims.isEmpty()) {
            System.out.println("No claims found.");
        } else {
            System.out.println("List of Claims:");
            for (Claim claim : claims) {
                System.out.println(claim);
            }
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        ClaimManagementSystem claimManagementSystem = new ClaimManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nClaim Management System");
            System.out.println("1. Submit a new claim");
            System.out.println("2. View claim details");
            System.out.println("3. Update claim information");
            System.out.println("4. Delete a claim");
            System.out.println("5. Display all claims");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter claim description: ");
                    String claimDescription = scanner.nextLine();
                    System.out.print("Enter claim amount: ");
                    double claimAmount = scanner.nextDouble();
                    claimManagementSystem.submitClaim(claimDescription, claimAmount);
                    break;
                case 2:
                    System.out.print("Enter claim ID to view details: ");
                    int claimIdToView = scanner.nextInt();
                    claimManagementSystem.viewClaimDetails(claimIdToView);
                    break;
                case 3:
                    System.out.print("Enter claim ID to update: ");
                    int claimIdToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character
                    System.out.print("Enter new claim description: ");
                    claimDescription = scanner.nextLine();
                    System.out.print("Enter new claim amount: ");
                    claimAmount = scanner.nextDouble();
                    claimManagementSystem.updateClaim(claimIdToUpdate, claimDescription, claimAmount);
                    break;
                case 4:
                    System.out.print("Enter claim ID to delete: ");
                    int claimIdToDelete = scanner.nextInt();
                    claimManagementSystem.deleteClaim(claimIdToDelete);
                    break;
                case 5:
                    claimManagementSystem.displayAllClaims();
                    break;
                case 6:
                    System.out.println("Exiting Claim Management System. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 6.");
            }
        }
    }
}
