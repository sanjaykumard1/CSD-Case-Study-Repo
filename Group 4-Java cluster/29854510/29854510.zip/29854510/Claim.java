public class Claim {
    private int claimId;
    private String claimDescription;
    private double claimAmount;
    private boolean isApproved;

    // Constructor
    public Claim(int claimId, String claimDescription, double claimAmount) {
        this.claimId = claimId;
        this.claimDescription = claimDescription;
        this.claimAmount = claimAmount;
        this.isApproved = false; // Claims start as not approved
    }

    // Getters and Setters
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public String getClaimDescription() {
        return claimDescription;
    }

    public void setClaimDescription(String claimDescription) {
        this.claimDescription = claimDescription;
    }

    public double getClaimAmount() {
        return claimAmount;
    }

    public void setClaimAmount(double claimAmount) {
        this.claimAmount = claimAmount;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void setApproved(boolean approved) {
        isApproved = approved;
    }

    // toString method for displaying claim details
    @Override
    public String toString() {
        return "Claim{" +
                "claimId=" + claimId +
                ", claimDescription='" + claimDescription + '\'' +
                ", claimAmount=" + claimAmount +
                ", isApproved=" + isApproved +
                '}';
    }
}
