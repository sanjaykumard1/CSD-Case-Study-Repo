package jdbc_connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManagement {
    private Connection connection;

    public CustomerManagement() {
        connection = DatabaseConnection.getConnection();
    }

    public void addCustomer() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            System.out.print("Enter contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter address: ");
            String address = scanner.nextLine();

            String query = "INSERT INTO Customer (name, email, contact_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, contactNumber);
            statement.setString(4, address);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new customer was inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCustomer() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();

            String query = "SELECT * FROM Customer WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                System.out.println("Address: " + resultSet.getString("address"));
            } else {
                System.out.println("Customer not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter new address: ");
            String address = scanner.nextLine();

            String query = "UPDATE Customer SET name = ?, email = ?, contact_number = ?, address = ? WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, contactNumber);
            statement.setString(4, address);
            statement.setInt(5, customerId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer information updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeCustomer() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();

            String query = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer removed successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
