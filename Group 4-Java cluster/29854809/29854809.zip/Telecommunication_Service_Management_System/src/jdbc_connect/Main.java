package jdbc_connect;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CustomerManagement customerManagement = new CustomerManagement();
        ServiceManagement serviceManagement = new ServiceManagement();
        SubscriptionManagement subscriptionManagement = new SubscriptionManagement();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Telecommunication Service Management System");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Remove Customer");
            System.out.println("5. Add Service");
            System.out.println("6. View Service");
            System.out.println("7. Update Service");
            System.out.println("8. Remove Service");
            System.out.println("9. Subscribe to Service");
            System.out.println("10. View Subscription");
            System.out.println("11. Update Subscription");
            System.out.println("12. Remove Subscription");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    customerManagement.addCustomer();
                    break;
                case 2:
                    customerManagement.viewCustomer();
                    break;
                case 3:
                    customerManagement.updateCustomer();
                    break;
                case 4:
                    customerManagement.removeCustomer();
                    break;
                case 5:
                    serviceManagement.addService();
                    break;
                case 6:
                    serviceManagement.viewService();
                    break;
                case 7:
                    serviceManagement.updateService();
                    break;
                case 8:
                    serviceManagement.removeService();
                    break;
                case 9:
                    subscriptionManagement.subscribeService();
                    break;
                case 10:
                    subscriptionManagement.viewSubscription();
                    break;
                case 11:
                    subscriptionManagement.updateSubscription();
                    break;
                case 12:
                    subscriptionManagement.removeSubscription();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }
}
