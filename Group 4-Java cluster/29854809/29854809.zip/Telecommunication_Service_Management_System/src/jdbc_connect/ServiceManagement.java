package jdbc_connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ServiceManagement {
    private Connection connection;

    public ServiceManagement() {
        connection = DatabaseConnection.getConnection();
    }

    public void addService() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter service name: ");
            String name = scanner.nextLine();
            System.out.print("Enter description: ");
            String description = scanner.nextLine();
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();

            String query = "INSERT INTO Service (name, description, price) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setDouble(3, price);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new service was inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewService() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter service ID: ");
            int serviceId = scanner.nextInt();

            String query = "SELECT * FROM Service WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, serviceId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Service ID: " + resultSet.getInt("service_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Description: " + resultSet.getString("description"));
                System.out.println("Price: " + resultSet.getDouble("price"));
            } else {
                System.out.println("Service not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateService() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter service ID: ");
            int serviceId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new service name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new description: ");
            String description = scanner.nextLine();
            System.out.print("Enter new price: ");
            double price = scanner.nextDouble();

            String query = "UPDATE Service SET name = ?, description = ?, price = ? WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setDouble(3, price);
            statement.setInt(4, serviceId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Service information updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeService() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter service ID: ");
            int serviceId = scanner.nextInt();

            String query = "DELETE FROM Service WHERE service_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, serviceId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Service removed successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
