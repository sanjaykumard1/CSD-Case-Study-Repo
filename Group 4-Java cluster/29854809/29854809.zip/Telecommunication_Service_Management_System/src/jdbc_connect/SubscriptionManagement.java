package jdbc_connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SubscriptionManagement {
    private Connection connection;

    public SubscriptionManagement() {
        connection = DatabaseConnection.getConnection();
    }

    public void subscribeService() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter service ID: ");
            int serviceId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter subscription date (YYYY-MM-DD): ");
            String subscriptionDate = scanner.nextLine();
            System.out.print("Enter status: ");
            String status = scanner.nextLine();

            String query = "INSERT INTO Subscription (customer_id, service_id, subscription_date, status) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            statement.setString(3, subscriptionDate);
            statement.setString(4, status);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new subscription was added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSubscription() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter subscription ID: ");
            int subscriptionId = scanner.nextInt();

            String query = "SELECT * FROM Subscription WHERE subscription_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, subscriptionId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Subscription ID: " + resultSet.getInt("subscription_id"));
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Service ID: " + resultSet.getInt("service_id"));
                System.out.println("Subscription Date: " + resultSet.getDate("subscription_date"));
                System.out.println("Status: " + resultSet.getString("status"));
            } else {
                System.out.println("Subscription not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSubscription() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter subscription ID: ");
            int subscriptionId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new customer ID: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter new service ID: ");
            int serviceId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new subscription date (YYYY-MM-DD): ");
            String subscriptionDate = scanner.nextLine();
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();

            String query = "UPDATE Subscription SET customer_id = ?, service_id = ?, subscription_date = ?, status = ? WHERE subscription_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            statement.setString(3, subscriptionDate);
            statement.setString(4, status);
            statement.setInt(5, subscriptionId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Subscription information updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeSubscription() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter subscription ID: ");
            int subscriptionId = scanner.nextInt();

            String query = "DELETE FROM Subscription WHERE subscription_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, subscriptionId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Subscription removed successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
