/**
 * 
 */
/**
 * 
 */
module jdbc_connect {
	requires java.sql;
}