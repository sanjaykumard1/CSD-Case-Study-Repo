import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EventManager {

    public static void manageEvent(Scanner input , Statement stmt){
        while(true) {
            System.out.println("\n\nEvent Management");
            System.out.println("\t1. crete new event");
            System.out.println("\t2. View event details");
            System.out.println("\t3. Update event information");
            System.out.println("\t4. Remove event");
            System.out.println("\t0. Go back");
            System.out.print("\tEnter your choice: ");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    addEvent(input,stmt);
                    break;
                case 2:
                    viewEvent(input,stmt);
                    break;
                case 3:
                    updateEvent(input,stmt);
                    break;
                case 4:
                    removeEvent(input,stmt);
                    break;
                case 0:
                    System.out.println("going back");
                    return;
            }
        }
    }

    private static void addEvent(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Event Details");
        System.out.print("Enter Event ID : ");
        int eventId = input.nextInt();
        System.out.print("Enter Event Name : ");
        String eventName = input.next();
        System.out.print("Enter Event Date (YYYY-MM-DD) : ");
        String eventDate = input.next();
        System.out.print("Enter Event Venue : ");
        String eventVenue = input.next();
        System.out.print("Enter Event type : ");
        String eventType = input.next();

        String query = "INSERT INTO event (event_id,name,date,venue,type) " +
                "VALUES(" + eventId + ",'" + eventName + "','" + eventDate + "','" + eventVenue + "','" + eventType + "')";

        try {
            int count = stmt.executeUpdate(query);
            if (count > 0) {
                System.out.println("\nEvent added successfully");
            } else {
                System.out.println("\nFailed");
            }
        } catch (SQLException e) {
            System.out.println("\n" + e.getMessage());
        }
    }


    private static void viewEvent(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Event ID");
        System.out.print("Enter Event ID : ");
        int eventId =input.nextInt();

        String query="SELECT * FROM event WHERE event_id="+ eventId;
        if (eventExist(eventId,stmt)){
            try {
                ResultSet data = stmt.executeQuery(query);
                while (data.next()) {
                    System.out.println("\nEvent Details ->");
                    System.out.println("Event Name : " + data.getString("name"));
                    System.out.println("Event Date : " + data.getString("date"));
                    System.out.println("Event Venue  : " + data.getString("venue"));
                    System.out.println("Event Type : " + data.getString("type"));
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }else{
            System.out.println("\nNo Event with the ID : "+ eventId);
        }
    }

    private static void updateEvent(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Event Details");
        System.out.print("Enter Event ID : ");
        int eventId = input.nextInt();
        if(eventExist(eventId,stmt)){
            System.out.print("Enter Event Name : ");
            String eventName = input.next();
            System.out.print("Enter Event date : ");
            String eventDate = input.next();
            System.out.print("Enter Event Venue : ");
            String eventVenue = input.next();
            System.out.print("Enter Event Type : ");
            String eventType = input.next();

            String query = "UPDATE event SET " +
                    "name = '"+ eventName +"'"+
                    ",type = '"+ eventType +"'"+
                    ",date = '"+eventDate+"'"+
                    ",venue = '"+ eventVenue +"'"+
                    " WHERE event_id="+eventId;

            try {
                int count = stmt.executeUpdate(query);
                if (count > 0) {
                    System.out.println("\nEvent Details Updated successfully");
                } else {
                    System.out.println("\nFailed");
                }
            } catch (SQLException e) {
                System.out.println("\n" + e.getMessage());
            }
        }else{
            System.out.println("\n No Event with Event ID : "+eventId);
        }
    }

    private static void removeEvent(Scanner input, Statement stmt){
        System.out.print("\n\nEnter the Event id : ");
        int eventId = input.nextInt();
        if (!eventExist(eventId,stmt)){
            System.out.println("\nNo Event with the ID : "+ eventId);
            return;
        }
        String query = " DELETE FROM event WHERE event_id="+ eventId;
        try{
            int rowsAffected= stmt.executeUpdate(query);
            if (rowsAffected>0){
                System.out.println("\nEvent Details Deleted");
            }else{
                System.out.println("\nEvent Deletion failed...!");
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    private static boolean eventExist(int eventId,Statement stmt){
        String query= "SELECT * from event where event_id="+eventId;
        try{
            ResultSet result=stmt.executeQuery(query);
            return result.next();
        }catch (SQLException e){
            System.out.println(e.getMessage());
            return false;
        }
    }


}

