import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ResultManager {

    public static void manageResult(Scanner input, Statement stmt){
        while(true) {
            System.out.println("\n\nResult Management");
            System.out.println("\t1. Record results for  event");
            System.out.println("\t2. View result details");
            System.out.println("\t3. Update result information");
            System.out.println("\t4. Remove result");
            System.out.println("\t0. Go back");
            System.out.print("\tEnter your choice: ");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    addResult(input,stmt);
                    break;
                case 2:
                    viewResult(input,stmt);
                    break;
                case 3:
                    updateResult(input,stmt);
                    break;
                case 4:
                    removeResult(input,stmt);
                    break;
                case 0:
                    return;
            }
        }
    }


    private static void addResult(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Result Details");
        System.out.print("Enter Result ID : ");
        int resultId = input.nextInt();
        System.out.print("Enter Event ID : ");
        int eventId = input.nextInt();
        System.out.print("Enter Athlete : ");
        int athleteId = input.nextInt();
        System.out.print("Enter Result : ");
        String result = input.next();
        System.out.print("Enter Result Date (YYYY-MM-DD) : ");
        String resultDate = input.next();

        String query = "INSERT INTO result (result_id,event_id,athlete_id,result,result_date) " +
                "VALUES(" + resultId + "," + eventId+ "," + athleteId + ",'" + result + "','" + resultDate + "')";

        try {
            int count = stmt.executeUpdate(query);
            if (count > 0) {
                System.out.println("\nResult added successfully");
            } else {
                System.out.println("\nFailed");
            }
        } catch (SQLException e) {
            System.out.println("\n" + e.getMessage());
        }
    }

    private static void viewResult(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Result ID");
        System.out.print("Enter Result ID : ");
        int resultId =input.nextInt();

        String query="SELECT * FROM result WHERE result_id="+ resultId;
        if (resultExist(resultId,stmt)){
            try {
                ResultSet data = stmt.executeQuery(query);
                while (data.next()) {
                    System.out.println("\nResult Details ->");
                    System.out.println("Result ID : " + data.getInt("result_id"));
                    System.out.println("Event ID : " + data.getInt("event_id"));
                    System.out.println("Athlete ID  : " + data.getInt("athlete_id"));
                    System.out.println("Result  : " + data.getString("result"));
                    System.out.println("Result Date : " + data.getString("result_date"));
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }else{
            System.out.println("\nNo Result with the ID : "+ resultId);
        }
    }

    private static void updateResult(Scanner input, Statement stmt){
        System.out.println("\n\nProvide Result Details");
        System.out.print("Enter Result ID : ");
        int resultId = input.nextInt();
        if(resultExist(resultId,stmt)){
            System.out.print("Enter Event ID : ");
            int eventId = input.nextInt();
            System.out.print("Enter Athlete ID : ");
            int athleteId = input.nextInt();
            System.out.print("Enter Result : ");
            String result = input.next();
            System.out.print("Enter Result Date : ");
            String resultDate = input.next();

            String query = "UPDATE result SET " +
                    "event_id = "+ eventId +
                    ",athlete_id = "+ athleteId +
                    ",result = '"+ result +"'"+
                    ",result_date = '"+ resultDate +"'"+
                    " WHERE result_id="+resultId;

            try {
                int count = stmt.executeUpdate(query);
                if (count > 0) {
                    System.out.println("\nResult Details Updated successfully");
                } else {
                    System.out.println("\nFailed");
                }
            } catch (SQLException e) {
                System.out.println("\n" + e.getMessage());
            }
        }else{
            System.out.println("\n No Result with Result ID : "+resultId);
        }
    }

    private static void removeResult(Scanner input, Statement stmt){
        System.out.print("\n\nEnter the Result id : ");
        int resultId = input.nextInt();
        if (!resultExist(resultId,stmt)){
            System.out.println("\nNo Result with the ID : "+ resultId);
            return;
        }
        String query = " DELETE FROM result WHERE result_id="+ resultId;
        try{
            int rowsAffected= stmt.executeUpdate(query);
            if (rowsAffected>0){
                System.out.println("\nResult Details Deleted");
            }else{
                System.out.println("\nResult Deletion failed...!");
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    private static boolean resultExist(int resultId, Statement stmt){
        String query= "SELECT * from result where result_id="+resultId;
        try{
            ResultSet result=stmt.executeQuery(query);
            return result.next();
        }catch (SQLException e){
            System.out.println(e.getMessage());
            return false;
        }
    }









}
