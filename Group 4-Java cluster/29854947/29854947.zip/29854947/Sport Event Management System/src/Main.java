import java.sql.*;
import java.util.Scanner;

public class Main {

    private static final String url="jdbc:mysql://localhost:3306/sport_event_management";
    private static final String username="USERNAME";
    private static final String password="PASSWORD";


    public static void main(String[] args) throws ClassNotFoundException{
        Scanner input = new Scanner(System.in);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection=DriverManager.getConnection(url,username,password);
            Statement stmt= connection.createStatement();
            while (true) {
                System.out.println("\nSport Event Management System");
                System.out.println("1. Athlete Management");
                System.out.println("2. Event Management");
                System.out.println("3. Result Management");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                int choice = input.nextInt();


                switch (choice) {
                    case 1:
                        AthleteManager.manageAthlete(input,stmt);
                        break;
                    case 2:
                        EventManager.manageEvent(input,stmt);
                        break;
                    case 3:
                        ResultManager.manageResult(input,stmt);
                        break;
                    case 0:
                        try {
                            input.close();
                            stmt.close();
                            connection.close();
                            exit();
                        } catch (InterruptedException e) {
                            System.out.println(e.getMessage());
                        }
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        }catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void  exit() throws InterruptedException {
        System.out.print("exiting system");
        int i=5;
        while (i!=0){
            System.out.print(".");
            Thread.sleep(500);
            i--;
        }
        System.out.println();
        System.out.println("Thank you for using Sport Event Management system");
    }
}
