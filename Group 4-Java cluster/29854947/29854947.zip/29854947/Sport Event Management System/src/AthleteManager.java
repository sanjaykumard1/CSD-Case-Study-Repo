import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class AthleteManager {

    public static void manageAthlete(Scanner input, Statement stmt) {
        while (true) {
            System.out.println("\n\nAthlete Management");
            System.out.println("\t1. Add new athlete");
            System.out.println("\t2. View athlete detail");
            System.out.println("\t3. Update athlete information");
            System.out.println("\t4. Remove athlete");
            System.out.println("\t0. Go back");
            System.out.print("\tEnter your choice: ");
            int choice = input.nextInt();

            switch (choice) {
                case 1:
                    addAthlete(input, stmt);
                    break;
                case 2:
                    viewAthlete(input, stmt);
                    break;
                case 3:
                    updateAthlete(input,stmt);
                    break;
                case 4:
                    removeAthlete(input,stmt);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");

            }
        }
    }

    private static void addAthlete(Scanner input, Statement stmt) {
        System.out.println("\n\nProvide Athlete Details");
        System.out.print("Enter Athlete ID : ");
        int athleteId = input.nextInt();
        System.out.print("Enter Athlete Name : ");
        String athleteName = input.next();
        System.out.print("Enter Athlete Country : ");
        String athleteCountry = input.next();
        input.nextLine();
        System.out.print("Enter Athlete Age : ");
        int athleteAge = input.nextInt();
        System.out.print("Enter Athlete Sport : ");
        String athleteSport = input.next();

        String query = "INSERT INTO athlete (athlete_id,name,country,age,sport) " +
                "VALUES(" + athleteId + ",'" + athleteName + "','" + athleteCountry + "'," + athleteAge + ",'" + athleteSport + "')";

        try {
            int count = stmt.executeUpdate(query);
            if (count > 0) {
                System.out.println("\nAthlete added successfully");
            } else {
                System.out.println("\nFailed");
            }
        } catch (SQLException e) {
            System.out.println("\n" + e.getMessage());
        }
    }

    private static void viewAthlete(Scanner input, Statement stmt) {
        System.out.println("\n\nProvide Athlete ID");
        System.out.print("Enter Athlete ID : ");
        int athleteId=input.nextInt();

        String query="SELECT * FROM athlete WHERE athlete_id="+athleteId;
        if (athleteExist(athleteId,stmt)){
            try {
                ResultSet data = stmt.executeQuery(query);
                while (data.next()) {
                    System.out.println("\nAthlete Details ->");
                    System.out.println("Athlete Name : " + data.getString("name"));
                    System.out.println("Athlete Age : " + data.getInt("age"));
                    System.out.println("Athlete Sport  : " + data.getString("sport"));
                    System.out.println("Athlete Country : " + data.getString("country"));
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
        }else{
            System.out.println("\nNo Athlete with the ID : "+athleteId);
        }
    }

    private static void updateAthlete(Scanner input, Statement stmt) {
        System.out.println("\n\nProvide Athlete Details");
        System.out.print("Enter Athlete ID : ");
        int athleteId = input.nextInt();
        if(athleteExist(athleteId,stmt)){
            System.out.print("Enter Athlete Name : ");
            String athleteName = input.next();
            System.out.print("Enter Athlete Country : ");
            String athleteCountry = input.next();
            input.nextLine();
            System.out.print("Enter Athlete Age : ");
            int athleteAge = input.nextInt();
            System.out.print("Enter Athlete Sport : ");
            String athleteSport = input.next();

            String query = "UPDATE athlete SET " +
                    "name = '"+athleteName+"'"+
                    ",sport = '"+athleteSport+"'"+
                    ",country = '"+athleteCountry+"'"+
                    ",age = "+athleteAge+
                    " WHERE athlete_id="+athleteId;

            try {
                int count = stmt.executeUpdate(query);
                if (count > 0) {
                    System.out.println("\nAthlete Details Updated successfully");
                } else {
                    System.out.println("\nFailed");
                }
            } catch (SQLException e) {
                System.out.println("\n" + e.getMessage());
            }
        }else{
            System.out.println("\n No athlete with Athlete ID : "+athleteId);
        }
    }

    private static void removeAthlete(Scanner input, Statement stmt){
        System.out.print("\n\nEnter the Athlete id : ");
        int athleteId = input.nextInt();
        if (!athleteExist(athleteId,stmt)){
            System.out.println("\nNo Athlete with the ID : "+athleteId);
            return;
        }
        String query = " DELETE FROM athlete WHERE athlete_id="+athleteId;
        try{
            int rowsAffected= stmt.executeUpdate(query);
            if (rowsAffected>0){
                System.out.println("\nAthlete Details Deleted");
            }else{
                System.out.println("\nAthlete Deletion failed...!");
            }
        }catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    private static boolean athleteExist(int athleteId,Statement stmt){
        String query= "SELECT * from athlete where athlete_id="+athleteId;
        try{
            ResultSet result=stmt.executeQuery(query);
            return result.next();
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }

}
