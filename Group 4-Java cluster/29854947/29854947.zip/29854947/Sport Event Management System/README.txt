Sport Event Management System

This is a console-based Sport Event Management System developed in Java. 
The application connects to a MySQL database using JDBC and provides functionalities to add, remove, update, and view records 
in the athlete, event, and result tables. 
These tables are connected to each other through relationships.

Features
	Add, remove, update, and view records in the athlete table.
	Add, remove, update, and view records in the event table.
	Add, remove, update, and view records in the result table.
	Maintain relationships between tables.

Setup and Usage Instructions 

	Prerequisites
		Java Development Kit (JDK) 8 or higher
		MySQL Server
		MySQL Connector/J (JDBC driver for MySQL)

	Database Setup
		
		1. Install MySQL Server:
			Download and install MySQL Server from MySQL Downloads.
		
		2. Create the Database and Tables:
			Open MySQL Workbench or your preferred MySQL client.
			Execute the following SQL script to create the database and tables:
				CREATE DATABASE sport_event_management;
				USE sport_event_management;
				CREATE TABLE Athlete (
				    athlete_id INT PRIMARY KEY,
				    name VARCHAR(100),
				    country VARCHAR(100),
				    age INT,
				    sport VARCHAR(100)
				);
				CREATE TABLE Event (
				    event_id INT PRIMARY KEY,
				    name VARCHAR(100),
				    date DATE,
				    venue VARCHAR(100),
				    type VARCHAR(50)
				);
				CREATE TABLE Result (
				    result_id INT PRIMARY KEY,
				    event_id INT,
				    athlete_id INT,
				    result VARCHAR(100),
				    result_date DATE,
				    FOREIGN KEY (event_id) REFERENCES Event(event_id),
				    FOREIGN KEY (athlete_id) REFERENCES Athlete(athlete_id)
				);

	Application Setup
		Import the Project:
			Open your preferred Java IDE (e.g., IntelliJ IDEA, Eclipse).
			Open the Project Folder in IDE.

	Add MySQL Connector/J:
		Download the MySQL Connector/J from MySQL Connector/J.
		Add the connector JAR file to your project's classpath.

	Configure Database Connection:
		Open the Main.java file.
		Update the database connection details (URL, username, password):

	Running the Application
		Compile and Run the Main.java file.

	Using the Application:
        Follow the on-screen instructions to
        add, remove, update, and view records in the athlete, event, and result tables.