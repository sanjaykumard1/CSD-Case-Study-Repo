//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Patient patientManagement = new Patient();
        Doctor doctorManagement = new Doctor();
        Appointment appointmentManagement = new Appointment();

        while (true) {
            System.out.println("Healthcare Management System");
            System.out.println("1. Patient Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Appointment Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Patient.managePatients(scanner);
                    break;
                case 2:
                    Doctor.manageDoctors(scanner);
                    break;
                case 3:
                    Appointment.manageAppointments(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}