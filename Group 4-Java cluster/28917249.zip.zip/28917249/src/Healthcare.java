import java.util.Scanner;

public class Healthcare {

    private static final Scanner scanner = new Scanner(System.in);
    private static final PatientDAO patientDAO = new PatientDAO();
    private static final DoctorDAO doctorDAO = new DoctorDAO();
    private static final AppointmentDAO appointmentDAO = new AppointmentDAO();

    public static void main(String[] args) {
        while (true) {
            displayMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    patientManagement();
                    break;
                case 2:
                    doctorManagement();
                    break;
                case 3:
                    appointmentManagement();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice! Please enter a number between 1 and 4.");
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("\n===== Healthcare Management System =====");
        System.out.println("1. Patient Management");
        System.out.println("2. Doctor Management");
        System.out.println("3. Appointment Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void patientManagement() {
        while (true) {
            displayPatientMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Register a new patient
                    break;
                case 2:
                    // View patient details
                    break;
                case 3:
                    // Update patient information
                    break;
                case 4:
                    // Delete a patient
                    break;
                case 5:
                    return; // Back to main menu
                default:
                    System.out.println("Invalid choice! Please enter a number between 1 and 5.");
            }
        }
    }

    private static void displayPatientMenu() {
        System.out.println("\n===== Patient Management =====");
        System.out.println("1. Register a new patient");
        System.out.println("2. View patient details");
        System.out.println("3. Update patient information");
        System.out.println("4. Delete a patient");
        System.out.println("5. Back to main menu");
        System.out.print("Enter your choice: ");
    }

    private static void doctorManagement() {
        while (true) {
            displayDoctorMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Add a new doctor
                    break;
                case 2:
                    // View doctor details
                    break;
                case 3:
                    // Update doctor information
                    break;
                case 4:
                    // Delete a doctor
                    break;
                case 5:
                    return; // Back to main menu
                default:
                    System.out.println("Invalid choice! Please enter a number between 1 and 5.");
            }
        }
    }

    private static void displayDoctorMenu() {
        System.out.println("\n===== Doctor Management =====");
        System.out.println("1. Add a new doctor");
        System.out.println("2. View doctor details");
        System.out.println("3. Update doctor information");
        System.out.println("4. Delete a doctor");
        System.out.println("5. Back to main menu");
        System.out.print("Enter your choice: ");
    }

    private static void appointmentManagement() {
        while (true) {
            displayAppointmentMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Schedule a new appointment
                    break;
                case 2:
                    // View appointment details
                    break;
                case 3:
                    // Update appointment information
                    break;
                case
