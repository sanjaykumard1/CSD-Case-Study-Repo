package com.service;

import java.sql.SQLException;
import java.time.LocalDate;

import com.dao.RegistrationDao;
import com.dao.RegistrationDaoImpl;
import com.exception.InvalidEventException;
import com.exception.InvalidRegistrationException;
import com.model.Registration;

public class RegistrationService {

	RegistrationDao registrationDao=new RegistrationDaoImpl();
	public void addRegistration(LocalDate registrationDate, String status, int eventId, int participantId) throws SQLException {
		registrationDao.addRegistration(registrationDate,status,eventId,participantId);
	}
	public Registration fetchRegistrationDetails(int regId) throws SQLException, InvalidRegistrationException {
		return registrationDao.fetchRegistrationDetails(regId);
	}
	public boolean cancelRegistration(int regId) throws SQLException, InvalidEventException {
		return registrationDao.cancelRegistration(regId);
	}

}
