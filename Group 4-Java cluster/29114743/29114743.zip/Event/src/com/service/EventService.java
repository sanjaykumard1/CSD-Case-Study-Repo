package com.service;

import java.sql.SQLException;
import java.time.LocalDate;

import com.dao.EventDao;
import com.dao.EventDaoImpl;
import com.exception.InvalidEventException;
import com.model.Event;

public class EventService {

	EventDao eventDao=new EventDaoImpl();
	public void AddEvent(String eventName, LocalDate eventDate, String eventLocation, String eventDescription,
			int eventCapacity) throws SQLException {
		eventDao.AddEvent(eventName,eventDate,eventLocation,eventDescription,eventCapacity);
	}
	public Event fetchEventDetails(int eventId) throws SQLException, InvalidEventException {
		return eventDao.fetchEventDetails(eventId);
	}
	public boolean updateEvent(int id, String name) throws SQLException {
		return eventDao.updateEvent(id,name);
	}
	public boolean deleteEvent(int id) throws SQLException, InvalidEventException {
		return eventDao.deleteEvent(id);
	}


}
