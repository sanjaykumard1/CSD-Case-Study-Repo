package com.service;

import java.sql.SQLException;

import com.dao.ParticipantDao;
import com.dao.ParticipantDaoImpl;
import com.exception.InvalidParticipantException;
import com.model.Participant;

public class ParticipantService {

	ParticipantDao participantDao=new ParticipantDaoImpl();
	
	public void addParticipant(String participantName, String participantEmail, String participantPhoneNumber) throws SQLException {
		participantDao.addParticipant(participantName,participantEmail,participantPhoneNumber);
	}

	public Participant fetchParticipantDetails(int participantId) throws SQLException, InvalidParticipantException {
		return participantDao.fetchParticipantDetails(participantId);
	}

	public void deleteParticipant(int participantId) throws SQLException, InvalidParticipantException {
		participantDao.deleteParticipant(participantId);
	}

	public boolean updateParticipant(int id, String email) throws SQLException {
		return participantDao.updateParticipant(id,email);
	}

	
	
	
	
	
}
