package com.model;

public class Participant {
	private int participantId;
	private String participantName;
	private String participantEmail;
	private String participantPhoneNumber;
	
	public Participant(int participantId, String participantName, String participantEmail,
			String participantPhoneNumber) {
		super();
		this.participantId = participantId;
		this.participantName = participantName;
		this.participantEmail = participantEmail;
		this.participantPhoneNumber = participantPhoneNumber;
	}
	
	
	public Participant(String participantName, String participantEmail, String participantPhoneNumber) {
		super();
		this.participantName = participantName;
		this.participantEmail = participantEmail;
		this.participantPhoneNumber = participantPhoneNumber;
	}


	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public String getParticipantName() {
		return participantName;
	}
	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}
	public String getParticipantEmail() {
		return participantEmail;
	}
	public void setParticipantEmail(String participantEmail) {
		this.participantEmail = participantEmail;
	}
	public String getParticipantPhoneNumber() {
		return participantPhoneNumber;
	}
	public void setParticipantPhoneNumber(String participantPhoneNumber) {
		this.participantPhoneNumber = participantPhoneNumber;
	}


	@Override
	public String toString() {
		return "Participant [participantId=" + participantId + ", participantName=" + participantName
				+ ", participantEmail=" + participantEmail + ", participantPhoneNumber=" + participantPhoneNumber + "]";
	}
}
