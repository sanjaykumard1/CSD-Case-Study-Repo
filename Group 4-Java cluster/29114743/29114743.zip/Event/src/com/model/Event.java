package com.model;

import java.time.LocalDate;

public class Event {
	private int eventId;
	private String eventName;
	private LocalDate eventDate;
	private String eventLocation;
	private String eventDescription;
	private int capacity;
	public Event(int eventId, String eventName, LocalDate eventDate, String eventLocation, String eventDescription,
			int capacity) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventLocation = eventLocation;
		this.eventDescription = eventDescription;
		this.capacity = capacity;
	}
	public Event(String eventName, LocalDate eventDate, String eventLocation, String eventDescription, int capacity) {
		super();
		this.eventName = eventName;
		this.eventDate = eventDate;
		this.eventLocation = eventLocation;
		this.eventDescription = eventDescription;
		this.capacity = capacity;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public LocalDate getEventDate() {
		return eventDate;
	}
	public void setEventDate(LocalDate eventDate) {
		this.eventDate = eventDate;
	}
	public String getEventLocation() {
		return eventLocation;
	}
	public void setEventLocation(String eventLocation) {
		this.eventLocation = eventLocation;
	}
	public String getEventDescription() {
		return eventDescription;
	}
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	@Override
	public String toString() {
		return "Event [eventName=" + eventName + ", eventDate=" + eventDate + ", eventLocation=" + eventLocation
				+ ", eventDescription=" + eventDescription + ", capacity=" + capacity + "]";
	}
}
