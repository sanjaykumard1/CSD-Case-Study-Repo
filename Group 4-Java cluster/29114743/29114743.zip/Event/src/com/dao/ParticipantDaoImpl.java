package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.exception.InvalidParticipantException;
import com.model.Participant;
import com.util.DbUtil;

public class ParticipantDaoImpl implements ParticipantDao{

	@Override
	public void addParticipant(String participantName, String participantEmail, String participantPhoneNumber) throws SQLException {
		Connection conn=DbUtil.getDBConn();
		String sql="insert into participant(name, email,phone_number)values(?,?,?)";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		
		pstmt.setString(1,participantName);
		pstmt.setString(2,participantEmail);
		pstmt.setString(3,participantPhoneNumber);
		pstmt.executeUpdate();
		DbUtil.dbClose();
	}

	@Override
	public Participant fetchParticipantDetails(int participantId) throws SQLException, InvalidParticipantException {
		Connection conn = DbUtil.getDBConn();
		String sql="select * from participant where participant_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		
		pstmt.setInt(1, participantId);
		
		ResultSet rst=pstmt.executeQuery();
		
		if(rst.next())
		{
			String name=rst.getString("name");
			String email=rst.getString("email");
			String phoneNo=rst.getString("phone_number");
			Participant p=new Participant(participantId,name,email,phoneNo);
			return p;
		}
		DbUtil.dbClose();
		throw new InvalidParticipantException("Invalid Participant Id");
	}

	@Override
	public void deleteParticipant(int participantId) throws SQLException, InvalidParticipantException {
		Connection conn=DbUtil.getDBConn();
		String sql="delete from participant where participant_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, participantId);
		int res=pstmt.executeUpdate();
		if(res==0)
		{
			throw new InvalidParticipantException("Invalid participant Id");
		}
	}

	@Override
	public boolean updateParticipant(int id, String email) throws SQLException {
		Connection conn=DbUtil.getDBConn();
		String sql="update participant set email=? where participant_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		
		pstmt.setString(1, email);
		pstmt.setInt(2, id);
		
		int res=pstmt.executeUpdate();
		DbUtil.dbClose();
		if(res==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	
	
	
}
