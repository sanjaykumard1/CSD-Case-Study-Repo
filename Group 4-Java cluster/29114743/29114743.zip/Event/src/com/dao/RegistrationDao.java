package com.dao;

import java.sql.SQLException;
import java.time.LocalDate;

import com.exception.InvalidEventException;
import com.exception.InvalidRegistrationException;
import com.model.Registration;

public interface RegistrationDao {

	void addRegistration(LocalDate registrationDate, String status, int eventId, int participantId) throws SQLException;

	Registration fetchRegistrationDetails(int regId) throws SQLException, InvalidRegistrationException;

	boolean cancelRegistration(int regId) throws SQLException, InvalidEventException;

}
