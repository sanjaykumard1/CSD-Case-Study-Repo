package com.dao;

import java.sql.SQLException;
import java.time.LocalDate;

import com.exception.InvalidEventException;
import com.model.Event;

public interface EventDao {

	void AddEvent(String eventName, LocalDate eventDate, String eventLocation, String eventDescription,
			int eventCapacity) throws SQLException;

	Event fetchEventDetails(int eventId) throws SQLException, InvalidEventException;

	boolean updateEvent(int id, String name) throws SQLException;

	boolean deleteEvent(int id) throws SQLException, InvalidEventException;
	
}
