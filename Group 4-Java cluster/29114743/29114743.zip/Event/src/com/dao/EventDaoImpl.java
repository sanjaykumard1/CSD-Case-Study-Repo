package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.exception.InvalidEventException;
import com.model.Event;
import com.util.DbUtil;

public class EventDaoImpl implements EventDao{

	@Override
	public void AddEvent(String eventName, LocalDate eventDate, String eventLocation, String eventDescription,int eventCapacity) throws SQLException {
		Connection conn=DbUtil.getDBConn();
		String sql="insert into event(name, date,location,description,capacity) values(?,?,?,?,?)";
		
		PreparedStatement pstmt=conn.prepareStatement(sql);
		
		pstmt.setString(1,eventName);
		pstmt.setObject(2,eventDate);
		pstmt.setString(3,eventLocation);
		pstmt.setString(4,eventDescription);
		pstmt.setInt(5, eventCapacity);
		
		pstmt.executeUpdate();
		
		DbUtil.dbClose();
	}

	@Override
	public Event fetchEventDetails(int eventId) throws SQLException, InvalidEventException {
		Connection conn=DbUtil.getDBConn();
		String sql="select * from event where event_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, eventId);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			String eventName=rst.getString("name");
			LocalDate eventDate=rst.getDate("date").toLocalDate();
			String eventLocation=rst.getString("location");
			String eventDescription=rst.getString("description");
			int eventCapacity=rst.getInt("capacity");
			Event event=new Event(eventName,eventDate,eventLocation,eventDescription,eventCapacity);
			return event;
		}
		DbUtil.dbClose();
		throw new InvalidEventException("Invalid Event ID");
	}

	@Override
	public boolean updateEvent(int id, String name) throws SQLException {
		Connection conn=DbUtil.getDBConn();
		String sql="update event set name=? where event_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		
		pstmt.setString(1, name);
		pstmt.setInt(2, id);
		
		int res=pstmt.executeUpdate();
		DbUtil.dbClose();
		if(res==0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean deleteEvent(int id) throws SQLException, InvalidEventException {
		Connection conn=DbUtil.getDBConn();
		String sql="delete from event where event_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, id);
		int res=pstmt.executeUpdate();
		if(res==1)
		{
			return true;
		}else {
			throw new InvalidEventException("Invalid Event Id");
		}
		
	}
	
	

}
