package com.dao;

import java.sql.SQLException;

import com.exception.InvalidParticipantException;
import com.model.Participant;

public interface ParticipantDao {

	void addParticipant(String participantName, String participantEmail, String participantPhoneNumber) throws SQLException;

	Participant fetchParticipantDetails(int participantId) throws SQLException, InvalidParticipantException;

	void deleteParticipant(int participantId) throws SQLException, InvalidParticipantException;

	boolean updateParticipant(int id, String email) throws SQLException;

}
