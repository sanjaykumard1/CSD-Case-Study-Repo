package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.exception.InvalidEventException;
import com.exception.InvalidRegistrationException;
import com.model.Registration;
import com.util.DbUtil;

public class RegistrationDaoImpl implements RegistrationDao{

	@Override
	public void addRegistration(LocalDate registrationDate, String status, int eventId, int participantId) throws SQLException {
		Connection conn=DbUtil.getDBConn();
		String sql="insert into registration(event_id, participant_id,registration_date,status)values(?,?,?,?);";
		
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, eventId);
		pstmt.setInt(2, participantId);
		pstmt.setObject(3,registrationDate);
		pstmt.setString(4,status);
		pstmt.executeUpdate();
		
		DbUtil.dbClose();
	}

	@Override
	public Registration fetchRegistrationDetails(int regId) throws SQLException, InvalidRegistrationException {
		Connection conn=DbUtil.getDBConn();
		String sql="select * from registration where registration_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, regId);
		ResultSet rst=pstmt.executeQuery();
		if(rst.next())
		{
			LocalDate eventDate=rst.getDate("registration_date").toLocalDate();
			String status=rst.getString("status");
			int eventId=rst.getInt("event_id");
			int participantId=rst.getInt("participant_id");
			Registration reg=new Registration(eventId,participantId,eventDate,status);
			return reg;
		}
		DbUtil.dbClose();
		throw new InvalidRegistrationException("Invalid Event ID");
	}

	@Override
	public boolean cancelRegistration(int regId) throws SQLException, InvalidEventException {
		Connection conn=DbUtil.getDBConn();
		String sql="update registration set status='cancelled' where registration_id=?";
		PreparedStatement pstmt=conn.prepareStatement(sql);
		pstmt.setInt(1, regId);
		int res=pstmt.executeUpdate();
		if(res==1)
		{
			return true;
		}else {
			throw new InvalidEventException("Invalid Registration Id");
		}
	}

	
	
}
