package com.controller;

import java.sql.SQLException;
import java.util.Scanner;
import com.exception.InvalidParticipantException;
import com.model.Participant;
import com.service.ParticipantService;

public class ParticipantController {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		ParticipantService ps=new ParticipantService();
		
		while(true)
		{
			System.out.println("Press 1. Add a new participant");
			System.out.println("Press 2. View participant details");
			System.out.println("Press 3. Update participant Information");
			System.out.println("Press 4. Delete participant");
			System.out.println("Press 0. Exit");
			System.out.println();
			System.out.println("Enter your choice");
			int input=s.nextInt();
			if(input==0)
			{
				System.out.println("Exiting,Thank you");
				break;
			}
			switch(input)
			{	
			case 1:
				System.out.println("Enter participant name");
				String participantName=s.next();
				System.out.println("Enter participant email");
				String participantEmail=s.next();
				System.out.println("Enter participant phone number");
				String participantPhoneNumber=s.next();
				
				try {
					ps.addParticipant(participantName,participantEmail,participantPhoneNumber);
					System.out.println("Participant Added Successfully");
				} catch (SQLException e) {
					System.out.println("Paricipant cannot be added");
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter the participant Id");
				try {
					int participantId=s.nextInt();
					Participant participant=ps.fetchParticipantDetails(participantId);
					System.out.println(participant.toString());
				} catch (SQLException | InvalidParticipantException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("Enter the participant Id to be updated");
				int id=s.nextInt();
				System.out.println("Enter the new participant email");
				String email=s.next();
				try {
					boolean res=ps.updateParticipant(id,email);
					if(res)
					{
						System.out.println("Participant Updated Successfully");
					}
					else
					{
						System.out.println("Participant cannot be updated");
					}
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter the participant id to delete");
				int participantId=s.nextInt();
				try {
					ps.deleteParticipant(participantId);
					System.out.println("Participant deleted successfully");
				} catch (SQLException | InvalidParticipantException e) {
					System.out.println(e.getMessage());
				}
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
		}	
		s.close();
		
	}

}
