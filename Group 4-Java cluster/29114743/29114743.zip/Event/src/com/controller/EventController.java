package com.controller;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.service.EventService;
import com.exception.InvalidEventException;
import com.model.*;
public class EventController {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);	
		EventService es=new EventService();
		
		while(true)
		{
			System.out.println("Press 1. Add a new event");
			System.out.println("Press 2. View event details");
			System.out.println("Press 3. Update event Information");
			System.out.println("Press 4. Delete an event");
			System.out.println("Press 0. Exit");
			System.out.println();
			System.out.println("Enter your choice");
			int input=s.nextInt();
			if(input==0)
			{
				System.out.println("Exiting,Thank you");
				break;
			}
			
			switch(input)
			{
			case 1:
				System.out.println("Enter the name of the event");
				String eventName=s.next();
				System.out.println("Enter the date of the event");
				String date=s.next();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate eventDate=LocalDate.parse(date, formatter);
				System.out.println("Enter the location of the event");
				String eventLocation=s.next();
				System.out.println("Enter the description of the event");
				String eventDescription=s.next();
				System.out.println("Enter the capacity of the event");
				int eventCapacity=s.nextInt();
				try {
					es.AddEvent(eventName,eventDate,eventLocation,eventDescription,eventCapacity);
					System.out.println("Event Added Successfully");
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter the event Id");
				try {
					int eventId=s.nextInt();
					Event event=es.fetchEventDetails(eventId);
					System.out.println(event.toString());
				} catch (SQLException | InvalidEventException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("Enter the event Id to be updated");
				int id=s.nextInt();
				System.out.println("Enter the new event name");
				String name=s.next();
				try {
					boolean res=es.updateEvent(id,name);
					if(res)
					{
						System.out.println("Event Updated Successfully");
					}
					else
					{
						System.out.println("Event cannot be updated");
					}
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter the event Id to be deleted");
				
				try {
					int eid=s.nextInt();
					boolean res=es.deleteEvent(eid);
					if(res)
					{
						System.out.println("Event Deleted Successfully");
					}
				} catch (SQLException | InvalidEventException e) {
					System.out.println("Event cannot be deleted");
					System.out.println(e.getMessage());
				}
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
		}
		s.close();
		
	}

}
