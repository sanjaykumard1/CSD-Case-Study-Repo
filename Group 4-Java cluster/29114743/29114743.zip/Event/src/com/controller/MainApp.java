package com.controller;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		
		System.out.println("Press 1. Event Management");
		System.out.println("Press 2. Participant Management");
		System.out.println("Press 3. Registration Management");
		
		int input=s.nextInt();
		
		switch(input)
		{
		case 1:
			EventController.main(args);
			break;
		case 2:
			ParticipantController.main(args);
			break;
		case 3:
			RegistrationController.main(args);
			break;
		default:
			System.out.println("Invalid Input");
			break;	
		}
		s.close();
	}
}
