package com.controller;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.exception.InvalidEventException;
import com.exception.InvalidRegistrationException;
import com.model.Registration;
import com.service.RegistrationService;
public class RegistrationController {
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		RegistrationService rs=new RegistrationService();
		while(true)
		{
			System.out.println("Press 1. Add a new registration");
			System.out.println("Press 2. View registration details");
			System.out.println("Press 3. Update registration Information");
			System.out.println("Press 4. Cancel a registration");
			System.out.println("Press 0. Exit");
			System.out.println();
			System.out.println("Enter your choice");
			int input=s.nextInt();
			if(input==0)
			{
				System.out.println("Exiting,Thank you");
				break;
			}
			switch(input)
			{	
			case 1:
				System.out.println("Enter registration date");
				String date=s.next();
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate registrationDate=LocalDate.parse(date, formatter);
				System.out.println("Enter the status");
				String status=s.next();
				System.out.println("Enter the event Id");
				int eventId=s.nextInt();
				System.out.println("Enter the participant Id");
				int participantId=s.nextInt();
				try {
					rs.addRegistration(registrationDate,status,eventId,participantId);
					System.out.println("Registration Successfull");
				} catch (SQLException e) {
					System.out.println("Registration Failed");
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter the event Id");
				try {
					int regId=s.nextInt();
					Registration reg=rs.fetchRegistrationDetails(regId);
					System.out.println(reg.toString());
					
				} catch (SQLException | InvalidRegistrationException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				System.out.println("Enter registration Id to cancel");
				int regId=s.nextInt();
				try {
					rs.cancelRegistration(regId);
					System.out.println("Registration Cancelled");
				} catch (SQLException | InvalidEventException e) {
					System.out.println(e.getMessage());
				}
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
		}	
		s.close();
	}
}
