package com.carrental.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import com.carrental.model.Car;
import com.carrental.model.Rental;

public class RentalDAO {
    public void addRental(Rental rental) {
        String sql = "INSERT INTO Rental (car_id, customer_name, customer_phone, rental_date, return_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, rental.getCarId());
            stmt.setString(2, rental.getCustomerName());
            stmt.setString(3, rental.getCustomerPhone());
            stmt.setDate(4, new java.sql.Date(rental.getRentalDate().getTime()));
            stmt.setDate(5, rental.getReturnDate() != null ? new java.sql.Date(rental.getReturnDate().getTime()) : null);
            stmt.executeUpdate();

            // Update car availability
            String updateCarSql = "UPDATE Car SET available_for_rent = ? WHERE car_id = ?";
            try (PreparedStatement updateStmt = conn.prepareStatement(updateCarSql)) {
                updateStmt.setBoolean(1, false);
                updateStmt.setInt(2, rental.getCarId());
                updateStmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Rental> getAllRentals() {
        List<Rental> rentals = new ArrayList<>();
        String sql = "SELECT * FROM Rental";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Rental rental = new Rental();
                rental.setRentalId(rs.getInt("rental_id"));
                rental.setCarId(rs.getInt("car_id"));
                rental.setCustomerName(rs.getString("customer_name"));
                rental.setCustomerPhone(rs.getString("customer_phone"));
                rental.setRentalDate(rs.getDate("rental_date"));
                rental.setReturnDate(rs.getDate("return_date"));
                rentals.add(rental);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }

    public void returnCar(int rentalId) {
        String sql = "UPDATE Rental SET return_date = ? WHERE rental_id = ?";
        try (Connection conn = DatabaseUtil.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(new java.util.Date().getTime()));
            stmt.setInt(2, rentalId);
            stmt.executeUpdate();

            // Update car availability
            String getCarSql = "SELECT car_id FROM Rental WHERE rental_id = ?";
            try (PreparedStatement getCarStmt = conn.prepareStatement(getCarSql)) {
                getCarStmt.setInt(1, rentalId);
                ResultSet rs = getCarStmt.executeQuery();
                if (rs.next()) {
                    int carId = rs.getInt("car_id");
                    String updateCarSql = "UPDATE Car SET available_for_rent = ? WHERE car_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateCarSql)) {
                        updateStmt.setBoolean(1, true);
                        updateStmt.setInt(2, carId);
                        updateStmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Rental> getActiveRentals() {
        List<Rental> rentals = new ArrayList<>();
        String sql = "SELECT * FROM Rental WHERE return_date IS NULL";
        try (Connection conn = DatabaseUtil.getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Rental rental = new Rental();
                rental.setRentalId(rs.getInt("rental_id"));
                rental.setCarId(rs.getInt("car_id"));
                rental.setCustomerName(rs.getString("customer_name"));
                rental.setCustomerPhone(rs.getString("customer_phone"));
                rental.setRentalDate(rs.getDate("rental_date"));
                rentals.add(rental);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }
}