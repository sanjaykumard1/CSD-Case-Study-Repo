package com.carrental;

import com.carrental.dao.CarDAO;
import com.carrental.dao.RentalDAO;
import com.carrental.model.Car;
import com.carrental.model.Rental;
import java.util.List;
import java.util.Scanner;
import java.sql.*;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final CarDAO carDAO = new CarDAO();
    private static final RentalDAO rentalDAO = new RentalDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Car Rental System");
            System.out.println("1. Add Car");
            System.out.println("2. View Car");
            System.out.println("3. Update Car");
            System.out.println("4. Delete Car");
            System.out.println("5. View Available Cars");
            System.out.println("6. View Rented Cars");
            System.out.println("7. Rent Car");
            System.out.println("8. Return Car");
            System.out.println("9. Exit");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (option) {
                case 1 -> addCar();
                case 2 -> viewCar();
                case 3 -> updateCar();
                case 4 -> deleteCar();
                case 5 -> viewAvailableCars();
                case 6 -> viewRentedCars();
                case 7 -> rentCar();
                case 8 -> returnCar();
                case 9 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid option, please try again.");
            }
        }
    }

    private static void addCar() {
        System.out.print("Enter make: ");
        String make = scanner.nextLine();
        System.out.print("Enter model: ");
        String model = scanner.nextLine();
        System.out.print("Enter year: ");
        int year = scanner.nextInt();
        System.out.print("Enter price per day: ");
        double pricePerDay = scanner.nextDouble();
        scanner.nextLine();  // Consume newline

        Car car = new Car();
        car.setMake(make);
        car.setModel(model);
        car.setYear(year);
        car.setPricePerDay(pricePerDay);
        car.setAvailableForRent(true);

        carDAO.addCar(car);
        System.out.println("Car added successfully.");
    }

    private static void viewCar() {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Car car = carDAO.getCar(carId);
        if (car != null) {
            System.out.println("Car ID: " + car.getCarId());
            System.out.println("Make: " + car.getMake());
            System.out.println("Model: " + car.getModel());
            System.out.println("Year: " + car.getYear());
            System.out.println("Price Per Day: " + car.getPricePerDay());
            System.out.println("Available for Rent: " + car.isAvailableForRent());
        } else {
            System.out.println("Car not found.");
        }
    }

    private static void updateCar() {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Car car = carDAO.getCar(carId);
        if (car == null) {
            System.out.println("Car not found.");
            return;
        }

        System.out.print("Enter new make (current: " + car.getMake() + "): ");
        String make = scanner.nextLine();
        System.out.print("Enter new model (current: " + car.getModel() + "): ");
        String model = scanner.nextLine();
        System.out.print("Enter new year (current: " + car.getYear() + "): ");
        int year = scanner.nextInt();
        System.out.print("Enter new price per day (current: " + car.getPricePerDay() + "): ");
        double pricePerDay = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        System.out.print("Available for rent (current: " + car.isAvailableForRent() + "): ");
        boolean availableForRent = scanner.nextBoolean();
        scanner.nextLine();  // Consume newline

        car.setMake(make);
        car.setModel(model);
        car.setYear(year);
        car.setPricePerDay(pricePerDay);
        car.setAvailableForRent(availableForRent);

        carDAO.updateCar(car);
        System.out.println("Car updated successfully.");
    }

    private static void deleteCar() {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        carDAO.deleteCar(carId);
        System.out.println("Car deleted successfully.");
    }

    private static void viewAvailableCars() {
        List<Car> cars = carDAO.getAllCars();
        System.out.println("Available Cars:");
        for (Car car : cars) {
            if (car.isAvailableForRent()) {
                System.out.println("Car ID: " + car.getCarId());
                System.out.println("Make: " + car.getMake());
                System.out.println("Model: " + car.getModel());
                System.out.println("Year: " + car.getYear());
                System.out.println("Price Per Day: " + car.getPricePerDay());
                System.out.println("Available for Rent: " + car.isAvailableForRent());
                System.out.println();
            }
        }
    }

    private static void viewRentedCars() {
        List<Rental> rentals = rentalDAO.getActiveRentals();
        System.out.println("Rented Cars:");
        for (Rental rental : rentals) {
            System.out.println("Rental ID: " + rental.getRentalId());
            System.out.println("Car ID: " + rental.getCarId());
            System.out.println("Customer Name: " + rental.getCustomerName());
            System.out.println("Customer Phone: " + rental.getCustomerPhone());
            System.out.println("Rental Date: " + rental.getRentalDate());
            System.out.println("Return Date: " + rental.getReturnDate());
            System.out.println();
        }
    }

    private static void rentCar() {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Car car = carDAO.getCar(carId);
        if (car == null) {
            System.out.println("Car not found.");
            return;
        }
        if (!car.isAvailableForRent()) {
            System.out.println("Car is not available for rent.");
            return;
        }

        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter customer phone: ");
        String customerPhone = scanner.nextLine();

        Rental rental = new Rental();
        rental.setCarId(carId);
        rental.setCustomerName(customerName);
        rental.setCustomerPhone(customerPhone);
        rental.setRentalDate(new java.util.Date());

        rentalDAO.addRental(rental);
        System.out.println("Car rented successfully.");
    }

    private static void returnCar() {
        System.out.print("Enter rental ID: ");
        int rentalId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        rentalDAO.returnCar(rentalId);
        System.out.println("Car returned successfully.");
    }
}