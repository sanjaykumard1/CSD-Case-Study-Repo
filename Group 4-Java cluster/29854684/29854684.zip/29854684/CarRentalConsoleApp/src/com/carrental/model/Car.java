package com.carrental.model;

public class Car {
    private int carId;
    private String make;
    private String model;
    private int year;
    private double pricePerDay;
    private boolean availableForRent;

    // Getters
    public int getCarId() {
        return carId;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }

    public boolean isAvailableForRent() {
        return availableForRent;
    }

    // Setters
    public void setCarId(int carId) {
        this.carId = carId;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public void setAvailableForRent(boolean availableForRent) {
        this.availableForRent = availableForRent;
    }
}
