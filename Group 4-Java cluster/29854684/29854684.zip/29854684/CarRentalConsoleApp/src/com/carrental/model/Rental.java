package com.carrental.model;

import java.util.Date;

public class Rental {
    private int rentalId;
    private int carId;
    private String customerName;
    private String customerPhone;
    private Date rentalDate;
    private Date returnDate;

    // Getters
    public int getRentalId() {
        return rentalId;
    }

    public int getCarId() {
        return carId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public Date getRentalDate() {
        return rentalDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    // Setters
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public void setRentalDate(Date rentalDate) {
        this.rentalDate = rentalDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }
}