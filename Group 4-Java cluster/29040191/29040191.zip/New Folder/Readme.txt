Candidate ID: 29040191 
Name: Roshan Kumar



News Publishing System

Overview: 
The News Publishing System is a menu-based console application developed using Core Java, MySQL, and JDBC. 
It allows users to manage news categories, articles, and comments efficiently. The application ensures the 
integrity of data by handling foreign key constraints and providing user-friendly error messages.



Features:

1. News Category Management:
   - Add a new news category
   - View news category details
   - Update news category information
   - Delete a news category

2. Article Management:
   - Add a new article to a category
   - View article details
   - Update article information
   - Delete an article

3. Comment Management:
   - Add a comment to an article
   - View comments for an article
   - Update a comment
   - Delete a comment
   
4. Users Management:
   - Add Users
   - View users
   - Update user details
   - Delete user

Database Schema:

1. Category Table:
  - category_id (Primary Key)
  - name
  - description

2. Article Table:
  - article_id (Primary Key)
  - category_id (Foreign Key references Category Table)
  - title
  - content
  - author
  - publish_date

3. Comment Table:
  - comment_id (Primary Key)
  - article_id (Foreign Key references Article Table)
  - user_id (Foreign Key references User Table)
  - content
  - comment_date

4. User Table:
  - user_id (Primary Key)
  - user_name
  - email
  - date_of_birth
  - registration_date
  

Implementation Details:
Following file are created to handle the operations involved in News publishing.

1. jdbc_connection.java
- Manages database connection using JDBC.
- After importing the jar files of Mysql j connector, database connection is established. 

2. categories.java
- Handles all operations related to news categories:
  - `addCategory()`
  - `viewCategory()`
  - `updateCategory()`
  - `deleteCategory()`

3. article_manager.java
- Handles all operations related to articles:
  - `addArticle()`: Checks if the category exists before adding an article.
  - `viewArticle()`
  - `updateArticle()`
  - `deleteArticle()`

4. CommentManager.java
- Handles all operations related to comments:
  - `addComment()`
  - `viewComments()`
  - `updateComment()`
  - `deleteComment()`

5. Main.java
- Provides a menu-driven interface for users to interact with the application.




Error Handling:
The application includes error handling to provide user-friendly messages and ensure data integrity, particularly with foreign key constraints.

How to Run:
1. Set up the MySQL database with the provided schema.
2. Update the database connection details in `DatabaseConnection.java`.
3. Compile and run the Java application from the console.


Conclusion:
The News Publishing System provides a robust and user-friendly platform for managing news categories, 
articles, and comments. The application ensures data integrity and demonstrates proficiency in Core Java, JDBC, and MySQL.

