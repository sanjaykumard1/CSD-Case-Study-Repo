/**
 * 
 */
/**
 * 
 */
module news_publishing_system {
	requires java.sql;
}