package Comment;

import java.sql.*;
import java.util.Scanner;

public class CommentManager {

    public static void handleCommentMenu(Scanner scanner) {
        int choice;

        do {
            System.out.println("Comment Management");
            System.out.println("1. Add a comment");
            System.out.println("2. View comments for an article");
            System.out.println("3. Update a comment");
            System.out.println("4. Delete a comment");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addComment(scanner);
                    break;
                case 2:
                    viewComments(scanner);
                    break;
                case 3:
                    updateComment(scanner);
                    break;
                case 4:
                    deleteComment(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    public static void addComment(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter comment content: ");
        String content = scanner.nextLine();

        int retries = 3;
        while (retries > 0) {
            try (Connection connection = Utilities.jdbc_connection.getConnection()) {
                connection.setAutoCommit(false);
                String query = "INSERT INTO Comment (article_id, user_id, content, comment_date) VALUES (?, ?, ?, NOW())";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setInt(1, articleId);
                    statement.setInt(2, userId);
                    statement.setString(3, content);
                    int rowsInserted = statement.executeUpdate();
                    connection.commit();
                    if (rowsInserted > 0) {
                        System.out.println("Comment added successfully.");
                    } else {
                        System.out.println("Failed to add comment.");
                    }
                    return;
                } catch (SQLException e) {
                    connection.rollback();
                    if (e.getSQLState().equals("40001")) { // SQLState for transaction rollback
                        retries--;
                        if (retries == 0) {
                            System.out.println("Failed to add comment after retries.");
                        } else {
                            System.out.println("Retrying transaction...");
                        }
                    } else {
                        throw e;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                break;
            }
        }
    }

    public static void viewComments(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "SELECT * FROM Comment WHERE article_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, articleId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    boolean hasResults = false;
                    while (resultSet.next()) {
                        hasResults = true;
                        System.out.println("Comment ID: " + resultSet.getInt("comment_id"));
                        System.out.println("User ID: " + resultSet.getInt("user_id"));
                        System.out.println("Content: " + resultSet.getString("content"));
                        System.out.println("Comment Date: " + resultSet.getTimestamp("comment_date"));
                        System.out.println("-------------------------");
                    }
                    if (!hasResults) {
                        System.out.println("No comments found for this article.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateComment(Scanner scanner) {
        System.out.print("Enter comment ID: ");
        int commentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new comment content: ");
        String content = scanner.nextLine();

        int retries = 3;
        while (retries > 0) {
            try (Connection connection = Utilities.jdbc_connection.getConnection()) {
                connection.setAutoCommit(false);
                String query = "UPDATE Comment SET content = ? WHERE comment_id = ?";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setString(1, content);
                    statement.setInt(2, commentId);
                    int rowsUpdated = statement.executeUpdate();
                    connection.commit();
                    if (rowsUpdated > 0) {
                        System.out.println("Comment updated successfully.");
                    } else {
                        System.out.println("Failed to update comment.");
                    }
                    return;
                } catch (SQLException e) {
                    connection.rollback();
                    if (e.getSQLState().equals("40001")) { // SQLState for transaction rollback
                        retries--;
                        if (retries == 0) {
                            System.out.println("Failed to update comment after retries.");
                        } else {
                            System.out.println("Retrying transaction...");
                        }
                    } else {
                        throw e;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                break;
            }
        }
    }

    public static void deleteComment(Scanner scanner) {
        System.out.print("Enter comment ID: ");
        int commentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        int retries = 3;
        while (retries > 0) {
            try (Connection connection = Utilities.jdbc_connection.getConnection()) {
                connection.setAutoCommit(false);
                String query = "DELETE FROM Comment WHERE comment_id = ?";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setInt(1, commentId);
                    int rowsDeleted = statement.executeUpdate();
                    connection.commit();
                    if (rowsDeleted > 0) {
                        System.out.println("Comment deleted successfully.");
                    } else {
                        System.out.println("Failed to delete comment.");
                    }
                    return;
                } catch (SQLException e) {
                    connection.rollback();
                    if (e.getSQLState().equals("40001")) { // SQLState for transaction rollback
                        retries--;
                        if (retries == 0) {
                            System.out.println("Failed to delete comment after retries.");
                        } else {
                            System.out.println("Retrying transaction...");
                        }
                    } else {
                        throw e;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                break;
            }
        }
    }
}
