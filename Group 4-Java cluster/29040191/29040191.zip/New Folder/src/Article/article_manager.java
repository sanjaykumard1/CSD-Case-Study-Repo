package Article;

import java.sql.*;
import java.util.Scanner;

public class article_manager {
    public static void handleArticleMenu(Scanner scanner) {
        int choice;

        do {
            System.out.println("Article Management");
            System.out.println("1. Add a new article");
            System.out.println("2. View article details");
            System.out.println("3. Update article information");
            System.out.println("4. Delete an article");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addArticle(scanner);
                    break;
                case 2:
                    viewArticle(scanner);
                    break;
                case 3:
                    updateArticle(scanner);
                    break;
                case 4:
                    deleteArticle(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    public static void addArticle(Scanner scanner) {
        System.out.print("Enter category ID: ");
        int categoryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter article title: ");
        String title = scanner.nextLine();
        System.out.print("Enter article content: ");
        String content = scanner.nextLine();
        System.out.print("Enter author name: ");
        String author = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "INSERT INTO Article (category_id, title, content, author, publish_date) VALUES (?, ?, ?, ?, NOW())";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, categoryId);
                statement.setString(2, title);
                statement.setString(3, content);
                statement.setString(4, author);
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Article added successfully.");
                } else {
                    System.out.println("Failed to add article.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "SELECT * FROM Article WHERE article_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, articleId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Article ID: " + resultSet.getInt("article_id"));
                        System.out.println("Category ID: " + resultSet.getInt("category_id"));
                        System.out.println("Title: " + resultSet.getString("title"));
                        System.out.println("Content: " + resultSet.getString("content"));
                        System.out.println("Author: " + resultSet.getString("author"));
                        System.out.println("Publish Date: " + resultSet.getTimestamp("publish_date"));
                    } else {
                        System.out.println("Article not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new content: ");
        String content = scanner.nextLine();
        System.out.print("Enter new author name: ");
        String author = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "UPDATE Article SET title = ?, content = ?, author = ? WHERE article_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, title);
                statement.setString(2, content);
                statement.setString(3, author);
                statement.setInt(4, articleId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Article updated successfully.");
                } else {
                    System.out.println("Failed to update article.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteArticle(Scanner scanner) {
        System.out.print("Enter article ID: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "DELETE FROM Article WHERE article_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, articleId);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Article deleted successfully.");
                } else {
                    System.out.println("Failed to delete article.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
