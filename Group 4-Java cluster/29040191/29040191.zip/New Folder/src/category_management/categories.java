package category_management;

import java.sql.*;
import java.util.Scanner;

public class categories {
    public static void handleCategoryMenu(Scanner scanner) {
        int choice;

        do {
            System.out.println("Category Management");
            System.out.println("1. Add a new news category");
            System.out.println("2. View news category details");
            System.out.println("3. Update news category information");
            System.out.println("4. Delete a news category");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addCategory(scanner);
                    break;
                case 2:
                    viewCategory(scanner);
                    break;
                case 3:
                    updateCategory(scanner);
                    break;
                case 4:
                    deleteCategory(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    public static void addCategory(Scanner scanner) {
        System.out.print("Enter category name: ");
        String name = scanner.nextLine();
        System.out.print("Enter category description: ");
        String description = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "INSERT INTO Category (name, description) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, name);
                statement.setString(2, description);
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Category added successfully.");
                } else {
                    System.out.println("Failed to add category.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewCategory(Scanner scanner) {
        System.out.print("Enter category ID: ");
        int categoryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "SELECT * FROM Category WHERE category_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, categoryId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Category ID: " + resultSet.getInt("category_id"));
                        System.out.println("Name: " + resultSet.getString("name"));
                        System.out.println("Description: " + resultSet.getString("description"));
                    } else {
                        System.out.println("Category not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateCategory(Scanner scanner) {
        System.out.print("Enter category ID: ");
        int categoryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new category name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new category description: ");
        String description = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "UPDATE Category SET name = ?, description = ? WHERE category_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, name);
                statement.setString(2, description);
                statement.setInt(3, categoryId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Category updated successfully.");
                } else {
                    System.out.println("Failed to update category.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteCategory(Scanner scanner) {
        System.out.print("Enter category ID: ");
        int categoryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "DELETE FROM Category WHERE category_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, categoryId);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Category deleted successfully.");
                } else {
                    System.out.println("Failed to delete category.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
