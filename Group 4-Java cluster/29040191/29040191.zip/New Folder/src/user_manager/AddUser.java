package user_manager;

import java.sql.*;
import java.util.Scanner;

public class AddUser {
    public static void handleUserMenu(Scanner scanner) {
        int choice;

        do {
            System.out.println("User Management");
            System.out.println("1. Add a new user");
            System.out.println("2. View user details");
            System.out.println("3. Update user information");
            System.out.println("4. Delete a user");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addUser(scanner);
                    break;
                case 2:
                    viewUser(scanner);
                    break;
                case 3:
                    updateUser(scanner);
                    break;
                case 4:
                    deleteUser(scanner);
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    public static void addUser(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        String dateOfBirth = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "INSERT INTO user (username, email, date_of_birth) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                statement.setString(2, email);
                statement.setDate(3, Date.valueOf(dateOfBirth));
                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("User added successfully.");
                } else {
                    System.out.println("Failed to add user.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "SELECT * FROM user WHERE user_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("User ID: " + resultSet.getInt("user_id"));
                        System.out.println("Username: " + resultSet.getString("username"));
                        System.out.println("Email: " + resultSet.getString("email"));
                        System.out.println("Date of Birth: " + resultSet.getDate("date_of_birth"));
                        System.out.println("Registration Date: " + resultSet.getTimestamp("registration_date"));
                    } else {
                        System.out.println("User not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new username: ");
        String username = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new date of birth (YYYY-MM-DD): ");
        String dateOfBirth = scanner.nextLine();

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "UPDATE user SET username = ?, email = ?, date_of_birth = ? WHERE user_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, username);
                statement.setString(2, email);
                statement.setDate(3, Date.valueOf(dateOfBirth));
                statement.setInt(4, userId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("User updated successfully.");
                } else {
                    System.out.println("Failed to update user.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteUser(Scanner scanner) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try (Connection connection = Utilities.jdbc_connection.getConnection()) {
            String query = "DELETE FROM user WHERE user_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userId);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("User deleted successfully.");
                } else {
                    System.out.println("Failed to delete user.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
