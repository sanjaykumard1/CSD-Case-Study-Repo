package Main_section;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("News Publishing System");
            System.out.println("1. Manage News Categories");
            System.out.println("2. Manage Articles");
            System.out.println("3. Manage Comments");
            System.out.println("4. Manage Users"); 
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    category_management.categories.handleCategoryMenu(scanner);
                    break;
                case 2:
                    Article.article_manager.handleArticleMenu(scanner);
                    break;
                case 3:
                    Comment.CommentManager.handleCommentMenu(scanner);
                    break;
                case 4:
                    user_manager.AddUser.handleUserMenu(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
