package com.cts;
import java.sql.*;
import java.util.Scanner;
public class DBApplication {
	public static void main(String args[]) throws ClassNotFoundException {
		try {
		      Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DBApplication.getConnection();
		Scanner scanner=new Scanner(System.in);
		while (true) {
			showmainmenu();
			int choice = scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				manageCourses(scanner, con);
				break ;
			case 2:
				manageStudents(scanner, con);
				break;
			case 3:
				manageGrades(scanner,con);
				break;
			case 4:
				calculateGPA(scanner,con);
				break;
			case 5:
				System.out.println("Exiting....");
				con.close();
				return ;
			default:
				System.out.println("Invalid Choice");
			}
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static Connection getConnection() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/classroom_management","root","Ajay1234@");

		return con;
	}
	private static void showmainmenu() {
		System.out.println("Classroom Managment System");
		System.out.println("1.Course Management");
		System.out.println("2.Student Management");
		System.out.println("3.Grade Management");
		System.out.println("4.claculate GPA");
		System.out.println("5.Exit");
		System.out.println("ENTER YOUR CHOICE: ");
	}
	private static void manageCourses(Scanner scanner,Connection con) {
		while (true) {
			System.out.println("\n--- Course Management ---");
            System.out.println("1. Add a new course");
            System.out.println("2. View course details");
            System.out.println("3. Update course information");
            System.out.println("4. Delete a course");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
             
            switch (choice) {
            case 1:
            	addCourse(scanner,con);
            	break;
            case 2:
            	viewCourseDetails(scanner,con);
            	break;
            case 3:
            	updateCourse(scanner,con);
            	break;
            case 4:
            	deleteCourse(scanner,con);
            	break;
            case 5:
            	return;
            default:
            	System.out.println("Invalid Choice");
            }
			
		}
	}
	
	private static void addCourse(Scanner scanner,Connection con) {
		System.out.println("Enter course id:");
		int course_id=scanner.nextInt();
		scanner.nextLine();
		System.out.print("Enter course title:");
        String title = scanner.nextLine();
        System.out.print("Enter instructor name: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter schedule: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter credits: ");
        int credits = scanner.nextInt();
        scanner.nextLine();
        try {
        	String sql="insert into course(course_id,title, instructor,schedule,credits) values (?,?,?,?,?)";
			PreparedStatement stmt=con.prepareStatement(sql);
			stmt.setInt(1,course_id);
        	stmt.setString(2, title);
        	stmt.setString(3, instructor);
        	stmt.setString(4, schedule);
        	stmt.setInt(5, credits);
        	int rowsInserted=stmt.executeUpdate();
        	if (rowsInserted >0) {
        		System.out.println("A new course inserted");
        	}
        }catch (SQLException e) {
        	e.printStackTrace();
        }
	}
	private static void viewCourseDetails(Scanner scanner, Connection con) {
		System.out.println("Enter courseid:");
		int courseId = scanner.nextInt();
        scanner.nextLine();
        try {
            String sql = "SELECT * FROM Course WHERE course_id = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, courseId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Course ID: " + resultSet.getInt("course_id"));
                System.out.println("Title: " + resultSet.getString("title"));
                System.out.println("Instructor: " + resultSet.getString("instructor"));
                System.out.println("Schedule: " + resultSet.getString("schedule"));
                System.out.println("Credits: " + resultSet.getInt("credits"));
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	private static void updateCourse(Scanner scanner,Connection con) {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter new course title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new instructor name: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter new schedule: ");
        String schedule = scanner.nextLine();
        System.out.print("Enter new credits: ");
        int credits = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            String sql = "UPDATE course SET title = ?, instructor = ?, schedule = ?, credits = ? WHERE course_id = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, title);
            statement.setString(2, instructor);
            statement.setString(3, schedule);
            statement.setInt(4, credits);
            statement.setInt(5, courseId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Course updated successfully!");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	private static void deleteCourse(Scanner scanner,Connection con) {
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            String sql = "DELETE FROM course WHERE course_id = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, courseId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Course deleted successfully!");
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
private static void manageStudents(Scanner scanner , Connection con) {
	while (true) {
		System.out.println("\n--- Student Management ---");
        System.out.println("1. Register a new student");
        System.out.println("2. View student details");
        System.out.println("3. Update student information");
        System.out.println("4. Delete a student");
        System.out.println("5. Back to main menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                registerStudent(scanner,con);
                break;
            case 2:
                viewStudentDetails(scanner,con);
                break;
            case 3:
                updateStudent(scanner,con);
                break;
            case 4:
                deleteStudent(scanner,con);
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
private static void registerStudent(Scanner scanner,Connection con) {
	System.out.println("Enter student id:");
	int id=scanner.nextInt();
	scanner.nextLine();
    System.out.print("Enter student name: ");
    String name = scanner.nextLine();
    System.out.print("Enter student email: ");
    String email = scanner.nextLine();
    System.out.print("Enter student phone number: ");
    String phoneNumber = scanner.nextLine();
    System.out.print("Enter student address: ");
    String address = scanner.nextLine();

    try {
        String sql = "INSERT INTO student (id,name, email, phone_number, address) VALUES (?,?, ?, ?, ?)";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, id);
        statement.setString(2, name);
        statement.setString(3, email);
        statement.setString(4, phoneNumber);
        statement.setString(5, address);
        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("A new student was registered successfully!");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

private static void viewStudentDetails(Scanner scanner,Connection con) {
    System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    scanner.nextLine(); // consume newline

    try {
        String sql = "SELECT * FROM student WHERE id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, studentId);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            System.out.println("Student ID: " + resultSet.getInt("id"));
            System.out.println("Name: " + resultSet.getString("name"));
            System.out.println("Email: " + resultSet.getString("email"));
            System.out.println("Phone Number: " + resultSet.getString("phone_number"));
            System.out.println("Address: " + resultSet.getString("address"));
        } else {
            System.out.println("Student not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
private static void updateStudent(Scanner scanner, Connection con) {
    System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    scanner.nextLine(); // consume newline

    System.out.print("Enter new student name: ");
    String name = scanner.nextLine();
    System.out.print("Enter new student email: ");
    String email = scanner.nextLine();
    System.out.print("Enter new student phone number: ");
    String phoneNumber = scanner.nextLine();
    System.out.print("Enter new student address: ");
    String address = scanner.nextLine();

    try {
        String sql = "UPDATE student SET name = ?, email = ?, phone_number = ?, address = ? WHERE id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, name);
        statement.setString(2, email);
        statement.setString(3, phoneNumber);
        statement.setString(4, address);
        statement.setInt(5, studentId);
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Student information updated successfully!");
        } else {
            System.out.println("Student not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
private static void deleteStudent(Scanner scanner,Connection con) {
    System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    scanner.nextLine(); // consume newline

    try {
        String sql = "DELETE FROM student WHERE id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, studentId);
        int rowsDeleted = statement.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("Student deleted successfully!");
        } else {
            System.out.println("Student not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

private static void manageGrades(Scanner scanner,Connection con) {
	while (true) {
		System.out.println("\n--- Grade Management ---");
        System.out.println("1. Assign a grade to a student for a course");
        System.out.println("2. View student grades");
        System.out.println("3. Update grade information");
        System.out.println("4. Remove a grade");
        System.out.println("5. Back to main menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                assignGrade(scanner,con);
                break;
            case 2:
                viewStudentGrades(scanner,con);
                break;
            case 3:
                updateGrade(scanner,con);
                break;
            case 4:
                removeGrade(scanner,con);
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
private static void assignGrade(Scanner scanner, Connection con) {
	System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    System.out.print("Enter course ID: ");
    int courseId = scanner.nextInt();
    scanner.nextLine(); // consume newline
    System.out.print("Enter grade: ");
    String grade = scanner.nextLine();
    try {
        String sql = "INSERT INTO grade (student_id, course_id, grade) VALUES (?, ?, ?)";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, studentId);
        statement.setInt(2, courseId);
        statement.setString(3, grade);
        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            System.out.println("Grade assigned successfully!");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
private static void viewStudentGrades(Scanner scanner,Connection con) {
    System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    scanner.nextLine(); // consume newline

    try {
        String sql = "SELECT grade.grade_id, course.title, grade.grade FROM grade " +
                     "JOIN course ON grade.course_id = course.course_id " +
                     "WHERE student_id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, studentId);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            System.out.println("Grade ID: " + resultSet.getInt("grade_id"));
            System.out.println("Course: " + resultSet.getString("title"));
            System.out.println("Grade: " + resultSet.getString("grade"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
private static void updateGrade(Scanner scanner,Connection con) {
    System.out.print("Enter grade ID: ");
    int gradeId = scanner.nextInt();
    scanner.nextLine(); // consume newline
    System.out.print("Enter new grade: ");
    String grade = scanner.nextLine();

    try {
        String sql = "UPDATE grade SET grade = ? WHERE grade_id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setString(1, grade);
        statement.setInt(2, gradeId);
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Grade updated successfully!");
        } else {
            System.out.println("Grade not found.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
private static void removeGrade(Scanner scanner,Connection con) {
	System.out.println("Enter gradeid");
	int gradeId=scanner.nextInt();
	scanner.nextLine();
	try {
		String sql="delete from grade where grade_id=?";
		PreparedStatement statement=con.prepareStatement(sql);
		statement.setInt(1,gradeId);
		int rowsDeleted=statement.executeUpdate();
		if (rowsDeleted >0) {
            System.out.println("Grade removed successfully.");

		}else {
            System.out.println("Grade not found.");

		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
}

private static void calculateGPA(Scanner scanner,Connection con) {
    System.out.print("Enter student ID: ");
    int studentId = scanner.nextInt();
    scanner.nextLine(); // consume newline

    try {
        String sql = "SELECT grade.grade, course.credits FROM grade " +
                     "JOIN course ON grade.course_id = course.course_id " +
                     "WHERE student_id = ?";
        PreparedStatement statement = con.prepareStatement(sql);
        statement.setInt(1, studentId);
        ResultSet resultSet = statement.executeQuery();

        int totalCredits = 0;
        double totalPoints = 0.0;
        while (resultSet.next()) {
            String grade = resultSet.getString("grade");
            int credits = resultSet.getInt("credits");
            double gradePoints = getGradePoints(grade);
            totalCredits += credits;
            totalPoints += gradePoints * credits;
        }

        if (totalCredits > 0) {
            double gpa = totalPoints / totalCredits;
            System.out.println("GPA: " + gpa);
        } else {
            System.out.println("No grades found for this student.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

private static double getGradePoints(String grade) {
    switch (grade) {
        case "A":
            return 10.0;
        case "B":
            return 8.0;
        case "C":
            return 6.0;
        case "D":
            return 5.0;
        case "F":
            return 4.0;
        default:
            return 0.0;
    }
}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


