package com.casestudy.dms.models;
import java.sql.Date;
public class Cases {
	private int caseId;
	private int clientId;
	private String caseNumber;
	private String description;
	private String status;
	private Date openDate;
	private Date closeDate;
	public int getCaseId() {
		return caseId;
	}
	public void setCaseId(int caseId) {
		this.caseId=caseId;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId=clientId;
	}
	public String getCaseNumber() {
		return caseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		this.caseNumber=caseNumber;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String Description) {
		this.description=description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status=status;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate=openDate;
	}
	public Date getCloseDate() {
		return closeDate;
	}
	public void setCloseDate(Date closeDate) {
		this.closeDate=closeDate;
	}
}

