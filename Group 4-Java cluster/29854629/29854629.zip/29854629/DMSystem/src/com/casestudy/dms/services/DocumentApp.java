package com.casestudy.dms.services;
import com.casestudy.dms.database.DocumentObj;
import com.casestudy.dms.models.Document;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;
public class DocumentApp {
	private DocumentObj documentObj=new DocumentObj();
	private Scanner sc=new Scanner(System.in);
	public void uploadDocument() throws ClassNotFoundException {
		System.out.print("Enter title: ");
		String title=sc.nextLine();
		System.out.print("Enter description: ");
		String description=sc.nextLine();
		System.out.print("Enter file path: ");
		String filePath=sc.nextLine();
		System.out.print("Enter upload date(yyyy-mm-dd): ");
		String uploadDate=sc.nextLine();
		Document document=new Document();
		document.setTitle(title);
		document.setDescription(description);
		document.setFilePath(filePath);
		document.setUploadDate(Date.valueOf(uploadDate));
		documentObj.uploadDocument(document);
		System.out.println("Document upload successfully");
	}
	public void viewDocument() throws ClassNotFoundException {
		System.out.print("Enter document ID: ");
		int documentId=sc.nextInt();
		sc.nextLine();
		Document document=documentObj.getDocumentById(documentId);
		if(document!=null) {
			System.out.println("Document ID: "+document.getDocumentId());
			System.out.println("Title: "+document.getTitle());
			System.out.println("Description: "+document.getDescription());
			System.out.println("File Path: "+document.getFilePath());
			System.out.println("Upload Date: "+document.getUploadDate());
		} else {
			System.out.println("Document not found!");
		}
	}
	public void updateDocument() throws ClassNotFoundException {
		System.out.print("Enter document ID: ");
		int documentId=sc.nextInt();
		sc.nextLine();
		Document document=documentObj.getDocumentById(documentId);
		if(document!=null) {
			System.out.print("Enter new title: ");
			String title=sc.nextLine();
			System.out.print("Enter new description: ");
			String description=sc.nextLine();
			System.out.print("Enter new file path: ");
			String filePath=sc.nextLine();
			System.out.print("Enter new upload date(yyyy-mm-dd): ");
			String uploadDate=sc.nextLine();
			document.setTitle(title);
			document.setDescription(description);
			document.setFilePath(filePath);
			document.setUploadDate(Date.valueOf(uploadDate));
			documentObj.updateDocument(document);
			System.out.println("Document updated successfully!");
		} else {
			System.out.println("Document not found!");
		}
	}
	public void deleteDocument() throws ClassNotFoundException {
		System.out.println("Enter document ID: ");
		int documentId=sc.nextInt();
		sc.nextLine();
		documentObj.deleteDocument(documentId);
		System.out.println("Document deleted successfully!");
	}
	public void listOfDocuments() throws ClassNotFoundException {
		List<Document> documents=documentObj.getAllDocuments();
		for(Document document:documents) {
			System.out.println("Document ID: "+document.getDocumentId());
			System.out.println("Title: "+document.getTitle());
			System.out.println("Description: "+document.getDescription());
			System.out.println("File Path: "+document.getFilePath());
			System.out.println("Upload Date: "+document.getUploadDate());
		}
	}
}
