package com.casestudy.dms.services;
import com.casestudy.dms.database.ClientObj;
import com.casestudy.dms.models.Client;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
public class ClientApp {
	private ClientObj clientObj=new ClientObj();
	Scanner sc=new Scanner(System.in);
	public void addClient() throws SQLException, ClassNotFoundException {
		System.out.print("Enter name: ");
		String name=sc.nextLine();
		System.out.print("Enter contact number: ");
		String contactNumber=sc.nextLine();
		System.out.print("Enter email: ");
		String email=sc.nextLine();
		System.out.print("Enter address: ");
		String address=sc.nextLine();
		Client client=new Client();
		client.setName(name);
		client.setContactNumber(contactNumber);
		client.setEmail(email);
		client.setAddress(address);
		clientObj.addClient(client);
		System.out.println("Client added successfully!");
	}
	public void viewClient() throws SQLException, ClassNotFoundException {
		System.out.print("Enter client ID: ");
		int clientId=sc.nextInt();
		sc.nextLine();
		Client client=clientObj.getClientById(clientId);
		if(client!=null) {
			System.out.println("Client ID: "+client.getClientId());
			System.out.println("Name: "+client.getName());
			System.out.println("Contact Number: "+client.getContactNumber());
			System.out.println("Email: "+client.getEmail());
			System.out.println("Address: "+client.getAddress());
		}
		else {
			System.out.println("Client not found!");
		}
	}
	public void updateClient() throws SQLException, ClassNotFoundException {
		System.out.println("Enter client ID: ");
		int clientId=sc.nextInt();
		sc.nextLine();
		Client client=clientObj.getClientById(clientId);
		if(client!=null) {
			System.out.print("Enter new name: ");
			String name=sc.nextLine();
			System.out.print("Enter new contact number: ");
			String contactNumber=sc.nextLine();
			System.out.print("Enter new email: ");
			String email=sc.nextLine();
			System.out.print("Enter new address: ");
			String address=sc.nextLine();
			client.setName(name);
			client.setContactNumber(contactNumber);
			client.setEmail(email);
			client.setAddress(address);
			clientObj.updateClient(client);
			System.out.println("Client updated successfully!");
		} else {
			System.out.println("Client not found!");
		}
	}
	public void deleteClient() throws SQLException, ClassNotFoundException {
		System.out.print("Enter client ID: ");
		int clientId=sc.nextInt();
		sc.nextLine();
		clientObj.deleteClient(clientId);
		System.out.println("Client deleted successfully!");
	}
	public void listOfClients() throws SQLException, ClassNotFoundException {
		List<Client> clients=clientObj.getAllClients();
		for(Client client:clients) {
			System.out.println("Client ID: "+client.getClientId());
			System.out.println("Name: "+client.getName());
			System.out.println("Contact Number: "+client.getContactNumber());
			System.out.println("Email: "+client.getEmail());
			System.out.println("Address: "+client.getAddress());
		}
	}
}
