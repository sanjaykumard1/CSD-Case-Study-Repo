package com.casestudy.dms.services;
import com.casestudy.dms.database.CaseObj;
import com.casestudy.dms.models.Cases;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class CasesApp {
	private CaseObj caseObj=new CaseObj();
	Scanner sc=new Scanner(System.in);
	public void createCase() throws ClassNotFoundException {
		System.out.print("Enter Client ID: ");
		int clientId=sc.nextInt();
		sc.nextLine();
		System.out.print("Enter Case Number: ");
		String caseNumber=sc.nextLine();
		System.out.print("Enter description: ");
		String description=sc.nextLine();
		System.out.print("Enter status: ");
		String status=sc.nextLine();
		System.out.print("Enter open date(yyyy-mm-dd): ");
		String openDate=sc.nextLine();
		System.out.print("Enter close date(yyyy-mm-dd): ");
		String closeDate=sc.nextLine();
		Cases cases=new Cases();
		cases.setClientId(clientId);
		cases.setCaseNumber(caseNumber);
		cases.setDescription(description);
		cases.setStatus(status);
		cases.setOpenDate(Date.valueOf(openDate));
		cases.setCloseDate(Date.valueOf(closeDate));
		caseObj.createCase(cases);
		System.out.println("Case created successfully!");
	}
	public void viewCase() throws SQLException, ClassNotFoundException {
		System.out.print("Enter case ID: ");
		int caseId=sc.nextInt();
		sc.nextLine();
		Cases cases=caseObj.getCaseById(caseId);
		if(cases!=null) {
			System.out.println("Case ID: "+cases.getCaseId());
			System.out.println("Client ID: "+cases.getClientId());
			System.out.println("Case Number: "+cases.getCaseNumber());
			System.out.println("Description: "+cases.getDescription());
			System.out.println("Status: "+cases.getStatus());
			System.out.println("Open Date: "+cases.getOpenDate());
			System.out.println("Close Date: "+cases.getCloseDate());
		} else {
			System.out.println("Case not found!");
		}
	}
	public void updateCases() throws SQLException, ClassNotFoundException {
		System.out.println("Enter case ID: ");
		int caseId=sc.nextInt();
		sc.nextLine();
		Cases cases=caseObj.getCaseById(caseId);
		if(cases!=null) {
			System.out.print("Enter new client ID: ");
			int clientId=sc.nextInt();
			sc.nextLine();
			System.out.print("Enter new Case Number: ");
			String caseNumber=sc.nextLine();
			System.out.print("Enter new description: ");
			String description=sc.nextLine();
			System.out.print("Enter new status: ");
			String status=sc.nextLine();
			System.out.print("Enter new open date(yyyy-mm-dd): ");
			String openDate=sc.nextLine();
			System.out.print("Enter new close date(yyyy-mm-dd): ");
			String closeDate=sc.nextLine();
			cases.setClientId(clientId);
			cases.setCaseNumber(caseNumber);
			cases.setDescription(description);
			cases.setStatus(status);
			cases.setOpenDate(Date.valueOf(openDate));
			cases.setCloseDate(Date.valueOf(closeDate));
			caseObj.updateCases(cases);
			System.out.println("Case updated successfully!");
		} else {
			System.out.println("Case not found!");
		}
	}
	public void deleteCases() throws SQLException, ClassNotFoundException {
		System.out.print("Enter case ID: ");
		int caseID=sc.nextInt();
		sc.nextLine();
		caseObj.deleteCases(caseID);
		System.out.println("Case deleted successfully!");
	}
	public void listOfCases() throws SQLException, ClassNotFoundException {
		List<Cases> cases1=caseObj.getAllCases();
		for(Cases cases:cases1) {
			System.out.println("Case ID: "+cases.getCaseId());
			System.out.println("Client ID: "+cases.getClientId());
			System.out.println("Case Number: "+cases.getCaseNumber());
			System.out.println("Description: "+cases.getDescription());
			System.out.println("Status: "+cases.getStatus());
			System.out.println("Open Date: "+cases.getOpenDate());
			System.out.println("Close Date: "+cases.getCloseDate());
		}
	}
	
}
