package com.casestudy.dms.database;
import com.casestudy.dms.models.Cases;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class CaseObj {
    public void createCase(Cases caseObj) throws ClassNotFoundException {
        String query = "INSERT INTO Cases (client_id, case_number, description, status, open_date, close_date) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, caseObj.getClientId());
            stmt.setString(2, caseObj.getCaseNumber());
            stmt.setString(3, caseObj.getDescription());
            stmt.setString(4, caseObj.getStatus());
            stmt.setDate(5, new java.sql.Date(caseObj.getOpenDate().getTime()));
            if (caseObj.getCloseDate() != null) {
                stmt.setDate(6, new java.sql.Date(caseObj.getCloseDate().getTime()));
            } else {
                stmt.setNull(6, Types.DATE);
            }
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public Cases getCaseById(int caseId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Cases WHERE case_id = ?";
        Cases cases = null;
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, caseId);
            ResultSet resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                cases = new Cases();
                cases.setCaseId(resultSet.getInt("case_id"));
                cases.setClientId(resultSet.getInt("client_id"));
                cases.setCaseNumber(resultSet.getString("case_number"));
                cases.setDescription(resultSet.getString("description"));
                cases.setStatus(resultSet.getString("status"));
                cases.setOpenDate(resultSet.getDate("open_date"));
                cases.setCloseDate(resultSet.getDate("close_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cases;
    }
    public void updateCases(Cases cases) throws ClassNotFoundException {
        String query = "UPDATE Cases SET client_id = ?, case_number = ?, description = ?, status = ?, open_date = ?, close_date = ? WHERE case_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, cases.getClientId());
            stmt.setString(2, cases.getCaseNumber());
            stmt.setString(3, cases.getDescription());
            stmt.setString(4, cases.getStatus());
            stmt.setDate(5, new java.sql.Date(cases.getOpenDate().getTime()));
            if (cases.getCloseDate() != null) {
                stmt.setDate(6, new java.sql.Date(cases.getCloseDate().getTime()));
            } else {
                stmt.setNull(6, Types.DATE);
            }
            stmt.setInt(7, cases.getCaseId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteCases(int caseId) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM Cases WHERE case_id = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, caseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<Cases> getAllCases() throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM Cases";
        List<Cases> casesList = new ArrayList<>();
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet resultSet = stmt.executeQuery(query)) {
            while (resultSet.next()) {
                Cases cases = new Cases();
                cases.setCaseId(resultSet.getInt("case_id"));
                cases.setClientId(resultSet.getInt("client_id"));
                cases.setCaseNumber(resultSet.getString("case_number"));
                cases.setDescription(resultSet.getString("description"));
                cases.setStatus(resultSet.getString("status"));
                cases.setOpenDate(resultSet.getDate("open_date"));
                cases.setCloseDate(resultSet.getDate("close_date"));
                casesList.add(cases);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return casesList;
    }
}
