package com.casestudy.dms.database;
import com.casestudy.dms.models.Document;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class DocumentObj {

	public void uploadDocument(Document document) throws ClassNotFoundException {
		String query="INSERT INTO Document(title,description,file_path,upload_date) VALUES(?,?,?,?)";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setString(1,document.getTitle());
			stmt.setString(2,document.getDescription());
			stmt.setString(3,document.getFilePath());
			stmt.setDate(4,new java.sql.Date(document.getUploadDate().getTime()));
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public Document getDocumentById(int documentId) throws ClassNotFoundException {
		String query="SELECT * FROM Document WHERE document_id=?";
		Document document=null;
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setInt(1, documentId);
			ResultSet resultSet=stmt.executeQuery();
			if(resultSet.next()) {
				document=new Document();
				document.setDocumentId(resultSet.getInt("document_id"));
				document.setTitle(resultSet.getString("title"));
				document.setDescription(resultSet.getString("description"));
				document.setFilePath(resultSet.getString("file_path"));
				document.setUploadDate(resultSet.getDate("upload_date"));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return document;
	}
	public void updateDocument(Document document) throws ClassNotFoundException {
		String query="UPDATE Document SET title=?, description=?, file_path=?, upload_date=? WHERE document_id=?";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setString(1, document.getTitle());
			stmt.setString(2, document.getDescription());
			stmt.setString(3, document.getFilePath());
			stmt.setDate(4,new java.sql.Date(document.getUploadDate().getTime()));
			stmt.setInt(5, document.getDocumentId());
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public void deleteDocument(int documentId) throws ClassNotFoundException {
		String query="DELETE FROM Document WHERE document_id=?";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setInt(1, documentId);
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Document> getAllDocuments() throws ClassNotFoundException{
		String query="SELECT * FROM Document";
		List<Document> documents=new ArrayList<>();
		try(Connection con=DatabaseConnection.getConnection();
			Statement stmt=con.createStatement();
      		ResultSet resultSet=stmt.executeQuery(query)){
			while(resultSet.next()) {
				Document document=new Document();
				document.setDocumentId(resultSet.getInt("document_id"));
				document.setTitle(resultSet.getString("title"));
				document.setFilePath(resultSet.getString("file_path"));
				document.setUploadDate(resultSet.getDate("upload_date"));
				documents.add(document);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return documents;
	}
}
