package com.casestudy.dms.database;
import com.casestudy.dms.models.Client;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ClientObj {
	public void addClient(Client client) throws SQLException, ClassNotFoundException {
		String query="INSERT INTO Client(name,contact_number,email,address) VALUES(?,?,?,?)";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setString(1, client.getName());
			stmt.setString(2, client.getContactNumber());
			stmt.setString(3, client.getEmail());
			stmt.setString(4, client.getAddress());
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public Client getClientById(int clientId) throws SQLException, ClassNotFoundException {
		String query="SELECT * FROM Client WHERE client_id=?";
		Client client=null;
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setInt(1, clientId);
			ResultSet resultSet=stmt.executeQuery();
			if(resultSet.next()) {
				client=new Client();
				client.setClientId(resultSet.getInt("client_id"));
				client.setName(resultSet.getString("name"));
				client.setContactNumber(resultSet.getString("contact_number"));
				client.setEmail(resultSet.getString("email"));
				client.setAddress(resultSet.getString("address"));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return client;
	}
	public void updateClient(Client client) throws ClassNotFoundException {
		String query="UPDATE Client SET name=?, contact_number=?, email=?, address=? WHERE client_id=?";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setString(1, client.getName());
			stmt.setString(2, client.getContactNumber());
			stmt.setString(3, client.getEmail());
			stmt.setString(4, client.getAddress());
			stmt.setInt(5, client.getClientId());
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public void deleteClient(int clientId) throws SQLException, ClassNotFoundException {
		String query="DELETE FROM Client WHERE client_id=?";
		try(Connection con=DatabaseConnection.getConnection();
			PreparedStatement stmt=con.prepareStatement(query)){
			stmt.setInt(1, clientId);
			stmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	public List<Client> getAllClients() throws SQLException, ClassNotFoundException{
		String query="SELECT * FROM Client";
		List<Client> clients=new ArrayList<>();
		try(Connection con=DatabaseConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet resultSet=stmt.executeQuery(query)){
			while(resultSet.next()) {
				Client client=new Client();
				client.setClientId(resultSet.getInt("client_id"));
				client.setName(resultSet.getString("name"));
				client.setContactNumber(resultSet.getString("contact_number"));
				client.setEmail(resultSet.getString("email"));
				client.setAddress(resultSet.getString("address"));
				clients.add(client);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		}
		return clients;
	}
}
