package com.casestudy.dms;
import com.casestudy.dms.services.DocumentApp;
import com.casestudy.dms.services.ClientApp;
import com.casestudy.dms.services.CasesApp;
import java.sql.SQLException;
import java.util.Scanner;
public class DocumentManagementSystem {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        DocumentApp documentApp = new DocumentApp();
        ClientApp clientApp = new ClientApp();
        CasesApp casesApp = new CasesApp();
        while (true) {
            System.out.println("Document Management System");
            System.out.println("1. Document Management");
            System.out.println("2. Client Management");
            System.out.println("3. Case Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    documentManagementMenu(documentApp);
                    break;
                case 2:
                    clientManagementMenu(clientApp);
                    break;
                case 3:
                    caseManagementMenu(casesApp);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void documentManagementMenu(DocumentApp documentApp) throws ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Document Management");
            System.out.println("1. Upload Document");
            System.out.println("2. View Document");
            System.out.println("3. Update Document");
            System.out.println("4. Delete Document");
            System.out.println("5. List Documents");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    documentApp.uploadDocument();
                    break;
                case 2:
                    documentApp.viewDocument();
                    break;
                case 3:
                    documentApp.updateDocument();
                    break;
                case 4:
                    documentApp.deleteDocument();
                    break;
                case 5:
                    documentApp.listOfDocuments();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void clientManagementMenu(ClientApp clientApp) throws SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Client Management");
            System.out.println("1. Add Client");
            System.out.println("2. View Client");
            System.out.println("3. Update Client");
            System.out.println("4. Delete Client");
            System.out.println("5. List Clients");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    clientApp.addClient();
                    break;
                case 2:
                    clientApp.viewClient();
                    break;
                case 3:
                    clientApp.updateClient();
                    break;
                case 4:
                    clientApp.deleteClient();
                    break;
                case 5:
                    clientApp.listOfClients();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void caseManagementMenu(CasesApp casesApp) throws SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Case Management");
            System.out.println("1. Create Case");
            System.out.println("2. View Case");
            System.out.println("3. Update Case");
            System.out.println("4. Delete Case");
            System.out.println("5. List Cases");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    casesApp.createCase();
                    break;
                case 2:
                    casesApp.viewCase();
                    break;
                case 3:
                    casesApp.updateCases();
                    break;
                case 4:
                    casesApp.deleteCases();
                    break;
                case 5:
                    casesApp.listOfCases();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}