/**
 * 
 */
/**
 * 
 */
module DMSystem {
	requires java.sql;
}