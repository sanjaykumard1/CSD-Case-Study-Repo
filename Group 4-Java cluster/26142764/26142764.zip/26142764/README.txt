TAX SERVICE SYSTEM

#Description#

1)This menu-based console application facilitates efficient management of taxpayers,
tax returns, and tax payments. 
2)Users can submit tax returns, record tax payments, 
and manage taxpayer information seamlessly.
3)The application ensures exception
handling and provides clear, user-friendly error messages for smooth operation.
4)Developed using Core Java and JDBC for MySQL.

#Functionalities#

Tax Payers:

1)User can register new user by adding their name,
  contact number,email,address,tax payers Id and tax Id number.
2)User can view the Tax Payers details by giving their taxpayers Id.
3)User can update the values in Tax Payers using their Tax Payers Id.
  If the Tax Payers doesnt exists then user cannot update the values 
  and throws the error.
4)User can delete the Tax Payer details and other related details
  using their Tax Payers Id(If the Tax Payers is deleted then other 
  tables containing details about the particular TaxPayers Id will
  also be deleted).

Tax Returns:

1)User can submit Tax Return details by adding their TaxPayers Id,
  return id,income,deductions ,filing date and automatically tax due is
  caluculated and stored.
2)User can view the Tax Return details by giving their return Id.
3)User can update the values in Tax Returns using their Return Id.
  If the Tax Payers and return Id  doesnt exists then user cannot 
  update the values and throws the error.
4)User can delete the Tax Returns details using their return Id(If
  the return id which is given does exist).

Tax Payements:

1)User can record Tax Payement details by adding their TaxPayers Id,
  Payment id,amount,payment date and status.
2)User can view the Tax Payement details by giving their Payment Id.
3)User can update the values in Tax Payement using their Payement Id.
  If the Tax Payers and payment Id  doesnt exists then user cannot 
  update the values and throws an error.
4)User can delete the Tax Payment details using their Payment Id(If
  the payment id which is given does exist).


#Requirements#

1)Eclipse IDE
2)MySql
3)mysql connecter jar file(To connect java and mysql using JDBC)

#Set Up#
1)Open the Eclipse IDE and Create an Java Project.
2)Create an package and class.
3)Download the mysql connecter jar file from the website.
4)Create an new folder in the java project.
5)Add the downloaded jar file to the created folder.
6)Build path to the jar file.
7)JDBC is connected successfully.
8)The classes are presented in the src folder.
9)copy the classes.
10)Run the Main.java after creating schemas in MySql.

#Establishing JDBC connection#

1)Add JDBC Driver to Classpath.
2)Import Required Packages.
3)Create a Connection String.
4)Establish the Connection.
5)Handle Exceptions and Close the Connection.


#MySql Schema#

1)Open the MySql workbench.
2)Copy the below schema and run it.

create database taxservice;
use taxservice;
create table Taxpayer (
    taxpayer_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_number VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    tax_id_number VARCHAR(50) NOT NULL
);

create table TaxReturn (
    return_id INT PRIMARY KEY,
    taxpayer_id INT,
    income DOUBLE NOT NULL,
    deductions DOUBLE NOT NULL,
    tax_due DOUBLE NOT NULL,
    filing_date DATE NOT NULL,
    FOREIGN KEY (taxpayer_id) REFERENCES Taxpayer(taxpayer_id)
);

create table TaxPayment (
    payment_id INT PRIMARY KEY,
    taxpayer_id INT,
    amount DOUBLE NOT NULL,
    payment_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL,
    FOREIGN KEY (taxpayer_id) REFERENCES Taxpayer(taxpayer_id)
);

