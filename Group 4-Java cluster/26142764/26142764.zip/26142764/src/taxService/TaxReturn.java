package taxService;

import java.util.*;
import java.sql.*;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TaxReturn {
	
    public static void manage() {//This method is called when the user enters the choice 1.
        Scanner sc = new Scanner(System.in);
        
        while (true) {//the loop will continue executing until the program is terminated.
            System.out.println("ENTER 1 TO REGISTER NEW TAX RETURN");
            System.out.println("ENTER 2 TO VIEW TAX RETURN DETAILS");
            System.out.println("ENTER 3 TO UPDATE TAX RETURN INFORMATION");
            System.out.println("ENTER 4 TO DELETE TAX RETURN");
            System.out.println("ENTER 5 TO RETURN MAINMENU");
            int choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    registerTaxReturn();//calls the method registerTaxReturn() from this class.
                    break;
                case 2:
                    viewTaxReturnDetails();//calls the method viewTaxReturnDetails() from this class.
                    break;
                case 3:
                    updateTaxReturn();//calls the method updateTaxReturn() from this class.
                    break;
                case 4:
                    deleteTaxReturn();//calls the method deleteTaxReturn() from this class.
                    break;
                case 5:
                    System.out.println("Returning to Mainmenu....");
                    return;//returns to mainmenu.
                default:
                    System.out.println("Your choice is invalid. Enter numbers from 1 to 5");
            }
        }
    }
    
    //method to register Tax Returns.
    private static void registerTaxReturn() {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter the tax return ID:");
        int returnId = sc.nextInt();
        
        System.out.println("Enter your taxpayer ID:");
        int taxpayerId = sc.nextInt();
        
        System.out.println("Enter your income:");
        double income = sc.nextDouble();
        
        System.out.println("Enter deductions:");
        double deductions = sc.nextDouble();
        sc.nextLine();
        
        String filingDate = promptForDate("Enter filing date (YYYY-MM-DD):", sc);
        
        // Calculation for tax due.
        double taxDue = (income - deductions) * 0.2;
        
        try (Connection con = DataBaseConnection.getConnection()) {
        	
        	//checks whether tax payer Id already exists.
            String queryCheck = "SELECT * FROM Taxpayer WHERE taxpayer_id = ?";
            PreparedStatement psCheck = con.prepareStatement(queryCheck);
            psCheck.setInt(1, taxpayerId);
            ResultSet rs = psCheck.executeQuery();
            if (!rs.next()) //Check if there are no more rows in the ResultSet
            {
                System.out.println("Taxpayer ID does not exist");
                return;
            }
            
            //checks whether the Tax return id already exists.
            queryCheck = "SELECT * FROM TaxReturn WHERE return_id = ?";
            psCheck = con.prepareStatement(queryCheck);
            psCheck.setInt(1, returnId);
            rs = psCheck.executeQuery();
            if (rs.next())
            {
                System.out.println("Tax return ID already exists");
                return;
            }
            
            //If theTax payers Id and Tax Return Id doesnt already exits then it inserts the values.
            String query = "INSERT INTO TaxReturn (return_id, taxpayer_id, income, deductions, tax_due, filing_date) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, returnId);
            ps.setInt(2, taxpayerId);
            ps.setDouble(3, income);
            ps.setDouble(4, deductions);
            ps.setDouble(5, taxDue);
            ps.setDate(6, Date.valueOf(filingDate));
            ps.executeUpdate();
            System.out.println("Tax return registered successfully!");
        } 
        catch (SQLException e)
        {
            System.out.println("Error registering tax return: " + e.getMessage());
        }
    }

    //method to view Tax Return details.
    private static void viewTaxReturnDetails()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter tax return ID:");
        int returnId = sc.nextInt();
        try (Connection con = DataBaseConnection.getConnection()) 
        {
            String query = "SELECT * FROM TaxReturn WHERE return_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, returnId);
            ResultSet rs = ps.executeQuery();
            if (rs.next())
            {
                System.out.println("Tax Return ID: " + rs.getInt("return_id"));
                System.out.println("Taxpayer ID: " + rs.getInt("taxpayer_id"));
                System.out.println("Income: " + rs.getDouble("income"));
                System.out.println("Deductions: " + rs.getDouble("deductions"));
                System.out.println("Tax Due: " + rs.getDouble("tax_due"));
                System.out.println("Filing Date: " + rs.getDate("filing_date"));
            } 
            else 
            {
                System.out.println("No tax return found with the given ID.");
            }
        } 
        catch (SQLException e) 
        {
            System.out.println("Error fetching tax return details: " + e.getMessage());
        }
    }

    //method to update Tax Return details.
    private static void updateTaxReturn()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter tax return ID:");
        int returnId = sc.nextInt();
        System.out.println("Enter new taxpayer ID:");
        int taxpayerId = sc.nextInt();
        System.out.println("Enter new income:");
        double income = sc.nextDouble();
        System.out.println("Enter new deductions:");
        double deductions = sc.nextDouble();
        sc.nextLine();
        // Prompt the user to enter a new payment date in the specified format (YYYY-MM-DD) and retrieve the validated date input.
        String filingDate = promptForDate("Enter new filing date (YYYY-MM-DD):", sc);
        
        // Calculations for tax due.
        double taxDue = (income - deductions) * 0.2;
        
        try (Connection con = DataBaseConnection.getConnection()) 
        {
            String queryCheck = "SELECT * FROM Taxpayer WHERE taxpayer_id = ?";
            PreparedStatement psCheck = con.prepareStatement(queryCheck);
            psCheck.setInt(1, taxpayerId);
            ResultSet rs = psCheck.executeQuery();
            if (!rs.next()) 
            {
                System.out.println("Taxpayer ID does not exist.");
                return;
            }
            
            String query = "UPDATE TaxReturn SET taxpayer_id = ?, income = ?, deductions = ?, tax_due = ?, filing_date = ? WHERE return_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            ps.setDouble(2, income);
            ps.setDouble(3, deductions);
            ps.setDouble(4, taxDue);
            ps.setDate(5, Date.valueOf(filingDate));
            ps.setInt(6, returnId);
            ps.executeUpdate();
            System.out.println("Tax return information updated successfully!");
        } 
        catch (SQLException e) 
        {
            System.out.println("Error updating tax return information: " + e.getMessage());
        }
    }

    //method to delete TaxReturns.
    private static void deleteTaxReturn()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter tax return ID:");
        int returnId = sc.nextInt();
        try (Connection con = DataBaseConnection.getConnection())
        {
        	//query to delete Tax returns using Return Id given.
            String query = "DELETE FROM TaxReturn WHERE return_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, returnId);
            ps.executeUpdate();
            System.out.println("Tax return deleted successfully!");
        } 
        catch (SQLException e)
        {
            System.out.println("Error deleting tax return: " + e.getMessage());
        }
    }

    //method to get valid format for date.
    private static String promptForDate(String message, Scanner sc) 
    {
        while (true) 
        {
            System.out.println(message);
            String input = sc.nextLine();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);// Set lenient mode to false for strict date parsing.
            try 
            {
                sdf.parse(input);
                return input;
            } 
            catch (ParseException e)//Handle ParseException.
            {
                System.out.println("Invalid date format. Please enter the date in YYYY-MM-DD format.");
            }
        }
    }
}
