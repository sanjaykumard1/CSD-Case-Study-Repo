package taxService;

import java.util.*;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TaxPayment {
	
    public static void manage() {//This method is called when the user enters the choice 3.

        Scanner sc = new Scanner(System.in);
        while (true) {//the loop will continue executing until the program is terminated.
            System.out.println("ENTER 1 TO REGISTER NEW TAX PAYMENT");
            System.out.println("ENTER 2 TO VIEW TAX PAYMENT DETAILS");
            System.out.println("ENTER 3 TO UPDATE TAX PAYMENT INFORMATION");
            System.out.println("ENTER 4 TO DELETE TAX PAYMENT");
            System.out.println("ENTER 5 TO RETURN MAINMENU");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    registerTaxPayment();//calls the method registerTaxPayment() from this class
                    break;
                    
                case 2:
                    viewTaxPaymentDetails();//calls the method viewTaxPaymentDetails() from this class
                    break;
                    
                case 3:
                    updateTaxPayment();//calls the method updateTaxPayment() from this class
                    break;
                    
                case 4:
                    deleteTaxPayment();//calls the method deleteTaxPayment() from this class
                    break;
                    
                case 5:System.out.println("Returning to Mainmenu....");
                    return;//returns to mainmenu.
                    
                default:
                    System.out.println("Your choice is invalid.Enter numbers from 1 to 5");
            }
        }
    }
    
    //method to register Tax Payement when tax payment Id is given.
    private static void registerTaxPayment() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter tax payment ID:");
        int paymentId = sc.nextInt();
        System.out.println("Enter your taxpayer ID:");
        int taxpayerId = sc.nextInt();
        System.out.println("Enter the amount:");
        double amount = sc.nextDouble();
        sc.nextLine(); 
        String paymentDate = promptForDate("Enter payment date (YYYY-MM-DD):", sc);
        System.out.println("Enter the status (paid/unpaid)");
        String status = sc.nextLine();

        try (Connection con = DataBaseConnection.getConnection()) //obtain a database connection using JDBC.
        {
            // Checks if the taxpayer Id exists.
            String queryCheck = "select * from Taxpayer where taxpayer_id = ?";
            PreparedStatement psCheck = con.prepareStatement(queryCheck);
            psCheck.setInt(1, taxpayerId);
            ResultSet rs = psCheck.executeQuery();
            if (!rs.next()) {
                System.out.println("Taxpayer ID does not exist");
                return;
            }

            // Checks if the payment Id already exists.
            queryCheck = "select * from TaxPayment where payment_id = ?";
            psCheck = con.prepareStatement(queryCheck);
            psCheck.setInt(1, paymentId);
            rs = psCheck.executeQuery();
            if (rs.next()) {
                System.out.println("Tax payment ID already exists");
                return;
            }

            // If it is not already exists then this query inserts new taxpayment record.
            String query = "insert into TaxPayment (payment_id, taxpayer_id, amount, payment_date, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, paymentId);
            ps.setInt(2, taxpayerId);
            ps.setDouble(3, amount);
            ps.setString(4, paymentDate);
            ps.setString(5, status);
            ps.executeUpdate();
            System.out.println("Tax payment recorded successfully!");
        } catch (SQLException e) {
            System.out.println("Error recording tax payment: " + e.getMessage());
        }
    }

    //method to view TaxPayment details.
    private static void viewTaxPaymentDetails() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the payment ID:");
        int paymentId = sc.nextInt();
        //Code that may throw an exception.
        try (Connection con = DataBaseConnection.getConnection()) //obtain a database connection using JDBC
        {
        	//query to display payment details.
            String query = "select * from TaxPayment where payment_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, paymentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Payment ID: " + rs.getInt("payment_id"));
                System.out.println("Taxpayer ID: " + rs.getInt("taxpayer_id"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("Payment Date: " + rs.getString("payment_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("No payment found with the given Id.");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching payment details: " + e.getMessage());
        }
    }

    //method to update the Tax Payment values.
    private static void updateTaxPayment() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the payment ID:");
        int paymentId = sc.nextInt();
        sc.nextLine(); 
        
        System.out.println("Enter new amount:");
        double amount = sc.nextDouble();
        sc.nextLine(); 
        
        // Prompt the user to enter a new payment date in the specified format (YYYY-MM-DD) and retrieve the validated date input.
        String paymentDate = promptForDate("Enter new payment date (YYYY-MM-DD):", sc);
        System.out.println("Enter new status (paid/unpaid)");
        
        String status = sc.nextLine();

        try (Connection con = DataBaseConnection.getConnection())
        {
            String query = "update TaxPayment set amount = ?, payment_date = ?, status = ? where payment_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setDouble(1, amount);
            ps.setString(2, paymentDate);
            ps.setString(3, status);
            ps.setInt(4, paymentId);
            
            int updated = ps.executeUpdate();
            if (updated > 0) 
            {
                System.out.println("Tax payment information updated successfully!");
            }
            else 
            {
                System.out.println("No tax payment found with the given ID.");
            }
        } 
        catch (SQLException e)
        {
            System.out.println("Error updating tax payment information: " + e.getMessage());
        }
    }
    
    //method to delete Tax Payment when payment Id is given.
    private static void deleteTaxPayment()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the payment ID:");
        int paymentId = sc.nextInt();

        try (Connection con = DataBaseConnection.getConnection())
        {
            String query = "delete from TaxPayment where payment_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, paymentId);
            int deleted = ps.executeUpdate();
            if (deleted > 0) 
            {
                System.out.println("Tax payment deleted successfully!");
            } 
            else 
            {
                System.out.println("No tax payment found with the given payment Id");
            }
        } 
        catch (SQLException e)
        {
            System.out.println("Error deleting tax payment: " + e.getMessage());
        }
    }

    //method to get valid format for date.
    private static String promptForDate(String message, Scanner sc) // Loop until a valid date input is provided.
    {
        while (true) // Loop until a valid date input is provided.
        {
            System.out.println(message);
            String input = sc.nextLine();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Create a SimpleDateFormat instance for parsing dates in "yyyy-MM-dd" format
            sdf.setLenient(false); // Set lenient mode to false for strict date parsing
            try 
            {
                sdf.parse(input);
                return input;
            } 
            catch (ParseException e)//Handle ParseException if input not in the given format.
            {
                System.out.println("Invalid date format.Please enter the date in YYYY-MM-DD format");
            }
        }
    }
}
