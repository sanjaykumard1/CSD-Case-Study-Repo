package taxService;

import java.util.*;
import java.sql.*;

public class TaxPayer 
{
    public static void manage() //This method is called when the user enters the choice 1.
    {
        Scanner sc = new Scanner(System.in);
        
        while (true)//the loop will continue executing until the program is terminated.
        {
            System.out.println("ENTER 1 TO REGISTER NEW TAXPAYER");
            System.out.println("ENTER 2 TO VIEW TAXPAYER DETAILS");
            System.out.println("ENTER 3 TO UPDATE TAXPAYER INFORMATION");
            System.out.println("ENTER 4 TO DELETE TAXPAYER");
            System.out.println("ENTER 5 TO RETURN MAINMENU");
            int choice = sc.nextInt();
            switch (choice) 
            {
                case 1:
                    registerTaxpayer();//calls the method registerTaxPayer() from this class.
                    break;
                    
                case 2:
                    viewTaxpayerDetails();//calls the method viewTaxPayer() from this class.
                    break;
                    
                case 3:
                    updateTaxpayer();//calls the method updateTaxPayer() from this class.
                    break;
                    
                case 4:
                    deleteTaxpayer();//calls the method deleteTaxPayer() from this class.
                    break;
                    
                case 5:
                	System.out.println("Returning to Mainmenu.....");
                    return;//returns to the Mainmenu.
                    
                default:
                    System.out.println("Your choice is invalid.Enter numbers from 1to 5");
            }
        }
    }

    //method to register new TaxPayers. 
    private static void registerTaxpayer() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your taxpayer Id:");
        int taxpayerId = sc.nextInt();
        sc.nextLine();//consumes new line to move the cursor to get other inputs too.
        
        System.out.println("Enter your name:");
        String name = sc.nextLine();
        
        System.out.println("Enter your contact number:");
        String contactNumber = sc.nextLine();
        
        System.out.println("Enter your email:");
        String email = sc.nextLine();
        
        System.out.println("Enter your address:");
        String address = sc.nextLine();
        
        System.out.println("Enter the tax ID number:");
        String taxIdNumber = sc.nextLine();
        
        //calls the method isValidContactNumber and returns the statement if the condition is false.
        if (!isValidContactNumber(contactNumber)) 
        {
            System.out.println("Invalid contact number.It should be a 10digit number");
            return;
        }
        
        //calls the method isValidEmail and returns the statement if the condition is false.
        if (!isValidEmail(email))
        {
            System.out.println("Invalid email");
            return;
        }
        
        //Code that may throw an exception.
        try (Connection con = DataBaseConnection.getConnection()) //obtain a database connection using JDBC
        {
            // Checks if the TaxPayer Id is already exists.
            String queryCheck = "select * from Taxpayer where taxpayer_id = ?";
            
            //Prepare a statement to check a query against the database connection.
            PreparedStatement psCheck = con.prepareStatement(queryCheck);
            
            psCheck.setInt(1, taxpayerId);
            //Execute the prepared statement to fetch results from the database.
            
            ResultSet rs = psCheck.executeQuery();
            //Check if there are more rows in the ResultSet.
            
            if (rs.next())
            {
                System.out.println("Taxpayer Id already exists");
                return;
            }
            
            // Checks if the contact number is already exists.
            queryCheck = "select * from Taxpayer where contact_number = ?";
            psCheck = con.prepareStatement(queryCheck);
            psCheck.setString(1, contactNumber);
            rs = psCheck.executeQuery();
            if (rs.next()) 
            {
                System.out.println("Contact number already exists");
                return;
            }

            // Checks if the email is already exists.
            queryCheck = "select * from Taxpayer where email = ?";
            psCheck = con.prepareStatement(queryCheck);
            psCheck.setString(1, email);
            rs = psCheck.executeQuery();
            if (rs.next())
            {
                System.out.println("Email already exists.");
                return;
            }

            // If it is not already exists then this query inserts new taxpayer record.
            String query = "insert into Taxpayer (taxpayer_id, name, contact_number, email, address, tax_id_number) values (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            ps.setString(2, name);
            ps.setString(3, contactNumber);
            ps.setString(4, email);
            ps.setString(5, address);
            ps.setString(6, taxIdNumber);
            ps.executeUpdate();
            System.out.println("Taxpayer registered successfully!");
        } 
        
        catch (SQLException e)//Handle specific type of exception(SQLException).
        {
            System.out.println("Error registering taxpayer: " + e.getMessage());
        }
    }
    
    //method to check the given number is a 10 digit number.
    private static boolean isValidContactNumber(String contactNumber)
    {
        return contactNumber.matches("\\d{10}");
    }
    
    //method to check the given email contains '@' symbol.
    private static boolean isValidEmail(String email)
    {
        return email.contains("@");
    }

    //method to view the details of the TaxPayers when the TaxPayer Id is given.
    private static void viewTaxpayerDetails()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your taxpayer Id:");
        int taxpayerId = sc.nextInt();
        
        try (Connection con = DataBaseConnection.getConnection())
        {
        	
        	//select query to display the TaxPayer table when the taxPayer Id is given.
            String query = "select * from Taxpayer where taxpayer_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) 
            {
                System.out.println("Taxpayer ID: " + rs.getInt("taxpayer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Contact Number: " + rs.getString("contact_number"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("Tax ID Number: " + rs.getString("tax_id_number"));
            } 
            else 
            {
                System.out.println("No taxpayer found with the given ID.");
            }
        } 
        catch (SQLException e) 
        {
            System.out.println("Error fetching taxpayer details: " + e.getMessage());
        }
    }

    //method to update the details of the TaxPayers when the TaxPayer Id is given.
    private static void updateTaxpayer() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your taxpayer Id:");
        int taxpayerId = sc.nextInt();
        sc.nextLine(); 
        System.out.println("Enter new name:");
        String name = sc.nextLine();
        System.out.println("Enter new contact number:");
        String contactNumber = sc.nextLine();
        System.out.println("Enter new email:");
        String email = sc.nextLine();
        System.out.println("Enter new address:");
        String address = sc.nextLine();
        System.out.println("Enter new tax ID number:");
        String taxIdNumber = sc.nextLine();
        
        //calls the method isValidContactNumber and returns the statement if the condition is false.
        if (!isValidContactNumber(contactNumber)) 
        {
            System.out.println("Invalid contact number.It should be a 10 digit number.");
            return;
        }
        
        //calls the method isValidEmail and returns the statement if the condition is false.
        if (!isValidEmail(email)) 
        {
            System.out.println("Invalid email");
            return;
        }
        
        try (Connection con = DataBaseConnection.getConnection())
        {
            // Checks if the contact number is already exists.
            String queryCheck = "select * from Taxpayer where contact_number = ? and taxpayer_id <> ?";
            PreparedStatement psCheck = con.prepareStatement(queryCheck);
            psCheck.setString(1, contactNumber);
            psCheck.setInt(2, taxpayerId);
            ResultSet rs = psCheck.executeQuery();
            if (rs.next()) 
            {
                System.out.println("Error: Contact number already exists.");
                return;
            }
            
            // Checks if the email is already exists.
            queryCheck = "select * from Taxpayer where email = ? and taxpayer_id <> ?";
            psCheck = con.prepareStatement(queryCheck);
            psCheck.setString(1, email);
            psCheck.setInt(2, taxpayerId);
            rs = psCheck.executeQuery();
            if (rs.next()) 
            {
                System.out.println("Email already exists");
                return;
            }
            
            // If it is not already exists then this query updates the taxpayer record.
            String query = "update Taxpayer set name = ?, contact_number = ?, email = ?, address = ?, tax_id_number = ? where taxpayer_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, contactNumber);
            ps.setString(3, email);
            ps.setString(4, address);
            ps.setString(5, taxIdNumber);
            ps.setInt(6, taxpayerId);
            ps.executeUpdate();
            System.out.println("Taxpayer information updated successfully!");
        }
        catch (SQLException e)
        {
            System.out.println("Error updating taxpayer information: " + e.getMessage());
        }
    }

    //method to delete taxpayers when the TaxPayer Id is given.
    private static void deleteTaxpayer() 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your taxpayer Id:");
        int taxpayerId = sc.nextInt();
        
        try (Connection con = DataBaseConnection.getConnection()) {
            // Delete related tax return records using TaxPayer Id.
            String query = "delete from TaxReturn where taxpayer_id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            ps.executeUpdate();
            
            // Delete related tax payment records using TaxPayer Id.
            query = "DELETE FROM TaxPayment WHERE taxpayer_id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            ps.executeUpdate();
            
            // Delete taxpayer record using TaxPayer Id.
            query = "delete from Taxpayer where taxpayer_id = ?";
            ps = con.prepareStatement(query);
            ps.setInt(1, taxpayerId);
            int deletedTaxpayer = ps.executeUpdate();
            
            //if any rows affected then it will be greater than zero only that means the records are deleted.
            if (deletedTaxpayer > 0) 
            {
                System.out.println("Taxpayer and all related records deleted successfully");
            }
            
            //if no rows affected then it will be zero only that means no records are deleted.
            else
            {
                System.out.println("No taxpayer found with the given Id.");
            }
        } 
        catch (SQLException e) 
        {
        	//Print an error message indicating failure to delete taxpayer.
            System.out.println("Error deleting taxpayer: " + e.getMessage());
        }
    }
}
