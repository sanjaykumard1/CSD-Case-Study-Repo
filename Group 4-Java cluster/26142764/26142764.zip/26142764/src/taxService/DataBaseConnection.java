package taxService;

import java.sql.*;

public class DataBaseConnection 
{
    private static final String url = "jdbc:mysql://localhost:3306/taxservice";
    private static final String user = "root";
    private static final String password = "Kavya@12";

    /*Establishes a connection to the MySQL database 
    using the specified URL, username, and password.*/
    public static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(url, user, password);
    }
}

