package taxService;

import java.util.*;

public class Main
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		
		while(true)//the loop will continue executing until the program is terminated.
		{
			System.out.println("WELCOME TO THE TAX SERVICE MANAGEMENT SYSTEM");
			System.out.println("ENTER 1 TO MANAGE TAXPAYERS");
			System.out.println("ENTER 2 TO MANAGE TAX RETURNS ");
			System.out.println("ENTER 3 TO MANAGE TAX PAYMENTS ");
			System.out.println("ENTER 4 TO EXIT");
			
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1: TaxPayer.manage();//calls the method manage() from TaxPayer class.
			        break;
			        
			case 2: TaxReturn.manage();//calls the method manage() from TaxReturn class.
			        break;
			        
			case 3: TaxPayment.manage();//calls the method manage() from TaxPayment class.
	                break;
	                
	        case 4: System.out.println("exited from the application!");
	        	    System.exit(0);//exits from the program.
	                
	        default: System.out.println("your choice is invalid!\nEnter numbers from 1 to 4");        
			
			}

		}
		
	}

}
