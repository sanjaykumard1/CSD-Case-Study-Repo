Grade Calculation 

Overview

This Java package, `com.gradeCalculation`, provides a comprehensive system to manage various aspects of a school, including students, teachers, courses, and grades. The main class, `gradeCalculationApp`, serves as the entry point for the application and offers a menu-driven interface for users to interact with the system.

Package Structure

- `gradeCalculationApp`: The main class containing the menu-driven interface and logic to handle user interactions.
- `DatabaseConnection`: A utility class to manage database connections.
- `StudentManagement`: A class to handle student-related operations.
- `TeacherManagement`: A class to handle teacher-related operations.
- `CourseManagement`: A class to handle course-related operations.
- `GradeManagement`: A class to handle grade-related operations.

How to Use

1. Run the Application
   - Execute the `main` method in the `gradeCalculationApp` class to start the application.

2. Main Menu
   - The application presents a main menu with the following options:
     1. Student Management
     2. Teacher Management
     3. Course Management
     4. Grade Management
     5. Exit

3. Student Management
   - The Student Management menu provides options to add, view, update, and delete student records.
   - Select the desired operation by entering the corresponding number.

4. Teacher Management
   - The Teacher Management menu provides options to add, view, update, and delete teacher records.
   - Select the desired operation by entering the corresponding number.

5. Course Management
   - The Course Management menu provides options to add, view, update, and delete course records.
   - Select the desired operation by entering the corresponding number.

6. Grade Management
   - The Grade Management menu provides options to assign grades, view grades, update grades, and calculate GPA.
   - Select the desired operation by entering the corresponding number.

Error Handling

- The application handles SQL exceptions and invalid input gracefully by displaying appropriate error messages and allowing the user to retry their actions.

Dependencies

- Java Development Kit (JDK)
- JDBC-compatible database (e.g., MySQL, PostgreSQL)

Authors

This package is developed by Harsh Pathak.
