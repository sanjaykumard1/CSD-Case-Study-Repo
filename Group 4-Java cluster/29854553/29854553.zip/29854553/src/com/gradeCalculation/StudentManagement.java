package com.gradeCalculation;

import java.sql.*;
import java.util.Scanner;

public class StudentManagement {
    private Connection connection;
    private Scanner scanner;

    public StudentManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addStudent() {
        try {
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            System.out.print("Enter address: ");
            String address = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();

            String sql = "INSERT INTO Student (name, date_of_birth, address, email) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setDate(2, Date.valueOf(dateOfBirth));
            statement.setString(3, address);
            statement.setString(4, email);
            statement.executeUpdate();
            System.out.println("Student added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewStudent() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Student WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Student ID: " + resultSet.getInt("student_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Date of Birth: " + resultSet.getDate("date_of_birth"));
                System.out.println("Address: " + resultSet.getString("address"));
                System.out.println("Email: " + resultSet.getString("email"));
            } else {
                System.out.println("Student not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateStudent() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            System.out.print("Enter new address: ");
            String address = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();

            String sql = "UPDATE Student SET name = ?, date_of_birth = ?, address = ?, email = ? WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setDate(2, Date.valueOf(dateOfBirth));
            statement.setString(3, address);
            statement.setString(4, email);
            statement.setInt(5, studentId);
            statement.executeUpdate();
            System.out.println("Student updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteStudent() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Student WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, studentId);
            statement.executeUpdate();
            System.out.println("Student deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
