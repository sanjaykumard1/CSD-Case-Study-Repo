package com.gradeCalculation;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class gradeCalculationApp {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            StudentManagement studentManagement = new StudentManagement(connection, scanner);
            TeacherManagement teacherManagement = new TeacherManagement(connection, scanner);
            CourseManagement courseManagement = new CourseManagement(connection, scanner);
            GradeManagement gradeManagement = new GradeManagement(connection, scanner);

            while (true) {
                System.out.println("School Management System");
                System.out.println("1. Student Management");
                System.out.println("2. Teacher Management");
                System.out.println("3. Course Management");
                System.out.println("4. Grade Management");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        manageStudents(studentManagement, scanner);
                        break;
                    case 2:
                        manageTeachers(teacherManagement, scanner);
                        break;
                    case 3:
                        manageCourses(courseManagement, scanner);
                        break;
                    case 4:
                        manageGrades(gradeManagement, scanner);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageStudents(StudentManagement studentManagement, Scanner scanner) {
        while (true) {
            System.out.println("Student Management");
            System.out.println("1. Add Student");
            System.out.println("2. View Student");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    studentManagement.addStudent();
                    break;
                case 2:
                    studentManagement.viewStudent();
                    break;
                case 3:
                    studentManagement.updateStudent();
                    break;
                case 4:
                    studentManagement.deleteStudent();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageTeachers(TeacherManagement teacherManagement, Scanner scanner) {
        while (true) {
            System.out.println("Teacher Management");
            System.out.println("1. Add Teacher");
            System.out.println("2. View Teacher");
            System.out.println("3. Update Teacher");
            System.out.println("4. Delete Teacher");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    teacherManagement.addTeacher();
                    break;
                case 2:
                    teacherManagement.viewTeacher();
                    break;
                case 3:
                    teacherManagement.updateTeacher();
                    break;
                case 4:
                    teacherManagement.deleteTeacher();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageCourses(CourseManagement courseManagement, Scanner scanner) {
        while (true) {
            System.out.println("Course Management");
            System.out.println("1. Add Course");
            System.out.println("2. View Course");
            System.out.println("3. Update Course");
            System.out.println("4. Delete Course");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    courseManagement.addCourse();
                    break;
                case 2:
                    courseManagement.viewCourse();
                    break;
                case 3:
                    courseManagement.updateCourse();
                    break;
                case 4:
                    courseManagement.deleteCourse();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageGrades(GradeManagement gradeManagement, Scanner scanner) {
        while (true) {
            System.out.println("Grade Management");
            System.out.println("1. Assign Grade");
            System.out.println("2. View Grades");
            System.out.println("3. Update Grade");
            System.out.println("4. Calculate GPA");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    gradeManagement.assignGrade();
                    break;
                case 2:
                    gradeManagement.viewGrades();
                    break;
                case 3:
                    gradeManagement.updateGrade();
                    break;
                case 4:
                    gradeManagement.calculateGPA();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
