package com.gradeCalculation;

import java.sql.*;
import java.util.Scanner;

public class CourseManagement {
    private Connection connection;
    private Scanner scanner;

    public CourseManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addCourse() {
        try {
            System.out.print("Enter course title: ");
            String title = scanner.nextLine();
            System.out.print("Enter course description: ");
            String description = scanner.nextLine();
            System.out.print("Enter teacher ID: ");
            int teacherId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "INSERT INTO Course (title, description, teacher_id) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, title);
            statement.setString(2, description);
            statement.setInt(3, teacherId);
            statement.executeUpdate();
            System.out.println("Course added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewCourse() {
        try {
            System.out.print("Enter course ID: ");
            int courseId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Course WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, courseId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Course ID: " + resultSet.getInt("course_id"));
                System.out.println("Title: " + resultSet.getString("title"));
                System.out.println("Description: " + resultSet.getString("description"));
                System.out.println("Teacher ID: " + resultSet.getInt("teacher_id"));
            } else {
                System.out.println("Course not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCourse() {
        try {
            System.out.print("Enter course ID: ");
            int courseId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new title: ");
            String title = scanner.nextLine();
            System.out.print("Enter new description: ");
            String description = scanner.nextLine();
            System.out.print("Enter new teacher ID: ");
            int teacherId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "UPDATE Course SET title = ?, description = ?, teacher_id = ? WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, title);
            statement.setString(2, description);
            statement.setInt(3, teacherId);
            statement.setInt(4, courseId);
            statement.executeUpdate();
            System.out.println("Course updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCourse() {
        try {
            System.out.print("Enter course ID: ");
            int courseId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Course WHERE course_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, courseId);
            statement.executeUpdate();
            System.out.println("Course deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
