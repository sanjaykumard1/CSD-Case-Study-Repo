package com.gradeCalculation;

import java.sql.*;
import java.util.Scanner;

public class TeacherManagement {
    private Connection connection;
    private Scanner scanner;

    public TeacherManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addTeacher() {
        try {
            System.out.print("Enter teacher name: ");
            String name = scanner.nextLine();
            System.out.print("Enter date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            System.out.print("Enter address: ");
            String address = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();

            String sql = "INSERT INTO Teacher (name, date_of_birth, address, email) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setDate(2, Date.valueOf(dateOfBirth));
            statement.setString(3, address);
            statement.setString(4, email);
            statement.executeUpdate();
            System.out.println("Teacher added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewTeacher() {
        try {
            System.out.print("Enter teacher ID: ");
            int teacherId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Teacher WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, teacherId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Teacher ID: " + resultSet.getInt("teacher_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Date of Birth: " + resultSet.getDate("date_of_birth"));
                System.out.println("Address: " + resultSet.getString("address"));
                System.out.println("Email: " + resultSet.getString("email"));
            } else {
                System.out.println("Teacher not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTeacher() {
        try {
            System.out.print("Enter teacher ID: ");
            int teacherId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new date of birth (YYYY-MM-DD): ");
            String dateOfBirth = scanner.nextLine();
            System.out.print("Enter new address: ");
            String address = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();

            String sql = "UPDATE Teacher SET name = ?, date_of_birth = ?, address = ?, email = ? WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setDate(2, Date.valueOf(dateOfBirth));
            statement.setString(3, address);
            statement.setString(4, email);
            statement.setInt(5, teacherId);
            statement.executeUpdate();
            System.out.println("Teacher updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteTeacher() {
        try {
            System.out.print("Enter teacher ID: ");
            int teacherId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Teacher WHERE teacher_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, teacherId);
            statement.executeUpdate();
            System.out.println("Teacher deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
