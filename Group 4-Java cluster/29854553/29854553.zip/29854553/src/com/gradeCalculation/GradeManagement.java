package com.gradeCalculation;

import java.sql.*;
import java.util.Scanner;

public class GradeManagement {
    private Connection connection;
    private Scanner scanner;

    public GradeManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void assignGrade() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            System.out.print("Enter course ID: ");
            int courseId = scanner.nextInt();
            System.out.print("Enter grade: ");
            double grade = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            String sql = "INSERT INTO Grade (student_id, course_id, grade) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, studentId);
            statement.setInt(2, courseId);
            statement.setDouble(3, grade);
            statement.executeUpdate();
            System.out.println("Grade assigned successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewGrades() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine();

            String sql = "SELECT g.grade_id, g.grade, c.title FROM Grade g JOIN Course c ON g.course_id = c.course_id WHERE g.student_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Grade ID: " + resultSet.getInt("grade_id"));
                System.out.println("Course Title: " + resultSet.getString("title"));
                System.out.println("Grade: " + resultSet.getDouble("grade"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateGrade() {
        try {
            System.out.print("Enter grade ID: ");
            int gradeId = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter new grade: ");
            double grade = scanner.nextDouble();
            scanner.nextLine();

            String sql = "UPDATE Grade SET grade = ? WHERE grade_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setDouble(1, grade);
            statement.setInt(2, gradeId);
            statement.executeUpdate();
            System.out.println("Grade updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void calculateGPA() {
        try {
            System.out.print("Enter student ID: ");
            int studentId = scanner.nextInt();
            scanner.nextLine();

            String sql = "SELECT AVG(grade) AS gpa FROM Grade WHERE student_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, studentId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("GPA: " + resultSet.getDouble("gpa"));
            } else {
                System.out.println("No grades found for the student.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
