import java.sql.*;

public class Room {
    private int roomNumber;
    private String type;
    private double pricePerNight;
    private boolean availabilityStatus;

    public Room(int roomNumber, String type, double pricePerNight, boolean availabilityStatus) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.pricePerNight = pricePerNight;
        this.availabilityStatus = availabilityStatus;
    }

    // Getters and setters

    public static void addRoom(Connection conn, Room room) throws SQLException {
        String sql = "INSERT INTO Room (room_number, type, price_per_night, availability_status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, room.getRoomNumber());
            pstmt.setString(2, room.getType());
            pstmt.setDouble(3, room.getPricePerNight());
            pstmt.setBoolean(4, room.isAvailabilityStatus());
            pstmt.executeUpdate();
        }
    }

    public static void viewRoom(Connection conn, int roomNumber) throws SQLException {
        String sql = "SELECT * FROM Room WHERE room_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, roomNumber);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Room Number: " + rs.getInt("room_number"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Price per Night: " + rs.getDouble("price_per_night"));
                System.out.println("Availability Status: " + rs.getBoolean("availability_status"));
            }
        }
    }

    public static void updateRoom(Connection conn, Room room) throws SQLException {
        String sql = "UPDATE Room SET type = ?, price_per_night = ?, availability_status = ? WHERE room_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, room.getType());
            pstmt.setDouble(2, room.getPricePerNight());
            pstmt.setBoolean(3, room.isAvailabilityStatus());
            pstmt.setInt(4, room.getRoomNumber());
            pstmt.executeUpdate();
        }
    }

    public static void deleteRoom(Connection conn, int roomNumber) throws SQLException {
        String sql = "DELETE FROM Room WHERE room_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, roomNumber);
            pstmt.executeUpdate();
        }
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public boolean isAvailabilityStatus() {
        return availabilityStatus;
    }

    public void setAvailabilityStatus(boolean availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

	public static Room getRoom(Connection conn, int roomNumber2) {
		// TODO Auto-generated method stub
		return null;
	}
}
