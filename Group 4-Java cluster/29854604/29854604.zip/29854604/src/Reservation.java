import java.sql.*;
import java.time.LocalDate;

public class Reservation {
    private int reservationId;
    private int roomNumber;
    private int guestId;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private double totalPrice;

    public Reservation(int reservationId, int roomNumber, int guestId, LocalDate checkInDate, LocalDate checkOutDate, double totalPrice) {
        this.reservationId = reservationId;
        this.roomNumber = roomNumber;
        this.guestId = guestId;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalPrice = totalPrice;
    }

    // Getters and setters

    public static void addReservation(Connection conn, Reservation reservation) throws SQLException {
        String sql = "INSERT INTO Reservation (room_number, guest_id, check_in_date, check_out_date, total_price) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, reservation.getRoomNumber());
            pstmt.setInt(2, reservation.getGuestId());
            pstmt.setDate(3, Date.valueOf(reservation.getCheckInDate()));
            pstmt.setDate(4, Date.valueOf(reservation.getCheckOutDate()));
            pstmt.setDouble(5, reservation.getTotalPrice());
            pstmt.executeUpdate();

            ResultSet keys = pstmt.getGeneratedKeys();
            if (keys.next()) {
                reservation.setReservationId(keys.getInt(1));
            }

            // Update room availability
            Room room = Room.getRoom(conn, reservation.getRoomNumber());
            room.setAvailabilityStatus(false);
            Room.updateRoom(conn, room);
        }
    }

    public static void viewReservation(Connection conn, int reservationId) throws SQLException {
        String sql = "SELECT * FROM Reservation WHERE reservation_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, reservationId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Reservation ID: " + rs.getInt("reservation_id"));
                System.out.println("Room Number: " + rs.getInt("room_number"));
                System.out.println("Guest ID: " + rs.getInt("guest_id"));
                System.out.println("Check-in Date: " + rs.getDate("check_in_date"));
                System.out.println("Check-out Date: " + rs.getDate("check_out_date"));
                System.out.println("Total Price: " + rs.getDouble("total_price"));
            }
        }
    }

    public static void updateReservation(Connection conn, Reservation reservation) throws SQLException {
        String sql = "UPDATE Reservation SET room_number = ?, guest_id = ?, check_in_date = ?, check_out_date = ?, total_price = ? WHERE reservation_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, reservation.getRoomNumber());
            pstmt.setInt(2, reservation.getGuestId());
            pstmt.setDate(3, Date.valueOf(reservation.getCheckInDate()));
            pstmt.setDate(4, Date.valueOf(reservation.getCheckOutDate()));
            pstmt.setDouble(5, reservation.getTotalPrice());
            pstmt.setInt(6, reservation.getReservationId());
            pstmt.executeUpdate();
        }
    }

    public static void deleteReservation(Connection conn, int reservationId) throws SQLException {
        // Get room number before deletion
        int roomNumber = -1;
        String selectSql = "SELECT room_number FROM Reservation WHERE reservation_id = ?";
        try (PreparedStatement selectPstmt = conn.prepareStatement(selectSql)) {
            selectPstmt.setInt(1, reservationId);
            ResultSet rs = selectPstmt.executeQuery();
            if (rs.next()) {
                roomNumber = rs.getInt("room_number");
            }
        }

        // Delete reservation
        String deleteSql = "DELETE FROM Reservation WHERE reservation_id = ?";
        try (PreparedStatement deletePstmt = conn.prepareStatement(deleteSql)) {
            deletePstmt.setInt(1, reservationId);
            deletePstmt.executeUpdate();
        }

        // Update room availability
        if (roomNumber != -1) {
            Room room = Room.getRoom(conn, roomNumber);
            room.setAvailabilityStatus(true);
            Room.updateRoom(conn, room);
        }
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public int getGuestId() {
        return guestId;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
}
