import java.sql.*;
import java.util.Scanner;
import java.time.LocalDate;

public class HotelManagementSystem {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/raghu2";
    private static final String USER = "root";
    private static final String PASS = "chinnu@143"; // Update with your MySQL password

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("\nHotel Management System");
                System.out.println("1. Room Management");
                System.out.println("2. Guest Management");
                System.out.println("3. Reservation Management");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        roomManagement(conn, scanner);
                        break;
                    case 2:
                        guestManagement(conn, scanner);
                        break;
                    case 3:
                        reservationManagement(conn, scanner);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void roomManagement(Connection conn, Scanner scanner) throws SQLException {
        System.out.println("\nRoom Management");
        System.out.println("1. Add Room");
        System.out.println("2. View Room");
        System.out.println("3. Update Room");
        System.out.println("4. Delete Room");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter room number: ");
                int roomNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter type: ");
                String type = scanner.nextLine();
                System.out.print("Enter price per night: ");
                double pricePerNight = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Enter availability status (true/false): ");
                boolean availabilityStatus = scanner.nextBoolean();
                scanner.nextLine();
                Room.addRoom(conn, new Room(roomNumber, type, pricePerNight, availabilityStatus));
                break;
            case 2:
                System.out.print("Enter room number: ");
                roomNumber = scanner.nextInt();
                scanner.nextLine();
                Room.viewRoom(conn, roomNumber);
                break;
            case 3:
                System.out.print("Enter room number: ");
                roomNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new type: ");
                type = scanner.nextLine();
                System.out.print("Enter new price per night: ");
                pricePerNight = scanner.nextDouble();
                scanner.nextLine();
                System.out.print("Enter new availability status (true/false): ");
                availabilityStatus = scanner.nextBoolean();
                scanner.nextLine();
                Room.updateRoom(conn, new Room(roomNumber, type, pricePerNight, availabilityStatus));
                break;
            case 4:
                System.out.print("Enter room number: ");
                roomNumber = scanner.nextInt();
                scanner.nextLine();
                Room.deleteRoom(conn, roomNumber);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void guestManagement(Connection conn, Scanner scanner) throws SQLException {
        System.out.println("\nGuest Management");
        System.out.println("1. Register Guest");
        System.out.println("2. View Guest");
        System.out.println("3. Update Guest");
        System.out.println("4. Delete Guest");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.nextLine();
                System.out.print("Enter address: ");
                String address = scanner.nextLine();
                Guest.addGuest(conn, new Guest(0, name, email, phoneNumber, address));
                break;
            case 2:
                System.out.print("Enter guest ID: ");
                int guestId = scanner.nextInt();
                scanner.nextLine();
                Guest.viewGuest(conn, guestId);
                break;
            case 3:
                System.out.print("Enter guest ID: ");
                guestId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new name: ");
                name = scanner.nextLine();
                System.out.print("Enter new email: ");
                email = scanner.nextLine();
                System.out.print("Enter new phone number: ");
                phoneNumber = scanner.nextLine();
                System.out.print("Enter new address: ");
                address = scanner.nextLine();
                Guest.updateGuest(conn, new Guest(guestId, name, email, phoneNumber, address));
                break;
            case 4:
                System.out.print("Enter guest ID: ");
                guestId = scanner.nextInt();
                scanner.nextLine();
                Guest.deleteGuest(conn, guestId);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void reservationManagement(Connection conn, Scanner scanner) throws SQLException {
        System.out.println("\nReservation Management");
        System.out.println("1. Make Reservation");
        System.out.println("2. View Reservation");
        System.out.println("3. Update Reservation");
        System.out.println("4. Cancel Reservation");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter room number: ");
                int roomNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter guest ID: ");
                int guestId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter check-in date (YYYY-MM-DD): ");
                LocalDate checkInDate = LocalDate.parse(scanner.nextLine());
                System.out.print("Enter check-out date (YYYY-MM-DD): ");
                LocalDate checkOutDate = LocalDate.parse(scanner.nextLine());
                double totalPrice = Room.getRoom(conn, roomNumber).getPricePerNight() *
                        (checkOutDate.toEpochDay() - checkInDate.toEpochDay());
                Reservation.addReservation(conn, new Reservation(0, roomNumber, guestId, checkInDate, checkOutDate, totalPrice));
                break;
            case 2:
                System.out.print("Enter reservation ID: ");
                int reservationId = scanner.nextInt();
                scanner.nextLine();
                Reservation.viewReservation(conn, reservationId);
                break;
            case 3:
                System.out.print("Enter reservation ID: ");
                reservationId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new room number: ");
                roomNumber = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new guest ID: ");
                guestId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new check-in date (YYYY-MM-DD): ");
                checkInDate = LocalDate.parse(scanner.nextLine());
                System.out.print("Enter new check-out date (YYYY-MM-DD): ");
                checkOutDate = LocalDate.parse(scanner.nextLine());
                totalPrice = Room.getRoom(conn, roomNumber).getPricePerNight() *
                        (checkOutDate.toEpochDay() - checkInDate.toEpochDay());
                Reservation.updateReservation(conn, new Reservation(reservationId, roomNumber, guestId, checkInDate, checkOutDate, totalPrice));
                break;
            case 4:
                System.out.print("Enter reservation ID: ");
                reservationId = scanner.nextInt();
                scanner.nextLine();
                Reservation.deleteReservation(conn, reservationId);
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}
