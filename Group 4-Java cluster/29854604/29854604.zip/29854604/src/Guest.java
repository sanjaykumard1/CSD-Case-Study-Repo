import java.sql.*;

public class Guest {
    private int guestId;
    private String name;
    private String email;
    private String phoneNumber;
    private String address;

    public Guest(int guestId, String name, String email, String phoneNumber, String address) {
        this.guestId = guestId;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Getters and setters

    public static void addGuest(Connection conn, Guest guest) throws SQLException {
        String sql = "INSERT INTO Guest (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, guest.getName());
            pstmt.setString(2, guest.getEmail());
            pstmt.setString(3, guest.getPhoneNumber());
            pstmt.setString(4, guest.getAddress());
            pstmt.executeUpdate();

            ResultSet keys = pstmt.getGeneratedKeys();
            if (keys.next()) {
                guest.setGuestId(keys.getInt(1));
            }
        }
    }

    public static void viewGuest(Connection conn, int guestId) throws SQLException {
        String sql = "SELECT * FROM Guest WHERE guest_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, guestId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Guest ID: " + rs.getInt("guest_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
            }
        }
    }

    public static void updateGuest(Connection conn, Guest guest) throws SQLException {
        String sql = "UPDATE Guest SET name = ?, email = ?, phone_number = ?, address = ? WHERE guest_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, guest.getName());
            pstmt.setString(2, guest.getEmail());
            pstmt.setString(3, guest.getPhoneNumber());
            pstmt.setString(4, guest.getAddress());
            pstmt.setInt(5, guest.getGuestId());
            pstmt.executeUpdate();
        }
    }

    public static void deleteGuest(Connection conn, int guestId) throws SQLException {
        String sql = "DELETE FROM Guest WHERE guest_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, guestId);
            pstmt.executeUpdate();
        }
    }

    public int getGuestId() {
        return guestId;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
