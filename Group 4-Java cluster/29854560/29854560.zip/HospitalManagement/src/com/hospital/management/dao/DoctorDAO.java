package com.hospital.management.dao;

import com.hospital.management.model.Doctor;
import java.util.List;

public interface DoctorDAO {
    void addDoctor(Doctor doctor);
    Doctor getDoctor(int doctorId);
    void updateDoctor(Doctor doctor);
    void deleteDoctor(int doctorId);
    List<Doctor> getAllDoctors();
}
