package com.hospital.management.dao.impl;

import com.hospital.management.dao.MedicalRecordDAO;
import com.hospital.management.model.MedicalRecord;
import com.hospital.management.util.DatabaseUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAOImpl implements MedicalRecordDAO {
    @Override
    public void addMedicalRecord(MedicalRecord medicalRecord) {
        String query = "INSERT INTO MedicalRecord (patient_id, doctor_id, date, diagnosis, treatment) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, medicalRecord.getPatientId());
            preparedStatement.setInt(2, medicalRecord.getDoctorId());
            preparedStatement.setString(3, medicalRecord.getDate());
            preparedStatement.setString(4, medicalRecord.getDiagnosis());
            preparedStatement.setString(5, medicalRecord.getTreatment());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public MedicalRecord getMedicalRecord(int recordId) {
        String query = "SELECT * FROM MedicalRecord WHERE record_id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, recordId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                MedicalRecord medicalRecord = new MedicalRecord();
                medicalRecord.setRecordId(resultSet.getInt("record_id"));
                medicalRecord.setPatientId(resultSet.getInt("patient_id"));
                medicalRecord.setDoctorId(resultSet.getInt("doctor_id"));
                medicalRecord.setDate(resultSet.getString("date"));
                medicalRecord.setDiagnosis(resultSet.getString("diagnosis"));
                medicalRecord.setTreatment(resultSet.getString("treatment"));
                return medicalRecord;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void updateMedicalRecord(MedicalRecord medicalRecord) {
        String query = "UPDATE MedicalRecord SET patient_id = ?, doctor_id = ?, date = ?, diagnosis = ?, treatment = ? WHERE record_id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, medicalRecord.getPatientId());
            preparedStatement.setInt(2, medicalRecord.getDoctorId());
            preparedStatement.setString(3, medicalRecord.getDate());
            preparedStatement.setString(4, medicalRecord.getDiagnosis());
            preparedStatement.setString(5, medicalRecord.getTreatment());
            preparedStatement.setInt(6, medicalRecord.getRecordId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMedicalRecord(int recordId) {
        String query = "DELETE FROM MedicalRecord WHERE record_id = ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, recordId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<MedicalRecord> getAllMedicalRecords() {
        List<MedicalRecord> medicalRecords = new ArrayList<>();
        String query = "SELECT * FROM MedicalRecord";
        try (Connection connection = DatabaseUtil.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                MedicalRecord medicalRecord = new MedicalRecord();
                medicalRecord.setRecordId(resultSet.getInt("record_id"));
                medicalRecord.setPatientId(resultSet.getInt("patient_id"));
                medicalRecord.setDoctorId(resultSet.getInt("doctor_id"));
                medicalRecord.setDate(resultSet.getString("date"));
                medicalRecord.setDiagnosis(resultSet.getString("diagnosis"));
                medicalRecord.setTreatment(resultSet.getString("treatment"));
                medicalRecords.add(medicalRecord);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicalRecords;
    }
}
