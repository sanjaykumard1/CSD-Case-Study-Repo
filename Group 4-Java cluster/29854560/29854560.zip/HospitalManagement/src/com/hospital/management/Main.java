package com.hospital.management;

import com.hospital.management.dao.DoctorDAO;
import com.hospital.management.dao.MedicalRecordDAO;
import com.hospital.management.dao.PatientDAO;
import com.hospital.management.dao.impl.DoctorDAOImpl;
import com.hospital.management.dao.impl.MedicalRecordDAOImpl;
import com.hospital.management.dao.impl.PatientDAOImpl;
import com.hospital.management.model.Doctor;
import com.hospital.management.model.MedicalRecord;
import com.hospital.management.model.Patient;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final PatientDAO patientDAO = new PatientDAOImpl();
    private static final DoctorDAO doctorDAO = new DoctorDAOImpl();
    private static final MedicalRecordDAO medicalRecordDAO = new MedicalRecordDAOImpl();
//FORMATTING STARTS
    private static void printTitle(String title) {
        System.out.println("============================================");
        System.out.println("         " + title);
        System.out.println("============================================");
    }

    private static void printMenu() {
        printTitle("Hospital Management System");
        System.out.println("1. Manage Patients");
        System.out.println("2. Manage Doctors");
        System.out.println("3. Manage Medical Records");
        System.out.println("4. Exit");
        prompt("Enter your choice ");
    }

    private static void prompt(String message) {
        System.out.print(String.format("%-30s: ", message));
    }

    private static void printMessage(String message) {
        System.out.println( "<<<<<<<<< "+ message+" >>>>>>>>>");
    }

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            printMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    managePatients();
                    break;
                case 2:
                    manageDoctors();
                    break;
                case 3:
                    manageMedicalRecords();
                    break;
                case 4:
                    printMessage("Exiting Hospital Management System. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    printMessage("Invalid choice. Please try again.");
            }
        }
        printMessage("Exiting Hospital Management System. Goodbye!");
    }

//PATIENT RELATED METHODS
    private static void managePatients() {
        while (true) {
            System.out.println();
            printTitle("Patient Management");
            System.out.println("1. Register a new patient");
            System.out.println("2. View patient details");
            System.out.println("3. Update patient information");
            System.out.println("4. Delete a patient");
            System.out.println("5. Back to main menu");
            prompt("Enter your choice ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addPatient();
                    break;
                case 2:
                    viewPatient();
                    break;
                case 3:
                    updatePatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    return;
                default:
                    printMessage("Invalid choice. Please try again.");
            }
        }
    }

    private static void addPatient() {
        System.out.println();
        printMessage("Patient Registration");
        prompt("Enter name ");
        String name = scanner.nextLine();
        prompt("Enter date of birth (yyyy-mm-dd) ");
        String dateOfBirth = scanner.nextLine();
        prompt("Enter gender ");
        String gender = scanner.nextLine();
        prompt("Enter address ");
        String address = scanner.nextLine();

        Patient patient = new Patient();
        patient.setName(name);
        patient.setDateOfBirth(dateOfBirth);
        patient.setGender(gender);
        patient.setAddress(address);

        patientDAO.addPatient(patient);
        printMessage("Patient registered successfully.");
        //printSeparator();

    }

    private static void viewPatient() {
        System.out.println();
        prompt("Enter patient ID ");
        int patientId = scanner.nextInt();
        scanner.nextLine();

        Patient patient = patientDAO.getPatient(patientId);
        if (patient != null) {
            printMessage("Patient Details");
            System.out.println("ID: " + patient.getPatientId());
            System.out.println("Name: " + patient.getName());
            System.out.println("Date of Birth: " + patient.getDateOfBirth());
            System.out.println("Gender: " + patient.getGender());
            System.out.println("Address: " + patient.getAddress());
        } else {
            printMessage("Patient not found.");
        }
        System.out.println("\n");
        //printSeparator();
    }

    private static void updatePatient() {
        System.out.println();
        prompt("Enter patient ID ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Patient patient = patientDAO.getPatient(patientId);
        if (patient != null) {
            boolean updating = true;

            while (updating) {
                System.out.println();
                printMessage("Select the field to update:");
                System.out.println("1. Name");
                System.out.println("2. Date of Birth");
                System.out.println("3. Gender");
                System.out.println("4. Address");
                System.out.println("5. Exit");

                prompt("Enter your choice ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        prompt("Enter new name ");
                        String name = scanner.nextLine();
                        patient.setName(name);
                        break;
                    case 2:
                        prompt("Enter new date of birth (yyyy-mm-dd) ");
                        String dateOfBirth = scanner.nextLine();
                        patient.setDateOfBirth(dateOfBirth);
                        break;
                    case 3:
                        prompt("Enter new gender ");
                        String gender = scanner.nextLine();
                        patient.setGender(gender);
                        break;
                    case 4:
                        prompt("Enter new address ");
                        String address = scanner.nextLine();
                        patient.setAddress(address);
                        break;
                    case 5:
                        updating = false;
                        break;
                    default:
                        printMessage("Invalid choice. Please try again.");
                        continue;
                }

                if (choice >= 1 && choice <= 4) {
                    patientDAO.updatePatient(patient);
                    printMessage("Patient information updated successfully.");
                }
            }
        } else {
            printMessage("Patient not found.");
        }
        System.out.println("\n");
    }

    private static void deletePatient() {
        System.out.println();
        prompt("Enter patient ID ");
        int patientId = scanner.nextInt();
        scanner.nextLine();

        patientDAO.deletePatient(patientId);
        printMessage("Patient deleted successfully.");
        System.out.println("\n");
    }

//DOCTOR RELATED METHODS
    private static void manageDoctors() {
        while (true) {
            System.out.println();
            printTitle("Doctor Management");
            System.out.println("1. Add a new doctor");
            System.out.println("2. View doctor details");
            System.out.println("3. Update doctor information");
            System.out.println("4. Delete a doctor");
            System.out.println("5. Back to main menu");
            prompt("Enter your choice ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addDoctor();
                    break;
                case 2:
                    viewDoctor();
                    break;
                case 3:
                    updateDoctor();
                    break;
                case 4:
                    deleteDoctor();
                    break;
                case 5:
                    return;
                default:
                    printMessage("Invalid choice. Please try again.");
            }
            //printSeparator();
        }
    }

    private static void addDoctor() {
        System.out.println();
        prompt("Enter name: ");
        String name = scanner.nextLine();
        prompt("Enter specialization: ");
        String specialization = scanner.nextLine();
        prompt("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        prompt("Enter email: ");
        String email = scanner.nextLine();

        Doctor doctor = new Doctor();
        doctor.setName(name);
        doctor.setSpecialization(specialization);
        doctor.setContactNumber(contactNumber);
        doctor.setEmail(email);

        doctorDAO.addDoctor(doctor);
        printMessage("Doctor added successfully.");
        //printSeparator();
        System.out.println("\n");
    }

    private static void viewDoctor() {
        System.out.println();
        prompt("Enter doctor ID ");
        int doctorId = scanner.nextInt();
        scanner.nextLine();

        Doctor doctor = doctorDAO.getDoctor(doctorId);
        if (doctor != null) {
            printMessage("Doctor Details");
            System.out.println("ID: " + doctor.getDoctorId());
            System.out.println("Name: " + doctor.getName());
            System.out.println("Specialization: " + doctor.getSpecialization());
            System.out.println("Contact Number: " + doctor.getContactNumber());
            System.out.println("Email: " + doctor.getEmail());
        } else {
            printMessage("Doctor not found.");
        }
        //printSeparator();
        System.out.println("\n");
    }

    private static void updateDoctor() {
        System.out.println();
        prompt("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Doctor doctor = doctorDAO.getDoctor(doctorId);
        if (doctor != null) {
            boolean updating = true;

            while (updating) {
                System.out.println();
                printMessage("Select the field to update:");
                System.out.println("1. Name");
                System.out.println("2. Specialization");
                System.out.println("3. Contact Number");
                System.out.println("4. Email");
                System.out.println("5. Exit");

                prompt("Enter your choice ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        prompt("Enter new name ");
                        String name = scanner.nextLine();
                        doctor.setName(name);
                        break;
                    case 2:
                        prompt("Enter new specialization ");
                        String specialization = scanner.nextLine();
                        doctor.setSpecialization(specialization);
                        break;
                    case 3:
                        prompt("Enter new contact number ");
                        String contactNumber = scanner.nextLine();
                        doctor.setContactNumber(contactNumber);
                        break;
                    case 4:
                        prompt("Enter new email ");
                        String email = scanner.nextLine();
                        doctor.setEmail(email);
                        break;
                    case 5:
                        updating = false;
                        break;
                    default:
                        printMessage("Invalid choice. Please try again.");
                        continue;
                }

                if (choice >= 1 && choice <= 4) {
                    doctorDAO.updateDoctor(doctor);
                    printMessage("Doctor information updated successfully.");
                }
            }
        } else {
            printMessage("Doctor not found.");
        }
        //printSeparator();
        System.out.println("\n");
    }

    private static void deleteDoctor() {
        System.out.println();
        prompt("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine();

        doctorDAO.deleteDoctor(doctorId);
        printMessage("Doctor deleted successfully.");
        //printSeparator();
        System.out.println("\n");
    }
//MEDICAL RECORDS
    private static void manageMedicalRecords() {
        while (true) {
            System.out.println();
            printTitle("Medical Record Management");
            System.out.println("1. Create a new medical record for a patient");
            System.out.println("2. View medical record details");
            System.out.println("3. Update medical record information");
            System.out.println("4. Delete a medical record");
            System.out.println("5. Back to main menu");
            prompt("Enter your choice ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addMedicalRecord();
                    break;
                case 2:
                    viewMedicalRecord();
                    break;
                case 3:
                    updateMedicalRecord();
                    break;
                case 4:
                    deleteMedicalRecord();
                    break;
                case 5:
                    return;
                default:
                    printMessage("Invalid choice. Please try again.");
            }
            //printSeparator();
        }
    }

    private static void addMedicalRecord() {
        System.out.println();
        prompt("Enter patient ID ");
        int patientId = scanner.nextInt();
        scanner.nextLine();
        prompt("Enter doctor ID ");
        int doctorId = scanner.nextInt();
        scanner.nextLine();
        prompt("Enter date (yyyy-mm-dd) ");
        String date = scanner.nextLine();
        prompt("Enter diagnosis ");
        String diagnosis = scanner.nextLine();
        prompt("Enter treatment ");
        String treatment = scanner.nextLine();

        MedicalRecord medicalRecord = new MedicalRecord();
        medicalRecord.setPatientId(patientId);
        medicalRecord.setDoctorId(doctorId);
        medicalRecord.setDate(date);
        medicalRecord.setDiagnosis(diagnosis);
        medicalRecord.setTreatment(treatment);

        medicalRecordDAO.addMedicalRecord(medicalRecord);
        printMessage("Medical record added successfully.");
        //printSeparator();
        System.out.println("\n");
    }

    private static void viewMedicalRecord() {
        System.out.println();
        prompt("Enter medical record ID ");
        int recordId = scanner.nextInt();
        scanner.nextLine();

        MedicalRecord medicalRecord = medicalRecordDAO.getMedicalRecord(recordId);
        if (medicalRecord != null) {
            printMessage("Medical Record Details");
            System.out.println("Record ID " + medicalRecord.getRecordId());
            System.out.println("Patient ID " + medicalRecord.getPatientId());
            System.out.println("Doctor ID " + medicalRecord.getDoctorId());
            System.out.println("Date " + medicalRecord.getDate());
            System.out.println("Diagnosis " + medicalRecord.getDiagnosis());
            System.out.println("Treatment " + medicalRecord.getTreatment());
        } else {
            printMessage("Medical record not found.");
        }
        //printSeparator();
        System.out.println("\n");
    }

    private static void updateMedicalRecord() {
        System.out.println();
        prompt("Enter medical record ID ");
        int recordId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        MedicalRecord medicalRecord = medicalRecordDAO.getMedicalRecord(recordId);
        if (medicalRecord != null) {
            boolean updating = true;

            while (updating) {
                printMessage("Select the field to update:");
                System.out.println("1. Patient ID");
                System.out.println("2. Doctor ID");
                System.out.println("3. Date");
                System.out.println("4. Diagnosis");
                System.out.println("5. Treatment");
                System.out.println("6. Exit");

                prompt("Enter your choice ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        prompt("Enter new patient ID ");
                        int patientId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        medicalRecord.setPatientId(patientId);
                        break;
                    case 2:
                        prompt("Enter new doctor ID ");
                        int doctorId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        medicalRecord.setDoctorId(doctorId);
                        break;
                    case 3:
                        prompt("Enter new date (yyyy-MM-dd) ");
                        String date = scanner.nextLine();

                        // Validate date format
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        dateFormat.setLenient(false);
                        try {
                            dateFormat.parse(date); // This will throw ParseException if the date is invalid
                            medicalRecord.setDate(date);
                        } catch (ParseException e) {
                            printMessage("Invalid date format. Please enter the date in yyyy-MM-dd format.");
                            continue;
                        }
                        break;
                    case 4:
                        prompt("Enter new diagnosis ");
                        String diagnosis = scanner.nextLine();
                        medicalRecord.setDiagnosis(diagnosis);
                        break;
                    case 5:
                        prompt("Enter new treatment ");
                        String treatment = scanner.nextLine();
                        medicalRecord.setTreatment(treatment);
                        break;
                    case 6:
                        updating = false;
                        break;
                    default:
                        printMessage("Invalid choice. Please try again.");
                        continue;
                }

                if (choice >= 1 && choice <= 5) {
                    medicalRecordDAO.updateMedicalRecord(medicalRecord);
                    printMessage("Medical record updated successfully.");
                }
            }
        } else {
            printMessage("Medical record not found.");
        }
        //printSeparator();
    }

    private static void deleteMedicalRecord() {
        System.out.println();
        prompt("Enter medical record ID ");
        int recordId = scanner.nextInt();
        scanner.nextLine();

        medicalRecordDAO.deleteMedicalRecord(recordId);
        printMessage("Medical record deleted successfully.");
        //printSeparator();
        System.out.println("\n");
    }
}


