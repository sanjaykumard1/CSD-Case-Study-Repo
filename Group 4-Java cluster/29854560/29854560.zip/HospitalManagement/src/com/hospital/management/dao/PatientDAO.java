package com.hospital.management.dao;
import java.util.List;
import com.hospital.management.model.Patient;

public interface PatientDAO {
    void addPatient(Patient patient);
    Patient getPatient(int patientId);
    void updatePatient(Patient patient);
    void deletePatient(int patientId);
    List<Patient> getAllPatients();
}
