package com.hospital.management.dao;

import com.hospital.management.model.MedicalRecord;
import java.util.List;

public interface MedicalRecordDAO {
    void addMedicalRecord(MedicalRecord medicalRecord);
    MedicalRecord getMedicalRecord(int recordId);
    void updateMedicalRecord(MedicalRecord medicalRecord);
    void deleteMedicalRecord(int recordId);
    List<MedicalRecord> getAllMedicalRecords();
}
