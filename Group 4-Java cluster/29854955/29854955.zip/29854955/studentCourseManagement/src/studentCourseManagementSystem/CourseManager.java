package studentCourseManagementSystem;

import java.sql.*;
import java.util.Scanner;

public class CourseManager {
    private Connection connection;
    private Scanner scanner;

    public CourseManager(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void displayCourses() {
        try {
            String query = "SELECT * FROM Course";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("ID: " + resultSet.getInt("course_id"));
                System.out.println("Title: " + resultSet.getString("title"));
                System.out.println("Instructor: " + resultSet.getString("instructor"));
                System.out.println("Schedule: " + resultSet.getString("schedule"));
                System.out.println("Capacity: " + resultSet.getInt("capacity"));
                System.out.println("Students Enrolled: " + resultSet.getInt("students_enrolled"));
                System.out.println();
            }
        } catch (SQLException e) {
            System.err.println("Error displaying courses: " + e.getMessage());
        }
    }

    public void assignCourse() {
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        try {
            String validateStudentQuery = "SELECT * FROM Student WHERE student_id = ?";
            String validateCourseQuery = "SELECT * FROM Course WHERE course_id = ?";

            PreparedStatement studentStatement = connection.prepareStatement(validateStudentQuery);
            PreparedStatement courseStatement = connection.prepareStatement(validateCourseQuery);

            studentStatement.setInt(1, studentId);
            courseStatement.setInt(1, courseId);

            ResultSet studentResultSet = studentStatement.executeQuery();
            ResultSet courseResultSet = courseStatement.executeQuery();

            if (studentResultSet.next() && courseResultSet.next()) {
                int coursesAssigned = studentResultSet.getInt("courses_assigned");
                int studentsEnrolled = courseResultSet.getInt("students_enrolled");
                int courseCapacity = courseResultSet.getInt("capacity");

                if (coursesAssigned < 5 && studentsEnrolled < courseCapacity) {
                    String assignCourseQuery = "INSERT INTO Assignment (course_id, student_id, assignment_date) VALUES (?, ?, NOW())";
                    PreparedStatement assignCourseStatement = connection.prepareStatement(assignCourseQuery);
                    assignCourseStatement.setInt(1, courseId);
                    assignCourseStatement.setInt(2, studentId);
                    assignCourseStatement.executeUpdate();

                    String updateStudentQuery = "UPDATE Student SET courses_assigned = courses_assigned + 1 WHERE student_id = ?";
                    String updateCourseQuery = "UPDATE Course SET students_enrolled = students_enrolled + 1 WHERE course_id = ?";

                    PreparedStatement updateStudentStatement = connection.prepareStatement(updateStudentQuery);
                    PreparedStatement updateCourseStatement = connection.prepareStatement(updateCourseQuery);
                    updateStudentStatement.setInt(1, studentId);
                    updateCourseStatement.setInt(1, courseId);
                    updateStudentStatement.executeUpdate();
                    updateCourseStatement.executeUpdate();
                    System.out.println("Course assigned successfully!");
                } else {
                    if (coursesAssigned >= 5) {
                        System.out.println("The student has already been assigned the maximum number of courses.");
                    }
                    if (studentsEnrolled >= courseCapacity) {
                        System.out.println("The course is already at full capacity.");
                    }
                }
            } else {
                System.out.println("Invalid student or course ID.");
            }
        } catch (SQLException e) {
            System.err.println("Error assigning course: " + e.getMessage());
        }
    }
}
