package studentCourseManagementSystem;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;



public class StudentManagementApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static Connection connection;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/StudentCourseMapping", "root", "123456");
            StudentManager studentManager = new StudentManager(connection, scanner);
            CourseManager courseManager = new CourseManager(connection, scanner);

            while (true) {
                System.out.println("1. Add a new student");
                System.out.println("2. View student details");
                System.out.println("3. Update student information");
                System.out.println("4. Delete a student");
                System.out.println("5. Display list of available courses");
                System.out.println("6. Display list of students");
                System.out.println("7. Assign a course to a student");
                System.out.println("8. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        studentManager.addStudent();
                        break;
                    case 2:
                        studentManager.viewStudentDetails();
                        break;
                    case 3:
                        studentManager.updateStudentInformation();
                        break;
                    case 4:
                        studentManager.deleteStudent();
                        break;
                    case 5:
                        courseManager.displayCourses();
                        break;
                    case 6:
                        studentManager.displayStudents();
                        break;
                    case 7:
                        courseManager.assignCourse();
                        break;
                    case 8:
                        System.out.println("Exiting application...");
                        connection.close();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }
}
