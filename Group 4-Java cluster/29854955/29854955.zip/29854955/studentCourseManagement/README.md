
# Student Management System

## Overview
This is a console-based application for managing student records and course assignments. The application allows users to perform CRUD operations on student records and assign courses to students, ensuring all constraints are validated.

## Features

### Student Management:
-Add a new student

-View student details

-Update student information

-Delete a student

-Display list of students

### Course Management:
-Display list of available courses

-Assign a course to a student with validation

-Update student and course records accordingly

-Database Schema

## Student Table:

student_id (Primary Key)

name

email

phone

courses_assigned (stores count of courses assigned)

## Course Table:
course_id (Primary Key)

title

instructor

schedule

capacity

students_enrolled (stores count of students enrolled)

## Assignment Table:

assignment_id (Primary Key)

course_id (Foreign Key references Course Table)

student_id (Foreign Key references Student Table)

assignment_date



## Usage
Follow the menu options to navigate through different functionalities. Enter the corresponding number for each operation and provide the required details when prompted.

## Error Handling
The application includes basic error handling and validation to ensure data integrity and provide user-friendly error messages.


