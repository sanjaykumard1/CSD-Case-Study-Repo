CREATE DATABASE StudentCourseMapping;
USE StudentCourseMapping;

CREATE TABLE Student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    email VARCHAR(50),
    phone VARCHAR(20),
    course_assigned INT DEFAULT 0
);

CREATE TABLE course(
course_id INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(50),
instructor VARCHAR(50),
schedule VARCHAR(50),
capacity INT,
student_enrolled INT DEFAULT 0
);

CREATE TABLE Assignment (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    assignment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Student(student_id),
	FOREIGN KEY (course_id) REFERENCES course(course_id)
);
