package com.hotelbooking;

//public class HotelBookingApp {
//
//	public HotelBookingApp() {
//		// TODO Auto-generated constructor stub
//	}
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
//
//}

import com.hotelbooking.dao.*;
import com.hotelbooking.model.*;
import java.util.List;
import java.util.Scanner;

public class HotelBookingApp {
    private static RoomDAO roomDAO = new RoomDAO();
    private static CustomerDAO customerDAO = new CustomerDAO();
    private static BookingDAO bookingDAO = new BookingDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Room Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Booking Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    roomManagement();
                    break;
                case 2:
                    customerManagement();
                    break;
                case 3:
                    bookingManagement();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void roomManagement() {
        System.out.println("1. Add Room");
        System.out.println("2. View Room Details");
        System.out.println("3. Update Room");
        System.out.println("4. Delete Room");
        System.out.println("5. List All Rooms");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                Room newRoom = new Room();
                System.out.print("Enter Room Number: ");
                newRoom.setRoomNumber(scanner.nextLine());
                System.out.print("Enter Room Type: ");
                newRoom.setType(scanner.nextLine());
                System.out.print("Enter Room Price: ");
                newRoom.setPrice(scanner.nextDouble());
                scanner.nextLine();
                System.out.print("Enter Room Status (available/booked): ");
                newRoom.setStatus(scanner.nextLine());
                roomDAO.addRoom(newRoom);
                break;
            case 2:
                System.out.print("Enter Room ID: ");
                Room room = roomDAO.getRoomById(scanner.nextInt());
                System.out.println(room);
                break;
            case 3:
                Room updateRoom = new Room();
                System.out.print("Enter Room ID: ");
                updateRoom.setRoomId(scanner.nextInt());
                scanner.nextLine();
                System.out.print("Enter Room Number: ");
                updateRoom.setRoomNumber(scanner.nextLine());
                System.out.print("Enter Room Type: ");
                updateRoom.setType(scanner.nextLine());
                System.out.print("Enter Room Price: ");
                updateRoom.setPrice(scanner.nextDouble());
                scanner.nextLine();
                System.out.print("Enter Room Status (available/booked): ");
                updateRoom.setStatus(scanner.nextLine());
                roomDAO.updateRoom(updateRoom);
                break;
            case 4:
                System.out.print("Enter Room ID: ");
                roomDAO.deleteRoom(scanner.nextInt());
                break;
            case 5:
                List<Room> rooms = roomDAO.getAllRooms();
                for (Room r : rooms) {
                    System.out.println(r);
                }
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }

    private static void customerManagement() {
        System.out.println("1. Register Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.println("5. List All Customers");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                Customer newCustomer = new Customer();
                System.out.print("Enter Customer Name: ");
                newCustomer.setName(scanner.nextLine());
                System.out.print("Enter Customer Email: ");
                newCustomer.setEmail(scanner.nextLine());
                System.out.print("Enter Customer Phone Number: ");
                newCustomer.setPhoneNumber(scanner.nextLine());
                customerDAO.addCustomer(newCustomer);
                break;
            case 2:
                System.out.print("Enter Customer ID: ");
                Customer customer = customerDAO.getCustomerById(scanner.nextInt());
                System.out.println(customer);
                break;
            case 3:
                Customer updateCustomer = new Customer();
                System.out.print("Enter Customer ID: ");
                updateCustomer.setCustomerId(scanner.nextInt());
                scanner.nextLine();
                System.out.print("Enter Customer Name: ");
                updateCustomer.setName(scanner.nextLine());
                System.out.print("Enter Customer Email: ");
                updateCustomer.setEmail(scanner.nextLine());
                System.out.print("Enter Customer Phone Number: ");
                updateCustomer.setPhoneNumber(scanner.nextLine());
                customerDAO.updateCustomer(updateCustomer);
                break;
            case 4:
                System.out.print("Enter Customer ID: ");
                customerDAO.deleteCustomer(scanner.nextInt());
                break;
            case 5:
                List<Customer> customers = customerDAO.getAllCustomers();
                for (Customer c : customers) {
                    System.out.println(c);
                }
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }

    private static void bookingManagement() {
        System.out.println("1. Book Room");
        System.out.println("2. View Booking Details");
        System.out.println("3. Cancel Booking");
        System.out.println("4. List All Bookings for Customer");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                Booking newBooking = new Booking();
                System.out.print("Enter Room ID: ");
                newBooking.setRoomId(scanner.nextInt());
                System.out.print("Enter Customer ID: ");
                newBooking.setCustomerId(scanner.nextInt());
                System.out.print("Enter Check-in Date (yyyy-mm-dd): ");
                newBooking.setCheckInDate(java.sql.Date.valueOf(scanner.next()));
                System.out.print("Enter Check-out Date (yyyy-mm-dd): ");
                newBooking.setCheckOutDate(java.sql.Date.valueOf(scanner.next()));
                bookingDAO.addBooking(newBooking);
                break;
            case 2:
                System.out.print("Enter Booking ID: ");
                Booking booking = bookingDAO.getBookingById(scanner.nextInt());
                System.out.println(booking);
                break;
            case 3:
                System.out.print("Enter Booking ID: ");
                bookingDAO.cancelBooking(scanner.nextInt());
                break;
            case 4:
                System.out.print("Enter Customer ID: ");
                List<Booking> bookings = bookingDAO.getBookingsByCustomerId(scanner.nextInt());
                for (Booking b : bookings) {
                    System.out.println(b);
                }
                break;
            default:
                System.out.println("Invalid choice, please try again.");
        }
    }
}
