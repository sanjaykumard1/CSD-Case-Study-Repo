package restaurant.dao;

import java.util.List;
import restaurant.entity.Order;

public interface OrderDao {
    List<Order> findAll();
    int placeOrder(Order order);
    int updateOrder(Order order);
    int cancelOrder(int orderId);
}
