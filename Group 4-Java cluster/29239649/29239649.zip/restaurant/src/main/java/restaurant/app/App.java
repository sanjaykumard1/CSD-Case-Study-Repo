package restaurant.app;

import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

import restaurant.dao.MenuDao;
import restaurant.dao.MenuDaoImpl;
import restaurant.dao.OrderDao;
import restaurant.dao.OrderDaoImpl;
import restaurant.dao.CustomerDao;
import restaurant.dao.CustomerDaoImpl;
import restaurant.entity.Menu;
import restaurant.entity.Order;
import restaurant.entity.Customer;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MenuDao menuDao = new MenuDaoImpl();
        OrderDao orderDao = new OrderDaoImpl();
        CustomerDao customerDao = new CustomerDaoImpl();

        while (true) {
            System.out.println("1. Menu Management");
            System.out.println("2. Order Management");
            System.out.println("3. Customer Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageMenu(scanner, menuDao);
                    break;
                case 2:
                    manageOrders(scanner, orderDao);
                    break;
                case 3:
                    manageCustomers(scanner, customerDao);
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageMenu(Scanner scanner, MenuDao menuDao) {
        System.out.println("1. Add Menu Item");
        System.out.println("2. View Menu Items");
        System.out.println("3. Update Menu Item");
        System.out.println("4. Delete Menu Item");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter description: ");
                String description = scanner.nextLine();
                System.out.print("Enter price: ");
                double price = scanner.nextDouble();
                scanner.nextLine();  // Consume newline
                System.out.print("Is available (true/false): ");
                boolean availability = scanner.nextBoolean();
                scanner.nextLine();  // Consume newline
                Menu newMenu = new Menu(0, name, description, price, availability);
                menuDao.addMenuItem(newMenu);
                System.out.println("Menu item added successfully.");
                break;
            case 2:
                List<Menu> menus = menuDao.findAll();
                for (Menu menu : menus) {
                    System.out.println(menu);
                }
                break;
            case 3:
                System.out.print("Enter item ID to update: ");
                int updateId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter new name: ");
                String newName = scanner.nextLine();
                System.out.print("Enter new description: ");
                String newDescription = scanner.nextLine();
                System.out.print("Enter new price: ");
                double newPrice = scanner.nextDouble();
                scanner.nextLine();  // Consume newline
                System.out.print("Is available (true/false): ");
                boolean newAvailability = scanner.nextBoolean();
                scanner.nextLine();  // Consume newline
                Menu updateMenu = new Menu(updateId, newName, newDescription, newPrice, newAvailability);
                menuDao.updateMenuItem(updateMenu);
                System.out.println("Menu item updated successfully.");
                break;
            case 4:
                System.out.print("Enter item ID to delete: ");
                int deleteId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                menuDao.deleteMenuItem(deleteId);
                System.out.println("Menu item deleted successfully.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void manageOrders(Scanner scanner, OrderDao orderDao) {
        System.out.println("1. Place Order");
        System.out.println("2. View Orders");
        System.out.println("3. Update Order");
        System.out.println("4. Cancel Order");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter item ID: ");
                int itemId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Timestamp orderDate = new Timestamp(System.currentTimeMillis());
                System.out.print("Enter status: ");
                String status = scanner.nextLine();
                Order newOrder = new Order(0, itemId, customerId, orderDate, status);
                orderDao.placeOrder(newOrder);
                System.out.println("Order placed successfully.");
                break;
            case 2:
                List<Order> orders = orderDao.findAll();
                for (Order order : orders) {
                    System.out.println(order);
                }
                break;
            case 3:
                System.out.print("Enter order ID to update: ");
                int updateId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter new item ID: ");
                int newItemId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter new customer ID: ");
                int newCustomerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter new status: ");
                String newStatus = scanner.nextLine();
                Order updateOrder = new Order(updateId, newItemId, newCustomerId, null, newStatus);
                orderDao.updateOrder(updateOrder);
                System.out.println("Order updated successfully.");
                break;
            case 4:
                System.out.print("Enter order ID to cancel: ");
                int cancelId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                orderDao.cancelOrder(cancelId);
                System.out.println("Order cancelled successfully.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void manageCustomers(Scanner scanner, CustomerDao customerDao) {
        System.out.println("1. Register Customer");
        System.out.println("2. View Customers");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.nextLine();
                System.out.print("Enter address: ");
                String address = scanner.nextLine();
                Customer newCustomer = new Customer(0, name, email, phoneNumber, address);
                customerDao.registerCustomer(newCustomer);
                System.out.println("Customer registered successfully.");
                break;
            case 2:
                List<Customer> customers = customerDao.findAll();
                for (Customer customer : customers) {
                    System.out.println(customer);
                }
                break;
            case 3:
                System.out.print("Enter customer ID to update: ");
                int updateId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter new name: ");
                String newName = scanner.nextLine();
                System.out.print("Enter new email: ");
                String newEmail = scanner.nextLine();
                System.out.print("Enter new phone number: ");
                String newPhoneNumber = scanner.nextLine();
                System.out.print("Enter new address: ");
                String newAddress = scanner.nextLine();
                Customer updateCustomer = new Customer(updateId, newName, newEmail, newPhoneNumber, newAddress);
                customerDao.updateCustomer(updateCustomer);
                System.out.println("Customer updated successfully.");
                break;
            case 4:
                System.out.print("Enter customer ID to delete: ");
                int deleteId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                customerDao.deleteCustomer(deleteId);
                System.out.println("Customer deleted successfully.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
