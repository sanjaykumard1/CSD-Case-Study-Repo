package restaurant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import restaurant.entity.Order;
import restaurant.util.DbUtil;

public class OrderDaoImpl implements OrderDao {
    private Connection connection = DbUtil.getConnection();

    @Override
    public List<Order> findAll() {
        List<Order> orders = new ArrayList<>();
        String query = "SELECT * FROM `order`";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Order order = new Order(rs.getInt("order_id"), rs.getInt("item_id"), rs.getInt("customer_id"), rs.getTimestamp("order_date"), rs.getString("status"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public int placeOrder(Order order) {
        String query = "INSERT INTO `order` (item_id, customer_id, order_date, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, order.getItemId());
            ps.setInt(2, order.getCustomerId());
            ps.setTimestamp(3, order.getOrderDate());
            ps.setString(4, order.getStatus());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int updateOrder(Order order) {
        String query = "UPDATE `order` SET item_id = ?, customer_id = ?, status = ? WHERE order_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, order.getItemId());
            ps.setInt(2, order.getCustomerId());
            ps.setString(3, order.getStatus());
            ps.setInt(4, order.getOrderId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int cancelOrder(int orderId) {
        String query = "UPDATE `order` SET status = 'cancelled' WHERE order_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, orderId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
