package restaurant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import restaurant.entity.Menu;
import restaurant.util.DbUtil;

public class MenuDaoImpl implements MenuDao {
    private Connection connection = DbUtil.getConnection();

    @Override
    public List<Menu> findAll() {
        List<Menu> menus = new ArrayList<>();
        String query = "SELECT * FROM menu";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Menu menu = new Menu(rs.getInt("item_id"), rs.getString("name"), rs.getString("description"), rs.getDouble("price"), rs.getBoolean("availability_status"));
                menus.add(menu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menus;
    }

    @Override
    public int addMenuItem(Menu menu) {
        String query = "INSERT INTO menu (name, description, price, availability_status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, menu.getName());
            ps.setString(2, menu.getDescription());
            ps.setDouble(3, menu.getPrice());
            ps.setBoolean(4, menu.isAvailabilityStatus());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int updateMenuItem(Menu menu) {
        String query = "UPDATE menu SET name = ?, description = ?, price = ?, availability_status = ? WHERE item_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, menu.getName());
            ps.setString(2, menu.getDescription());
            ps.setDouble(3, menu.getPrice());
            ps.setBoolean(4, menu.isAvailabilityStatus());
            ps.setInt(5, menu.getItemId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int deleteMenuItem(int itemId) {
        String query = "DELETE FROM menu WHERE item_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, itemId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
