package restaurant.dao;

import java.util.List;
import restaurant.entity.Menu;

public interface MenuDao {
    List<Menu> findAll();
    int addMenuItem(Menu menu);
    int updateMenuItem(Menu menu);
    int deleteMenuItem(int itemId);
}
