package restaurant.entity;

import java.sql.Timestamp;

public class Order {
    private int orderId;
    private int itemId;
    private int customerId;
    private Timestamp orderDate;
    private String status;

    public Order(int orderId, int itemId, int customerId, Timestamp orderDate, String status) {
        this.orderId = orderId;
        this.itemId = itemId;
        this.customerId = customerId;
        this.orderDate = orderDate;
        this.status = status;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order [orderId=" + orderId + ", itemId=" + itemId + ", customerId=" + customerId + ", orderDate="
                + orderDate + ", status=" + status + "]";
    }
}
