package restaurant.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
    private static Connection connection = null;

    public static Connection getConnection() {
        if (connection != null) {
            return connection;
        }
        try {
            String url = "jdbc:mysql://localhost:3306/restaurant_management";
            String username = "root";
            String password = "root123";
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection established");
        } catch (Exception e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
        return connection;
    }
}
