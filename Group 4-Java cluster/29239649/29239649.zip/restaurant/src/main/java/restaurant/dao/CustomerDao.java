package restaurant.dao;

import java.util.List;
import restaurant.entity.Customer;

public interface CustomerDao {
    List<Customer> findAll();
    int registerCustomer(Customer customer);
    int updateCustomer(Customer customer);
    int deleteCustomer(int customerId);
}
