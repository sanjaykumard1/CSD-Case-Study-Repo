package com.example.ticketing;

import java.sql.*;
import java.util.Scanner;

public class TicketingSystemApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Ticketing System Menu ---");
            System.out.println("1. Create a new ticket");
            System.out.println("2. View ticket details");
            System.out.println("3. View all tickets");
            System.out.println("4. Update ticket information");
            System.out.println("5. Delete a ticket");
            System.out.println("6. Assign a ticket");
            System.out.println("7. View assigned tickets");
            System.out.println("8. Update assignment information");
            System.out.println("9. Delete assignment records");
            System.out.println("10. Resolve a ticket");
            System.out.println("11. View resolved tickets");
            System.out.println("12. Update resolution information");
            System.out.println("13. Delete resolution records");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createTicket(scanner);
                    break;
                case 2:
                    viewTicketDetails(scanner);
                    break;
                case 3:
                    viewAllTickets();
                    break;
                case 4:
                    updateTicketInformation(scanner);
                    break;
                case 5:
                    deleteTicket(scanner);
                    break;
                case 6:
                    assignTicket(scanner);
                    break;
                case 7:
                    viewAssignedTickets(scanner);
                    break;
                case 8:
                    updateAssignmentInformation(scanner);
                    break;
                case 9:
                    deleteAssignmentRecords(scanner);
                    break;
                case 10:
                    resolveTicket(scanner);
                    break;
                case 11:
                    viewResolvedTickets(scanner);
                    break;
                case 12:
                    updateResolutionInformation(scanner);
                    break;
                case 13:
                    deleteResolutionRecords(scanner);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void createTicket(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter issue description: ");
            String issueDescription = scanner.nextLine();
            String sql = "INSERT INTO Ticket (customer_id, creation_date, issue_description, status) VALUES (?, NOW(), ?, 'Open')";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, customerId);
                pstmt.setString(2, issueDescription);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Ticket created successfully!");
                } else {
                    System.out.println("Failed to create ticket.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewTicketDetails(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            String sql = "SELECT * FROM Ticket WHERE ticket_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, ticketId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
                        System.out.println("Customer ID: " + rs.getInt("customer_id"));
                        System.out.println("Creation Date: " + rs.getDate("creation_date"));
                        System.out.println("Issue Description: " + rs.getString("issue_description"));
                        System.out.println("Status: " + rs.getString("status"));
                    } else {
                        System.out.println("Ticket not found.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAllTickets() {
        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "SELECT * FROM Ticket";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
                    System.out.println("Customer ID: " + rs.getInt("customer_id"));
                    System.out.println("Creation Date: " + rs.getDate("creation_date"));
                    System.out.println("Issue Description: " + rs.getString("issue_description"));
                    System.out.println("Status: " + rs.getString("status"));
                    System.out.println("-------------");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateTicketInformation(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter new issue description: ");
            String issueDescription = scanner.nextLine();
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();
            String sql = "UPDATE Ticket SET issue_description = ?, status = ? WHERE ticket_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, issueDescription);
                pstmt.setString(2, status);
                pstmt.setInt(3, ticketId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Ticket updated successfully!");
                } else {
                    System.out.println("Failed to update ticket.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteTicket(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            String sql = "DELETE FROM Ticket WHERE ticket_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, ticketId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Ticket deleted successfully!");
                } else {
                    System.out.println("Failed to delete ticket.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void assignTicket(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            System.out.print("Enter representative ID: ");
            int representativeId = scanner.nextInt();
            String sql = "INSERT INTO Assignment (ticket_id, representative_id, assignment_date, status) VALUES (?, ?, NOW(), 'Assigned')";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, ticketId);
                pstmt.setInt(2, representativeId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Ticket assigned successfully!");
                } else {
                    System.out.println("Failed to assign ticket.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewAssignedTickets(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter representative ID: ");
            int representativeId = scanner.nextInt();
            String sql = "SELECT * FROM Assignment WHERE representative_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, representativeId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        System.out.println("Assignment ID: " + rs.getInt("assignment_id"));
                        System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
                        System.out.println("Assignment Date: " + rs.getDate("assignment_date"));
                        System.out.println("Status: " + rs.getString("status"));
                        System.out.println("-------------");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateAssignmentInformation(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter assignment ID: ");
            int assignmentId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();
            String sql = "UPDATE Assignment SET status = ? WHERE assignment_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, status);
                pstmt.setInt(2, assignmentId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Assignment updated successfully!");
                } else {
                    System.out.println("Failed to update assignment.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteAssignmentRecords(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter assignment ID: ");
            int assignmentId = scanner.nextInt();
            String sql = "DELETE FROM Assignment WHERE assignment_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, assignmentId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Assignment deleted successfully!");
                } else {
                    System.out.println("Failed to delete assignment.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void resolveTicket(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter resolution details: ");
            String resolutionDetails = scanner.nextLine();
            String sql = "INSERT INTO Resolution (ticket_id, resolution_date, resolution_details, status) VALUES (?, NOW(), ?, 'Resolved')";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, ticketId);
                pstmt.setString(2, resolutionDetails);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Ticket resolved successfully!");
                } else {
                    System.out.println("Failed to resolve ticket.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewResolvedTickets(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter ticket ID: ");
            int ticketId = scanner.nextInt();
            String sql = "SELECT * FROM Resolution WHERE ticket_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, ticketId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        System.out.println("Resolution ID: " + rs.getInt("resolution_id"));
                        System.out.println("Resolution Date: " + rs.getDate("resolution_date"));
                        System.out.println("Resolution Details: " + rs.getString("resolution_details"));
                        System.out.println("Status: " + rs.getString("status"));
                        System.out.println("-------------");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateResolutionInformation(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter resolution ID: ");
            int resolutionId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter new resolution details: ");
            String resolutionDetails = scanner.nextLine();
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();
            String sql = "UPDATE Resolution SET resolution_details = ?, status = ? WHERE resolution_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, resolutionDetails);
                pstmt.setString(2, status);
                pstmt.setInt(3, resolutionId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Resolution updated successfully!");
                } else {
                    System.out.println("Failed to update resolution.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteResolutionRecords(Scanner scanner) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            System.out.print("Enter resolution ID: ");
            int resolutionId = scanner.nextInt();
            String sql = "DELETE FROM Resolution WHERE resolution_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, resolutionId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Resolution deleted successfully!");
                } else {
                    System.out.println("Failed to delete resolution.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
