INSERT INTO Customer (name, email) VALUES ('John', 'john@gmail.com');
INSERT INTO Customer (name, email) VALUES ('Jane', 'jane@gmail.com');
INSERT INTO Customer (name, email) VALUES ('Johnson', 'johnson@gmail.com');

INSERT INTO Representative (name, email) VALUES ('Bob', 'bob.brown@gmail.com');
INSERT INTO Representative (name, email) VALUES ('Charlie Davis', 'charlie.davis@gmail.com');
INSERT INTO Representative (name, email) VALUES ('David', 'david.wilson@gmail.com');