package stock_trading;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PortfolioManagement {
    public void createPortfolio(Portfolio portfolio) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if owner_id exists in User table
            if (!userExists(connection, portfolio.getOwnerId())) {
                System.out.println("Error creating portfolio: User with ID " + portfolio.getOwnerId() + " does not exist.");
                return;
            }


            String query = "INSERT INTO Portfolio (portfolio_name, owner_id) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, portfolio.getPortfolioName());
            statement.setInt(2, portfolio.getOwnerId());
            statement.executeUpdate();
            System.out.println("Portfolio created successfully.");
        } catch (SQLException e) {
            System.out.println("Error creating portfolio: " + e.getMessage());
        }
    }


    public void viewPortfolio(int portfolioId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Portfolio WHERE portfolio_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, portfolioId);
            ResultSet resultSet = statement.executeQuery();


            if (resultSet.next()) {
                System.out.println("Portfolio ID: " + resultSet.getInt("portfolio_id"));
                System.out.println("Portfolio Name: " + resultSet.getString("portfolio_name"));
                System.out.println("Owner ID: " + resultSet.getInt("owner_id"));
            } else {
                System.out.println("Portfolio not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing portfolio: " + e.getMessage());
        }
    }


    public void updatePortfolio(Portfolio portfolio) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            // Check if owner_id exists in User table
            if (!userExists(connection, portfolio.getOwnerId())) {
                System.out.println("Error updating portfolio: User with ID " + portfolio.getOwnerId() + " does not exist.");
                return;
            }


            String query = "UPDATE Portfolio SET portfolio_name = ?, owner_id = ? WHERE portfolio_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, portfolio.getPortfolioName());
            statement.setInt(2, portfolio.getOwnerId());
            statement.setInt(3, portfolio.getPortfolioId());
            int rowsUpdated = statement.executeUpdate();


            if (rowsUpdated > 0) {
                System.out.println("Portfolio updated successfully.");
            } else {
                System.out.println("Portfolio not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating portfolio: " + e.getMessage());
        }
    }


    public void deletePortfolio(int portfolioId) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM Portfolio WHERE portfolio_id = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, portfolioId);
            int rowsDeleted = statement.executeUpdate();


            if (rowsDeleted > 0) {
                System.out.println("Portfolio deleted successfully.");
            } else {
                System.out.println("Portfolio not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting portfolio: " + e.getMessage());
        }
    }


    private boolean userExists(Connection connection, int userId) throws SQLException {
        String query = "SELECT 1 FROM User WHERE user_id = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, userId);
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next();
    }
}