package stock_trading;

public class Portfolio {
 private int portfolioId;
 private String portfolioName;
 private int ownerId;

 // Getters and Setters
 public int getPortfolioId() {
     return portfolioId;
 }

 public void setPortfolioId(int portfolioId) {
     this.portfolioId = portfolioId;
 }

 public String getPortfolioName() {
     return portfolioName;
 }

 public void setPortfolioName(String portfolioName) {
     this.portfolioName = portfolioName;
 }

 public int getOwnerId() {
     return ownerId;
 }

 public void setOwnerId(int ownerId) {
     this.ownerId = ownerId;
 }
}

