package stock_trading;

import java.sql.Timestamp;

public class Transaction {
 private int transactionId;
 private int stockId;
 private int portfolioId;
 private String transactionType;
 private int quantity;
 private Timestamp transactionDate;

 // Getters and Setters
 public int getTransactionId() {
     return transactionId;
 }

 public void setTransactionId(int transactionId) {
     this.transactionId = transactionId;
 }

 public int getStockId() {
     return stockId;
 }

 public void setStockId(int stockId) {
     this.stockId = stockId;
 }

 public int getPortfolioId() {
     return portfolioId;
 }

 public void setPortfolioId(int portfolioId) {
     this.portfolioId = portfolioId;
 }

 public String getTransactionType() {
     return transactionType;
 }

 public void setTransactionType(String transactionType) {
     this.transactionType = transactionType;
 }

 public int getQuantity() {
     return quantity;
 }

 public void setQuantity(int quantity) {
     this.quantity = quantity;
 }

 public Timestamp getTransactionDate() {
     return transactionDate;
 }

 public void setTransactionDate(Timestamp transactionDate) {
     this.transactionDate = transactionDate;
 }
}

