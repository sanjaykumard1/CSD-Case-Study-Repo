package stock_trading;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StockManagement {
 public void addStock(Stock stock) {
     String sql = "INSERT INTO Stock (stock_name, price_per_share, quantity_available) VALUES (?, ?, ?)";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setString(1, stock.getStockName());
         pstmt.setDouble(2, stock.getPricePerShare());
         pstmt.setInt(3, stock.getQuantityAvailable());
         pstmt.executeUpdate();
     } catch (SQLException e) {
         System.out.println("Error adding stock: " + e.getMessage());
     }
 }

 public void viewStock(int stockId) {
     String sql = "SELECT * FROM Stock WHERE stock_id = ?";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, stockId);
         ResultSet rs = pstmt.executeQuery();
         while (rs.next()) {
             System.out.println("Stock ID: " + rs.getInt("stock_id"));
             System.out.println("Stock Name: " + rs.getString("stock_name"));
             System.out.println("Price per Share: " + rs.getDouble("price_per_share"));
             System.out.println("Quantity Available: " + rs.getInt("quantity_available"));
         }
     } catch (SQLException e) {
         System.out.println("Error viewing stock: " + e.getMessage());
     }
 }

 public void updateStock(Stock stock) {
     String sql = "UPDATE Stock SET stock_name = ?, price_per_share = ?, quantity_available = ? WHERE stock_id = ?";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setString(1, stock.getStockName());
         pstmt.setDouble(2, stock.getPricePerShare());
         pstmt.setInt(3, stock.getQuantityAvailable());
         pstmt.setInt(4, stock.getStockId());
         pstmt.executeUpdate();
     } catch (SQLException e) {
         System.out.println("Error updating stock: " + e.getMessage());
     }
 }

 public void removeStock(int stockId) {
     String sql = "DELETE FROM Stock WHERE stock_id = ?";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, stockId);
         pstmt.executeUpdate();
     } catch (SQLException e) {
         System.out.println("Error removing stock: " + e.getMessage());
     }
 }
}
