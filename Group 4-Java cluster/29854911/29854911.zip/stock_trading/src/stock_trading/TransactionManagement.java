package stock_trading;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class TransactionManagement {
 public void buyStock(Transaction transaction) {
     String sql = "INSERT INTO Transaction (stock_id, portfolio_id, transaction_type, quantity, transaction_date) VALUES (?, ?, 'Buy', ?, ?)";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, transaction.getStockId());
         pstmt.setInt(2, transaction.getPortfolioId());
         pstmt.setInt(3, transaction.getQuantity());
         pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
         pstmt.executeUpdate();
         
         updateStockQuantity(transaction.getStockId(), -transaction.getQuantity());
     } catch (SQLException e) {
         System.out.println("Error buying stock: " + e.getMessage());
     }
 }

 public void sellStock(Transaction transaction) {
     String sql = "INSERT INTO Transaction (stock_id, portfolio_id, transaction_type, quantity, transaction_date) VALUES (?, ?, 'Sell', ?, ?)";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, transaction.getStockId());
         pstmt.setInt(2, transaction.getPortfolioId());
         pstmt.setInt(3, transaction.getQuantity());
         pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
         pstmt.executeUpdate();
         
         updateStockQuantity(transaction.getStockId(), transaction.getQuantity());
     } catch (SQLException e) {
         System.out.println("Error selling stock: " + e.getMessage());
     }
 }

 public void viewTransactionHistory(int portfolioId) {
     String sql = "SELECT * FROM Transaction WHERE portfolio_id = ?";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, portfolioId);
         ResultSet rs = pstmt.executeQuery();
         while (rs.next()) {
             System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
             System.out.println("Stock ID: " + rs.getInt("stock_id"));
             System.out.println("Portfolio ID: " + rs.getInt("portfolio_id"));
             System.out.println("Transaction Type: " + rs.getString("transaction_type"));
             System.out.println("Quantity: " + rs.getInt("quantity"));
             System.out.println("Transaction Date: " + rs.getTimestamp("transaction_date"));
         }
     } catch (SQLException e) {
         System.out.println("Error viewing transaction history: " + e.getMessage());
     }
 }

 private void updateStockQuantity(int stockId, int quantityChange) {
     String sql = "UPDATE Stock SET quantity_available = quantity_available + ? WHERE stock_id = ?";
     try (Connection conn = DatabaseConnection.getConnection();
          PreparedStatement pstmt = conn.prepareStatement(sql)) {
         pstmt.setInt(1, quantityChange);
         pstmt.setInt(2, stockId);
         pstmt.executeUpdate();
     } catch (SQLException e) {
         System.out.println("Error updating stock quantity: " + e.getMessage());
     }
 }
}
