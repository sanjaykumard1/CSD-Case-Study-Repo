package stock_trading;

public class Stock {
 private int stockId;
 private String stockName;
 private double pricePerShare;
 private int quantityAvailable;

 // Getters and Setters
 public int getStockId() {
     return stockId;
 }

 public void setStockId(int stockId) {
     this.stockId = stockId;
 }

 public String getStockName() {
     return stockName;
 }

 public void setStockName(String stockName) {
     this.stockName = stockName;
 }

 public double getPricePerShare() {
     return pricePerShare;
 }

 public void setPricePerShare(double pricePerShare) {
     this.pricePerShare = pricePerShare;
 }

 public int getQuantityAvailable() {
     return quantityAvailable;
 }

 public void setQuantityAvailable(int quantityAvailable) {
     this.quantityAvailable = quantityAvailable;
 }
}

