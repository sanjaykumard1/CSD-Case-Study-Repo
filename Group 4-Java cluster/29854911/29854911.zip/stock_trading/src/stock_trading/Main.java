package stock_trading;

import java.util.Scanner;
public class Main {
 public static void main(String[] args) {
 Scanner scanner = new Scanner(System.in);
 StockManagement stockManagement = new StockManagement();
 PortfolioManagement portfolioManagement = new PortfolioManagement();
 TransactionManagement transactionManagement = new TransactionManagement();
 while (true) {
 System.out.println("Welcome to the Stock Trading System");
 System.out.println("1. Manage Stocks");
 System.out.println("2. Manage Portfolios");
 System.out.println("3. Manage Transactions");
 System.out.println("4. Exit");
 System.out.print("Enter your choice: ");
 int choice = scanner.nextInt();
 switch (choice) {
 case 1:
 manageStocks(stockManagement, scanner);
 break;
 case 2:
 managePortfolios(portfolioManagement, scanner);
 break;
 case 3:
 manageTransactions(transactionManagement, scanner);
 break;
 case 4:
 System.out.println("Exiting...");
 System.exit(0);
 break;
 default:
 System.out.println("Invalid choice. Please try again.");
 }
 }
 }
 private static void manageStocks(StockManagement stockManagement, Scanner 
scanner) {
 System.out.println("1. Add Stock");
 System.out.println("2. View Stock");
 System.out.println("3. Update Stock");
 System.out.println("4. Remove Stock");
 System.out.print("Enter your choice: ");
 int choice = scanner.nextInt();
 switch (choice) {
 case 1:
 System.out.print("Enter stock name: ");
 String stockName = scanner.next();
 System.out.print("Enter price per share: ");
 double pricePerShare = scanner.nextDouble();
 System.out.print("Enter quantity available: ");
 int quantityAvailable = scanner.nextInt();
 Stock stock = new Stock();
 stock.setStockName(stockName);
 stock.setPricePerShare(pricePerShare);
 stock.setQuantityAvailable(quantityAvailable);
 stockManagement.addStock(stock);
 System.out.println("Stock added successfully.");
 break;
 case 2:
 System.out.print("Enter stock ID: ");
 int stockId = scanner.nextInt();
 stockManagement.viewStock(stockId);
 break;
 case 3:
 System.out.print("Enter stock ID: ");
 stockId = scanner.nextInt();
 System.out.print("Enter new stock name: ");
 stockName = scanner.next();
 System.out.print("Enter new price per share: ");
 pricePerShare = scanner.nextDouble();
 System.out.print("Enter new quantity available: ");
 quantityAvailable = scanner.nextInt();
 stock = new Stock();
 stock.setStockId(stockId);
 stock.setStockName(stockName);
 stock.setPricePerShare(pricePerShare);
 stock.setQuantityAvailable(quantityAvailable);
 stockManagement.updateStock(stock);
 System.out.println("Stock updated successfully.");
 break;
 case 4:
 System.out.print("Enter stock ID: ");
 stockId = scanner.nextInt();
 stockManagement.removeStock(stockId);
 System.out.println("Stock removed successfully.");
 break;
 default:
 System.out.println("Invalid choice. Please try again.");
 }
 }
 private static void managePortfolios(PortfolioManagement portfolioManagement, 
Scanner scanner) {
 System.out.println("1. Create Portfolio");
 System.out.println("2. View Portfolio");
 System.out.println("3. Update Portfolio");
 System.out.println("4. Delete Portfolio");
 System.out.print("Enter your choice: ");
 int choice = scanner.nextInt();
 switch (choice) {
 case 1:
 System.out.print("Enter portfolio name: ");
 String portfolioName = scanner.next();
 System.out.print("Enter owner ID: ");
 int ownerId = scanner.nextInt();
 Portfolio portfolio = new Portfolio();
 portfolio.setPortfolioName(portfolioName);
 portfolio.setOwnerId(ownerId);
 portfolioManagement.createPortfolio(portfolio);
 System.out.println("Portfolio created successfully.");
 break;
 case 2:
 System.out.print("Enter portfolio ID: ");
 int portfolioId = scanner.nextInt();
 portfolioManagement.viewPortfolio(portfolioId);
 break;
 case 3:
 System.out.print("Enter portfolio ID: ");
 portfolioId = scanner.nextInt();
 System.out.print("Enter new portfolio name: ");
 portfolioName = scanner.next();
 System.out.print("Enter new owner ID: ");
 ownerId = scanner.nextInt();
 Portfolio updatedPortfolio = new Portfolio();
 updatedPortfolio.setPortfolioId(portfolioId);
 updatedPortfolio.setPortfolioName(portfolioName);
 updatedPortfolio.setOwnerId(ownerId);
 portfolioManagement.updatePortfolio(updatedPortfolio);
 System.out.println("Portfolio updated successfully.");
 break;
 case 4:
 System.out.print("Enter portfolio ID: ");
 portfolioId = scanner.nextInt();
 portfolioManagement.deletePortfolio(portfolioId);
 System.out.println("Portfolio deleted successfully.");
 break;
 default:
 System.out.println("Invalid choice. Please try again.");
 }
 }
 private static void manageTransactions(TransactionManagement 
transactionManagement, Scanner scanner) {
 System.out.println("1. Buy Stock");
 System.out.println("2. Sell Stock");
 System.out.println("3. View Transaction History");
 System.out.print("Enter your choice: ");
 int choice = scanner.nextInt();
 switch (choice) {
 case 1:
 System.out.print("Enter stock ID: ");
 int stockId = scanner.nextInt();
 System.out.print("Enter portfolio ID: ");
 int portfolioId = scanner.nextInt();
 System.out.print("Enter quantity to buy: ");
 int quantity = scanner.nextInt();
 Transaction buyTransaction = new Transaction();
 buyTransaction.setStockId(stockId);
 buyTransaction.setPortfolioId(portfolioId);
 buyTransaction.setQuantity(quantity);
 buyTransaction.setTransactionType("Buy");
 transactionManagement.buyStock(buyTransaction);
 System.out.println("Stock bought successfully.");
 break;
 case 2:
 System.out.print("Enter stock ID: ");
 stockId = scanner.nextInt();
 System.out.print("Enter portfolio ID: ");
 portfolioId = scanner.nextInt();
 System.out.print("Enter quantity to sell: ");
 quantity = scanner.nextInt();
 Transaction sellTransaction = new Transaction();
 sellTransaction.setStockId(stockId);
 sellTransaction.setPortfolioId(portfolioId);
 sellTransaction.setQuantity(quantity);
 sellTransaction.setTransactionType("Sell");
 transactionManagement.sellStock(sellTransaction);
 System.out.println("Stock sold successfully.");
 break;
 case 3:
 System.out.print("Enter portfolio ID: ");
 portfolioId = scanner.nextInt();
 transactionManagement.viewTransactionHistory(portfolioId);
 break;
 default:
 System.out.println("Invalid choice. Please try again.");
 }
 }
}

