# Stock Trading System

This is a console-based stock trading system implemented in Java. It manages stocks, portfolios, and transactions using a MySQL database.

## Features

1. Stock Management:
   - Add stock
   - View stock
   - Update stock
   - Remove stock

2. Portfolio Management:
   - Create portfolio
   - View portfolio
   - Update portfolio
   - Delete portfolio

3. Transaction Management:
   - Buy stock
   - Sell stock
   - View transaction history

## Setup

### Prerequisites

- Java Development Kit (JDK) 8 or later
- MySQL Server
- MySQL Connector for Java

### Database Setup

1. Create the database and tables using the provided SQL script:

   ```sql
   CREATE DATABASE stock_trading_system;

   USE stock_trading_system;

   CREATE TABLE User (
       user_id INT AUTO_INCREMENT PRIMARY KEY,
       name VARCHAR(100),
       email VARCHAR(100),
       contact_number VARCHAR(15),
       address VARCHAR(255)
   );

   CREATE TABLE Stock (
       stock_id INT AUTO_INCREMENT PRIMARY KEY,
       stock_name VARCHAR(100),
       price_per_share DECIMAL(10, 2),
       quantity_available INT
   );

   CREATE TABLE Portfolio (
       portfolio_id INT AUTO_INCREMENT PRIMARY KEY,
       portfolio_name VARCHAR(100),
       owner_id INT,
       FOREIGN KEY (owner_id) REFERENCES User(user_id)
   );

   CREATE TABLE Transaction (
       transaction_id INT AUTO_INCREMENT PRIMARY KEY,
       stock_id INT,
       portfolio_id INT,
       transaction_type ENUM('Buy', 'Sell'),
       quantity INT,
       transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       FOREIGN KEY (stock_id) REFERENCES Stock(stock_id),
       FOREIGN KEY (portfolio_id) REFERENCES Portfolio(portfolio_id)
   );
Running the Application
Clone the repository:


git clone <repository-url>
Navigate to the project directory:


cd StockTradingSystem
Compile the Java files:


javac -d out -sourcepath src src/main/java/com/stocktrading/*.java
Run the application:


java -cp out com.stocktrading.Main
Note
Update the database connection details in DatabaseConnection.java with your MySQL username and password.

**Add MySQL Connector/J to Your Project:**

Download the MySQL Connector/J from MySQL Connector/J.
Add the JAR file to your project's build path.
In Eclipse:

Right-click on your project in the Project Explorer.
Select Build Path -> Configure Build Path.
Go to the Libraries tab and click on Add External JARs.
Navigate to the location where you downloaded the MySQL Connector/J, select the JAR file, and click Open.
Click Apply and Close.
Compile and Run:

Compile the Java files.
Run the Main class to start the application.
Usage Instructions
Run the application.
Use the main menu to navigate to the desired management section (portfolio, stocks, transaction).
Follow the prompts to Manage Stocks,Manage Portfolio, Manage Transactions.
Exception Handling
The application includes basic exception handling to manage SQL exceptions and provide user-friendly error messages.

Code Conventions
The code follows standard Java coding conventions and is well-documented with comments for clarity.


Thank you for using the Stock Trading System!