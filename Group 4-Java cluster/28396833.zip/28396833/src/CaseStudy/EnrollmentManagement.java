package CaseStudy;

import java.sql.*;
import java.util.Scanner;

public class EnrollmentManagement {
    private static final Scanner scanner = new Scanner(System.in);

    public static void enrollStudent() throws Exception {
        System.out.print("Enter enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        System.out.print("Enter student ID: ");
        int studentId = scanner.nextInt();
        System.out.print("Enter course ID: ");
        int courseId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter enrollment date (YYYY-MM-DD): ");
        String enrollmentDate = scanner.nextLine();
        System.out.print("Enter grade: ");
        String grade = scanner.nextLine();

        String sql = "INSERT INTO Enrollment (enrollment_id, student_id, course_id, enrollment_date, grade) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            stmt.setInt(2, studentId);
            stmt.setInt(3, courseId);
            stmt.setDate(4, Date.valueOf(enrollmentDate));
            stmt.setString(5, grade);
            stmt.executeUpdate();
            System.out.println("Student enrolled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewEnrollment() throws Exception {
        System.out.print("Enter enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "SELECT * FROM Enrollment WHERE enrollment_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Enrollment ID: " + rs.getInt("enrollment_id"));
                System.out.println("Student ID: " + rs.getInt("student_id"));
                System.out.println("Course ID: " + rs.getInt("course_id"));
                System.out.println("Enrollment Date: " + rs.getDate("enrollment_date"));
                System.out.println("Grade: " + rs.getString("grade"));
            } else {
                System.out.println("Enrollment not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateEnrollment() throws Exception {
        System.out.print("Enter enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "UPDATE Enrollment SET enrollment_date = ?, grade = ? WHERE enrollment_id = ?";

        System.out.print("Enter new enrollment date (DD-MM-YYYY) or enter the old one: ");
        String enrollmentDate = scanner.nextLine();
        System.out.print("Enter new grade or enter the old one: ");
        String grade = scanner.nextLine();

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            if (!enrollmentDate.isEmpty()) {
                stmt.setDate(1, Date.valueOf(enrollmentDate));
            } else {
                stmt.setDate(1, null);
            }
            if (!grade.isEmpty()) {
                stmt.setString(2, grade);
            } else {
                stmt.setString(2, null);
            }
            stmt.setInt(3, enrollmentId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Enrollment updated successfully.");
            } else {
                System.out.println("Enrollment not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void withdrawStudent() throws Exception {
        System.out.print("Enter enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "DELETE FROM Enrollment WHERE enrollment_id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Student withdrawn from course successfully.");
            } else {
                System.out.println("Enrollment not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
