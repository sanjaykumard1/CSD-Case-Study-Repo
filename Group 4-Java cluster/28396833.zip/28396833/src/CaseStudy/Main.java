package CaseStudy;


import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws Exception {
        while (true) {
            System.out.println("University Course Management System");
            System.out.println("1. Manage Courses");
            System.out.println("2. Manage Students");
            System.out.println("3. Manage Enrollments");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    manageCourses();
                    break;
                case 2:
                    manageStudents();
                    break;
                case 3:
                    manageEnrollments();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageCourses() throws Exception {
        while (true) {
            System.out.println("Course Management");
            System.out.println("1. Add Course");
            System.out.println("2. View Course");
            System.out.println("3. Update Course");
            System.out.println("4. Delete Course");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    CourseManagement.addCourse();
                    break;
                case 2:
                    CourseManagement.viewCourse();
                    break;
                case 3:
                    CourseManagement.updateCourse();
                    break;
                case 4:
                    CourseManagement.deleteCourse();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageStudents() throws Exception {
        while (true) {
            System.out.println("Student Management");
            System.out.println("1. Register Student");
            System.out.println("2. View Student");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    StudentManagement.addStudent();
                    break;
                case 2:
                    StudentManagement.viewStudent();
                    break;
                case 3:
                    StudentManagement.updateStudent();
                    break;
                case 4:
                    StudentManagement.deleteStudent();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageEnrollments() throws Exception {
        while (true) {
            System.out.println("Enrollment Management");
            System.out.println("1. Enroll Student");
            System.out.println("2. View Enrollment");
            System.out.println("3. Update Enrollment");
            System.out.println("4. Withdraw Student");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    EnrollmentManagement.enrollStudent();
                    break;
                case 2:
                    EnrollmentManagement.viewEnrollment();
                    break;
                case 3:
                    EnrollmentManagement.updateEnrollment();
                    break;
                case 4:
                    EnrollmentManagement.withdrawStudent();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
