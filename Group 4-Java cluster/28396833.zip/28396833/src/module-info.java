/**
 * 
 */
/**
 * 
 */
module Cognizant23 {
	requires java.sql;
}