package Bank;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBconnection {
	// private static final CustomerOperations customeroperat = new CustomerOperations();
 
	private static final ResultSet NULL = null;

	public static void main(String args[]) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankmanagementsystem","root","1313");
		if (connect != null) {
	        System.out.println("Connected to database!");
	    } else {
	        System.out.println("Failed to make connection!");
	    }
		
		
		System.out.println("********WELCOME TO CTS BANK*********");
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			
			System.out.println("1.Customer");
			System.out.println("2.AccountManager");
			int opt = sc.nextInt();
			switch(opt) {
			
			case 1:
				System.out.println("Enter the ID:");
				String customerno = sc.next();
				
				try {
			        Statement stmt = connect.createStatement();
			        String query = "select * from customer where customerID="+customerno+";";
			    //person is the table name
			        ResultSet rs = stmt.executeQuery(query);
			        while (rs.next()) {
			            String customerID = rs.getObject(1).toString();
			            String Accountname = rs.getObject(2).toString();
			            System.out.println("Name of the person is " + customerID + " and Name----------" + Accountname);
			    //Person table has name and gender column

			        }
			    } catch (SQLException e) {
			        e.printStackTrace();
			        for(Throwable ex : e) {
			            System.err.println("Error occurred " + ex);
			        }
			        System.out.println("Error in fetching data");
			    }
				int custopt = 0;
				while(custopt != 3) {
				System.out.println("1.Balance");
				System.out.println("2.Tranfer");
				System.out.println("3.EXIT");
				
				custopt = sc.nextInt();
				switch(custopt) {
				case 1:
				//try {
					System.out.println("Enter the AccountNo:");
					String AccountID = sc.next();
					Statement stmt = connect.createStatement();
			        String query = "select balance from Accounts where customerID="+customerno+" and AccountID="+AccountID+";";
			    //person is the table name
			        ResultSet rs = stmt.executeQuery(query);
			        while (rs.next()) {
			            int balancedata = rs.getInt("balance");
			            //String Accountid = rs.getObject(2).toString();
			            if(rs.wasNull())
			            {
			            	System.out.println("ZERO BALANCE");
			            }
			            System.out.println("The balance amount:" + balancedata);
			            break;
			        }
			        break;
			
			case 2:
				System.out.println("1.withdrawal");
				System.out.println("2.Deposit");
				System.out.println("3.Transfer to another account");
				int transferopt = sc.nextInt();
				switch(transferopt)
				{
				case 1:
					System.out.println("Enter the amount to be withdrawal:");
					int withdrawalamt = sc.nextInt();
					
					int actualbal=0;
					Statement stmt1 = connect.createStatement();
			        String query1 = "select balance from accounts where customerID="+customerno+";";
			        ResultSet rs1 = stmt1.executeQuery(query1);
			        
			         actualbal = rs1.getInt(4);
			        
			        if(actualbal<withdrawalamt || actualbal == 0)
			        {
			        	System.out.println("Funds not sufficient !");
			        }
			        break;
							
					//stmt1.execute(querytransfer);
				case 2:
					System.out.println("Enter the amount to be deposited");
					int depositamount = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the account to Deposit:");
					String accountno = sc.nextLine();
					
					Statement stmt12 = connect.createStatement();
					String querytransfer= "update accounts set balance = balance + "+depositamount+" where accountID ="+accountno+";";
					stmt12.execute(querytransfer);
					System.out.println("Successfully deposited");
					
					
				case 3:
					System.out.println("Enter the Account no money need to be transferred:");
					String transferaccnt = sc.nextLine();
					System.out.println("Enter the amount to be transferred :");
					int Transferamt = sc.nextInt();
					Statement stmt11 = connect.createStatement();
					String querytransfer1 = "update accounts set balance = balance - "+Transferamt+" where customerID="+customerno+";";
					stmt11.execute(querytransfer1);
					Statement stmt111 = connect.createStatement();
					String querytransfer11 = "update accounts set balance = balance + "+Transferamt+" where accountID="+transferaccnt+";";
					stmt111.execute(querytransfer11);
					System.out.println("Successfully sent !");				
					System.out.println(" Facility Not yet started ");
					break;
				}
					
	        }
				
		}
			case 2:
				System.out.println("*********Closing account******");
				System.out.println("Enter the Account no:");
				String closeaccount = sc.next();
				Statement stmt12 = connect.createStatement();
				String querycloseaccnt= "delete from accounts where accountID="+closeaccount+";";
				stmt12.execute(querycloseaccnt);
				System.out.println("Successfully deposited");
				
	}
}
	
	}



		}
	
//Class.forName("com.mysql.cj.jdbc.Driver");
//Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankmanagementsystem","root","1313");
//System.out.println("Connection created");
