/**
 * 
 */
/**
 * 
 */
module BankmanagementMain {
	requires java.sql;
}