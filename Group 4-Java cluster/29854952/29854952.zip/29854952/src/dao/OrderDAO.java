package dao;

import java.sql.SQLException;
import java.util.List;

import entity.Order;


public interface OrderDAO {
    void addOrder(Order order) throws SQLException;
    Order getOrder(int orderId) throws SQLException;
    void updateOrder(Order order) throws SQLException;
    void deleteOrder(int orderId) throws SQLException;
    List<Order> getAllOrders() throws SQLException;
}
