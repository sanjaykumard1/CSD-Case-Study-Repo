package dao;

import java.sql.SQLException;

import entity.Product;

public interface ProductDAO {
    void addProduct(Product product) throws SQLException;
    Product getProduct(int productId) throws SQLException;
    void updateProduct(Product product) throws SQLException;
    void deleteProduct(int productId) throws SQLException;
}