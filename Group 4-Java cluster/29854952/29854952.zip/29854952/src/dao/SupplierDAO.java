package dao;

import java.sql.SQLException;

import entity.Supplier;

public interface SupplierDAO {
    void addSupplier(Supplier supplier) throws SQLException;
    Supplier getSupplier(int supplierId) throws SQLException;
    void updateSupplier(Supplier supplier) throws SQLException;
    void deleteSupplier(int supplierId) throws SQLException;
}
