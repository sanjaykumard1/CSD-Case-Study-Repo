package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import entity.Order;


import util.DatabaseConnection;

public class OrderDAOImpl implements OrderDAO {
    @Override
    public void addOrder(Order order) throws SQLException {
        String sql = "INSERT INTO `order` (product_id, supplier_id, order_date, delivery_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, order.getProductId());
            stmt.setInt(2, order.getSupplierId());
            stmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            stmt.setDate(4, new java.sql.Date(order.getDeliveryDate().getTime()));
            stmt.setString(5, order.getStatus());
            stmt.executeUpdate();

            // Update product quantity
            updateProductQuantity(order.getProductId(), -1);
        }
    }

    @Override
    public Order getOrder(int orderId) throws SQLException {
        String sql = "SELECT * FROM `order` WHERE order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Order(
                        rs.getInt("order_id"),
                        rs.getInt("product_id"),
                        rs.getInt("supplier_id"),
                        rs.getDate("order_date"),
                        rs.getDate("delivery_date"),
                        rs.getString("status")
                );
            }
        }
        return null;
    }

    @Override
    public void updateOrder(Order order) throws SQLException {
        String sql = "UPDATE `order` SET product_id = ?, supplier_id = ?, order_date = ?, delivery_date = ?, status = ? WHERE order_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, order.getProductId());
            stmt.setInt(2, order.getSupplierId());
            stmt.setDate(3, new java.sql.Date(order.getOrderDate().getTime()));
            stmt.setDate(4, new java.sql.Date(order.getDeliveryDate().getTime()));
            stmt.setString(5, order.getStatus());
            stmt.setInt(6, order.getOrderId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteOrder(int orderId) throws SQLException {
        Order order = getOrder(orderId);
        if (order != null) {
            String sql = "DELETE FROM `order` WHERE order_id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, orderId);
                stmt.executeUpdate();

                // Update product quantity
                updateProductQuantity(order.getProductId(), 1);
            }
        }
    }

    @Override
    public List<Order> getAllOrders() throws SQLException {
        String sql = "SELECT * FROM `order`";
        List<Order> orders = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                orders.add(new Order(
                        rs.getInt("order_id"),
                        rs.getInt("product_id"),
                        rs.getInt("supplier_id"),
                        rs.getDate("order_date"),
                        rs.getDate("delivery_date"),
                        rs.getString("status")
                ));
            }
        }
        return orders;
    }

    private void updateProductQuantity(int productId, int quantityChange) throws SQLException {
        String sql = "UPDATE product SET quantity_in_stock = quantity_in_stock + ? WHERE product_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, quantityChange);
            stmt.setInt(2, productId);
            stmt.executeUpdate();
        }
    }
}