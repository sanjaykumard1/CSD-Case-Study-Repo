package main;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import dao.OrderDAO;
import dao.OrderDAOImpl;
import dao.ProductDAO;
import dao.ProductDAOImpl;
import dao.SupplierDAO;
import dao.SupplierDAOImpl;
import entity.Order;
import entity.Product;
import entity.Supplier;

public class Main {
    private static final ProductDAO productDAO = new ProductDAOImpl();
    private static final SupplierDAO supplierDAO = new SupplierDAOImpl();
    private static final OrderDAO orderDAO = new OrderDAOImpl();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Stock Management System");
            System.out.println("1. Product Management");
            System.out.println("2. Supplier Management");
            System.out.println("3. Order Management");
            System.out.println("4. Exit");
            System.out.println("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (option) {
                    case 1:
                        manageProducts(scanner);
                        break;
                    case 2:
                        manageSuppliers(scanner);
                        break;
                    case 3:
                        manageOrders(scanner);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void manageProducts(Scanner scanner) throws SQLException {
        System.out.println("Product Management");
        System.out.println("1. Add a new product");
        System.out.println("2. View product details");
        System.out.println("3. Update product information");
        System.out.println("4. Delete a product");
        System.out.println("Choose an option: ");
        int option = scanner.nextInt();
        scanner.nextLine();

        switch (option) {
            case 1:
                System.out.println("Enter product name: ");
                String name = scanner.nextLine();
                System.out.println("Enter product description: ");
                String description = scanner.nextLine();
                System.out.println("Enter product price: ");
                double price = scanner.nextDouble();
                System.out.println("Enter quantity in stock: ");
                int quantity = scanner.nextInt();
                productDAO.addProduct(new Product(0, name, description, price, quantity));
                System.out.println("Product added.");
                break;
            case 2:
                System.out.println("Enter product ID: ");
                int productId = scanner.nextInt();
                try {
                    Product product = productDAO.getProduct(productId);
                    if (product != null) {
                        System.out.println("Product ID: " + product.getProductId());
                        System.out.println("Name: " + product.getName());
                        System.out.println("Description: " + product.getDescription());
                        System.out.println("Price: " + product.getPrice());
                        System.out.println("Quantity in Stock: " + product.getQuantityInStock());
                    } else {
                        System.out.println("Product not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Product not found: " + e.getMessage());
                }
                break;
            case 3:
                System.out.println("Enter product ID: ");
                productId = scanner.nextInt();
                scanner.nextLine();
                try {
                    Product product = productDAO.getProduct(productId);
                    if (product != null) {
                        System.out.println("Enter new product name: ");
                        name = scanner.nextLine();
                        System.out.println("Enter new product description: ");
                        description = scanner.nextLine();
                        System.out.println("Enter new product price: ");
                        price = scanner.nextDouble();
                        System.out.println("Enter new quantity in stock: ");
                        quantity = scanner.nextInt();
                        productDAO.updateProduct(new Product(productId, name, description, price, quantity));
                        System.out.println("Product updated.");
                    } else {
                        System.out.println("Product not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Product update failed: " + e.getMessage());
                }
                break;
            case 4:
                System.out.println("Enter product ID: ");
                productId = scanner.nextInt();
                try {
                    productDAO.deleteProduct(productId);
                    System.out.println("Product deleted.");
                } catch (SQLException e) {
                    System.err.println("Product deletion failed: " + e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid option. Try again.");
        }
    }

    private static void manageOrders(Scanner scanner) throws SQLException {
        System.out.println("Order Management");
        System.out.println("1. Place a new order");
        System.out.println("2. View order details");
        System.out.println("3. Update order information");
        System.out.println("4. Cancel an order");
        System.out.println("Choose an option: ");
        int option = scanner.nextInt();
        scanner.nextLine();

        switch (option) {
            case 1:
                System.out.println("Enter product ID: ");
                int productId = scanner.nextInt();
                System.out.println("Enter supplier ID: ");
                int supplierId = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Enter delivery date (YYYY-MM-DD): ");
                String deliveryDateStr = scanner.nextLine();
                Date orderDate = new java.sql.Date(System.currentTimeMillis());
                Date deliveryDate = java.sql.Date.valueOf(deliveryDateStr);
                
                if (deliveryDate.before(orderDate)) {
                    System.out.println("Delivery date cannot be before the order date.");
                    return;
                }
                
                String status = "placed";

                try {
                    Product product = productDAO.getProduct(productId);
                    if (product == null) {
                        System.out.println("Product not found.");
                    } else if (product.getQuantityInStock() == 0) {
                        System.out.println("Cannot place order. Product is out of stock.");
                    } else {
                        orderDAO.addOrder(new Order(0, productId, supplierId, orderDate, deliveryDate, status));
                        System.out.println("Order placed.");
                    }
                } catch (SQLException e) {
                    System.err.println("Order placement failed: " + e.getMessage());
                }
                break;
            case 2:
                System.out.println("Enter order ID: ");
                int orderId = scanner.nextInt();
                try {
                    Order order = orderDAO.getOrder(orderId);
                    if (order != null) {
                        System.out.println("Order ID: " + order.getOrderId());
                        System.out.println("Product ID: " + order.getProductId());
                        System.out.println("Supplier ID: " + order.getSupplierId());
                        System.out.println("Order Date: " + order.getOrderDate());
                        System.out.println("Delivery Date: " + order.getDeliveryDate());
                        System.out.println("Status: " + order.getStatus());
                    } else {
                        System.out.println("Order not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Order retrieval failed: " + e.getMessage());
                }
                break;
            case 3:
                System.out.println("Enter order ID: ");
                orderId = scanner.nextInt();
                scanner.nextLine();
                try {
                    Order order = orderDAO.getOrder(orderId);
                    if (order != null) {
                        System.out.println("Enter new product ID: ");
                        productId = scanner.nextInt();
                        System.out.println("Enter new supplier ID: ");
                        supplierId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter new delivery date (YYYY-MM-DD): ");
                        deliveryDateStr = scanner.nextLine();
                        orderDate = new java.sql.Date(System.currentTimeMillis());
                        deliveryDate = java.sql.Date.valueOf(deliveryDateStr);
                        
                        if (deliveryDate.before(orderDate)) {
                            System.out.println("Delivery date cannot be before the order date.");
                            return;
                        }

                        System.out.println("Enter new status: ");
                        status = scanner.nextLine();
                        orderDAO.updateOrder(new Order(orderId, productId, supplierId, orderDate, deliveryDate, status));
                        System.out.println("Order updated.");
                    } else {
                        System.out.println("Order not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Order update failed: " + e.getMessage());
                }
                break;
            case 4:
                System.out.println("Enter order ID: ");
                orderId = scanner.nextInt();
                try {
                    Order order = orderDAO.getOrder(orderId);
                    if (order != null) {
                        order.setStatus("cancelled");
                        orderDAO.updateOrder(order);
                        System.out.println("Order cancelled.");
                    } else {
                        System.out.println("Order not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Order cancellation failed: " + e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid option. Try again.");
        }
    }

    private static void manageSuppliers(Scanner scanner) throws SQLException {
        System.out.println("Supplier Management");
        System.out.println("1. Add a new supplier");
        System.out.println("2. View supplier details");
        System.out.println("3. Update supplier information");
        System.out.println("4. Delete a supplier");
        System.out.println("Choose an option: ");
        int option = scanner.nextInt();
        scanner.nextLine();

        switch (option) {
            case 1:
                System.out.println("Enter supplier name: ");
                String name = scanner.nextLine();
                System.out.println("Enter supplier email: ");
                String email = scanner.nextLine();
                System.out.println("Enter supplier phone number: ");
                String phoneNumber = scanner.nextLine();
                System.out.println("Enter supplier address: ");
                String address = scanner.nextLine();
                try {
                    supplierDAO.addSupplier(new Supplier(0, name, email, phoneNumber, address));
                    System.out.println("Supplier added.");
                } catch (SQLException e) {
                    System.err.println("Supplier addition failed: " + e.getMessage());
                }
                break;
            case 2:
                System.out.println("Enter supplier ID: ");
                int supplierId = scanner.nextInt();
                try {
                    Supplier supplier = supplierDAO.getSupplier(supplierId);
                    if (supplier != null) {
                        System.out.println("Supplier ID: " + supplier.getSupplierId());
                        System.out.println("Name: " + supplier.getName());
                        System.out.println("Email: " + supplier.getEmail());
                        System.out.println("Phone Number: " + supplier.getPhoneNumber());
                        System.out.println("Address: " + supplier.getAddress());
                    } else {
                        System.out.println("Supplier not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Supplier retrieval failed: " + e.getMessage());
                }
                break;
            case 3:
                System.out.println("Enter supplier ID: ");
                supplierId = scanner.nextInt();
                scanner.nextLine();
                try {
                    Supplier supplier = supplierDAO.getSupplier(supplierId);
                    if (supplier != null) {
                        System.out.println("Enter new supplier name: ");
                        name = scanner.nextLine();
                        System.out.println("Enter new supplier email: ");
                        email = scanner.nextLine();
                        System.out.println("Enter new supplier phone number: ");
                        phoneNumber = scanner.nextLine();
                        System.out.println("Enter new supplier address: ");
                        address = scanner.nextLine();
                        supplierDAO.updateSupplier(new Supplier(supplierId, name, email, phoneNumber, address));
                        System.out.println("Supplier updated.");
                    } else {
                        System.out.println("Supplier not found.");
                    }
                } catch (SQLException e) {
                    System.err.println("Supplier update failed: " + e.getMessage());
                }
                break;
            case 4:
                System.out.println("Enter supplier ID: ");
                supplierId = scanner.nextInt();
                try {
                    supplierDAO.deleteSupplier(supplierId);
                    System.out.println("Supplier deleted.");
                } catch (SQLException e) {
                    System.err.println("Supplier deletion failed: " + e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid option. Try again.");
        }
    }
}
