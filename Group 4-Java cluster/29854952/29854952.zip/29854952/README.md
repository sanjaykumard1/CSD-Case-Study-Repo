## Stock Management System

This project is a menu-based console application developed in Java using JDBC to interact with a MySQL database. It simulates a stock management system allowing users to manage products, suppliers, and orders efficiently.

### Features

**Product Management**
- Add a new product
- View product details
- Update product information
- Delete a product

**Supplier Management**
- Add a new supplier
- View supplier details
- Update supplier information
- Delete a supplier

**Order Management**
- Place a new order
- View order details
- Update order information
- Cancel an order

### Database Schema

The project uses MySQL with the following schema:

#### Product Table
- `product_id` (Primary Key)
- `name`
- `description`
- `price`
- `quantity_in_stock`

#### Supplier Table
- `supplier_id` (Primary Key)
- `name`
- `email`
- `phone_number`
- `address`

#### Order Table
- `order_id` (Primary Key)
- `product_id` (Foreign Key referencing Product Table)
- `supplier_id` (Foreign Key referencing Supplier Table)
- `order_date`
- `delivery_date`
- `status` (placed/delivered/cancelled)

### Setup Instructions

1. **Database Setup**
   - Create a MySQL database named `stock_management`.
   - Execute the SQL script provided (`create_tables.sql`) to create the necessary tables (`product`, `supplier`, `order`).

2. **Java Dependencies**
   - JDK (Java Development Kit)
   - MySQL JDBC Driver

3. **Project Setup**
   - Clone the repository from GitHub:
     ```
     git clone https://github.com/trinity2040/CSD-Case-Study-Repo//Group 4-Java cluster/29854952
     ```
   - Import the project into your IDE (Eclipse, IntelliJ, etc.).
   - Set up the JDBC driver for MySQL in your project.

4. **Running the Application**
   - Compile and run the `Main.java` file.
   - Follow the console prompts to interact with the stock management system.

### Usage

- **Adding a Product:**
  - Provide product details such as name, description, price, and quantity.
- **Viewing Product Details:**
  - Enter the product ID to view its details.
- **Updating Product Information:**
  - Enter the product ID and update its details.
- **Deleting a Product:**
  - Enter the product ID to delete it from the system.

- **Adding a Supplier:**
  - Enter supplier details including name, email, phone number, and address.
- **Viewing Supplier Details:**
  - Enter the supplier ID to view its details.
- **Updating Supplier Information:**
  - Enter the supplier ID and update its details.
- **Deleting a Supplier:**
  - Enter the supplier ID to delete it from the system.

- **Placing a New Order:**
  - Enter the product ID, supplier ID, order date, and delivery date to place an order.
- **Viewing Order Details:**
  - Enter the order ID to view its details.
- **Updating Order Information:**
  - Enter the order ID and update its details.
- **Cancelling an Order:**
  - Enter the order ID to cancel the order.

### Error Handling

- The application handles database errors using SQLExceptions, providing informative messages for the user.


