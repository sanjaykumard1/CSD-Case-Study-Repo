import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class PortfolioPerformanceChart {
	private static final String url="jdbc:mysql://localhost:3305/project";
	private static final String user="root";
	private static final String password="root";
	public static void calculate_portfolio_value(int id,String query) {
		try {
			Connection con=DriverManager.getConnection(url,user,password);
		query = "SELECT * FROM portfolio right join stock on portfolio.stock_id=stock.stock_id WHERE portfolio_id = ?";
        PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setInt(1, id);
        ResultSet rs = pstmt.executeQuery();
        
        int totval=0;
      	  while(rs.next()) {
      		  
        System.out.println("Stock ID - "+rs.getInt("stock_id")+ "\nQuantity - "+rs.getInt("quantity")+"\nPurchase Price - "+rs.getInt("purchase_price")+" \nPurchase Date - "+rs.getDate("purchase_date")+" \nCurrent Price - "+rs.getInt("current_price"));
        int qty=rs.getInt("quantity");
        int price=rs.getInt("current_price");
        totval=totval+(qty*price);
        System.out.println();

      	  }
      	  System.out.println("Portfolio Value: "+totval);
      	 
        }
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void analyze_performance(int id,String query) {
		try {
			Connection con=DriverManager.getConnection(url,user,password);
			query = "SELECT * FROM portfolio join stock on portfolio.stock_id=stock.stock_id WHERE portfolio_id = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            int totval=0,performance=0;
	      	  while(rs.next()) {
	        int qty=rs.getInt("quantity");
	        int price=rs.getInt("current_price");
	        int purchaseprice=rs.getInt("purchase_price");
    		  performance=performance+(qty*purchaseprice);
	        totval=totval+(qty*price);
	        
	      	  }
	      	int store=totval-performance;
	      	  System.out.println("ROI - "+store);
	      	  if(store>0) {
	      		  System.out.println("profit - "+store);
	      	  }
	      	  else if(store<0) {
	      		  System.out.println("loss - "+store);
	      	  }
	      	  else {
	      		  System.out.println("N0 loss no gain - "+store);
	      	  }
	      	  
		 }
		catch(Exception e) {
			e.printStackTrace();
		}
	}
    public static void gui(int id) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Portfolio Performance");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600);

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/project", "root", "root");

                // Query to get the stock data
                String query = "SELECT stock.stock_id, portfolio.quantity, stock.current_price, portfolio.purchase_price, portfolio.purchase_date " +
                               "FROM portfolio " +
                               "JOIN stock ON portfolio.stock_id = stock.stock_id " +
                               "WHERE portfolio_id = ?";
                PreparedStatement pstmt = con.prepareStatement(query);
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();

                DefaultPieDataset dataset = new DefaultPieDataset();
                int totalValue = 0;
                Map<String, Integer> stockValues = new HashMap<>();

                while (rs.next()) {
                    int stockId = rs.getInt("stock.stock_id");
                    int quantity = rs.getInt("portfolio.quantity");
                    int currentPrice = rs.getInt("stock.current_price");
                    int purchasePrice = rs.getInt("portfolio.purchase_price");
                    int value = quantity * currentPrice;

                    stockValues.put("Stock ID " + stockId, value);
                    totalValue += value;

                   /* System.out.println("Stock ID - " + stockId +
                                       "\nQuantity - " + quantity +
                                       "\nPurchase Price - " + purchasePrice +
                                       "\nPurchase Date - " + rs.getDate("portfolio.purchase_date") +
                                       "\nCurrent Price - " + currentPrice);*/
                }

                for (Map.Entry<String, Integer> entry : stockValues.entrySet()) {
                    dataset.setValue(entry.getKey(), entry.getValue());
                }

                JFreeChart chart = ChartFactory.createPieChart(
                        "Portfolio Performance",
                        dataset,
                        true,
                        true,
                        false
                );

                ChartPanel chartPanel = new ChartPanel(chart);
                frame.setContentPane(chartPanel);
                frame.setVisible(true);

                rs.close();
                pstmt.close();
                con.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
