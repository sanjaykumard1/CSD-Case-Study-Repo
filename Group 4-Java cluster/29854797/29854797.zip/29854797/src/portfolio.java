import java.util.*;
import java.sql.*;
public class portfolio {
  private static final String url="jdbc:mysql://localhost:3305/project";
  private static final String user="root";
  private static final String password="root";
  static void add_stocks_to_portfolio(int portfolio_id,int stock_id,int quantity,int purchase_price,String purchase_date) {
	  Connection con=null;
	  PreparedStatement pstmt=null;
	  try {
		  con=DriverManager.getConnection(url, user, password);
		  String query="insert into portfolio(portfolio_id,stock_id,quantity,purchase_price,purchase_date) VALUES (?, ?, ?, ?, ?)";
		  pstmt = con.prepareStatement(query);
          pstmt.setInt(1, portfolio_id);
          pstmt.setInt(2, stock_id);
          pstmt.setInt(3, quantity);
          pstmt.setInt(4, purchase_price);
          pstmt.setString(5, purchase_date);
          int rows_inserted = pstmt.executeUpdate();
          if (rows_inserted > 0) {
              System.out.println("Inserted successfully");
          }
	  }
	  catch(Exception e) {
		  e.printStackTrace();
	  }
  }
  static void view_portfolio_details(int id)
  {
	  Connection con=null;
	 // PreparedStatement pstmt1=null;
	  try {
		  con=DriverManager.getConnection(url, user, password);
		  String query = "SELECT * FROM portfolio WHERE portfolio_id = ?";
		  PreparedStatement pstmt1 = con.prepareStatement(query);
		  pstmt1.setInt(1, id);
		  ResultSet rs = pstmt1.executeQuery();
			  while(rs.next()) {
				  
		  System.out.println("Stock ID - "+rs.getInt("stock_id")+ "\nQuantity - "+rs.getInt("quantity")+"\nPurchase Price - "+rs.getInt("purchase_price")+" \nPurchase Date - "+rs.getDate("purchase_date"));
		  System.out.println();
	  }
	  }
	  catch(Exception e) {
		  e.printStackTrace();
	  }
}
  static void update_stock_information(String query2,String cid,String val1,int val2,int sid,int pid) {
	  Connection con=null;
	  
	  try {
		  con=DriverManager.getConnection(url, user, password);
		   query2 = "UPDATE portfolio SET " + cid + " = ? WHERE stock_id = ? AND portfolio_id = ?";
	      	PreparedStatement pstmt2 = con.prepareStatement(query2);
          
          if(cid.equals("purchase_date")) {
          	pstmt2.setString(1, val1);
          }
          else {
          	pstmt2.setInt(1, val2);
          }
          pstmt2.setInt(2, sid);
          pstmt2.setInt(3, pid);
          int rowsUpdated = pstmt2.executeUpdate();
          if (rowsUpdated > 0) {
              System.out.println("Record updated successfully!");
          } else {
              System.out.println("No record found with the given Stock ID in the specified portfolio.");
          }
	      	  }
	  catch(Exception e) {
		  e.printStackTrace();
	        
	  }
  }
  static void delete_stocks_from_portfolio(int sid,int id,String query1) {
	  Connection con=null;
	  try {
		  con=DriverManager.getConnection(url, user, password);
		  query1="delete  from portfolio where stock_id=? and portfolio_id=?";
	      	PreparedStatement pstmt1 = con.prepareStatement(query1);
          pstmt1.setInt(1, sid);
          pstmt1.setInt(2,id);
          int rowsdeleted = pstmt1.executeUpdate();
          if (rowsdeleted > 0) {
              System.out.println(" Deleted successfully!");
          } else {
              System.out.println("No stock found ");
          }
          //ResultSet rs1 = pstmt1.executeQuery();
	        }
	  catch(Exception e) {
		  e.printStackTrace();

	  }
  }
}
  
