import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class stock {
	private static final String url="jdbc:mysql://localhost:3305/project";
	private static final String user="root";
	private static final String password="root";
  static void retrive_display_realtime_stock() {
	  try {
	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
  	  Statement stmt=con.createStatement();
  	String query = "SELECT * FROM stock";
    PreparedStatement pstmt = con.prepareStatement(query);
    ResultSet rs = pstmt.executeQuery();
    System.out.println("ID - Current Price");
  	  while(rs.next()) {
  		  
    System.out.print(rs.getInt("stock_id")+ " -   "+rs.getInt("current_price"));
    System.out.println();
  	  }
	}
	  catch(Exception e) {
		  e.printStackTrace();
	  }
}
  static void historical_stock_data(int id,String query) {
	  try {
		  Connection con=DriverManager.getConnection(url, user, password);
		   query = "SELECT * FROM historical_data WHERE stock_id = ?";
          PreparedStatement pstmt = con.prepareStatement(query);
          pstmt.setInt(1, id);
          ResultSet rs = pstmt.executeQuery();
	      	  while(rs.next()) {
	      		  
	        System.out.println("Date - "+rs.getDate("date")+"\nClosing Price - "+rs.getInt("closing_price")+" \nQuantity Sold - "+rs.getInt("quantity_sold"));
          System.out.println();
	      	  }
	        }
	  catch(Exception e) {
		  e.printStackTrace();
	  }
  }
  static void update_stock_information(String query2,String cid,String val1,int val2,int sid) {
	  try {
	  Connection con=DriverManager.getConnection(url, user, password);
	  query2 = "UPDATE stock SET " + cid + " = ? WHERE stock_id = ?";
    	PreparedStatement pstmt2 = con.prepareStatement(query2);
      //pstmt2.setString(1,cid );
      if(cid.equals("stock_name")) {
      	pstmt2.setString(1, val1);
      }
      else {
      	pstmt2.setInt(1, val2);
      }
      pstmt2.setInt(2, sid);
      int rowsUpdated = pstmt2.executeUpdate();
      if (rowsUpdated > 0) {
          System.out.println("Record updated successfully!");
      } else {
          System.out.println("No record found with the given Stock ID in the specified portfolio.");
      }
    	  }
	  catch(Exception e) {
		  e.printStackTrace();
	  }
  }
}
