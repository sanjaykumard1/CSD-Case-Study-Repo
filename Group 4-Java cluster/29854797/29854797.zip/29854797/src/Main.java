import java.sql.*;
import java.util.*;
public class Main {
public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	     while(true) {
	    	 System.out.println("1. portfolio_management\n2. Stock Information\n3. Portfolio Analysis\n4. Exit");
	    	 int option=sc.nextInt();
	    	 switch(option) {
	    	 case 1:
	    	 {
	    		 System.out.println("1. Add new stocks to the portfolio\n2. View portfolio details\n3. Update stock information\n4. Delete stocks from the portfolio  ");
	    		 int val=sc.nextInt();
	    		 switch(val) {
	    		 case 1:
	    		 {
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Stocks Available");
	    		      	System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  ResultSet rs=stmt.executeQuery("Select * from stock");
	    		      	  while(rs.next()) {
	    		      		  System.out.println(rs.getInt("stock_id")+ " - "+rs.getString("stock_name"));
	    		      		  
	    		      	  }
	    		        }
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    			 System.out.println("enter portfolio_id: ");
	    			 int portfolio_id=sc.nextInt();
	    			 System.out.println("enter stock_id: ");
	    			int stock_id=sc.nextInt();
	    			System.out.println("enter qunatity: ");
	    			int quantity =sc.nextInt();
	    			System.out.println("enter purchase_price: ");
	    			int purchase_price=sc.nextInt();
	    			System.out.println("enter purchase_date: ");
	    			String purchase_date=sc.next();
	    			portfolio.add_stocks_to_portfolio(portfolio_id,stock_id,quantity,purchase_price,purchase_date);
	    		 }
	    		 break;
	    		 case 2:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Portfolio details");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter portfolio_id: ");
	    		      	  int id=sc.nextInt();
	    		      	  portfolio.view_portfolio_details(id);
	    		        }
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 case 3:
	    		 {
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Portfolio id: ");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter portfolio_id: ");
	    		      	  int pid=sc.nextInt();
	    		      	String query = "SELECT * FROM portfolio WHERE portfolio_id = ?";
	    	            PreparedStatement pstmt = con.prepareStatement(query);
	    	            pstmt.setInt(1, pid);
	    	            ResultSet rs = pstmt.executeQuery();
	    		      	  while(rs.next()) {
	    		      		  
	    		        System.out.println("Stock ID - "+rs.getInt("stock_id")+ "\nQuantity - "+rs.getInt("quantity")+"\nPurchase Price - "+rs.getInt("purchase_price")+" \nPurchase Date - "+rs.getDate("purchase_date"));
	                    System.out.println();
	    		      	  }
	                    System.out.print("Enter Stock_id to be updated: ");
	    		      	  int sid=sc.nextInt();
	    		      	 System.out.println("Enter column to be updated: ");
	    		      	 String cid=sc.next();
	    		      	 String val1 = null;
	    		      	 int val2 = 0;
	    		      	 if(cid.equals("purchase_date")){
	    		      		 System.out.println("enter value to be updated");
	    		      		  val1=sc.next();
	    		      	 }
	    		      	 else {
	    		      		 System.out.println("Enter value to be updated");
	    		      		  val2=sc.nextInt();
	    		      	 }
	    		      	 String query2=null;
	    		      	 portfolio.update_stock_information(query2,cid,val1,val2,sid,pid);
	    		      	
	    		      	  }
	    		        
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 case 4:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Portfolio details");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter portfolio_id: ");
	    		      	  int id=sc.nextInt();
	    		      	String query = "SELECT * FROM portfolio right join stock on portfolio.stock_id=stock.stock_id where portfolio_id=? ";
	    	            PreparedStatement pstmt = con.prepareStatement(query);
	    	            pstmt.setInt(1, id);
	    	            ResultSet rs = pstmt.executeQuery();
	    		      	  while(rs.next()) {
	    		      		  
	    		        System.out.println("Stock ID - "+rs.getInt("stock_id")+ "\nNAME - "+rs.getString("stock_name"));
	    		        System.out.println();
	    		      	  }
	    		      	  System.out.println("enter Stock Id to delete");
	    		      	  int sid=sc.nextInt();
	    		      	  String query1=null;
	    		      	  portfolio.delete_stocks_from_portfolio(sid,id,query1);
	    			 }
	    		      	   	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    			 
	    		 }
	    		 break;
	    		 default:{
	    			 System.out.println("wrong choice");
	    		 }
	    		 }
	    	
	    	 }
	    	 break;
	    	 case 2:
	    	 {
	    		 System.out.println("1. Retrieve and display real-time stock prices\n2. View historical stock data\n3. Update stock information (e.g., stock name, price)  ");
	    		 int res=sc.nextInt();
	    		 switch(res) {
	    		 case 1:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Real-Time Stock Prices");
	    		      	  stock.retrive_display_realtime_stock();
	    		        }
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 case 2:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Historical stock data");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter stock_id: ");
	    		      	  int id=sc.nextInt();
	    		      	  String query=null;
	    		      	  stock.historical_stock_data(id,query);
	    			 }
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 case 3:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	String query = "SELECT * FROM stock";
	    	            PreparedStatement pstmt = con.prepareStatement(query);
	    	            ResultSet rs = pstmt.executeQuery();
	    		      	  while(rs.next()) {
	    		      		  
	    		        System.out.println("Stock ID - "+rs.getInt("stock_id")+ "\nStock Name - "+rs.getString("stock_name")+"\nCurrent Price - "+rs.getInt("current_price")+" \nHigh Price - "+rs.getInt("high_price")+" \nLow Price - "+rs.getInt("low_price"));
	                    System.out.println();
	    		      	  }
	                    System.out.print("Enter Stock_id to be updated: ");
	    		      	  int sid=sc.nextInt();
	    		      	 System.out.println("Enter column to be updated: ");
	    		      	 String cid=sc.next();
	    		      	 String val1 = null;
	    		      	 int val2 = 0;
	    		      	 if(cid.equals("stock_name")){
	    		      		 System.out.println("enter value to be updated");
	    		      		  val1=sc.next();
	    		      	 }
	    		      	 else {
	    		      		 System.out.println("Enter value to be updated");
	    		      		  val2=sc.nextInt();
	    		      	 }
	    		      	 String query2=null;
	    		      	 stock.update_stock_information(query2,cid,val1,val2,sid);
	    			 }
	    		        
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 default:{
	    			 System.out.println("wrong choice");
	    		 }
	    		 }
	    	 }
	    	 break;
	    	 case 3:{
	    		 System.out.println("1. Calculate portfolio value based on current stock prices\n2. Analyze portfolio performance (e.g., ROI, gains/losses)\n3. View graphical representation of portfolio performance ");
	    		 int val=sc.nextInt();
	    		 switch(val) {
	    		 case 1:{
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Portfolio value based on current stock prices");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter portfolio_id: ");
	    		      	  int id=sc.nextInt();
	    		      	  String query=null;
	    		      	PortfolioPerformanceChart.calculate_portfolio_value(id,query);
	    			 }
	    			catch(Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    		 }
	    		 break;
	    		 case 2:{
	    			 
	    			 try {
	    		      	  Class.forName("com.mysql.cj.jdbc.Driver");
	    		      	  System.out.println("Analyze portfolio performance (e.g., ROI, gains/losses)");
	    		      	//System.out.println("id - name");
	    		      	
	    		      	  Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3305/project","root","root");
	    		      	  Statement stmt=con.createStatement();
	    		      	  System.out.print("Enter portfolio_id: ");
	    		      	  int id=sc.nextInt();
	    		      	  String query=null;
	    		      	  PortfolioPerformanceChart.analyze_performance(id, query);
	    		      	
	    		        
	    		 }
	    			 catch(Exception e) {
	    				 e.printStackTrace();
	    			 }
	    		      	  
	    		      	 
	    			 }
	    		 break;
	    		 case 3:{
	    			 System.out.println("Enter the portfolio id to be viewed : " );
	    			 int id=sc.nextInt();
	    			 PortfolioPerformanceChart.gui(id);
                      
	    		 }
	    		 break;
	    		 default:{
	    			 System.out.println("wrong choice");
	    		 }
	    		 }
	    	 }
	    	 break;
	    	 case 4:{
	    		 System.out.println("Exiting");
	    		 return;
	    	 }
	    	 default:
	    		 System.out.println("invalid choice");
	    		 
	     }
	    	 
		}

	}
}

	


