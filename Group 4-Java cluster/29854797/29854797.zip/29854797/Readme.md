# Stock Portfolio Management
     Develop a menu-based console application to assess your proficiency in Core Java, MySQL, and JDBC. The application will simulate a stock portfolio management system, allowing users to track their investments, view stock details, and analyze portfolio performance.
# Tools Requirement
     1.Ecllipse : 2024-03(4.31.0)
     2.Mysql Workbench:8.0.38
# How to impoer this project
     1.Start Eclipse
     2.Import the project (File->Import).
     3.Click General,select the Exiting Projects into workspace and click next.
     4.Select the root directory and click Finish.
# How to run this project
     1.Select Run and click Run
     2.The console will be popped up.
# Sample Output
```
1. portfolio_management
2. Stock Information
3. Portfolio Analysis
4. Exit
1
1. Add new stocks to the portfolio
2. View portfolio details
3. Update stock information
4. Delete stocks from the portfolio  
2
Portfolio details
Enter portfolio_id: 2
Stock ID - 3
Quantity - 2
Purchase Price - 400 
Purchase Date - 2024-07-03

Stock ID - 1
Quantity - 4
Purchase Price - 568 
Purchase Date - 2024-07-11

Stock ID - 5
Quantity - 7
Purchase Price - 5666 
Purchase Date - 2024-07-18

1. portfolio_management
2. Stock Information
3. Portfolio Analysis
4. Exit
2
1. Retrieve and display real-time stock prices
2. View historical stock data
3. Update stock information (e.g., stock name, price)  
1
Real-Time Stock Prices
ID - Current Price
1 -   500
2 -   800
3 -   390
4 -   450
5 -   1000
1. portfolio_management
2. Stock Information
3. Portfolio Analysis
4. Exit
1. portfolio_management
2. Stock Information
3. Portfolio Analysis
4. Exit
4
Exiting
```
