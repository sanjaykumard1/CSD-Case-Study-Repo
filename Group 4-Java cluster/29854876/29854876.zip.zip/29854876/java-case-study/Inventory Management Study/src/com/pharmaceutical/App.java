package com.pharmaceutical;

import com.pharmaceutical.dao.*;
import com.pharmaceutical.entity.Inventory;
import com.pharmaceutical.entity.Medication;
import com.pharmaceutical.entity.Supplier;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class App {

    private static MedicationDao medicationDao;
    private static SupplierDao supplierDao;
    private static InventoryDao inventoryDao;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        medicationDao = new MedicationImpl();
        supplierDao = new SupplierImpl();
        inventoryDao = new InventoryImpl();

        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addMedication();
                    break;
                case 2:
                    viewMedication();
                    break;
                case 3:
                    updateMedication();
                    break;
                case 4:
                    deleteMedication();
                    break;
                case 5:
                    viewAllMedications();
                    break;
                case 6:
                    addSupplier();
                    break;
                case 7:
                    viewSupplier();
                    break;
                case 8:
                    updateSupplier();
                    break;
                case 9:
                    deleteSupplier();
                    break;
                case 10:
                    viewAllSuppliers();
                    break;
                case 11:
                    addInventory();
                    break;
                case 12:
                    updateInventory();
                    break;
                case 13:
                    getAllInventoryLevels();
                    break;
                case 14:
                    getLowStockAlerts();
                    break;
                case 15:
                    System.out.println("Exiting the application.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

        private static void showMenu() {
            System.out.println("\nPharmaceutical Inventory Management System");
            System.out.println("1. Add a new medication");
            System.out.println("2. View medication details");
            System.out.println("3. Update medication information");
            System.out.println("4. Delete a medication");
            System.out.println("5. View all medications");
            System.out.println("6. Add a new supplier");
            System.out.println("7. View supplier details");
            System.out.println("8. Update supplier information");
            System.out.println("9. Delete a supplier");
            System.out.println("10. View all suppliers");
            System.out.println("11. Add a new inventory");
            System.out.println("12. Update inventory levels");
            System.out.println("13. View inventory levels");
            System.out.println("14. Generate low-stock alerts");
            System.out.println("15. Exit");
            System.out.print("Enter your choice: ");
        }

        private static void addMedication() {
            System.out.print("Enter medication ID: ");
            int medicationId = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter medication name: ");
            String name = scanner.nextLine();
            System.out.print("Enter medication description: ");
            String description = scanner.nextLine();
            System.out.print("Enter medication price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter medication quantity in stock: ");
            int quantityInStock = scanner.nextInt();
            scanner.nextLine();

            Medication medication = new Medication();
            medication.setMedicationId(medicationId);
            medication.setName(name);
            medication.setDescription(description);
            medication.setPrice(price);
            medication.setQuantityInStock(quantityInStock);

            medicationDao.addMedication(medication);
            System.out.println("Medication added successfully.");
        }

        private static void viewMedication() {
            System.out.print("Enter medication ID to view: ");
            int medicationId = scanner.nextInt();
            scanner.nextLine();

            Medication medication = medicationDao.getMedicationById(medicationId);
            if (medication != null) {
                System.out.println("Medication ID: " + medication.getMedicationId());
                System.out.println("Name: " + medication.getName());
                System.out.println("Description: " + medication.getDescription());
                System.out.println("Price: " + medication.getPrice());
                System.out.println("Quantity in Stock: " + medication.getQuantityInStock());
            } else {
                System.out.println("Medication not found.");
            }
        }

        private static void updateMedication() {
            System.out.print("Enter medication ID to update: ");
            int medicationId = scanner.nextInt();
            scanner.nextLine();

            Medication medication = medicationDao.getMedicationById(medicationId);
            if (medication != null) {
                System.out.print("Enter new name (or press Enter to keep current): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    medication.setName(name);
                }

                System.out.print("Enter new description (or press Enter to keep current): ");
                String description = scanner.nextLine();
                if (!description.isEmpty()) {
                    medication.setDescription(description);
                }

                System.out.print("Enter new price (or press Enter to keep current): ");
                String priceInput = scanner.nextLine();
                if (!priceInput.isEmpty()) {
                    double price = Double.parseDouble(priceInput);
                    medication.setPrice(price);
                }

                System.out.print("Enter new quantity in stock (or press Enter to keep current): ");
                String quantityInput = scanner.nextLine();
                if (!quantityInput.isEmpty()) {
                    int quantityInStock = Integer.parseInt(quantityInput);
                    medication.setQuantityInStock(quantityInStock);
                }

                int rowsAffected = medicationDao.updateMedication(medication);
                if (rowsAffected > 0) {
                    System.out.println("Medication updated successfully.");
                } else {
                    System.out.println("No changes made to the medication.");
                }
            } else {
                System.out.println("Medication not found.");
            }
        }

        private static void deleteMedication() {
            System.out.print("Enter medication ID to delete: ");
            int medicationId = scanner.nextInt();
            scanner.nextLine();

            int rowsAffected = medicationDao.deleteMedication(medicationId);
            if (rowsAffected > 0) {
                System.out.println("Medication deleted successfully.");
            } else {
                System.out.println("Medication not found.");
            }
        }

        private static void viewAllMedications() {
            List<Medication> medications = medicationDao.getAllMedications();
            if (medications.isEmpty()) {
                System.out.println("No medications found.");
            } else {
                for (Medication medication : medications) {
                    System.out.println("\nMedication ID: " + medication.getMedicationId());
                    System.out.println("Name: " + medication.getName());
                    System.out.println("Description: " + medication.getDescription());
                    System.out.println("Price: " + medication.getPrice());
                    System.out.println("Quantity in Stock: " + medication.getQuantityInStock());
                }
            }
        }

    private static void addSupplier() {
        System.out.println("\nEnter details for the new supplier:");
        System.out.print("Supplier ID: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone Number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();

        Supplier supplier = new Supplier();
        supplier.setSupplierId(supplierId);
        supplier.setName(name);
        supplier.setEmail(email);
        supplier.setPhoneNumber(phoneNumber);
        supplier.setAddress(address);

        supplierDao.addSupplier(supplier);
        System.out.println("Supplier added successfully.");
    }

    private static void viewSupplier() {
        System.out.print("Enter supplier ID to view: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine();

        Supplier supplier = supplierDao.getSupplierById(supplierId);
        if (supplier != null) {
            System.out.println("\nSupplier Details:");
            System.out.println("Supplier ID: " + supplier.getSupplierId());
            System.out.println("Name: " + supplier.getName());
            System.out.println("Email: " + supplier.getEmail());
            System.out.println("Phone Number: " + supplier.getPhoneNumber());
            System.out.println("Address: " + supplier.getAddress());
        } else {
            System.out.println("Supplier not found.");
        }
    }

    private static void updateSupplier() {
        System.out.print("Enter supplier ID to update: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine();

        Supplier supplier = supplierDao.getSupplierById(supplierId);
        if (supplier != null) {
            System.out.println("\nCurrent Supplier Details:");
            System.out.println("Supplier ID: " + supplier.getSupplierId());
            System.out.println("Name: " + supplier.getName());
            System.out.println("Email: " + supplier.getEmail());
            System.out.println("Phone Number: " + supplier.getPhoneNumber());
            System.out.println("Address: " + supplier.getAddress());

            System.out.print("\nEnter new name (or press Enter to keep current): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                supplier.setName(name);
            }

            System.out.print("Enter new email (or press Enter to keep current): ");
            String email = scanner.nextLine();
            if (!email.isEmpty()) {
                supplier.setEmail(email);
            }

            System.out.print("Enter new phone number (or press Enter to keep current): ");
            String phoneNumber = scanner.nextLine();
            if (!phoneNumber.isEmpty()) {
                supplier.setPhoneNumber(phoneNumber);
            }

            System.out.print("Enter new address (or press Enter to keep current): ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) {
                supplier.setAddress(address);
            }

            int rowsAffected = supplierDao.updateSupplier(supplier);
            if (rowsAffected > 0) {
                System.out.println("Supplier updated successfully.");
            } else {
                System.out.println("No changes made to the supplier.");
            }
        } else {
            System.out.println("Supplier not found.");
        }
    }

    private static void deleteSupplier() {
        System.out.print("Enter supplier ID to delete: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        int rowsAffected = supplierDao.deleteSupplier(supplierId);

        if (rowsAffected > 0) {
            System.out.println("Supplier deleted successfully.");
        } else {
            System.out.println("Supplier not found.");
        }
    }

    private static void viewAllSuppliers() {
        List<Supplier> suppliers = supplierDao.getAllSuppliers();

        if (suppliers.isEmpty()) {
            System.out.println("No suppliers found.");
        } else {
            System.out.println("\nAll Suppliers:");
            for (Supplier supplier : suppliers) {
                System.out.println("\nSupplier ID: " + supplier.getSupplierId());
                System.out.println("Name: " + supplier.getName());
                System.out.println("Email: " + supplier.getEmail());
                System.out.println("Phone Number: " + supplier.getPhoneNumber());
                System.out.println("Address: " + supplier.getAddress());
            }
        }
    }

    private static void addInventory() {
        System.out.println("\nEnter details for the new inventory:");

        System.out.print("Inventory ID: ");
        int inventoryId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Medication ID: ");
        int medicationId = scanner.nextInt();
        scanner.nextLine();

        // Validate if the medication ID exists
        if (isValidMedicationId(medicationId)) {
            System.out.print("Supplier ID: ");
            int supplierId = scanner.nextInt();
            scanner.nextLine();

            // Validate if the supplier ID exists
            if (isValidSupplierId(supplierId)) {
                System.out.print("Quantity received: ");
                int quantityReceived = scanner.nextInt();
                scanner.nextLine();

                System.out.print("Date received (YYYY-MM-DD format): ");
                String dateReceivedInput = scanner.nextLine();
                Date dateReceived = null;

                // Validate and parse date input
                if (!dateReceivedInput.isEmpty()) {
                    try {
                        LocalDate localDate = LocalDate.parse(dateReceivedInput);
                        dateReceived = Date.valueOf(localDate);
                    } catch (DateTimeParseException e) {
                        System.out.println("Invalid date format. Please enter date in YYYY-MM-DD format.");
                        return;
                    }
                } else {
                    System.out.println("Date received not provided. Please enter date in YYYY-MM-DD format.");
                    return;
                }

                Inventory inventory = new Inventory();
                inventory.setInventoryId(inventoryId);
                inventory.setMedicationId(medicationId);
                inventory.setSupplierId(supplierId);
                inventory.setQuantityReceived(quantityReceived);
                inventory.setDateReceived(dateReceived);

                int rowsAffected = inventoryDao.addInventory(inventory);
                if (rowsAffected > 0) {
                    System.out.println("Inventory added successfully.");
                } else {
                    System.out.println("Failed to add inventory. Please try again.");
                }
            } else {
                System.out.println("Supplier ID does not exist. Please enter a valid Supplier ID.");
            }
        } else {
            System.out.println("Medication ID does not exist. Please enter a valid Medication ID.");
        }
    }

    private static boolean isValidMedicationId(int medicationId) {
        Medication medication = medicationDao.getMedicationById(medicationId);
        return medication != null;
    }

    private static void updateInventory() {
        System.out.print("Enter inventory ID to update: ");
        int inventoryId = scanner.nextInt();
        scanner.nextLine();

        Inventory existingInventory = inventoryDao.getInventoryById(inventoryId);
        if (existingInventory == null) {
            System.out.println("Inventory with ID " + inventoryId + " does not exist.");
            return;
        }

        System.out.print("Enter new medication ID (or press Enter to keep current): ");
        String medicationIdInput = scanner.nextLine();
        int medicationId = medicationIdInput.isEmpty() ? existingInventory.getMedicationId() : Integer.parseInt(medicationIdInput);

        System.out.print("Enter new supplier ID (or press Enter to keep current): ");
        String supplierIdInput = scanner.nextLine();
        int supplierId = supplierIdInput.isEmpty() ? existingInventory.getSupplierId() : Integer.parseInt(supplierIdInput);

        System.out.print("Enter new quantity received (or press Enter to keep current): ");
        String quantityReceivedInput = scanner.nextLine();
        int quantityReceived = quantityReceivedInput.isEmpty() ? existingInventory.getQuantityReceived() : Integer.parseInt(quantityReceivedInput);

        System.out.print("Enter new date received (YYYY-MM-DD format) (or press Enter to keep current): ");
        String dateReceivedInput = scanner.nextLine();
        Date dateReceived;
        if (dateReceivedInput.isEmpty()) {
            dateReceived = existingInventory.getDateReceived();
        } else {
            try {
                LocalDate localDate = LocalDate.parse(dateReceivedInput);
                dateReceived = Date.valueOf(localDate);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please enter date in YYYY-MM-DD format.");
                return;
            }
        }

        Inventory updatedInventory = new Inventory();
        updatedInventory.setInventoryId(inventoryId);
        updatedInventory.setMedicationId(medicationId);
        updatedInventory.setSupplierId(supplierId);
        updatedInventory.setQuantityReceived(quantityReceived);
        updatedInventory.setDateReceived(dateReceived);

        int rowsAffected = inventoryDao.updateInventory(updatedInventory);
        if (rowsAffected > 0) {
            System.out.println("Inventory updated successfully.");
        } else {
            System.out.println("Failed to update inventory. Please try again.");
        }
    }


    private static boolean isValidSupplierId(int supplierId) {
        Supplier supplier = supplierDao.getSupplierById(supplierId);
        return supplier != null;
    }

    private static void getAllInventoryLevels() {
        List<Inventory> inventoryList = inventoryDao.getAllInventoryLevels();

        if (inventoryList.isEmpty()) {
            System.out.println("No inventory levels found.");
        } else {
            System.out.println("\nAll Inventory Levels:");
            for (Inventory inventory : inventoryList) {
                System.out.println("\nInventory ID: " + inventory.getInventoryId());
                System.out.println("Medication ID: " + inventory.getMedicationId());
                System.out.println("Supplier ID: " + inventory.getSupplierId());
                System.out.println("Quantity Received: " + inventory.getQuantityReceived());
                System.out.println("Date Received: " + inventory.getDateReceived());
            }
        }
    }

    private static void getLowStockAlerts() {
        System.out.print("Enter low stock threshold: ");
        int threshold = scanner.nextInt();
        scanner.nextLine();

        List<Medication> lowStockInventory = inventoryDao.getLowStockAlerts(threshold);

        if (lowStockInventory.isEmpty()) {
            System.out.println("No inventory items with low stock found.");
        } else {
            System.out.println("\nInventory Items with Low Stock (Threshold: " + threshold + "):");
            for (Medication medication : lowStockInventory) {
                System.out.println("\nMedication ID: " + medication.getMedicationId());
                System.out.println("Name: " + medication.getName());
                System.out.println("Quantity in Stock: " + medication.getQuantityInStock());
            }
        }
    }


}