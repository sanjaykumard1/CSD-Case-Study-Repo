package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Inventory;
import com.pharmaceutical.entity.Medication;
import com.pharmaceutical.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InventoryImpl implements InventoryDao {

    private static final String SELECT_INVENTORY = "select * from inventory where inventory_id = ?";

    private static final String INSERT_QUERY = "insert into inventory (inventory_id, medication_id, supplier_id, quantity_received, date_received) values (?, ?, ?, ?, ?)";
    private static final String UPDATE_INVENTORY_QUERY = "update inventory set medication_id = ?, supplier_id = ?, quantity_received = ?, date_received = ? where inventory_id = ?";
    private static final String UPDATE_MEDICATION_QUERY = "update medication set quantity_in_stock = quantity_in_stock + ? where medication_id = ?";
    private static final String SELECT_ALL = "select * from inventory";
    private static final String LOW_STOCK_ALERTS_QUERY = "select medication_id, name, quantity_in_stock from medication where quantity_in_stock < ?";

    private Connection connection= DbUtil.getConnection();

    public int addInventory(Inventory inventory) {
        PreparedStatement ps = null;
        PreparedStatement psUpdate = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(INSERT_QUERY);
            ps.setInt(1, inventory.getInventoryId());
            ps.setInt(2, inventory.getMedicationId());
            ps.setInt(3, inventory.getSupplierId());
            ps.setInt(4, inventory.getQuantityReceived());
            ps.setDate(5, inventory.getDateReceived());

            rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                // Update the medication stock
                psUpdate = connection.prepareStatement(UPDATE_MEDICATION_QUERY);
                psUpdate.setInt(1, inventory.getQuantityReceived());
                psUpdate.setInt(2, inventory.getMedicationId());
                int updateRows = psUpdate.executeUpdate();

                if (updateRows > 0) {
                    System.out.println("Medication stock updated successfully.");
                } else {
                    System.out.println("Failed to update medication stock.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error adding inventory: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                System.out.println("Error closing PreparedStatement: " + e.getMessage());
                e.printStackTrace();
            }
        }

        return rowsAffected;
    }

    @Override
    public Inventory getInventoryById(int inventoryId) {
        Inventory inventory = null;
        PreparedStatement ps = null;
        ResultSet rs = null;


        try {
            ps = connection.prepareStatement(SELECT_INVENTORY);
            ps.setInt(1, inventoryId);
            rs = ps.executeQuery();

            if (rs.next()) {
                // Extract data from the result set and create an Inventory object
                inventory = new Inventory();
                inventory.setInventoryId(rs.getInt("inventory_id"));
                inventory.setMedicationId(rs.getInt("medication_id"));
                inventory.setSupplierId(rs.getInt("supplier_id"));
                inventory.setQuantityReceived(rs.getInt("quantity_received"));
                inventory.setDateReceived(rs.getDate("date_received"));
            }
        } catch (SQLException e) {
            System.out.println("Error while fetching inventory by ID: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return inventory;
    }
    @Override
    public int updateInventory(Inventory inventory) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            // Update the inventory
            ps = connection.prepareStatement(UPDATE_INVENTORY_QUERY);
            ps.setInt(1, inventory.getMedicationId());
            ps.setInt(2, inventory.getSupplierId());
            ps.setInt(3, inventory.getQuantityReceived());
            ps.setDate(4, new java.sql.Date(inventory.getDateReceived().getTime()));
            ps.setInt(5, inventory.getInventoryId());
            rowsAffected = ps.executeUpdate();

            // Update the quantity in stock in the Medication table
            if (rowsAffected > 0) {
                ps = connection.prepareStatement(UPDATE_MEDICATION_QUERY);
                ps.setInt(1, inventory.getQuantityReceived());
                ps.setInt(2, inventory.getMedicationId());
                ps.executeUpdate();
            }

        } catch (SQLException e) {
            System.out.println("Update Inventory Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return rowsAffected;
    }

    @Override
    public List<Inventory> getAllInventoryLevels() {
        List<Inventory> inventoryList = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_ALL);
            rs = ps.executeQuery();

            while (rs.next()) {
                Inventory inventory = new Inventory();
                inventory.setInventoryId(rs.getInt("inventory_id"));
                inventory.setMedicationId(rs.getInt("medication_id"));
                inventory.setSupplierId(rs.getInt("supplier_id"));
                inventory.setQuantityReceived(rs.getInt("quantity_received"));
                inventory.setDateReceived(rs.getDate("date_received"));
                inventoryList.add(inventory);
            }
        } catch (SQLException e) {
            System.out.println("Get All Inventory Levels Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return inventoryList;
    }

    @Override
    public List<Medication> getLowStockAlerts(int threshold) {
        List<Medication> lowStockList = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(LOW_STOCK_ALERTS_QUERY);
            ps.setInt(1, threshold);
            rs = ps.executeQuery();

            while (rs.next()) {
                Medication medication = new Medication();
                medication.setMedicationId(rs.getInt("medication_id"));
                medication.setName(rs.getString("name"));
                medication.setQuantityInStock(rs.getInt("quantity_in_stock"));
                lowStockList.add(medication);
            }
        } catch (SQLException e) {
            System.out.println("Get Low Stock Alerts Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return lowStockList;
    }
}
