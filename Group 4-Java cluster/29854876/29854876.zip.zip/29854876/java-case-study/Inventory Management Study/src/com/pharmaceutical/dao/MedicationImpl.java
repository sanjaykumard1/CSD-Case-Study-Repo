package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Medication;
import com.pharmaceutical.util.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicationImpl implements MedicationDao{

    private Connection connection=DbUtil.getConnection();

    private static final String INSERT_QUERY = "insert into medication values(?, ?, ?, ?, ?)";
    private static final String SELECT_MEDICATION = "select * from medication where medication_id = ?";
    private static final String UPDATE_QUERY = "update medication set name = ?, description = ?, price = ?, quantity_in_stock = ? where medication_id = ?";
    private static final String DELETE_QUERY = "delete from medication where medication_id = ?";
    private static final String SELECT_ALL = "select * from medication";


    @Override
    public int addMedication(Medication medication) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(INSERT_QUERY);
            ps.setInt(1, medication.getMedicationId());
            ps.setString(2, medication.getName());
            ps.setString(3, medication.getDescription());
            ps.setDouble(4, medication.getPrice());
            ps.setInt(5, medication.getQuantityInStock());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Insertion Error in Medication table: " + e);
            e.printStackTrace();
        }
        finally {
            try {
                ps.close();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return rowsAffected;
    }

    @Override
    public Medication getMedicationById(int medicationId) {
        Medication medication = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_MEDICATION);
            ps.setInt(1, medicationId);
            rs = ps.executeQuery();

            if(rs.next()) {
                medication = new Medication();
                medication.setMedicationId(rs.getInt("medication_id"));
                medication.setName(rs.getString("name"));
                medication.setDescription(rs.getString("description"));
                medication.setPrice(rs.getDouble("price"));
                medication.setQuantityInStock(rs.getInt("quantity_in_stock"));
            }
        } catch (SQLException e) {
            System.out.println("Selection Error: " + e);
            e.printStackTrace();
        }
        finally {
            try {
                if(rs != null) {
                    rs.close();
                }
                if(ps != null) {
                    ps.close();
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return medication;
    }

    @Override
    public int updateMedication(Medication medication) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(UPDATE_QUERY);
            ps.setString(1, medication.getName());
            ps.setString(2, medication.getDescription());
            ps.setDouble(3, medication.getPrice());
            ps.setInt(4, medication.getQuantityInStock());
            ps.setInt(5, medication.getMedicationId());

            rowsAffected = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Update Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return rowsAffected;
    }

    @Override
    public int deleteMedication(int medicationId) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(DELETE_QUERY);
            ps.setInt(1, medicationId);

            rowsAffected = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Delete Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return rowsAffected;
    }

    @Override
    public List<Medication> getAllMedications() {
        List<Medication> medications = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_ALL);
            rs = ps.executeQuery();

            while (rs.next()) {
                Medication medication = new Medication();
                medication.setMedicationId(rs.getInt("medication_id"));
                medication.setName(rs.getString("name"));
                medication.setDescription(rs.getString("description"));
                medication.setPrice(rs.getDouble("price"));
                medication.setQuantityInStock(rs.getInt("quantity_in_stock"));
                medications.add(medication);
            }
        } catch (SQLException e) {
            System.out.println("Query Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return medications;
    }
}
