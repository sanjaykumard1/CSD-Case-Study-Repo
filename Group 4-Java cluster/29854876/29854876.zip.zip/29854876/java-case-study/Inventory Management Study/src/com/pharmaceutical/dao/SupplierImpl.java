package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Supplier;
import com.pharmaceutical.util.DbUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierImpl implements SupplierDao {

    private static final String INSERT_QUERY = "insert into supplier(supplier_id, name, email, phone_number, address) values (?, ?, ?, ?, ?)";
    private static final String SELECT_SUPPLIER = "select * from supplier where supplier_id = ?";
    private static final String UPDATE_QUERY = "update supplier set name=?, email=?, phone_number=?, address=? where supplier_id=?";
    private static final String DELETE_QUERY = "delete from supplier where supplier_id=?";
    private static final String SELECT_ALL = "select * from supplier";

    private Connection connection= DbUtil.getConnection();

    @Override
    public int addSupplier(Supplier supplier) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(INSERT_QUERY);
            ps.setInt(1, supplier.getSupplierId());
            ps.setString(2, supplier.getName());
            ps.setString(3, supplier.getEmail());
            ps.setString(4, supplier.getPhoneNumber());
            ps.setString(5, supplier.getAddress());
            rowsAffected = ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Insert Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return rowsAffected;
    }

    @Override
    public Supplier getSupplierById(int supplierId) {
        Supplier supplier = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = connection.prepareStatement(SELECT_SUPPLIER);
            ps.setInt(1, supplierId);
            rs = ps.executeQuery();

            if (rs.next()) {
                supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setName(rs.getString("name"));
                supplier.setEmail(rs.getString("email"));
                supplier.setPhoneNumber(rs.getString("phone_number"));
                supplier.setAddress(rs.getString("address"));
            }
        } catch (SQLException e) {
            System.out.println("Query Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return supplier;
    }

    @Override
    public int updateSupplier(Supplier supplier) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(UPDATE_QUERY);
            ps.setString(1, supplier.getName());
            ps.setString(2, supplier.getEmail());
            ps.setString(3, supplier.getPhoneNumber());
            ps.setString(4, supplier.getAddress());
            ps.setInt(5, supplier.getSupplierId());

            rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Supplier updated successfully.");
            } else {
                System.out.println("Failed to update supplier.");
            }
        } catch (SQLException e) {
            System.out.println("Update Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return rowsAffected;
    }

    @Override
    public int deleteSupplier(int supplierId) {
        PreparedStatement ps = null;
        int rowsAffected = 0;

        try {
            ps = connection.prepareStatement(DELETE_QUERY);
            ps.setInt(1, supplierId);

            rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Supplier deleted successfully.");
            } else {
                System.out.println("Failed to delete supplier.");
            }
        } catch (SQLException e) {
            System.out.println("Delete Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return rowsAffected;
    }

    @Override
    public List<Supplier> getAllSuppliers() {
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Supplier> suppliers = new ArrayList<>();

        try {
            ps = connection.prepareStatement(SELECT_ALL);
            rs = ps.executeQuery();

            while (rs.next()) {
                Supplier supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setName(rs.getString("name"));
                supplier.setEmail(rs.getString("email"));
                supplier.setPhoneNumber(rs.getString("phone_number"));
                supplier.setAddress(rs.getString("address"));

                suppliers.add(supplier);
            }
        } catch (SQLException e) {
            System.out.println("Query Error: " + e);
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return suppliers;
    }
}
