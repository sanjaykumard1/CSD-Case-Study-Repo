package com.pharmaceutical.entity;

import java.sql.Date;

public class Inventory {
    private int inventoryId;
    private int medicationId;
    private int supplierId;
    private int quantityReceived;
    private Date dateReceived;

    // Getters and Setters
    public int getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    public int getMedicationId() {
        return medicationId;
    }

    public void setMedicationId(int medicationId) {
        this.medicationId = medicationId;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public int getQuantityReceived() {
        return quantityReceived;
    }

    public void setQuantityReceived(int quantityReceived) {
        this.quantityReceived = quantityReceived;
    }

    public Date getDateReceived() {
        return dateReceived;
    }

    public void setDateReceived(Date dateReceived) {
        this.dateReceived = dateReceived;
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "inventoryId=" + inventoryId +
                ", medicationId=" + medicationId +
                ", supplierId=" + supplierId +
                ", quantityReceived=" + quantityReceived +
                ", dateReceived=" + dateReceived +
                '}';
    }
}
