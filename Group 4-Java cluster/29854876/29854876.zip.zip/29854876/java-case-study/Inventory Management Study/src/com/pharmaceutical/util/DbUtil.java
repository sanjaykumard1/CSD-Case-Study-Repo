package com.pharmaceutical.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
    private static Connection connection = null;
    private static String url = "jdbc:mysql://localhost:3306/pharmaceutical_inventory";
    private static String username = "root";
    private static String password = "Kasba42$";

    public static Connection getConnection() {
        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection Succesful");
        } catch (SQLException e) {
            System.out.println("Connection Not Created: " + e);
        }
        return connection;
    }

    public static void main(String[] args) {
        getConnection();
    }
}


