package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Medication;
import java.util.List;

public interface MedicationDao {

    // Create (Add a new medication)
    public int addMedication(Medication medication);

    // Read (View medication details)
    public Medication getMedicationById(int medicationId);

    // Update (Update medication information)
    public int updateMedication(Medication medication);

    // Delete (Delete a medication)
    public int deleteMedication(int medicationId);

    // Read all medications
    public List<Medication> getAllMedications();
}

