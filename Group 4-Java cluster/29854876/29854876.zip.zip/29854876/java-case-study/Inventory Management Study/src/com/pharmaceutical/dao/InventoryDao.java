package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Inventory;
import com.pharmaceutical.entity.Medication;

import java.util.List;

public interface InventoryDao {

    Inventory getInventoryById(int inventoryId);

    int addInventory(Inventory inventory);

    // Update inventory levels by adding new inventory entries
    int updateInventory(Inventory inventory);

    // View all inventory levels
    List<Inventory> getAllInventoryLevels();

    // Generate low-stock alerts
    List<Medication> getLowStockAlerts(int threshold);
}

