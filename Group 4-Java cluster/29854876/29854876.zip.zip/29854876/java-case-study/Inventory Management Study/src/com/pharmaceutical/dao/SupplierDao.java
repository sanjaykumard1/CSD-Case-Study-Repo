package com.pharmaceutical.dao;

import com.pharmaceutical.entity.Supplier;
import java.util.List;

public interface SupplierDao {

    // Method to add a new supplier
    int addSupplier(Supplier supplier);

    // Method to get a supplier by ID
    Supplier getSupplierById(int supplierId);

    // Method to update supplier information
    int updateSupplier(Supplier supplier);

    // Method to delete a supplier by ID
    int deleteSupplier(int supplierId);

    // Method to retrieve all suppliers
    List<Supplier> getAllSuppliers();
}

