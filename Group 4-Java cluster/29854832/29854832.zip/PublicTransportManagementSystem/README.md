Public Transportation Management System
This project is a simple console-based application for managing public transportation. It is built using Core Java, MySQL, and JDBC. The application allows users to manage buses, passengers, and routes.

Features
Bus Management

Add a new bus
View bus details
Update bus information
Delete a bus
Passenger Management

Add a new passenger
View passenger details
Update passenger information
Delete a passenger
Route Management

Add a new route
View route details
Update route information
Delete a route