# Product Review Management System

This project implements a menu-based console application in Java for managing product reviews, ratings, and improvements for a consumer electronics company. It utilizes MySQL for database storage and JDBC for database interactions.

## Functionalities

1. *Review Management*
    - Add a new review for a product
    - View review details
    - Update review information
    - Delete a review

2. *Rating Management*
    - Add a rating for a product
    - View average ratings for products
    - Update rating information
    - Delete rating records

3. *Improvement Management*
    - Implement product improvements based on reviews
    - View improvement details
    - Update improvement status
    - Delete improvement records

## Database Schema

### Product Table

- product_id INT AUTO_INCREMENT PRIMARY KEY
- product_name VARCHAR(100) NOT NULL
- description TEXT
- category VARCHAR(50)
- price DECIMAL(10, 2)

### Customer Table

- customer_id INT AUTO_INCREMENT PRIMARY KEY
- customer_name VARCHAR(100) NOT NULL
- email VARCHAR(100) UNIQUE
- phone_number VARCHAR(15)
- address VARCHAR(200)

### Review Table

- review_id INT AUTO_INCREMENT PRIMARY KEY
- product_id INT
- customer_id INT
- review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- review_text TEXT
- FOREIGN KEY (product_id) REFERENCES Product(product_id) ON DELETE CASCADE
- FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE

### Rating Table

- rating_id INT AUTO_INCREMENT PRIMARY KEY
- product_id INT
- customer_id INT
- rating_value INT
- FOREIGN KEY (product_id) REFERENCES Product(product_id) ON DELETE CASCADE
- FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE

### Improvement Table

- improvement_id INT AUTO_INCREMENT PRIMARY KEY
- product_id INT
- implementation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
- improvement_details TEXT
- status VARCHAR(20) DEFAULT 'Pending'
- FOREIGN KEY (product_id) REFERENCES Product(product_id)

## Setup Instructions

1. *Database Setup*:
    - Create a MySQL database named productreview.
    - Execute the SQL commands provided in schema.sql to create the necessary tables (Product, Customer, Review, Rating, Improvement).

2. *Java Application Setup*:
    - Clone this repository to your local machine.
    - Open the project in your preferred Java IDE.

3. *Configure Database Connection*:
    - Modify the DatabaseConnection.java file to set your MySQL database credentials (URL, USERNAME, PASSWORD).

4. *Run the Application*:
    - Compile and run the Main.java file to start the console application.
    - Follow the menu options to manage product reviews, ratings, and improvements.

## Usage

- Use the console menu to navigate through different functionalities:
    - Add, view, update, and delete reviews for products.
    - Add, view, update, and delete ratings for products.
    - Implement, view, update, and delete improvements based on customer feedback.
