import dao.ImprovementDAO;
import dao.RatingDAO;
import dao.ReviewDAO;
import mod.Improvement;
import mod.Rating;
import mod.Review;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReviewDAO reviewDAO = new ReviewDAO();
        RatingDAO ratingDAO = new RatingDAO();
        ImprovementDAO improvementDAO = new ImprovementDAO();

        while (true) {
            System.out.println("Product Review Management System");
            System.out.println("1. Review Management");
            System.out.println("2. Rating Management");
            System.out.println("3. Improvement Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    manageReviews(scanner, reviewDAO);
                    break;
                case 2:
                    manageRatings(scanner, ratingDAO);
                    break;
                case 3:
                    manageImprovements(scanner, improvementDAO);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageReviews(Scanner scanner, ReviewDAO reviewDAO) {
        System.out.println("Review Management");
        System.out.println("1. Add Review");
        System.out.println("2. View Review");
        System.out.println("3. Update Review");
        System.out.println("4. Delete Review");
        System.out.println("5. Exit");

        System.out.print("Select an option: ");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                System.out.print("Enter product ID: ");
                int productId = scanner.nextInt();
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter review text: ");
                String reviewText = scanner.nextLine();
                reviewDAO.addReview(new Review(productId, customerId, reviewText));
                break;
            case 2:
                System.out.print("Enter review ID: ");
                int reviewId = scanner.nextInt();
                Review review = reviewDAO.getReview(reviewId);
                System.out.println(review);
                break;
            case 3:
                System.out.print("Enter review ID to update: ");
                int updateReviewId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter updated review text: ");
                String updatedReviewText = scanner.nextLine();
                reviewDAO.updateReview(updateReviewId, updatedReviewText);
                break;
            case 4:
                System.out.print("Enter review ID to delete: ");
                int deleteReviewId = scanner.nextInt();
                reviewDAO.deleteReview(deleteReviewId);
                break;
            case 5:
                System.out.println("Exiting...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageRatings(Scanner scanner, RatingDAO ratingDAO) {
        System.out.println("Rating Management");
        System.out.println("1. Add Rating");
        System.out.println("2. View Average Ratings");
        System.out.println("3. Update Rating");
        System.out.println("4. Delete Rating");
        System.out.println("5. Exit");
        System.out.print("Select an option: ");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                System.out.print("Enter product ID: ");
                int productId = scanner.nextInt();
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                System.out.print("Enter rating value (1-5): ");
                int ratingValue = scanner.nextInt();
                ratingDAO.addRating(new Rating(productId, customerId, ratingValue));
                break;
            case 2:
                System.out.print("Enter product ID to view average rating: ");
                int avgProductId = scanner.nextInt();
                double averageRating = ratingDAO.getAverageRating(avgProductId);
                System.out.println("Average Rating for Product ID " + avgProductId + ": " + averageRating);
                break;
            case 3:
                System.out.print("Enter rating ID to update: ");
                int updateRatingId = scanner.nextInt();
                System.out.print("Enter updated rating value (1-5): ");
                int updatedRatingValue = scanner.nextInt();
                ratingDAO.updateRating(updateRatingId, updatedRatingValue);
                break;
            case 4:
                System.out.print("Enter rating ID to delete: ");
                int deleteRatingId = scanner.nextInt();
                ratingDAO.deleteRating(deleteRatingId);
                break;
            case 5:
                System.out.println("Exiting...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageImprovements(Scanner scanner, ImprovementDAO improvementDAO) {
        System.out.println("Improvement Management");
        System.out.println("1. Implement Product Improvement");
        System.out.println("2. View Improvement Details");
        System.out.println("3. Update Improvement Status");
        System.out.println("4. Delete Improvement");
        System.out.println("5. Exit");
        System.out.print("Select an option: ");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                System.out.print("Enter product ID for improvement: ");
                int productId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter improvement details: ");
                String improvementDetails = scanner.nextLine();
                improvementDAO.implementImprovement(new Improvement(productId, improvementDetails));
                break;
            case 2:
                System.out.print("Enter improvement ID: ");
                int improvementId = scanner.nextInt();
                Improvement improvement = improvementDAO.getImprovement(improvementId);
                System.out.println(improvement);
                break;
            case 3:
                System.out.print("Enter improvement ID to update: ");
                int updateImprovementId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter updated improvement status: ");
                String updatedStatus = scanner.nextLine();
                improvementDAO.updateImprovementStatus(updateImprovementId, updatedStatus);
                break;
            case 4:
                System.out.print("Enter improvement ID to delete: ");
                int deleteImprovementId = scanner.nextInt();
                improvementDAO.deleteImprovement(deleteImprovementId);
                break;
            case 5:
                System.out.println("Exiting...");
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}
