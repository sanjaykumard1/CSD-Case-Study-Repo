package mod;

public class Review {
    private int reviewId;
    private int productId;
    private int customerId;
    private String reviewText;

    public Review(int productId, int customerId, String reviewText) {
        this.productId = productId;
        this.customerId = customerId;
        this.reviewText = reviewText;
    }

    public Review(int reviewId, int productId, int customerId, String reviewText) {
        this.reviewId = reviewId;
        this.productId = productId;
        this.customerId = customerId;
        this.reviewText = reviewText;
    }

    public int getReviewId() {
        return reviewId;
    }

    public int getProductId() {
        return productId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getReviewText() {
        return reviewText;
    }

    @Override
    public String toString() {
        return "Review{" +
                "reviewId=" + reviewId +
                ", productId=" + productId +
                ", customerId=" + customerId +
                ", reviewText='" + reviewText + '\'' +
                '}';
    }
}
