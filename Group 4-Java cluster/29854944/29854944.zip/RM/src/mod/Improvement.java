package mod;

public class Improvement {
    private int improvementId;
    private int productId;
    private String improvementDetails;
    private String status;

    public Improvement(int productId, String improvementDetails) {
        this.productId = productId;
        this.improvementDetails = improvementDetails;
    }

    public Improvement(int improvementId, int productId, String improvementDetails, String status) {
        this.improvementId = improvementId;
        this.productId = productId;
        this.improvementDetails = improvementDetails;
        this.status = status;
    }

    public int getImprovementId() {
        return improvementId;
    }

    public int getProductId() {
        return productId;
    }

    public String getImprovementDetails() {
        return improvementDetails;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Improvement{" +
                "improvementId=" + improvementId +
                ", productId=" + productId +
                ", improvementDetails='" + improvementDetails + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
