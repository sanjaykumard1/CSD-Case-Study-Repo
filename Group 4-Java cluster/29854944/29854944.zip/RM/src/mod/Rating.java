package mod;

public class Rating {
    private int ratingId;
    private int productId;
    private int customerId;
    private int ratingValue;

    public Rating(int productId, int customerId, int ratingValue) {
        this.productId = productId;
        this.customerId = customerId;
        this.ratingValue = ratingValue;
    }

    public Rating(int ratingId, int productId, int customerId, int ratingValue) {
        this.ratingId = ratingId;
        this.productId = productId;
        this.customerId = customerId;
        this.ratingValue = ratingValue;
    }

    public int getRatingId() {
        return ratingId;
    }

    public int getProductId() {
        return productId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getRatingValue() {
        return ratingValue;
    }

    @Override
    public String toString() {
        return "Rating{" +
                "ratingId=" + ratingId +
                ", productId=" + productId +
                ", customerId=" + customerId +
                ", ratingValue=" + ratingValue +
                '}';
    }
}
