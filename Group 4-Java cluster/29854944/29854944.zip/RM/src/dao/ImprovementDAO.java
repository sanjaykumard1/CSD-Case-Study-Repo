package dao;

import dbc.DatabaseConnection;
import mod.Improvement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ImprovementDAO {
    private Connection connection;

    public ImprovementDAO() {
        this.connection = DatabaseConnection.getConnection();
    }

    public void implementImprovement(Improvement improvement) {
        try {
            String sql = "INSERT INTO Improvement (product_id, implementation_date, improvement_details, status) VALUES (?, NOW(), ?, 'Pending')";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, improvement.getProductId());
            statement.setString(2, improvement.getImprovementDetails());
            statement.executeUpdate();
            System.out.println("Improvement implemented successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Improvement getImprovement(int improvementId) {
        try {
            String sql = "SELECT * FROM Improvement WHERE improvement_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, improvementId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                String improvementDetails = resultSet.getString("improvement_details");
                String status = resultSet.getString("status");
                return new Improvement(improvementId, productId, improvementDetails, status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateImprovementStatus(int improvementId, String updatedStatus) {
        try {
            String sql = "UPDATE Improvement SET status = ? WHERE improvement_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, updatedStatus);
            statement.setInt(2, improvementId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Improvement status updated successfully.");
            } else {
                System.out.println("No improvement found with ID " + improvementId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteImprovement(int improvementId) {
        try {
            String sql = "DELETE FROM Improvement WHERE improvement_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, improvementId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Improvement deleted successfully.");
            } else {
                System.out.println("No improvement found with ID " + improvementId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

