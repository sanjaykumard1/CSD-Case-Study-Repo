package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import dbc.DatabaseConnection;
import mod.Rating;

public class RatingDAO {
    private Connection connection;

    public RatingDAO() {
        this.connection = DatabaseConnection.getConnection();
    }

    public void addRating(Rating rating) {
        try {
            String sql = "INSERT INTO Rating (product_id, customer_id, rating_value) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, rating.getProductId());
            statement.setInt(2, rating.getCustomerId());
            statement.setInt(3, rating.getRatingValue());
            statement.executeUpdate();
            System.out.println("Rating added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double getAverageRating(int productId) {
        try {
            String sql = "SELECT AVG(rating_value) AS average_rating FROM Rating WHERE product_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, productId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getDouble("average_rating");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    public void updateRating(int ratingId, int updatedRatingValue) {
        try {
            String sql = "UPDATE Rating SET rating_value = ? WHERE rating_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, updatedRatingValue);
            statement.setInt(2, ratingId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Rating updated successfully.");
            } else {
                System.out.println("No rating found with ID " + ratingId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRating(int ratingId) {
        try {
            String sql = "DELETE FROM Rating WHERE rating_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, ratingId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Rating deleted successfully.");
            } else {
                System.out.println("No rating found with ID " + ratingId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
