package dao;

import dbc.DatabaseConnection;
import mod.Review;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReviewDAO {
    private Connection connection;

    public ReviewDAO() {
        this.connection = DatabaseConnection.getConnection();
    }

    public void addReview(Review review) {
        try {
            String sql = "INSERT INTO Review (product_id, customer_id, review_date, review_text) VALUES (?, ?, NOW(), ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, review.getProductId());
            statement.setInt(2, review.getCustomerId());
            statement.setString(3, review.getReviewText());
            statement.executeUpdate();
            System.out.println("Review added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Review getReview(int reviewId) {
        try {
            String sql = "SELECT * FROM Review WHERE review_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, reviewId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int productId = resultSet.getInt("product_id");
                int customerId = resultSet.getInt("customer_id");
                String reviewText = resultSet.getString("review_text");
                return new Review(reviewId, productId, customerId, reviewText);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateReview(int reviewId, String updatedReviewText) {
        try {
            String sql = "UPDATE Review SET review_text = ? WHERE review_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, updatedReviewText);
            statement.setInt(2, reviewId);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Review updated successfully.");
            } else {
                System.out.println("No review found with ID " + reviewId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteReview(int reviewId) {
        try {
            String sql = "DELETE FROM Review WHERE review_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, reviewId);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Review deleted successfully.");
            } else {
                System.out.println("No review found with ID " + reviewId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

