// dao/MagazineDAO.java
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Magazine;
import util.DatabaseConnection;

public class MagazineDAO {
    public void addMagazine(Magazine magazine) {
        String sql = "INSERT INTO Magazine (title, genre, publication_frequency, publisher) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, magazine.getTitle());
            pstmt.setString(2, magazine.getGenre());
            pstmt.setString(3, magazine.getPublicationFrequency());
            pstmt.setString(4, magazine.getPublisher());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Magazine getMagazine(int magazineId) {
        String sql = "SELECT * FROM Magazine WHERE magazine_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, magazineId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Magazine(rs.getInt("magazine_id"), rs.getString("title"), rs.getString("genre"),
                        rs.getString("publication_frequency"), rs.getString("publisher"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Implement updateMagazine and deleteMagazine similarly...
}
