// Main.java
import java.util.Scanner;
import dao.MagazineDAO;
import model.Magazine;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final MagazineDAO magazineDAO = new MagazineDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Add a new magazine");
            System.out.println("2. View magazine details");
            System.out.println("3. Update magazine information");
            System.out.println("4. Delete a magazine");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addMagazine();
                    break;
                case 2:
                    viewMagazine();
                    break;
                case 3:
                    updateMagazine();
                    break;
                case 4:
                    deleteMagazine();
                    break;
                case 5:
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void addMagazine() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter publication frequency: ");
        String frequency = scanner.nextLine();
        System.out.print("Enter publisher: ");
        String publisher = scanner.nextLine();

        Magazine magazine = new Magazine(title, genre, frequency, publisher);
        magazineDAO.addMagazine(magazine);
        System.out.println("Magazine added successfully!");
    }

    private static void viewMagazine() {
        System.out.print("Enter magazine ID: ");
        int magazineId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Magazine magazine = magazineDAO.getMagazine(magazineId);
        if (magazine != null) {
            System.out.println(magazine);
        } else {
            System.out.println("Magazine not found.");
        }
    }

    // Implement updateMagazine and deleteMagazine similarly...
}
