CREATE DATABASE DigitalMagazineDB;

USE DigitalMagazineDB;

CREATE TABLE Magazine (
    magazine_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    publication_frequency VARCHAR(50),
    publisher VARCHAR(255)
);

CREATE TABLE Article (
    article_id INT AUTO_INCREMENT PRIMARY KEY,
    magazine_id INT,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255),
    content TEXT,
    publish_date DATE,
    FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
);

CREATE TABLE User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    date_of_birth DATE,
    registration_date DATE
);

CREATE TABLE Subscription (
    subscription_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    magazine_id INT,
    subscription_date DATE,
    expiry_date DATE,
    status VARCHAR(10),
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (magazine_id) REFERENCES Magazine(magazine_id)
);
