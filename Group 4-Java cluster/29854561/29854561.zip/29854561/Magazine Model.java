// model/Magazine.java
public class Magazine {
    private int magazineId;
    private String title;
    private String genre;
    private String publicationFrequency;
    private String publisher;

    // Constructor, getters, and setters...
}
