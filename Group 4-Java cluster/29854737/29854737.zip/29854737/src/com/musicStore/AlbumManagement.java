package com.musicStore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AlbumManagement {
    public static void manageAlbums(Connection conn, Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("Album Management");
            System.out.println("1. Add New Album");
            System.out.println("2. View Album Details");
            System.out.println("3. Update Album Information");
            System.out.println("4. Delete Album");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addAlbum(conn, scanner);
                    break;
                case 2:
                    viewAlbum(conn, scanner);
                    break;
                case 3:
                    updateAlbum(conn, scanner);
                    break;
                case 4:
                    deleteAlbum(conn, scanner);
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addAlbum(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter album title: ");
            scanner.nextLine(); // Consume newline
            String title = scanner.nextLine();
            System.out.print("Enter artist ID: ");
            int artistId = scanner.nextInt();
            System.out.print("Enter release date (YYYY-MM-DD): ");
            scanner.nextLine(); // Consume newline
            String releaseDate = scanner.nextLine();
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();

            String query = "INSERT INTO Album (title, artist_id, release_date, price) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);
            stmt.setInt(2, artistId);
            stmt.setString(3, releaseDate);
            stmt.setDouble(4, price);
            stmt.executeUpdate();

            System.out.println("Album added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding album: " + e.getMessage());
        }
    }

    private static void viewAlbum(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter album ID: ");
            int albumId = scanner.nextInt();

            String query = "SELECT * FROM Album WHERE album_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, albumId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Album ID: " + rs.getInt("album_id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Artist ID: " + rs.getInt("artist_id"));
                System.out.println("Release Date: " + rs.getDate("release_date"));
                System.out.println("Price: " + rs.getDouble("price"));
            } else {
                System.out.println("Album not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing album: " + e.getMessage());
        }
    }

    private static void updateAlbum(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter album ID to update: ");
            int albumId = scanner.nextInt();

            System.out.print("Enter new title: ");
            scanner.nextLine(); // Consume newline
            String title = scanner.nextLine();
            System.out.print("Enter new artist ID: ");
            int artistId = scanner.nextInt();
            System.out.print("Enter new release date (YYYY-MM-DD): ");
            scanner.nextLine(); // Consume newline
            String releaseDate = scanner.nextLine();
            System.out.print("Enter new price: ");
            double price = scanner.nextDouble();

            String query = "UPDATE Album SET title = ?, artist_id = ?, release_date = ?, price = ? WHERE album_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, title);
            stmt.setInt(2, artistId);
            stmt.setString(3, releaseDate);
            stmt.setDouble(4, price);
            stmt.setInt(5, albumId);
            stmt.executeUpdate();

            System.out.println("Album updated successfully.");
        } catch (SQLException e) {
            System.out.println("Error updating album: " + e.getMessage());
        }
    }

    private static void deleteAlbum(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter album ID to delete: ");
            int albumId = scanner.nextInt();

            String query = "DELETE FROM Album WHERE album_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, albumId);
            stmt.executeUpdate();

            System.out.println("Album deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting album: " + e.getMessage());
        }
    }
}
