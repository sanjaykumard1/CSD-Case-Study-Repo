package com.musicStore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/MusicStore";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Chicken__65";

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            System.out.println("Connected to the database!");
            Scanner scanner = new Scanner(System.in);
            boolean exit = false;

            while (!exit) {
                System.out.println("Music Store Management System");
                System.out.println("1. Manage Artists");
                System.out.println("2. Manage Albums");
                System.out.println("3. Manage Sales");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        ArtistManagement.manageArtists(conn, scanner);
                        break;
                    case 2:
                        AlbumManagement.manageAlbums(conn, scanner);
                        break;
                    case 3:
                        SalesManagement.manageSales(conn, scanner);
                        break;
                    case 4:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

            scanner.close();
        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
    }
}
