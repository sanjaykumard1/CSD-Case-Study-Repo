package com.musicStore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class SalesManagement {
    public static void manageSales(Connection conn, Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("Sales Management");
            System.out.println("1. Record New Sale");
            System.out.println("2. View Sales Details");
            System.out.println("3. Update Sale Information");
            System.out.println("4. Cancel Sale");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    recordSale(conn, scanner);
                    break;
                case 2:
                    viewSale(conn, scanner);
                    break;
                case 3:
                    updateSale(conn, scanner);
                    break;
                case 4:
                    cancelSale(conn, scanner);
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void recordSale(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter album ID: ");
            int albumId = scanner.nextInt();
            System.out.print("Enter sale date (YYYY-MM-DD): ");
            scanner.nextLine(); // Consume newline
            String saleDate = scanner.nextLine();
            System.out.print("Enter quantity sold: ");
            int quantitySold = scanner.nextInt();

            String queryPrice = "SELECT price FROM Album WHERE album_id = ?";
            PreparedStatement stmtPrice = conn.prepareStatement(queryPrice);
            stmtPrice.setInt(1, albumId);
            ResultSet rsPrice = stmtPrice.executeQuery();

            if (rsPrice.next()) {
                double price = rsPrice.getDouble("price");
                double totalPrice = price * quantitySold;

                String query = "INSERT INTO Sales (album_id, sale_date, quantity_sold, total_price) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, albumId);
                stmt.setString(2, saleDate);
                stmt.setInt(3, quantitySold);
                stmt.setDouble(4, totalPrice);
                stmt.executeUpdate();

                System.out.println("Sale recorded successfully.");
            } else {
                System.out.println("Album not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error recording sale: " + e.getMessage());
        }
    }

    private static void viewSale(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter sale ID: ");
            int saleId = scanner.nextInt();

            String query = "SELECT * FROM Sales WHERE sale_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, saleId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Sale ID: " + rs.getInt("sale_id"));
                System.out.println("Album ID: " + rs.getInt("album_id"));
                System.out.println("Sale Date: " + rs.getDate("sale_date"));
                System.out.println("Quantity Sold: " + rs.getInt("quantity_sold"));
                System.out.println("Total Price: " + rs.getDouble("total_price"));
            } else {
                System.out.println("Sale not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing sale: " + e.getMessage());
        }
    }

    private static void updateSale(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter sale ID to update: ");
            int saleId = scanner.nextInt();

            System.out.print("Enter new album ID: ");
            int albumId = scanner.nextInt();
            System.out.print("Enter new sale date (YYYY-MM-DD): ");
            scanner.nextLine(); // Consume newline
            String saleDate = scanner.nextLine();
            System.out.print("Enter new quantity sold: ");
            int quantitySold = scanner.nextInt();

            String queryPrice = "SELECT price FROM Album WHERE album_id = ?";
            PreparedStatement stmtPrice = conn.prepareStatement(queryPrice);
            stmtPrice.setInt(1, albumId);
            ResultSet rsPrice = stmtPrice.executeQuery();

            if (rsPrice.next()) {
                double price = rsPrice.getDouble("price");
                double totalPrice = price * quantitySold;

                String query = "UPDATE Sales SET album_id = ?, sale_date = ?, quantity_sold = ?, total_price = ? WHERE sale_id = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setInt(1, albumId);
                stmt.setString(2, saleDate);
                stmt.setInt(3, quantitySold);
                stmt.setDouble(4, totalPrice);
                stmt.setInt(5, saleId);
                stmt.executeUpdate();

                System.out.println("Sale updated successfully.");
            } else {
                System.out.println("Album not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating sale: " + e.getMessage());
        }
    }

    private static void cancelSale(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter sale ID to cancel: ");
            int saleId = scanner.nextInt();

            String query = "DELETE FROM Sales WHERE sale_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, saleId);
            stmt.executeUpdate();

            System.out.println("Sale canceled successfully.");
        } catch (SQLException e) {
            System.out.println("Error canceling sale: " + e.getMessage());
        }
    }
}
