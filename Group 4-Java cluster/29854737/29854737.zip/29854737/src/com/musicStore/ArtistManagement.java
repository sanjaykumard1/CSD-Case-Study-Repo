package com.musicStore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ArtistManagement {
    public static void manageArtists(Connection conn, Scanner scanner) {
        boolean exit = false;

        while (!exit) {
            System.out.println("Artist Management");
            System.out.println("1. Add New Artist");
            System.out.println("2. View Artist Details");
            System.out.println("3. Update Artist Information");
            System.out.println("4. Delete Artist");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addArtist(conn, scanner);
                    break;
                case 2:
                    viewArtist(conn, scanner);
                    break;
                case 3:
                    updateArtist(conn, scanner);
                    break;
                case 4:
                    deleteArtist(conn, scanner);
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addArtist(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter artist name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter genre: ");
            String genre = scanner.nextLine();
            System.out.print("Enter country: ");
            String country = scanner.nextLine();

            String query = "INSERT INTO Artist (name, genre, country) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, genre);
            stmt.setString(3, country);
            stmt.executeUpdate();

            System.out.println("Artist added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding artist: " + e.getMessage());
        }
    }

    private static void viewArtist(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter artist ID: ");
            int artistId = scanner.nextInt();

            String query = "SELECT * FROM Artist WHERE artist_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, artistId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Artist ID: " + rs.getInt("artist_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Genre: " + rs.getString("genre"));
                System.out.println("Country: " + rs.getString("country"));
            } else {
                System.out.println("Artist not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error viewing artist: " + e.getMessage());
        }
    }

    private static void updateArtist(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter artist ID to update: ");
            int artistId = scanner.nextInt();

            System.out.print("Enter new name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter new genre: ");
            String genre = scanner.nextLine();
            System.out.print("Enter new country: ");
            String country = scanner.nextLine();

            String query = "UPDATE Artist SET name = ?, genre = ?, country = ? WHERE artist_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, genre);
            stmt.setString(3, country);
            stmt.setInt(4, artistId);
            stmt.executeUpdate();

            System.out.println("Artist updated successfully.");
        } catch (SQLException e) {
            System.out.println("Error updating artist: " + e.getMessage());
        }
    }

    private static void deleteArtist(Connection conn, Scanner scanner) {
        try {
            System.out.print("Enter artist ID to delete: ");
            int artistId = scanner.nextInt();

            String query = "DELETE FROM Artist WHERE artist_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, artistId);
            stmt.executeUpdate();

            System.out.println("Artist deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting artist: " + e.getMessage());
        }
    }
}
