CREATE DATABASE MusicStore;
USE MusicStore;


CREATE TABLE Artist (
    artist_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    genre VARCHAR(255),
    country VARCHAR(255)
);

CREATE TABLE Album (
    album_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    artist_id INT,
    release_date DATE,
    price DECIMAL(10, 2),
    FOREIGN KEY (artist_id) REFERENCES Artist(artist_id) ON DELETE CASCADE
);

CREATE TABLE Sales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    album_id INT,
    sale_date DATE,
    quantity_sold INT,
    total_price DECIMAL(10, 2),
    FOREIGN KEY (album_id) REFERENCES Album(album_id)
);

-- To view the tables:
SELECT*FROM Artist;
SELECT*FROM Album;
SELECT*FROM Sales;
