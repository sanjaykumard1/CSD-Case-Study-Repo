# Music Store Management System

## Overview
This project is a console-based application for managing a music store. It allows users to manage albums, artists, and sales data using a MySQL database. The application is built using Java and JDBC for database connectivity.

## Features
- **Album Management**: Add, view, update, and delete albums.
- **Artist Management**: Add, view, update, and delete artists.
- **Sales Management**: Record and view sales data.

## Prerequisites
- Java Development Kit (JDK) installed.
- MySQL Server and MySQL Workbench installed.
- JDBC driver for MySQL (Connector/J) included in the project.

## Setup and Installation

### MySQL Database Setup
1. Create a new database named `musicStore`.
2. Use the provided SQL script (`database_setup.sql`) to create the necessary tables and insert initial data.     

3. Ensure that the MySQL server is running and accessible.

### Project Setup
1. Clone the repository to your local machine:
   
   git clone https://github.com/trinity2040/CSD-Case-Study-Repo.git

2.Navigate to the Project Directory:
   cd CSD-Case-Study-Repo/Group 4-Java cluster/29854737

3.Open the project in Eclipse:

Open Eclipse.
Import the project by selecting File -> Import -> Existing Projects into Workspace.
Navigate to the project directory and select it.

4.Database Configuration
Update the database connection details in the DatabaseConnection.java file:
java
Copy code
private static final String DB_URL = "jdbc:mysql://localhost:3306/musicstore";
private static final String USER = "root"; // Your MySQL username
private static final String PASS = "password"; // Your MySQL password

5.Running the Application
Open the Main.java file in Eclipse.
Run the Main.java file as a Java application.
