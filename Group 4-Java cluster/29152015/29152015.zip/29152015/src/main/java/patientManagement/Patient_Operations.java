package patientManagement;

import java.util.Scanner;

public class Patient_Operations {
	static boolean projectOptions=true,patientOptions=true,medicalOptions=true,appointmentOptions=true;
	
	public static void backToPatients(int backOption) {    
		if(backOption==0) {
			patientOptions=false;
			projectOptions=true;
		}
		else if(backOption==1) {
			patientOptions=true;
			projectOptions=true;
		}
		else {
			System.out.println("Press Correct Option 0 or 1 to continue");
		}
	}
	public static void backToAppointment(int backOption) {
		if(backOption==0) {
			appointmentOptions=false;
			projectOptions=true;
		}
		else if(backOption==1) {
			appointmentOptions=true;
			projectOptions=true;
		}
		else {
			System.out.println("Press Correct Option 0 or 1 to continue");
		}
	}
	public static void backToMedical(int backOption) {
		if(backOption==0) {
			medicalOptions=false;
			projectOptions=true;
		}
		else if(backOption==1) {
			medicalOptions=true;
			projectOptions=true;
		}
		else {
			System.out.println("Press Correct Option 0 or 1 to continue");
		}
	}
	
	public static void main(String[] args) {
		Add_Patient_Details add=new Add_Patient_Details();
		View_Patient_Details view=new View_Patient_Details();
		Update_Patient_Details update=new Update_Patient_Details();
		Delete_Patient_Details delete=new Delete_Patient_Details();
		AddNewAppointment addapp=new AddNewAppointment();
		View_Appointment_Details viewapp=new View_Appointment_Details();
		Update_Appointment_Details updateapp=new Update_Appointment_Details();
		Delete_Appointments deleteapp=new Delete_Appointments();
		AddMedicalStaffDetails addmedi=new AddMedicalStaffDetails();
		View_Medical_Staff_Details viewmedi=new View_Medical_Staff_Details();
		Update_MedicalStaff_Details updatemedi=new Update_MedicalStaff_Details();
		Delete_MedicalStaff_Details deletemedi=new Delete_MedicalStaff_Details();
		
		
		
		
		System.out.println("-----------------------------------------------------------------\n");
		
		System.out.print("\n         WELCOME TO PATIENT MANAGEMENT SYSTEM \n\n\n");
		
		System.out.println("-----------------------------------------------------------------\n");
	
		System.out.println();
		
		
		Scanner sc=new Scanner(System.in);
	
		while(projectOptions) {
		System.out.println("Press 1 to Access Patient Details");
		System.out.println("Press 2 to Access Appointment Details");
		System.out.println("Press 3 to Access Medical Staff Details");
		System.out.println("Press 4 to Exit\n\n\n");
		
		System.out.println("-----------------------------------------------------------------\n");
		System.out.print("Select the option:");
		int option=sc.nextInt();
		
		if(option==1) {
			patientOptions=true;
			while(patientOptions) {
			System.out.println("Press A to Add the Details of Patient : ");
			System.out.println("Press V to View the Details of Patient : ");
			System.out.println("Press U to Update the Details of Patient : ");
			System.out.println("Press D to Delete the Details of Patient : ");
			
			char operations=sc.next().charAt(0);
			int backOption;
			switch(operations) {
			case 'A':
				add.addDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				backOption=sc.nextInt();
				backToPatients(backOption);
				break;
			case 'V':
				view.viewDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				 backOption=sc.nextInt();
				backToPatients(backOption);
				break;
			case 'U':
				update.updateDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				 backOption=sc.nextInt();
				backToPatients(backOption);
				break;
			case 'D':
				delete.deleteDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				backOption=sc.nextInt();
				backToPatients(backOption);
				break;
			default:
				System.out.println("Enter the correct character to access");
			}
		
			}
		}
      else if(option==2) {
			appointmentOptions=true;
			while(appointmentOptions) {
				System.out.println("Press A to Add the new appointment for Patients : ");
				System.out.println("Press V to View the appointment Details: ");
				System.out.println("Press U to Update the appointment Details : ");
				System.out.println("Press D to Delete the appointment Details: ");
				char operations=sc.next().charAt(0);
				int backOption;
				switch(operations) {
				case 'A':
					addapp.addAppointment();
					System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
					backOption=sc.nextInt();
					backToAppointment(backOption);
					break;
				case 'V':
					viewapp.viewAppointmentDetails();
					System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
					 backOption=sc.nextInt();
					 backToAppointment(backOption);
					break;
				case 'U':
					updateapp.updateAppointmentDetails();
					System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
					 backOption=sc.nextInt();
					 backToAppointment(backOption);
					break;
				case 'D':
					deleteapp.deleteAppointment();
					System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
					backOption=sc.nextInt();
					backToAppointment(backOption);
					break;
				default:
					System.out.println("Enter the correct character to access");
				}
			
			}
		}
		
		else if(option==3) {
			medicalOptions=true;
			while(medicalOptions) {
			System.out.println("Press A to Add the Details of Medical Staff : ");
			System.out.println("Press V to View the Details of Medical Staff : ");
			System.out.println("Press U to Update the Details of Medical Staff : ");
			System.out.println("Press D to Delete the Details of Medical Staff : ");
			
			char operations=sc.next().charAt(0);
			int backOption;
			switch(operations) {
			case 'A':
				addmedi.addMedicalStaffDetail();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				backOption=sc.nextInt();
				backToMedical(backOption);
				break;
			case 'V':
				viewmedi.viewMedicalDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				 backOption=sc.nextInt();
				backToMedical(backOption);
				break;
			case 'U':
				updatemedi.updateMedicalDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				 backOption=sc.nextInt();
				 backToMedical(backOption);
				break;
			case 'D':
				deletemedi.deleteMedicalDetails();
				System.out.println("Press 0 to Main Menu\nPress 1 to Previous Option\n");
				backOption=sc.nextInt();
				backToMedical(backOption);
				break;
			default:
				System.out.println("Enter the correct character to access");
			}
		
			}
			
		}
		
		else if(option==4) {
			projectOptions=false;
			System.out.println("THANK YOU !");
		}
		else {
			System.out.println("Press correct option to proceed!");
		}
		

	}
		
	}
}
