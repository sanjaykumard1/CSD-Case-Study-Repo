package patientManagement;

import java.util.List;

class View_Appointment_Details {
	public void viewAppointmentDetails() {
		AppointmentUser au=new AppointmentUser();
		
		
		List<appointmentManage> view_appointment_details=au.appointmentList();
		view_appointment_details.forEach((appointment_detail)->{
			System.out.println("Appointment Id: "+appointment_detail.getAppoinment_id()+
					"Patient Id: "+appointment_detail.getPatient_id()+
					"Appointment Date: "+appointment_detail.getAppointment_date()+
					"Appointment Time: "+appointment_detail.getAppointment_time()+
					"Doctor Id: "+appointment_detail.getDoctor_id()+
					"Appointment Status: "+appointment_detail.getAppointment_status());	
		});

	}
}
