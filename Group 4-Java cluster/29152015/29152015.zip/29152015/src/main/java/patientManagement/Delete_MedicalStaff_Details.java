package patientManagement;

import java.util.Scanner;

class Delete_MedicalStaff_Details {
	public void deleteMedicalDetails() {
		// TODO Auto-generated method stub
		MedicalUser mu=new MedicalUser();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Staff Id which want to delete : ");
		long id=sc.nextLong();
		if(mu.validateId(id)) {
		mu.delete(id);
	}
		else {
			System.out.println("Invalid Id");
		}
		}
}
