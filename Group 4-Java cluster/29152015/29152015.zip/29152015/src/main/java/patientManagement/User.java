package patientManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class User {
	//Add Patient
	public long addPatient(patientManage patient) {
		Connection con=dataBase.getCon();
		long primaryKey=0;
		try {
			PreparedStatement stmt=con.prepareStatement("insert into patient values(?,?,?,?,?,?)");
			stmt.setLong(1,patient.getPatient_id());
			stmt.setString(2, patient.getPatient_name());
			stmt.setString(3, patient.getDate_of_birth());
			stmt.setString(4, patient.getContact_number());
			stmt.setString(5, patient.getEmail());
			stmt.setString(6, patient.getGender());
		    primaryKey=stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return primaryKey;
	}
	
	public boolean validateId(long id) {
		Connection con=dataBase.getCon();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from patient");
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
			if(rs.getLong(1)==id) {
				return true;
			}
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	return false;
	}
	
	//To See the list of Patients
	public List<patientManage> patientList(){
		List<patientManage> list=new ArrayList<patientManage>();
		Connection con=dataBase.getCon();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from patient");
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				patientManage pm=new patientManage();
				pm.setPatient_id(rs.getLong(1));
				pm.setPatient_name(rs.getString(2));
				pm.setDate_of_birth(rs.getString(3));
				pm.setContact_number(rs.getString(4));
				pm.setEmail(rs.getString(5));
				pm.setGender(rs.getString(6));
				
				list.add(pm);
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}
	
	//To Update the Patient Data
	public patientManage update(patientManage p,long patient_id) {
		Connection con=dataBase.getCon();
		try {
			PreparedStatement stmt=con.prepareStatement
					("update patient set patient_name=?,date_of_birth=?,contact_number=?,email=?,gender=? where patient_id=?");
			stmt.setString(1,p.getPatient_name());
			stmt.setString(2, p.getDate_of_birth());
			stmt.setString(3,p.getContact_number());
			stmt.setString(4, p.getEmail());
			stmt.setString(5, p.getGender());
			stmt.setLong(6, patient_id);
			stmt.executeUpdate();
			//System.out.println("Patient data was updated !");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return p;
	}
	
	//To Delete the patient Data
	public void delete(long id) {
		Connection con=dataBase.getCon();	
		try {
			PreparedStatement stmt=con.prepareStatement("delete from patient where patient_id=?");
			stmt.setLong(1,id);
			stmt.executeUpdate();
		System.out.println("Record is deleted");
		} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
}
