package patientManagement;

import java.util.Scanner;

class AddNewAppointment {
 public void addAppointment() {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter Appointment Id :");
	 long appointment_id=sc.nextLong();
	 System.out.println("Enter Patient Id :");
	 long patient_id=sc.nextLong();
	 System.out.println("Enter Appointment Date:");
	 String appointment_date=sc.next();
	 System.out.println("Enter Appointment Time:");
	 String appointment_time=sc.next();
	 System.out.println("Enter Doctor Id :");
	 long doctor_id=sc.nextLong();
	 System.out.println("Enter Appointment Status:");
	 String appointment_status=sc.next();
	
	 AppointmentUser au=new AppointmentUser();
	 appointmentManage am=new appointmentManage();
	 
	 am.setAppoinment_id(appointment_id);
	 am.setPatient_id(patient_id);
	 am.setAppointment_date(appointment_date);
	 am.setAppointment_time(appointment_time);
	 am.setDoctor_id(doctor_id);
	 am.setAppointment_status(appointment_status);
	
	 long primaryKey=au.addNewAppointment(am);
		System.out.println("Data is added"+primaryKey);
	 
	 
}
 }

