package patientManagement;

import java.util.Scanner;

class Delete_Appointments {

	public void deleteAppointment() {
		// TODO Auto-generated method stub
		AppointmentUser au=new AppointmentUser();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Appointment Id which want to delete : ");
		long id=sc.nextLong();
		if(au.validateId(id)) {
			au.delete(id);
		}
		else {
			System.out.println("Enter Correct Id!");
		}
	}
}
