package patientManagement;

import java.util.Scanner;

class Update_MedicalStaff_Details {

	public void updateMedicalDetails() {
		// TODO Auto-generated method stub
		MedicalUser u=new MedicalUser();
		medicalStaffManagement msm=new medicalStaffManagement();	
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter Staff Id for whose data need to be updated= ");
		long staff_id=sc.nextLong();
		if(u.validateId(staff_id)) {
		System.out.println("Enter Staff Name = ");
		String staff_name=sc.next();
		System.out.println("Enter Staff Type = ");
		String staff_type=sc.next();
		System.out.println("Enter Department=");
		String staff_department=sc.next();
		System.out.println("Enter Contact Number = ");
		String contact_number=sc.next();
		System.out.println("Enter Email = ");
		String email=sc.next();
		
		
		msm.setStaff_name(staff_name);
		msm.setStaff_type(staff_type);
		msm.setDepartment(staff_department);
		msm.setContact_number(contact_number);
		msm.setEmail(email);
		u.update(msm, staff_id);
		System.out.println("Data is updated!!");
		}
		else {
			System.out.println("Entered Staff Id is not available in Database");
		}
	}

}
