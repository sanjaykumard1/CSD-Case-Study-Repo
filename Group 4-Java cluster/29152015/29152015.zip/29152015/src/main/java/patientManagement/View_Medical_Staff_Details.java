package patientManagement;

import java.util.List;

class View_Medical_Staff_Details {
	public void viewMedicalDetails() {
		MedicalUser mu=new MedicalUser();
		List<medicalStaffManagement> view_medicalStaff_details=mu.StaffList();
		//System.out.println("Staff List : "+view_medicalStaff_details);
		view_medicalStaff_details.forEach((medical_detail)->{
			System.out.println("Staff Id: "+medical_detail.getStaff_id()+
					" Staff name: "+medical_detail.getStaff_name()+
					" Staff type : "+medical_detail.getStaff_type()+
					" Department: "+medical_detail.getDepartment()+
					"Contact Number: "+medical_detail.getContact_number()+
					" Staff Email: "+medical_detail.getEmail()
					);
		});

	}
}
