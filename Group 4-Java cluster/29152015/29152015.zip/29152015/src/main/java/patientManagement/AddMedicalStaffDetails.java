package patientManagement;

import java.util.Scanner;

class AddMedicalStaffDetails {
	public void addMedicalStaffDetail() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter Staff Id :");
		 long staff_id=sc.nextLong();
		 System.out.println("Enter Staff Name :");
		 String staff_name=sc.next();
		 System.out.println("Enter Staff Type :");
		 String staff_type=sc.next();
		 System.out.println("Enter Department :");
		 String department=sc.next();
		 System.out.println("Enter Contact Number :");
		 String contact_number=sc.next();
		 System.out.println("Enter email :");
		 String email=sc.next();
		 
		 MedicalUser mu=new MedicalUser();
		 medicalStaffManagement msm=new medicalStaffManagement();
		 msm.setStaff_id(staff_id);
		 msm.setStaff_name(staff_name);
		 msm.setStaff_type(staff_type);
		 msm.setDepartment(department);
		 msm.setContact_number(contact_number);
		 msm.setEmail(email);
		 
		 long primaryKey=mu.addMedicalStaff(msm);
			System.out.println("Data is added"+primaryKey);
		 
		 
	}
}
