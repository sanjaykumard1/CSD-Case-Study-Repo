package patientManagement;

public class medicalStaffManagement {
	private long staff_id;
	private String staff_name;
	private String staff_type;
	private String department;
	private String contact_number;
	private String email;
	public long getStaff_id() {
		return staff_id;
	}
	public void setStaff_id(long l) {
		this.staff_id = l;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getStaff_type() {
		return staff_type;
	}
	public void setStaff_type(String staff_type) {
		this.staff_type = staff_type;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
