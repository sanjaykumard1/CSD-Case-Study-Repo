package patientManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicalUser {
	    //Add Medical Staff
		public long addMedicalStaff(medicalStaffManagement medical) {
			Connection con=dataBase.getCon();
			long primaryKey=0;
			try {
				PreparedStatement stmt=con.prepareStatement("insert into medicalstaff values(?,?,?,?,?,?)");
				stmt.setLong(1,medical.getStaff_id());
				stmt.setString(2,medical.getStaff_name());
				stmt.setString(3,medical.getStaff_type());
				stmt.setString(4,medical.getDepartment());
				stmt.setString(5,medical.getContact_number());
				stmt.setString(6,medical.getEmail());
			    primaryKey=stmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return primaryKey;
		}
		
		public boolean validateId(long id) {
			Connection con=dataBase.getCon();
			try {
				PreparedStatement stmt=con.prepareStatement("select * from medicalstaff");
				ResultSet rs=stmt.executeQuery();
				while(rs.next()) {
				if(rs.getLong(1)==id) {
					return true;
				}
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		return false;
		}
		//To See the list of Staff Name
		public List<medicalStaffManagement> StaffList(){
			List<medicalStaffManagement> list=new ArrayList<medicalStaffManagement>();
			Connection con=dataBase.getCon();
			try {
				PreparedStatement stmt=con.prepareStatement("select * from medicalstaff");
				ResultSet rs=stmt.executeQuery();
				while(rs.next()) {
					medicalStaffManagement msm=new medicalStaffManagement();
					msm.setStaff_id(rs.getLong(1));
					msm.setStaff_name(rs.getString(2));
					msm.setStaff_type(rs.getString(3));
					msm.setDepartment(rs.getString(4));
					msm.setContact_number(rs.getString(5));
					msm.setEmail(rs.getString(6));
					list.add(msm);
				}
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
			return list;
		}
		
		
		//To Update the Patient Data
		public medicalStaffManagement update(medicalStaffManagement msm,long staff_id) {
			Connection con=dataBase.getCon();
			try {
				PreparedStatement stmt=con.prepareStatement
						("update medicalstaff set staff_name=?,staff_type=?,department=?,contact_number=?,email=? where staff_id=?");
				stmt.setString(1,msm.getStaff_name());
				stmt.setString(2,msm.getStaff_type());
				stmt.setString(3,msm.getDepartment());
				stmt.setString(4, msm.getContact_number());
				stmt.setString(5,msm.getEmail());
				stmt.setLong(6, staff_id);
				stmt.executeUpdate();
				//System.out.println("Patient data was updated !");	
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return msm;
		
		}
		//To Delete the Medical Staff Data
		public void delete(long id) {
			Connection con=dataBase.getCon();	
			try {
				PreparedStatement stmt=con.prepareStatement("delete from medicalstaff where staff_id=?");
				stmt.setLong(1,id);
				stmt.executeUpdate();
			System.out.println("Record is deleted");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}