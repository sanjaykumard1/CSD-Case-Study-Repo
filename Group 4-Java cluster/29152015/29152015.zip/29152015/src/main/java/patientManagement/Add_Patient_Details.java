
package patientManagement;

import java.util.Scanner;

class Add_Patient_Details {

	public void addDetails() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Patient Id = ");
		long patient_id=sc.nextLong();
		System.out.println("Enter Patient Name = ");
		String patient_name=sc.next();
		System.out.println("Enter Date of Birth = ");
		String date_of_birth=sc.next();
		System.out.println("Enter Contact Number = ");
		String contact_number=sc.next();
		System.out.println("Enter Email = ");
		String email=sc.next();
		System.out.println("Enter Gender = ");
		String gender=sc.next();
		
		
		
		//Add patient User
		User patientUser=new User();
		patientManage pm=new patientManage();
		pm.setPatient_id(patient_id);
		pm.setPatient_name(patient_name);
		pm.setGender(gender);
		pm.setContact_number(contact_number);
		pm.setDate_of_birth(date_of_birth);
		pm.setEmail(email);
		long primaryKey=patientUser.addPatient(pm);
		System.out.println("Data is added"+primaryKey);

	}

}
