package patientManagement;

import java.util.List;

class View_Patient_Details {

	public void viewDetails() {
		User u=new User();
		List<patientManage> view_patient_details=u.patientList();
		System.out.println("Patient List : "+view_patient_details);
		view_patient_details.forEach((patient_detail)->{
			System.out.println("Patient Id: "+patient_detail.getPatient_id()+
					" Patient name: "+patient_detail.getPatient_name()+
					" Patient Date of Birth: "+patient_detail.getDate_of_birth()+
					" Patient Contact Number: "+patient_detail.getContact_number()+
					" Patient Email: "+patient_detail.getEmail()+
					" Patient Gender: "+patient_detail.getGender()
					);
		});

	}

}
