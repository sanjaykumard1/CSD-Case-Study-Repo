package patientManagement;

import java.util.Scanner;

class Update_Patient_Details {

	public void updateDetails() {
		// TODO Auto-generated method stub
		User u=new User();
		patientManage p=new patientManage();
//		
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter Patient Id for whose data need to be updated= ");
		long patient_id=sc.nextLong();
		if(u.validateId(patient_id)) {
		System.out.println("Enter Patient Name = ");
		String patient_name=sc.next();
		System.out.println("Enter Date of Birth = ");
		String date_of_birth=sc.next();
		System.out.println("Enter Contact Number = ");
		String contact_number=sc.next();
		System.out.println("Enter Email = ");
		String email=sc.next();
		System.out.println("Enter Gender = ");
		String gender=sc.next();
		
		
		p.setPatient_name(patient_name);
		p.setDate_of_birth(date_of_birth);
		p.setContact_number(contact_number);
		p.setEmail(email);
		p.setGender(gender);
		u.update(p, patient_id);
		System.out.println("Data is updated!!");
		}
		else {
			System.out.println("Enter Id is not Available in Database!");
		}
	}

}
