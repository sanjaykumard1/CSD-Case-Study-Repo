package patientManagement;

import java.util.Scanner;

class Update_Appointment_Details {

	public void updateAppointmentDetails() {
		// TODO Auto-generated method stub
		AppointmentUser au=new AppointmentUser();
		appointmentManage am=new appointmentManage();
		System.out.println("Enter Appointment Id for whose appointment need to be updated= ");
		Scanner sc=new Scanner(System.in);
		long appointment_id=sc.nextLong();
		
		if(au.validateId(appointment_id)) {
		System.out.println("Enter Patient Id = ");
		long patient_id=sc.nextLong();
		System.out.println("Enter Appointment Date = ");
		String appointment_date=sc.next();
		System.out.println("Enter Appointment Time = ");
		String appointment_time=sc.next();
		System.out.println("Enter Doctor Id = ");
		long doctor_id=sc.nextLong();
		System.out.println("Enter Appointment Status = ");
		String appointment_status=sc.next();
		
		am.setPatient_id(patient_id);
		am.setAppointment_date(appointment_date);
		am.setAppointment_time(appointment_time);
		am.setDoctor_id(doctor_id);
		am.setAppointment_status(appointment_status);
		au.updateAppointment(am, appointment_id);
		System.out.println("Data is updated!!");

	}
		else {
			System.out.println("Entered appointment is not valid and It does not found in the Database!");
		}
	}
}
