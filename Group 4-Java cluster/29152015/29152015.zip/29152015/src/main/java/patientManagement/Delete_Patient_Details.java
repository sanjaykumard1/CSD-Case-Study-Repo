package patientManagement;

import java.util.Scanner;

class Delete_Patient_Details {

	public void deleteDetails() {
		// TODO Auto-generated method stub
		User u=new User();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Patient Id which want to delete : ");
		
	
		long id=sc.nextLong();	
		if(u.validateId(id)) {
			u.delete(id);
		}
		else {
			System.out.println("Invalid Id");
		}
		

	}

}
