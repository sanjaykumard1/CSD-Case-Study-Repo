package patientManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AppointmentUser {
	 //Add Medical Staff
	public long addNewAppointment(appointmentManage appointment) {
		Connection con=dataBase.getCon();
		long primaryKey=0;
		try {
			PreparedStatement stmt=con.prepareStatement("insert into appointment values(?,?,?,?,?,?)");
			stmt.setLong(1,appointment.getAppoinment_id());
			stmt.setLong(2,appointment.getPatient_id());
			stmt.setString(3,appointment.getAppointment_date());
			stmt.setString(4,appointment.getAppointment_time());
			stmt.setLong(5,appointment.getDoctor_id());
			stmt.setString(6,appointment.getAppointment_status());
		    primaryKey=stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return primaryKey;
	}
	
	public boolean validateId(long id) {
		Connection con=dataBase.getCon();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from appointment");
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
			if(rs.getLong(1)==id) {
				return true;
			}
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	return false;
	}
	//To See the Appointment list 
	public List<appointmentManage> appointmentList(){
		List<appointmentManage> list=new ArrayList<appointmentManage>();
		Connection con=dataBase.getCon();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from appointment");
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				appointmentManage am=new appointmentManage();
				am.setAppoinment_id(rs.getLong(1));
				am.setPatient_id(rs.getLong(2));
				am.setAppointment_date(rs.getString(3));
				am.setAppointment_time(rs.getString(4));
				am.setDoctor_id(rs.getLong(5));
				am.setAppointment_status(rs.getString(6));
				
				list.add(am);
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//To Update the Appointment Data
			public appointmentManage updateAppointment(appointmentManage am,long appointment_id) {
				Connection con=dataBase.getCon();
				try {
					PreparedStatement stmt=con.prepareStatement
				("update appointment set patient_id=?,appointment_date=?,appointment_time=?,doctor_id=?,appointment_status=? where appointment_id=?");
					stmt.setLong(1,am.getPatient_id());
					stmt.setString(2, am.getAppointment_date());
					stmt.setString(3, am.getAppointment_time());
					stmt.setLong(4,am.getDoctor_id());
					stmt.setString(5, am.getAppointment_status());
					stmt.setLong(6, appointment_id);
				
					stmt.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return am;
			
			}
			
			//To Cancel the Appointments
			public void delete(long id) {
				Connection con=dataBase.getCon();	
				try {
					PreparedStatement stmt=con.prepareStatement("delete from appointment where appointment_id=?");
					stmt.setLong(1,id);
					stmt.executeUpdate();
				System.out.println("Appointment is deleted");
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}}
