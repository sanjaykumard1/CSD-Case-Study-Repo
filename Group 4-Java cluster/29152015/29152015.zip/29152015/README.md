
# Patient Management System




## Objective
Develop a menu-based console application to assess your proficiency in Core Java, MySQL, and JDBC.
The application will simulate a patient management system for a healthcare facility, allowing users
to manage patient records, appointments, and medical staff.
## Setup
1.To create Patient Table
```bash
CREATE TABLE `patient` (
  `patient_id` int NOT NULL,
  `patient_name` varchar(45) DEFAULT NULL,
  `date_of_birth` varchar(45) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `contact_number_UNIQUE` (`contact_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```


2.To Create Appointment Table
```bash
CREATE TABLE `appointment` (
  `appointment_id` int NOT NULL,
  `patient_id` int DEFAULT NULL,
  `appointment_date` varchar(45) NOT NULL,
  `appointment_time` varchar(45) NOT NULL,
  `doctor_id` int DEFAULT NULL,
  `appointment_status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`appointment_id`),
  KEY `patient_id_idx` (`patient_id`),
  KEY `doctor_id_idx` (`doctor_id`),
  CONSTRAINT `doctor_id` FOREIGN KEY (`doctor_id`) REFERENCES `medicalstaff` (`staff_id`),
  CONSTRAINT `patient_id` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```
3.To Create medicalstaff Table

```bash
CREATE TABLE `medicalstaff` (
  `staff_id` int NOT NULL,
  `staff_name` varchar(45) NOT NULL,
  `staff_type` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```



Functionalities:
1. Patient Management:

   Added new patients to the system

   We can View the patient details

   We can Update the patient information

   We can Delete the patient from the system

2. Appointment Management:

 Schedule new appointments for patients

 View appointment details

 Update appointment information

 Cancel appointments

3. Medical Staff Management:

 Add new medical staff (doctors, nurses, etc.) to the system

 View medical staff details

 Update medical staff information

 Delete medical staff from the system
## Steps
1.Download source code 

2.Open in your Eclipse IDE

3.Make sure that you have required external Jars for JDBC

4.Connect JDBC driver with mySQL workbench as per the username and password

5.Execute the Patient_Operations.java because it has the main method

6.Follow as per the menu provided by the source code