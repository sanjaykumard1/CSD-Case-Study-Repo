import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ProductionOrderManager {
	private static Scanner sc=new Scanner(System.in);

	public void addProductionOrder() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows = 0;
		try {
			String query="INSERT INTO production_scheduling_system.production_order(order_id,product_id,quantity,order_date,due_date,status) VALUES(?,?,?,?,?,?)";
			System.out.println("Enter Order Id:");
			int order_id=sc.nextInt();
			System.out.println("Enter Product Id:");
			int product_id=sc.nextInt();
			System.out.println("Enter Quantity:");
			int quantity=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter Order Date (YYYY-MM-DD) :");
			String order_date=sc.nextLine();
			System.out.println("Enter Due Date (YYYY-MM-DD) :");
			String due_date=sc.nextLine();
			System.out.println("Status:");
			String status=sc.nextLine();
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			ps.setInt(1,order_id);
			ps.setInt(2,product_id);
			ps.setInt(3, quantity);
			ps.setString(4,order_date);
			ps.setString(5,due_date);
			ps.setString(6, status);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();
		}
		return;
	}

	public void viewProductionOrder() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			String query="SELECT * FROM production_scheduling_system.production_order";
			con=DataBaseConnection.getConnection();
			st=con.createStatement();
			rs=st.executeQuery(query);
			if(rs.next()) {
			do {
				System.out.println("Order Id = "+rs.getInt(1));
				System.out.println("Product Id = "+rs.getInt(2));
				System.out.println("Quantity = "+rs.getInt(3));
				System.out.println("Order Date = "+rs.getDate(4));
				System.out.println("Due Date = "+rs.getDate(5));
				System.out.println("Status = "+rs.getString(6));
				System.out.println("---------------------------");
			}while(rs.next());
			}
			else {
				System.out.println("Table is empty!");
			    System.out.println("---------------------------");
			}
		}
		catch(SQLException e){
            e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		rs.close();
		st.close();
		con.close();
		}
		return;
	}

	public void updateProductionOrder() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter statements to update:");
			String updatest=sc.nextLine();
			System.out.println("Condition:");
			String condition=sc.nextLine();
			String query="Update production_scheduling_system.production_order SET "+updatest+" WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();
		}
		return;
	}

	public void deleteProductionOrder() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter Condition:");
			String condition=sc.nextLine();
			String query="DELETE FROM production_scheduling_system.production_order WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		if(rows>0)
		    System.out.println(rows+" rows affected");
		else
			System.out.println("No rows were found matching the records");
		ps.close();
		con.close();
		}
		return;
	}
	
}
