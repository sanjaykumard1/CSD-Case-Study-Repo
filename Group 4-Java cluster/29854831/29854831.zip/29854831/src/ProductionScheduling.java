import java.sql.SQLException;
import java.util.Scanner;

public class ProductionScheduling {
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws SQLException {
		while(true) {
			System.out.println("Production Scheduling System");
			System.out.println("1.Manage Production Orders");
			System.out.println("2.Manage Resources");
			System.out.println("3.Manage Schedules");
			System.out.println("4.Exit");
			System.out.println("----------------------------");
			System.out.println("Enter any choice:");
			int choice=sc.nextInt();
			System.out.println("----------------------------");
			switch(choice) {
			case 1:
				ProductionOrderManager productionOrder=new ProductionOrderManager();
				manageProductionOrders(productionOrder);
				break;
			case 2:
				ResourceManager resource=new ResourceManager();
				manageResource(resource);
				break;
			case 3:
				ScheduleManager schedule=new ScheduleManager();
				manageSchedule(schedule);
				break;
			case 4:
				System.exit(0);
			default:
				System.out.println("Invalid choice..Please try again!..");
			}
		}
	}
		public static void manageProductionOrders(ProductionOrderManager productionOrder) throws SQLException {
			System.out.println("Manage Production Orders");
			System.out.println("1.Add Production Order");
			System.out.println("2.View Production Order");
			System.out.println("3.Update Production Order");
			System.out.println("4.Delete Production Order");
			System.out.println("5.Back to Main Menu");
			System.out.println("----------------------------");
			while(true) {
				System.out.println("Choose any operation to perform:");
				int choice=sc.nextInt();
				switch(choice) {
				case 1:
					productionOrder.addProductionOrder();
					break;
				case 2:
					productionOrder.viewProductionOrder();
					break;
				case 3:
					productionOrder.updateProductionOrder();
					break;
				case 4:
					productionOrder.deleteProductionOrder();
					break;
				case 5:
					return;
				default:
					System.out.println("Invalid Choice..Please try again!..");
				}
			}
		}
			public static void manageResource(ResourceManager resource) throws SQLException {
				System.out.println("Manage Resources");
				System.out.println("1.Add Resource");
				System.out.println("2.View Resource");
				System.out.println("3.Update Resource");
				System.out.println("4.Delete Resource");
				System.out.println("5.Back to Main Menu");
				System.out.println("----------------------------");
				while(true) {
					System.out.println("Choose any operation to perform:");
					int choice=sc.nextInt();
					switch(choice) {
					case 1:
						resource.addResource();
						break;
					case 2:
						resource.viewResource();
						break;
					case 3:
						resource.updateResource();
						break;
					case 4:
						resource.deleteResource();
						break;
					case 5:
						return;
					default:
						System.out.println("Invalid Choice..Please try again!..");
					}
				}
			}
				public static void manageSchedule(ScheduleManager schedule) throws SQLException {
					System.out.println("Manage Schedules");
					System.out.println("1.Add Schedule");
					System.out.println("2.View Schedule");
					System.out.println("3.Update Schedule");
					System.out.println("4.Delete Schedule");
					System.out.println("5.Back to Main Menu");
					System.out.println("----------------------------");
					while(true) {
						System.out.println("Choose any operation to perform:");
						int choice=sc.nextInt();
						switch(choice) {
						case 1:
							schedule.addSchedule();
							break;
						case 2:
							schedule.viewSchedule();
							break;
						case 3:
							schedule.updateSchedule();
							break;
						case 4:
							schedule.deleteSchedule();
							break;
						case 5:
							return;
						default:
							System.out.println("Invalid Choice..Please try again!..");
						}
					}
				}
			}
