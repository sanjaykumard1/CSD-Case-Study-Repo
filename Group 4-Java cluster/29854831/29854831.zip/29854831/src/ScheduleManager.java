import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ScheduleManager {
    private static Scanner sc=new Scanner(System.in);
	public void addSchedule() throws SQLException {
		// TODO Auto-generated method stub
		String query="INSERT INTO production_scheduling_system.schedule(schedule_id,order_id,resource_id,start_time,end_time) VALUES(?,?,?,?,?)";
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter Schedule Id:");
			int schedule_id=sc.nextInt();
			System.out.println("Enter Order Id:");
			int order_id=sc.nextInt();
			System.out.println("Enter Resource Id:");
			int resource_id=sc.nextInt();
			System.out.println("Enter Start Time (HH-MM-SS) :");
			String start_time=sc.nextLine();
			System.out.println("Enter End Time (HH-MM-SS) :");
			String end_time=sc.nextLine();
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			ps.setInt(1,schedule_id);
			ps.setInt(2,order_id);
			ps.setInt(3,resource_id);
			ps.setString(4,start_time);
			ps.setString(5,end_time);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();
		}
		return;
	}

	public void viewSchedule() throws SQLException {
		// TODO Auto-generated method stub
		String query="SELECT * FROM production_scheduling_system.schedule";
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=DataBaseConnection.getConnection();
			st=con.createStatement();
			rs=st.executeQuery(query);
			if(rs.next()) {
			while(rs.next()) {
				System.out.println("Schedule Id = "+rs.getInt(1));
				System.out.println("Order Id = "+rs.getInt(2));
				System.out.println("Resource Id = "+rs.getInt(3));
				System.out.println("Start Time = "+rs.getTime(4));
				System.out.println("End Time = "+rs.getTime(5));
				System.out.println("---------------------------");
			}	
			}
			else {
				System.out.println("Table is empty");
			    System.out.println("---------------------------");
			}
		}
		catch(SQLException e){
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		rs.close();
		st.close();
		con.close();
		}
		return;
	}

	public void updateSchedule() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter statements to update:");
			String updatest=sc.nextLine();
			System.out.println("Condition:");
			String condition=sc.nextLine();
			String query="Update production_scheduling_system.schedule SET "+updatest+" WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();
		}
		return;
	}

	public void deleteSchedule() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter Condition:");
			String condition=sc.nextLine();
			String query="DELETE FROM production_scheduling_system.schedule WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		if(rows>0)
		   System.out.println(rows+" rows affected");
		else
		   System.out.println("No rows were found matching the condition");
		ps.close();
		con.close();
		}
		return;
	}

}
