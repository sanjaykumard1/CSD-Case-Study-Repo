import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ResourceManager {
    private static Scanner sc=new Scanner(System.in);
	public void addResource() throws SQLException {
		// TODO Auto-generated method stub
		String query="INSERT INTO production_scheduling_system.resource(resource_id,name,type,availability) VALUES(?,?,?,?)";
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter Resource Id:");
			int resource_id=sc.nextInt();
			System.out.println("Enter Name:");
			String name=sc.nextLine();
			System.out.println("Enter Type:");
			String type=sc.nextLine();
			System.out.println("Enter Availability:");
			String availability=sc.nextLine();
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			ps.setInt(1,resource_id);
			ps.setString(2,name);
			ps.setString(3,type);
			ps.setString(4,availability);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();
		}
		return;
	}

	public void viewResource() throws SQLException {
		// TODO Auto-generated method stub
		String query="SELECT * FROM production_scheduling_system.resource";
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=DataBaseConnection.getConnection();
			st=con.createStatement();
			rs=st.executeQuery(query);
			if(rs.next()) {
			while(rs.next()) {
				System.out.println("Resource Id = "+rs.getInt(1));
				System.out.println("Name = "+rs.getString(2));
				System.out.println("Type = "+rs.getString(3));
				System.out.println("Availability = "+rs.getString(4));
				System.out.println("---------------------------");
			}	
			}
			else {
				System.out.println("Table is empty");
			    System.out.println("---------------------------");
			}
		} 
		catch(SQLException e){
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		rs.close();
		st.close();
		con.close();
		}
		return;
	}

	public void updateResource() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter statements to update:");
			String updatest=sc.nextLine();
			System.out.println("Condition:");
			String condition=sc.nextLine();
			String query="Update production_scheduling_system.resource SET "+updatest+" WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		System.out.println(rows+" rows affected");
		ps.close();
		con.close();	
		}
		return;
	}

	public void deleteResource() throws SQLException {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement ps=null;
		int rows=0;
		try {
			System.out.println("Enter Condition:");
			String condition=sc.nextLine();
			String query="DELETE FROM production_scheduling_system.resource WHERE "+condition;
			con=DataBaseConnection.getConnection();
			ps=con.prepareStatement(query);
			rows=ps.executeUpdate();
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Error executing query: " + e.getMessage());
		}
		finally {
		if(rows>0)
		    System.out.println(rows+" rows affected");
		else
			System.out.println("No rows were found matching the condition");
		ps.close();
		con.close();
		}
		return;
	}
}
