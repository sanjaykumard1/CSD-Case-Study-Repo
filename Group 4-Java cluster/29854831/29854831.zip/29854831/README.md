# Production Scheduling System

## Description
This project is a menu-based console project developed in core Java.

## Functionalities

### 1.Production Order Management:
- Add a new production order
- View production order details
- Update a production order
- Delete a production order

### 2.Resource Management:
- Add a new resource
- View resource details
- Update a resource
- Delete a resource

### 3.Scheduling Management:
- Add a new schedule
- View scheduling details
- Update a schedule
- Delete a schedule


## Database Schema

### Production Order Table:
- 'order_id' (Primary Key)
- 'product_id'
- 'quantity'
- 'order_date'
- 'due_date'
- 'status' (Open/Closed)

### Resource Table:
- 'resource_id' (Primary Key)
- 'name'
- 'type'
- 'availability'

### Schedule Table:
- 'schedule_id' (Primary Key)
- 'order_id' (Foreign Key references Production Order Table)
- 'resource_id' (Foreign Key references Resource Table)
- 'start_time'
- 'end_time'


## Installation

### Prerequisites:
- Java Development Kit (JDK)
- MySQL database Server
- MySQL Workbench
- MySQL JDBC Driver

### Setup Instructions:
- Clone the Repository
- Setup the MySQL database
- Configure database connection in the application (DataBaseConnection.java)
- Compile and run the application (ProductionScheduling.java)


## Usage
- The application presents a menu-based interface allowing users to manage production orders,resources and schedules.
