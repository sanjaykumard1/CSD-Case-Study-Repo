package com.example.shoppingcart;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    public void addToCart(int productId, int quantity) {
        String query = "INSERT INTO Cart (product_id, quantity) VALUES (?, ?)";

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, productId);
            preparedStatement.setInt(2, quantity);
            preparedStatement.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void removeFromCart(int cartId) {
        String query = "DELETE FROM Cart WHERE cart_id = ?";

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, cartId);
            preparedStatement.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateCartQuantity(int cartId, int quantity) {
        String query = "UPDATE Cart SET quantity = ? WHERE cart_id = ?";

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, cartId);
            preparedStatement.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public List<Cart> getCartItems() {
        List<Cart> cartItems = new ArrayList<>();
        String query = "SELECT * FROM Cart";

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                int cartId = resultSet.getInt("cart_id");
                int productId = resultSet.getInt("product_id");
                int quantity = resultSet.getInt("quantity");

                Cart cart = new Cart(cartId, productId, quantity);
                cartItems.add(cart);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return cartItems;
    }

    public CartItem getCartItemByProductId(int productId) {
        String query = "SELECT * FROM Cart WHERE product_id = ?";
        CartItem cartItem = null;

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, productId);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int cartId = resultSet.getInt("cart_id");
                    int quantity = resultSet.getInt("quantity");

                    cartItem = new CartItem(cartId, productId, quantity);
                }
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return cartItem;
    }

    
    public CartItem getCartItemById(int cart_id) {
        String query = "SELECT * FROM Cart WHERE cart_id = ?";
        CartItem cartItem = null;

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, cart_id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int productId = resultSet.getInt("product_id");
                    int quantity = resultSet.getInt("quantity");

                    cartItem = new CartItem(cart_id, productId, quantity);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return cartItem;
    }
    

}
