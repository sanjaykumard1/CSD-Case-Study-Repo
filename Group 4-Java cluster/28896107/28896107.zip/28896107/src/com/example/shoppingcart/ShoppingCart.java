package com.example.shoppingcart;

import java.util.List;
import java.util.Scanner;

public class ShoppingCart {
    private static ProductDAO productDAO = new ProductDAO();
    private static CartDAO cartDAO = new CartDAO();
    private static OrdersDAO orderDAO = new OrdersDAO();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Display Products");
            System.out.println("2. View Product Details");
            System.out.println("3. Add Product to Cart");
            System.out.println("4. Remove Product from Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Update Cart Quantity");
            System.out.println("7. Checkout");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displayProducts();
                    break;
                case 2:
                    viewProductDetails(scanner);
                    break;
                case 3:
                    addProductToCart(scanner);
                    break;
                case 4:
                    removeProductFromCart(scanner);
                    break;
                case 5:
                    viewCart();
                    break;
                case 6:
                    updateCartQuantity(scanner);
                    break;
                case 7:
                    checkout(scanner);
                    break;
                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayProducts() {
        List<Products> products = productDAO.getAllProducts();
        System.out.println("Available Products:");
        for (Products product : products) {
            System.out.println("ID: " + product.getProduct_id());
            System.out.println("Name: " + product.getName());
            System.out.println("Description: " + product.getDescription());
            System.out.println("Price: " + product.getPrice());
            System.out.println("Stock Quantity: " + product.getStock_quantity());
            System.out.println("------------------------------------");
        }
    }

    private static void viewProductDetails(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        Products product = productDAO.getProductById(productId);
        
        if (product != null) {
            System.out.println("Product Details:");
            System.out.printf("%-15s: %s%n", "Product ID", product.getProduct_id());
            System.out.printf("%-15s: %s%n", "Name", product.getName());
            System.out.printf("%-15s: %s%n", "Description", product.getDescription());
            System.out.printf("%-15s: %.2f%n", "Price", product.getPrice());
            System.out.printf("%-15s: %d%n", "Stock Quantity", product.getStock_quantity());
            System.out.println("------------------------------------");
        } else {
            System.out.println("Product not found.");
        }
    }


    private static void addProductToCart(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        Products product = productDAO.getProductById(productId);
        //Check if product id exists
        if (product == null) {
            System.out.println("Product with ID " + productId + " does not exist.");
            return;
        }

        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();

        CartItem cartItem = cartDAO.getCartItemByProductId(productId);
        int currentCartQuantity = (cartItem != null) ? cartItem.getQuantity() : 0;

        int availableStock = product.getStock_quantity() + currentCartQuantity; // Add currentCartQuantity back to available stock

        int totalQuantity = currentCartQuantity + quantity;

        if (totalQuantity > availableStock) {
            int itemsAvailable = availableStock - currentCartQuantity;
            if (itemsAvailable > 0) {
                System.out.println(" Only " + itemsAvailable + " items added.Product is now out of stock.");
                quantity = itemsAvailable;
            } else {
                System.out.println("Product out of stock. No items available.");
                return;
            }
        }

        if (cartItem != null) {
           
            cartDAO.updateCartQuantity(cartItem.getCartId(), currentCartQuantity + quantity);
            System.out.println("Product quantity updated in cart.");
        } else {
            
            cartDAO.addToCart(productId, quantity);
            System.out.println("Product added to cart.");
        }

        
        productDAO.updateProductStock(productId, quantity); 
    }



    private static void removeProductFromCart(Scanner scanner) {
        System.out.print("Enter cart ID: ");
        int cartId = scanner.nextInt();

     // Check if the cart ID exists
        CartItem cartItem = cartDAO.getCartItemById(cartId);
        if (cartItem == null) {
            System.out.println("Cart item with ID " + cartId + " does not exist.");
            return;
        }

        int productId = cartItem.getproduct_id();
        int quantity = cartItem.getQuantity();

       
        cartDAO.removeFromCart(cartId);

        productDAO.increaseProductStock(productId, quantity);

        System.out.println("Product successfully removed from cart");
    }


    private static void viewCart() {
        List<Cart> cartItems = cartDAO.getCartItems();
        // Check if the cart is empty
        if (cartItems.isEmpty()) {
            System.out.println("The cart is empty.");
        } else {
            System.out.printf("%-10s %-20s %-10s %-10s %-10s%n", "Cart ID", "Product Name", "Product ID", "Quantity", "Price");
            System.out.println("--------------------------------------------------------------");

            double cartTotal = 0.0;

            for (Cart cart : cartItems) {
                Products product = productDAO.getProductById(cart.getProduct_id());
                if (product != null) {
                    double itemTotal = product.getPrice() * cart.getQuantity();
                    cartTotal += itemTotal;
                    System.out.printf("%-10d %-20s %-10d %-10d %-10.2f%n", 
                        cart.getCart_id(), 
                        product.getName(), 
                        cart.getProduct_id(), 
                        cart.getQuantity(), 
                        itemTotal);
                } 
            }

            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-52s %-10.2f%n", "Cart Total", cartTotal);
            System.out.println("--------------------------------------------------------------");
        }
    }


    private static void updateCartQuantity(Scanner scanner) {
        System.out.print("Enter cart ID: ");
        int cartId = scanner.nextInt();
        
        
        CartItem cartItem = cartDAO.getCartItemById(cartId);
        
        // Check if the cartID exists
        if (cartItem == null) {
            System.out.println("Cart with ID " + cartId + " does not exist.");
            return;
        }
        
        Products product = productDAO.getProductById(cartItem.getproduct_id());
        if (product == null) {
            System.out.println("Product with ID " + cartItem.getproduct_id() + " does not exist.");
            return;
        }

        System.out.print("Enter new quantity: ");
        int newQuantity = scanner.nextInt();

        int availableStock = product.getStock_quantity();

        if (newQuantity > availableStock + cartItem.getQuantity()) {
            System.out.println("Only " + availableStock + " items available. Updating to the maximum available quantity.");
            newQuantity = availableStock + cartItem.getQuantity();
        }

        
        cartDAO.updateCartQuantity(cartId, newQuantity);
        
        productDAO.updateProductStock(cartItem.getproduct_id(), newQuantity - cartItem.getQuantity());
        
        System.out.println("Cart updated.");
    }


    private static void checkout(Scanner scanner) {
    	
        // Check if the cart is empty
        List<Cart> cartItems = cartDAO.getCartItems();
        if (cartItems.isEmpty()) {
            System.out.println("The cart is empty. Cannot proceed to checkout.");
            return;
        }

        System.out.print("Enter customer name: ");
        String customerName = scanner.next();
        System.out.print("Enter shipping address: ");
        String shippingAddress = scanner.next();

      
        double totalPrice = 0.0;
        System.out.println("\nCart Summary:");
        System.out.printf("%-20s %-10s %-10s %-10s%n", "Product Name", "Product ID", "Quantity", "Price");
        System.out.println("--------------------------------------------------------");

        for (Cart cart : cartItems) {
            Products product = productDAO.getProductById(cart.getProduct_id());
            if (product != null) {
                double itemTotal = product.getPrice() * cart.getQuantity();
                totalPrice += itemTotal;
                System.out.printf("%-20s %-10d %-10d %-10.2f%n", product.getName(), cart.getProduct_id(), cart.getQuantity(), itemTotal);
            } else {
                System.out.printf("%-20s %-10d %-10d %-10s%n", "Unknown Product", cart.getProduct_id(), cart.getQuantity(), "N/A");
            }
        }

        System.out.println("--------------------------------------------------------");
        System.out.printf("Total Price: %.2f%n", totalPrice);

        
        System.out.print("\nDo you want to place the order? (yes/no): ");
        String confirm = scanner.next();
        if (!confirm.equalsIgnoreCase("yes")) {
            System.out.println("Order cancelled.");
            return;
        }

        
        for (Cart cart : cartItems) {
            orderDAO.placeOrder(cart.getCart_id(), customerName, shippingAddress, totalPrice);
            cartDAO.removeFromCart(cart.getCart_id());
        }

        System.out.println("Order placed with total price: " + totalPrice);
    }


}
