package com.example.shoppingcart;

import java.sql.*;
import java.util.Date;

public class OrdersDAO {
    public void placeOrder(int cart_id, String customerName, String shippingAddress, double totalPrice) {
        String query = "INSERT INTO Orders (cart_id, customer_name, shipping_address, order_date, total_price) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DbConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, cart_id);
            preparedStatement.setString(2, customerName);
            preparedStatement.setString(3, shippingAddress);
            preparedStatement.setDate(4, new java.sql.Date(new Date().getTime()));
            preparedStatement.setDouble(5, totalPrice);
            preparedStatement.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
