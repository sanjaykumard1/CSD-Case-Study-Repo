Shopping Cart 

The various features of the menu based shopping cart are:

-Display list of products
-view product details for a particular product
-Add a product to cart
-Remove a product from cart
-View cart and total price of items in cart
-Update cart quantity
-Checkout by entering shipping details and place the order


SQL Schema:

CREATE TABLE Product (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT NOT NULL
);

INSERT INTO Product (name, description, price, stock_quantity) 
VALUES ('Watch', 'Titan Watch.', 1500, 30);
----------------------------------------------------------------------------
CREATE TABLE Cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT,
    quantity INT,
    FOREIGN KEY (product_id) REFERENCES Product(product_id) ON DELETE CASCADE
);
-------------------------------------------------------------------------------

CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT,
    customer_name VARCHAR(255),
    shipping_address TEXT,
    order_date DATE,
    total_price DECIMAL(10, 2),
    FOREIGN KEY (cart_id) REFERENCES Cart(cart_id) ON DELETE CASCADE
);
-------------------------------------------------------------------------------
