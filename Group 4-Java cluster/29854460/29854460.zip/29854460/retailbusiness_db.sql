create database retailbusiness_db;
use retailbusiness_db;
CREATE TABLE Customer (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone BIGINT,
    address VARCHAR(255)
);
CREATE TABLE Product  (
    product_id INT  PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(100),
    price DECIMAL(12, 4),
    stock_quantity INT
);
CREATE TABLE Orders (
    order_id INT  PRIMARY KEY,
    customer_id INT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(100),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);
CREATE TABLE Order_Item (
    order_item_id INT  PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);


