package com.retail;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class RetailManagementSystem {

    private static final String URL = "jdbc:mysql://localhost:3306/retailbusiness_db";
    private static final String USERNAME = "root"; // replace with the MySQL username
    private static final String PASSWORD = "NI07@muthu"; // replace with the MySQL password
    public static void main(String[] args) {
        Connection conn = null;
        Scanner sc = new Scanner(System.in);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connection created");
                displayMenu();

                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                sc.nextLine(); // Consume newline left-over

                switch (choice) {
                    case 1:
                        addCustomerMenu(sc, conn);
                        break;
                    case 2:
                        viewCustomerMenu(sc, conn);
                        break;
                    case 3:
                        updateCustomerMenu(sc, conn);
                        break;
                    case 4:
                        deleteCustomerMenu(sc, conn);
                        break;
                    case 5:
                        addProductMenu(sc, conn);
                        break;
                    case 6:
                        viewProductMenu(sc, conn);
                        break;
                    case 7:
                        updateProductMenu(sc, conn);
                        break;
                    case 8:
                        deleteProductMenu(sc, conn);
                        break;
                    case 9:
                        placeOrderMenu(sc, conn);
                        break;
                    case 10:
                        viewOrderMenu(sc, conn);
                        break;
                    case 11:
                        updateOrderMenu(sc, conn);
                        break;
                    case 12:
                        cancelOrderMenu(sc, conn);
                        break;
                    case 13:
                        System.out.println("Exiting Retail Management System");
                        System.exit(13);
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid option.");
                        break;
                }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            sc.close();
            if (conn != null) {
                try {
                    conn.close();
                    System.out.println("Connection closed");
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nRetail Management System Menu:");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customer");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.println("5. Add Product");
        System.out.println("6. View Product");
        System.out.println("7. Update Product");
        System.out.println("8. Delete Product");
        System.out.println("9. Place Order");
        System.out.println("10. View Order");
        System.out.println("11. Update Order");
        System.out.println("12. Cancel Order");
        System.out.println("13. Exit");
    }

    private static void addCustomerMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("Enter Customer ID: ");
        long customerId = scanner.nextLong();
        scanner.nextLine(); // Consume newline left-over
        System.out.println("Enter Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter Email: ");
        String email = scanner.nextLine();
        System.out.println("Enter Phone Number: ");
        long phone = scanner.nextLong();
        scanner.nextLine(); // Consume newline left-over
        System.out.println("Enter Address: ");
        String address = scanner.nextLine();
        addCustomer(customerId, name, email, phone, address, conn);
    }

    private static void viewCustomerMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("Enter Customer ID: ");
        long viewCustomerId = scanner.nextLong();
        viewCustomer(viewCustomerId, conn);
    }

    private static void updateCustomerMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.println("Enter Customer ID: ");
        long updateCustomerId = scanner.nextLong();
        scanner.nextLine();
        System.out.println("Enter Name: ");
        String updatedName = scanner.nextLine();
        System.out.println("Enter Email: ");
        String updatedEmail = scanner.nextLine();
        System.out.println("Enter Phone Number: ");
        long updatedPhone = scanner.nextLong();
        scanner.nextLine();
        System.out.println("Enter Address: ");
        String updatedAddress = scanner.nextLine();
        updateCustomer(updateCustomerId, updatedName, updatedEmail, updatedPhone, updatedAddress, conn);
    }

    private static void deleteCustomerMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Customer ID: ");
        System.out.flush();
        long deleteCustomerId = scanner.nextLong();
        deleteCustomer(deleteCustomerId, conn);
    }

    private static void addProductMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Product ID: ");
        System.out.flush();
        long productId = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter Name: ");
        System.out.flush();
        String productName = scanner.nextLine();
        System.out.print("Enter Category: ");
        System.out.flush();
        String category = scanner.nextLine();
        System.out.print("Enter Price: ");
        System.out.flush();
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter Stock Quantity: ");
        System.out.flush();
        int stockQuantity = scanner.nextInt();
        addProduct(productId, productName, category, price, stockQuantity, conn);
    }

    private static void viewProductMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Product ID: ");
        System.out.flush();
        long viewProductId = scanner.nextLong();
        viewProduct(viewProductId, conn);
    }

    private static void updateProductMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Product ID: ");
        System.out.flush();
        long updateProductId = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter Name: ");
        System.out.flush();
        String updatedProductName = scanner.nextLine();
        System.out.print("Enter Category: ");
        System.out.flush();
        String updatedCategory = scanner.nextLine();
        System.out.print("Enter Price: ");
        System.out.flush();
        double updatedPrice = scanner.nextDouble();
        scanner.nextLine(); 
        System.out.print("Enter Stock Quantity: ");
        System.out.flush();
        int updatedStockQuantity = scanner.nextInt();
        updateProduct(updateProductId, updatedProductName, updatedCategory, updatedPrice, updatedStockQuantity, conn);
    }

    private static void deleteProductMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Product ID: ");
        System.out.flush();
        long deleteProductId = scanner.nextLong();
        deleteProduct(deleteProductId, conn);
    }

    private static void placeOrderMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Customer ID: ");
        System.out.flush();
        long customerIdOrder = scanner.nextLong();
        long orderId = placeOrder(customerIdOrder, conn);

        if (orderId > 0) {

            System.out.print("Enter Product ID: ");
            System.out.flush();
            long productIdOrder = scanner.nextLong();
            System.out.print("Enter Quantity: ");
            System.out.flush();
            int quantity = scanner.nextInt();
            System.out.print("Enter Price: ");
            System.out.flush();
            double orderPrice = scanner.nextDouble();
            addOrderItem(orderId, productIdOrder, quantity, orderPrice, conn);
        }
    }

    private static void viewOrderMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Order ID: ");
        System.out.flush();
        long viewOrderId = scanner.nextLong();
        viewOrderDetails(viewOrderId, conn);
    }

    private static void updateOrderMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Order ID: ");
        System.out.flush();
        long updateOrderId = scanner.nextLong();
        scanner.nextLine();
        System.out.print("Enter New Status: ");
        System.out.flush();
        String newStatus = scanner.nextLine();
        updateOrderStatus(updateOrderId, newStatus, conn);
    }

    private static void cancelOrderMenu(Scanner scanner, Connection conn) throws SQLException {
        System.out.print("Enter Order ID: ");
        System.out.flush();
        long cancelOrderId = scanner.nextLong();
        cancelOrder(cancelOrderId, conn);
    }