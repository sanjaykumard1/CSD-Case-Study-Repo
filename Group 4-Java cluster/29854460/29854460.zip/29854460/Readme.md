
# CUSTOMER ORDER MANAGEMENT SYSTEM

This is a menu-based console application developed to assess proficiency in Core Java, MySQL, and JDBC. The application simulates a customer order management system for a retail business, allowing users to manage customers, orders, and products.

- ## Features

### Customer Management
- Add a new customer
- View customer details
- Update customer information
- Delete a customer

### Product Management
- Add a new product
- View product details
- Update product information
- Delete a product

### Order Management
- Place a new order
- View order details
- Update order status
- Cancel an order

## ## Database Schema

### Customer Table
| Column Name | Data Type | Description              |
|-------------|-----------|--------------------------|
| CustomerID  | INT       | Unique identifier for customers |
| Name        | VARCHAR   | Name of the customer     |
| Email       | VARCHAR   | Email address of the customer |
| PhoneNumber | BIGINT    | Phone number of the customer |
| Address     | VARCHAR   | Address of the customer  |

### Product Table
| Column Name  | Data Type | Description                  |
|--------------|-----------|------------------------------|
| ProductID    | INT       | Unique identifier for products |
| Name         | VARCHAR   | Name of the product          |
| Category     | VARCHAR   | Category of the product      |
| Price        | DECIMAL   | Price of the product         |
| StockQuantity| INT       | Stock quantity of the product |

### Order Table
| Column Name | Data Type | Description                  |
|-------------|-----------|------------------------------|
| OrderID     | INT       | Unique identifier for orders |
| CustomerID  | INT       | ID of the customer who placed the order |
| OrderDate   | DATE      | Date the order was placed    |
| Status      | VARCHAR   | Status of the order          |

### Order_Items Table
| Column Name | Data Type | Description                  |
|-------------|-----------|------------------------------|
| OrderItemID | INT       | Unique identifier for order items |
| OrderID     | INT       | ID of the order              |
| ProductID   | INT       | ID of the product            |
| Quantity    | INT       | Quantity of the product ordered |
| Price       | DECIMAL   | Price of the product ordered |

## Software Installation

- **Java**: Eclipse-Workspace
- **Database**: MySQL Server
- **Driver**: JDBC Driver for MySQL

    
## Database setup
CREATE DATABASE retailbusiness_db;
Use retail_business_Ddb;

CREATE TABLE Customer (
    customer_id BIGINT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100),
    phone BIGINT,
    address VARCHAR(255)
);

CREATE TABLE Product (
    product_id BIGINT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(100),
    price DOUBLE,
    stock_quantity INT
);

CREATE TABLE Orders (
    order_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    customer_id BIGINT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

CREATE TABLE Order_Item (
    order_item_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT,
    product_id BIGINT,
    quantity INT,
    price DOUBLE,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);

## Set up
#Clone the Repository

git clone https://github.com/yourusername/retail-management-system.git
cd retail-management-system


## Build and run
javac -cp .:mysql-connector-java-8.0.23.jar com/retail/RetailManagementSystem.java
java -cp .:mysql-connector-java-8.0.23.jar com.retail.RetailManagementSystem

## Usage
Navigate through the menu to manage customers, products, and orders.
