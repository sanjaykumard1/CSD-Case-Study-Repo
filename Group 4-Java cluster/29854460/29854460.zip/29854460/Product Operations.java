public static void addProduct(long product_id, String name, String category, double price, int stock_quantity, Connection conn) {
        String sql = "INSERT INTO Product (product_id, name, category, price, stock_quantity) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, product_id);
            ps.setString(2, name);
            ps.setString(3, category);
            ps.setDouble(4, price);
            ps.setInt(5, stock_quantity);
            ps.executeUpdate();
            System.out.println("Product added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewProduct(long product_id, Connection conn) {
        String sql = "SELECT * FROM Product WHERE product_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, product_id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Product Details:");
                System.out.println("ID: " + rs.getLong("product_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Category: " + rs.getString("category"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Stock Quantity: " + rs.getInt("stock_quantity"));
            } else {
                System.out.println("Product not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateProduct(long product_id, String name, String category, double price, int stock_quantity, Connection conn) {
        String sql = "UPDATE Product SET name = ?, category = ?, price = ?, stock_quantity = ? WHERE product_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, category);
            ps.setDouble(3, price);
            ps.setInt(4, stock_quantity);
            ps.setLong(5, product_id);
            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Product information updated successfully");
            } else {
                System.out.println("Failed to update product information. Product not found or no changes made.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteProduct(long product_id, Connection conn) throws SQLException {
    	  conn.setAutoCommit(false);

    	  try {
    	    deleteOrderItemsByProductId(product_id, conn);
    	    String sql = "DELETE FROM Product WHERE product_id = ?";
    	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
    	      ps.setLong(1, product_id);
    	      int rowsDeleted = ps.executeUpdate();
    	      if (rowsDeleted > 0) {
    	        System.out.println("Product deleted successfully");
    	      } else {
    	        System.out.println("Failed to delete product. Product not found.");
    	      }
    	    }
    	    conn.commit();

    	  } catch (SQLException e) {
    	    conn.rollback();
    	    e.printStackTrace();
    	  } finally {
    	    conn.setAutoCommit(true);
    	  }
    	}

    	// Method to delete order items associated with a product
    	public static void deleteOrderItemsByProductId(long product_id, Connection c) throws SQLException {
    	  String sql = "DELETE FROM Order_Item WHERE product_id = ?";
    	  try (PreparedStatement ps = c.prepareStatement(sql)) {
    	    ps.setLong(1, product_id);
    	    ps.executeUpdate();
    	  }


    	}