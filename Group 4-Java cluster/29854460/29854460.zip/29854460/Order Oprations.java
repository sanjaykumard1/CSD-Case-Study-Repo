public static long placeOrder(long customer_id, Connection conn) throws SQLException {
    String sql = "INSERT INTO Orders (customer_id, order_date, status) VALUES (?, NOW(), 'Pending')";
    try (PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
        ps.setLong(1, customer_id);
        int rowsAffected = ps.executeUpdate();

        if (rowsAffected == 0) {
            throw new SQLException("Creating order failed, no rows affected.");
        }

        try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                return generatedKeys.getLong(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }
        }
    }
}
//order operations
public static void addOrderItem(long order_id, long product_id, int quantity, double price, Connection conn) throws SQLException {
    String sql = "INSERT INTO Order_Item (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setLong(1, order_id);
        ps.setLong(2, product_id);
        ps.setInt(3, quantity);
        ps.setDouble(4, price);
        ps.executeUpdate();
        System.out.println("Order item added successfully");
    }
}

public static void updateOrderStatus(long order_id, String status, Connection conn) throws SQLException {
    String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, status);
        ps.setLong(2, order_id);
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Order status updated successfully");
        } else {
            System.out.println("Failed to update order status. Order not found.");
        }
    }
}

public static void viewOrderDetails(long order_id, Connection conn) throws SQLException {
    PreparedStatement orderPs = null;
    PreparedStatement itemPs = null;
    ResultSet orderRs = null;
    ResultSet itemRs = null;

    try {
        String orderSql = "SELECT o.order_id, o.customer_id, o.order_date, o.status "
                + "FROM Orders o "
                + "WHERE o.order_id = ?";
        orderPs = conn.prepareStatement(orderSql);
        orderPs.setLong(1, order_id);
        orderRs = orderPs.executeQuery();

        if (orderRs.next()) {
            long orderId = orderRs.getLong("order_id");
            long customerId = orderRs.getLong("customer_id");
            String orderDate = orderRs.getString("order_date");
            String status = orderRs.getString("status");

            System.out.println("Order Details:");
            System.out.println("Order ID: " + orderId);
            System.out.println("Customer ID: " + customerId);
            System.out.println("Order Date: " + orderDate);
            System.out.println("Status: " + status);
            String itemSql = "SELECT oi.product_id, oi.quantity, oi.price "
                    + "FROM Order_Item oi "
                    + "WHERE oi.order_id = ?";
            itemPs = conn.prepareStatement(itemSql);
            itemPs.setLong(1, orderId);
            itemRs = itemPs.executeQuery();

            System.out.println("\nOrder Items:");
            while (itemRs.next()) {
                long productId = itemRs.getLong("product_id");
                int quantity = itemRs.getInt("quantity");
                double price = itemRs.getDouble("price");

                System.out.println("  Product ID: " + productId);
                System.out.println("  Quantity: " + quantity);
                System.out.println("  Price: $" + price);
            }
        } else {
            System.out.println("Order not found with ID: " + order_id);
        }
    } finally {
        if (itemRs != null) itemRs.close();
        if (itemPs != null) itemPs.close();
        if (orderRs != null) orderRs.close();
        if (orderPs != null) orderPs.close();
    }
}

public static boolean productExists(long product_id, Connection conn) throws SQLException {
    String sql = "SELECT COUNT(*) FROM Product WHERE product_id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setLong(1, product_id);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
    }
    return false;
}
public static void cancelOrder(long order_id, Connection conn) throws SQLException {
    String sql = "UPDATE Orders SET status = 'Cancelled' WHERE order_id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setLong(1, order_id);
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Order cancelled successfully");
        } else {
            System.out.println("Failed to cancel order. Order not found.");
        }
    }
}
}
