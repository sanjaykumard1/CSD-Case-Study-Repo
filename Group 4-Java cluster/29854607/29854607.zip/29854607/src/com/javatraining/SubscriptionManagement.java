package com.javatraining;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//class for subscription management

public class SubscriptionManagement {
	public static void menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nSubscription Management");
            System.out.println("1. Subscribe to a magazine");
            System.out.println("2. View subscription details");
            System.out.println("3. Update subscription information");
            System.out.println("4. Cancel a subscription");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    subscribe();
                    break;
                case 2:
                    viewSubscription();
                    break;
                case 3:
                    updateSubscription();
                    break;
                case 4:
                    cancelSubscription();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void subscribe() {
        // Code to subscribe to a magazine
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter magazine ID: ");
        int magazineId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter subscription date (YYYY-MM-DD): ");
        String subscriptionDate = scanner.nextLine();
        System.out.print("Enter expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Subscription (user_id, magazine_id, subscription_date, expiry_date, status) VALUES (?, ?, ?, ?, 'active')";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            pstmt.setInt(2, magazineId);
            pstmt.setString(3, subscriptionDate);
            pstmt.setString(4, expiryDate);
            pstmt.executeUpdate();
            System.out.println("Subscription added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding subscription: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void viewSubscription() {
        // Code to view subscription details
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter subscription ID to view details: ");
        int subscriptionId = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Subscription WHERE subscription_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, subscriptionId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("User ID: " + rs.getInt("user_id"));
                System.out.println("Magazine ID: " + rs.getInt("magazine_id"));
                System.out.println("Subscription Date: " + rs.getString("subscription_date"));
                System.out.println("Expiry Date: " + rs.getString("expiry_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing subscription details: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void updateSubscription() {
        // Code to update subscription information
    	scanner scanner = new Scanner(System.in);
        System.out.print("Enter subscription ID to update: ");
        int subscriptionId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new expiry date (YYYY-MM-DD): ");
        String expiryDate = scanner.nextLine();
        System.out.print("Enter new status (active/inactive): ");
        String status = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Subscription SET expiry_date = ?, status = ? WHERE subscription_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, expiryDate);
            pstmt.setString(2, status);
            pstmt.setInt(3, subscriptionId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Subscription updated successfully!");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating subscription: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void cancelSubscription() {
        // Code to cancel a subscription
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter subscription ID to cancel: ");
        int subscriptionId = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Subscription SET status = 'inactive' WHERE subscription_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, subscriptionId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Subscription canceled successfully!");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error canceling subscription: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
