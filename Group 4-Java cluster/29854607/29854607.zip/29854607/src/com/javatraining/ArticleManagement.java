package com.javatraining;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


//class for article management
public class ArticleManagement {
	public static void menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nArticle Management");
            System.out.println("1. Add a new article");
            System.out.println("2. View article details");
            System.out.println("3. Update article information");
            System.out.println("4. Delete an article");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addArticle();
                    break;
                case 2:
                    viewArticle();
                    break;
                case 3:
                    updateArticle();
                    break;
                case 4:
                    deleteArticle();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void addArticle() {
        // Code to add article
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter magazine ID: ");
        int magazineId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter content: ");
        String content = scanner.nextLine();
        System.out.print("Enter publish date (YYYY-MM-DD): ");
        String publishDate = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Article (magazine_id, title, author, content, publish_date) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, magazineId);
            pstmt.setString(2, title);
            pstmt.setString(3, author);
            pstmt.setString(4, content);
            pstmt.setString(5, publishDate);
            pstmt.executeUpdate();
            System.out.println("Article added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding article: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void viewArticle() {
        // Code to view article details
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter article ID to view details: ");
        int articleId = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Article WHERE article_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, articleId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Magazine ID: " + rs.getInt("magazine_id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Author: " + rs.getString("author"));
                System.out.println("Content: " + rs.getString("content"));
                System.out.println("Publish Date: " + rs.getString("publish_date"));
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing article details: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void updateArticle() {
        // Code to update article information
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter article ID to update: ");
        int articleId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new author: ");
        String author = scanner.nextLine();
        System.out.print("Enter new content: ");
        String content = scanner.nextLine();
        System.out.print("Enter new publish date (YYYY-MM-DD): ");
        String publishDate = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Article SET title = ?, author = ?, content = ?, publish_date = ? WHERE article_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, author);
            pstmt.setString(3, content);
            pstmt.setString(4, publishDate);
            pstmt.setInt(5, articleId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Article updated successfully!");
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating article: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void deleteArticle() {
        // Code to delete an article
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter article ID to delete: ");
        int articleId = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Article WHERE article_id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, articleId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Article deleted successfully!");
            } else {
                System.out.println("Article not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting article: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
