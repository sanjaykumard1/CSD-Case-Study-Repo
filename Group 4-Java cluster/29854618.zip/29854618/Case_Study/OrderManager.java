package com.jdbc2;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OrderManager {
    private Scanner scanner = new Scanner(System.in);

    public void placeOrder() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        List<OrderItem> orderItems = new ArrayList<>();
        double totalAmount = 0;

        while (true) {
            System.out.print("Enter product ID (0 to finish): ");
            int productId = scanner.nextInt();
            if (productId == 0) break;

            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();

            // Get product price and check stock
            String checkProductSql = "SELECT price, stock_quantity FROM Product WHERE product_id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(checkProductSql)) {

                pstmt.setInt(1, productId);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    double price = rs.getDouble("price");
                    int stockQuantity = rs.getInt("stock_quantity");

                    if (stockQuantity >= quantity) {
                        OrderItem item = new OrderItem(productId, quantity, price);
                        orderItems.add(item);
                        totalAmount += price * quantity;
                    } else {
                        System.out.println("Not enough stock. Available: " + stockQuantity);
                    }
                } else {
                    System.out.println("Product not found.");
                }

            } catch (SQLException e) {
                System.out.println("Error checking product: " + e.getMessage());
                return;
            }
        }

        if (orderItems.isEmpty()) {
            System.out.println("No items in the order. Cancelling.");
            return;
        }

        // Insert order
        String insertOrderSql = "INSERT INTO Order (customer_id, order_date, total_amount, status) VALUES (?, NOW(), ?, 'pending')";
        String insertOrderItemSql = "INSERT INTO OrderItem (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        String updateProductSql = "UPDATE Product SET stock_quantity = stock_quantity - ? WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement pstmtOrder = conn.prepareStatement(insertOrderSql, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement pstmtOrderItem = conn.prepareStatement(insertOrderItemSql);
                 PreparedStatement pstmtUpdateProduct = conn.prepareStatement(updateProductSql)) {

                // Insert order
                pstmtOrder.setInt(1, customerId);
                pstmtOrder.setDouble(2, totalAmount);
                int affectedRows = pstmtOrder.executeUpdate();

                if (affectedRows == 0) {
                    throw new SQLException("Creating order failed, no rows affected.");
                }

                try (ResultSet generatedKeys = pstmtOrder.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int orderId = generatedKeys.getInt(1);

                        // Insert order items and update product stock
                        for (OrderItem item : orderItems) {
                            pstmtOrderItem.setInt(1, orderId);
                            pstmtOrderItem.setInt(2, item.getProductId());
                            pstmtOrderItem.setInt(3, item.getQuantity());
                            pstmtOrderItem.setDouble(4, item.getPrice());
                            pstmtOrderItem.executeUpdate();

                            pstmtUpdateProduct.setInt(1, item.getQuantity());
                            pstmtUpdateProduct.setInt(2, item.getProductId());
                            pstmtUpdateProduct.executeUpdate();
                        }

                        conn.commit();
                        System.out.println("Order placed successfully. Order ID: " + orderId);
                    } else {
                        throw new SQLException("Creating order failed, no ID obtained.");
                    }
                }

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error placing order: " + e.getMessage());
        }
    }

    public void viewOrder() {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();

        String sql = "SELECT o.*, c.name as customer_name, oi.product_id, p.name as product_name, oi.quantity, oi.price " +
                     "FROM `Order` o " +
                     "JOIN Customer c ON o.customer_id = c.customer_id " +
                     "JOIN OrderItem oi ON o.order_id = oi.order_id " +
                     "JOIN Product p ON oi.product_id = p.product_id " +
                     "WHERE o.order_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, orderId);
            ResultSet rs = pstmt.executeQuery();

            boolean orderFound = false;
            while (rs.next()) {
                if (!orderFound) {
                    System.out.println("Order Details:");
                    System.out.println("Order ID: " + rs.getInt("order_id"));
                    System.out.println("Customer: " + rs.getString("customer_name"));
                    System.out.println("Order Date: " + rs.getTimestamp("order_date"));
                    System.out.println("Total Amount: " + rs.getDouble("total_amount"));
                    System.out.println("Status: " + rs.getString("status"));
                    System.out.println("Items:");
                    orderFound = true;
                }

                System.out.println("  - " + rs.getString("product_name") + 
                                   " (Quantity: " + rs.getInt("quantity") + 
                                   ", Price: " + rs.getDouble("price") + ")");
            }

            if (!orderFound) {
                System.out.println("Order not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error viewing order: " + e.getMessage());
        }
    }

    public void updateOrder() {
        System.out.print("Enter order ID to update: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new order status (pending/confirmed/shipped/delivered/cancelled): ");
        String status = scanner.nextLine();

        String sql = "UPDATE `Order` SET status = ? WHERE order_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, status);
            pstmt.setInt(2, orderId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Order status updated successfully.");
            } else {
                System.out.println("Order not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error updating order: " + e.getMessage());
        }
    }

    public void cancelOrder() {
        System.out.print("Enter order ID to cancel: ");
        int orderId = scanner.nextInt();

        String updateOrderSql = "UPDATE `Order` SET status = 'cancelled' WHERE order_id = ? AND status != 'cancelled'";
        String getOrderItemsSql = "SELECT product_id, quantity FROM OrderItem WHERE order_id = ?";
        String updateProductSql = "UPDATE Product SET stock_quantity = stock_quantity + ? WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            try {
                // Update order status
                try (PreparedStatement pstmtUpdateOrder = conn.prepareStatement(updateOrderSql)) {
                    pstmtUpdateOrder.setInt(1, orderId);
                    int affectedRows = pstmtUpdateOrder.executeUpdate();

                    if (affectedRows == 0) {
                        System.out.println("Order not found or already cancelled.");
                        return;
                    }
                }

                // Get order items
                List<OrderItem> orderItems = new ArrayList<>();
                try (PreparedStatement pstmtGetItems = conn.prepareStatement(getOrderItemsSql)) {
                    pstmtGetItems.setInt(1, orderId);
                    ResultSet rs = pstmtGetItems.executeQuery();

                    while (rs.next()) {
                        orderItems.add(new OrderItem(rs.getInt("product_id"), rs.getInt("quantity"), 0));
                    }
                }

                // Update product stock
                try (PreparedStatement pstmtUpdateProduct = conn.prepareStatement(updateProductSql)) {
                    for (OrderItem item : orderItems) {
                        pstmtUpdateProduct.setInt(1, item.getQuantity());
                        pstmtUpdateProduct.setInt(2, item.getProductId());
                        pstmtUpdateProduct.executeUpdate();
                    }
                }

                conn.commit();
                System.out.println("Order cancelled successfully.");

            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error cancelling order: " + e.getMessage());
        }
    }
}