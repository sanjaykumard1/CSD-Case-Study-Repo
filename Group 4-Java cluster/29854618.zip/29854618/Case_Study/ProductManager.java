package com.jdbc2;

import java.sql.*;
import java.util.Scanner;

public class ProductManager {
    private Scanner scanner = new Scanner(System.in);

    public void addProduct() {
        System.out.println("Enter product details:");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();
        System.out.print("Price: ");
        double price = scanner.nextDouble();
        System.out.print("Stock Quantity: ");
        int stockQuantity = scanner.nextInt();

        String sql = "INSERT INTO Product (name, description, price, stock_quantity) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, stockQuantity);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Product added successfully.");
            } else {
                System.out.println("Failed to add product.");
            }

        } catch (SQLException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    public void viewProduct() {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();

        String sql = "SELECT * FROM Product WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Product Details:");
                System.out.println("ID: " + rs.getInt("product_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Stock Quantity: " + rs.getInt("stock_quantity"));
            } else {
                System.out.println("Product not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error viewing product: " + e.getMessage());
        }
    }

    public void updateProduct() {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new product details (press Enter to skip):");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Description: ");
        String description = scanner.nextLine();
        System.out.print("Price: ");
        String priceStr = scanner.nextLine();
        System.out.print("Stock Quantity: ");
        String stockQuantityStr = scanner.nextLine();

        String sql = "UPDATE Product SET name = COALESCE(?, name), description = COALESCE(?, description), " +
                     "price = COALESCE(?, price), stock_quantity = COALESCE(?, stock_quantity) WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name.isEmpty() ? null : name);
            pstmt.setString(2, description.isEmpty() ? null : description);
            pstmt.setObject(3, priceStr.isEmpty() ? null : Double.parseDouble(priceStr));
            pstmt.setObject(4, stockQuantityStr.isEmpty() ? null : Integer.parseInt(stockQuantityStr));
            pstmt.setInt(5, productId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product not found or no changes made.");
            }

        } catch (SQLException e) {
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    public void deleteProduct() {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();

        String sql = "DELETE FROM Product WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, productId);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }
}