package com.jdbc2;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static ProductManager productManager = new ProductManager();
    private static CustomerManager customerManager = new CustomerManager();
    private static OrderManager orderManager = new OrderManager();

    public static void main(String[] args) {
        while (true) {
            displayMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    productMenu();
                    break;
                case 2:
                    customerMenu();
                    break;
                case 3:
                    orderMenu();
                    break;
                case 4:
                    System.out.println("Application Closed!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("\n--- Consumer Electronics Store Management System ---");
        System.out.println("1. Product Management");
        System.out.println("2. Customer Management");
        System.out.println("3. Order Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void productMenu() {
        while (true) {
            System.out.println("\n--- Product Management ---");
            System.out.println("1. Add a new product");
            System.out.println("2. View product details");
            System.out.println("3. Update product information");
            System.out.println("4. Delete a product");
            System.out.println("5. Return to main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    productManager.addProduct();
                    break;
                case 2:
                    productManager.viewProduct();
                    break;
                case 3:
                    productManager.updateProduct();
                    break;
                case 4:
                    productManager.deleteProduct();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void customerMenu() {
        while (true) {
            System.out.println("\n--- Customer Management ---");
            System.out.println("1. Add a new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete a customer");
            System.out.println("5. Return to main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    customerManager.addCustomer();
                    break;
                case 2:
                    customerManager.viewCustomer();
                    break;
                case 3:
                    customerManager.updateCustomer();
                    break;
                case 4:
                    customerManager.deleteCustomer();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void orderMenu() {
        while (true) {
            System.out.println("\n--- Order Management ---");
            System.out.println("1. Place a new order");
            System.out.println("2. View order details");
            System.out.println("3. Update order information");
            System.out.println("4. Cancel an order");
            System.out.println("5. Return to main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    orderManager.placeOrder();
                    break;
                case 2:
                    orderManager.viewOrder();
                    break;
                case 3:
                    orderManager.updateOrder();
                    break;
                case 4:
                    orderManager.cancelOrder();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Product class
    public static class Product {
        private int productId;
        private String name;
        private String description;
        private double price;
        private int stockQuantity;

        // Constructor
        public Product(int productId, String name, String description, double price, int stockQuantity) {
            this.productId = productId;
            this.name = name;
            this.description = description;
            this.price = price;
            this.stockQuantity = stockQuantity;
        }

        // Getters and setters
        public int getProductId() { return productId; }
        public void setProductId(int productId) { this.productId = productId; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
        public int getStockQuantity() { return stockQuantity; }
        public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }
    }

    // Customer class
    public static class Customer {
        private int customerId;
        private String name;
        private String email;
        private String phoneNumber;
        private String address;

        // Constructor
        public Customer(int customerId, String name, String email, String phoneNumber, String address) {
            this.customerId = customerId;
            this.name = name;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.address = address;
        }

        // Getters and setters
        public int getCustomerId() { return customerId; }
        public void setCustomerId(int customerId) { this.customerId = customerId; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhoneNumber() { return phoneNumber; }
        public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
        public String getAddress() { return address; }
        public void setAddress(String address) { this.address = address; }
    }

    // Order class
    public static class Order {
        private int orderId;
        private int customerId;
        private Date orderDate;
        private double totalAmount;
        private String status;
        private List<OrderItem> orderItems;

        // Constructor
        public Order(int orderId, int customerId, Date orderDate, double totalAmount, String status) {
            this.orderId = orderId;
            this.customerId = customerId;
            this.orderDate = orderDate;
            this.totalAmount = totalAmount;
            this.status = status;
            this.orderItems = new ArrayList<>();
        }

        // Getters and setters
        public int getOrderId() { return orderId; }
        public void setOrderId(int orderId) { this.orderId = orderId; }
        public int getCustomerId() { return customerId; }
        public void setCustomerId(int customerId) { this.customerId = customerId; }
        public Date getOrderDate() { return orderDate; }
        public void setOrderDate(Date orderDate) { this.orderDate = orderDate; }
        public double getTotalAmount() { return totalAmount; }
        public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public List<OrderItem> getOrderItems() { return orderItems; }
        public void setOrderItems(List<OrderItem> orderItems) { this.orderItems = orderItems; }

        // Method to add an order item
        public void addOrderItem(OrderItem item) {
            orderItems.add(item);
        }
    }

    // OrderItem class
    public static class OrderItem {
        private int orderItemId;
        private int orderId;
        private int productId;
        private int quantity;
        private double price;

        // Constructor
        public OrderItem(int orderItemId, int orderId, int productId, int quantity, double price) {
            this.orderItemId = orderItemId;
            this.orderId = orderId;
            this.productId = productId;
            this.quantity = quantity;
            this.price = price;
        }

        // Getters and setters
        public int getOrderItemId() { return orderItemId; }
        public void setOrderItemId(int orderItemId) { this.orderItemId = orderItemId; }
        public int getOrderId() { return orderId; }
        public void setOrderId(int orderId) { this.orderId = orderId; }
        public int getProductId() { return productId; }
        public void setProductId(int productId) { this.productId = productId; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
        public double getPrice() { return price; }
        public void setPrice(double price) { this.price = price; }
    }
}