package attendance;

import java.sql.*;
import java.util.*;

public class Employee {
	private static int employee_id;
	private static String name;
	private static String department;
	private static String email;
	private static String phone_number;
	
	public static void addEmployee (Connection con, Scanner sc ) throws SQLException {
		System.out.println ("Enter employee Id: ");
		employee_id = sc.nextInt ();
		sc.nextLine();
		System.out.println ("Enter Employee Name: ");
		name = sc.nextLine();
		System.out.println ("Enter Department: ");
		department = sc.nextLine ();
		System.out.println ("Enter email");
		email = sc.nextLine ();
		System.out.println ("Enter phone number ");
		phone_number = sc.nextLine ();
		
		String query = "insert into employee (employee_id, name, department, email, phone_number) values (?, ?, ?, ?, ?)";
		
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt (1, employee_id);
		st.setString(2, name);
		st.setString(3, department);
		st.setString(4, email);
		st.setString(5, phone_number);
		
		st.executeUpdate();
	}
	
	public static void viewEmployee (Connection con, Scanner sc) throws SQLException {
		int id;
		System.out.println ("Enter the Employee ID: ");
		id = sc.nextInt();
		
		String query = "select * from employee where employee_id = ?";
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		
		ResultSet res = st.executeQuery ();
		
		res.next();
		
		System.out.println ("Employee ID: " + res.getInt("employee_id"));
		System.out.println ("Employee Name: " + res.getString("name"));
		System.out.println ("Employee Department: " + res.getString("department"));
		System.out.println ("Employee Email: " + res.getString("email"));
		System.out.println ("Employee Phone Number: " + res.getString("phone_number"));
		
	}
	
	public static void updateEmployee (Connection con, Scanner sc) throws SQLException {
		int id;
		System.out.println("Enter id of employee: ");
		id = sc.nextInt();
		sc.nextLine(); // carriage return
		System.out.println ("Enter employee Id: ");
		employee_id = sc.nextInt ();
		sc.nextLine();
		System.out.println ("Enter Employee Name: ");
		name = sc.nextLine();
		System.out.println ("Enter Department: ");
		department = sc.nextLine ();
		System.out.println ("Enter email");
		email = sc.nextLine ();
		System.out.println ("Enter phone number ");
		phone_number = sc.nextLine ();
		
		String query = "update employee set employee_id = ?, name = ?, department = ?, email = ?, phone_number = ? where employee_id = ?";

		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, employee_id);
		st.setString(2, name);
		st.setString(3, department);
		st.setString(4,  email);
		st.setString(5, phone_number);
		st.setInt(6,  id);
		
		st.executeUpdate();
		
	}
	
	public static void deleteEmployee (Connection con, Scanner sc) throws SQLException {
		String query = "delete from employee where employee_id = ?";
		int id;
		
		System.out.println ("Enter the Employee ID: ");
		id = sc.nextInt();
		sc.nextLine ();
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		
		st.executeUpdate();
		
	}
}
