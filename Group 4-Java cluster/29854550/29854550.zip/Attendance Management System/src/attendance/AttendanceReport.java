package attendance;

import java.sql.*;
import java.util.*;

public class AttendanceReport {
	public static void monthlyAttendance (Connection con, Scanner sc) throws SQLException {
		int month;
		int id;
		String query = "select * from attendance where employee_id = ? AND MONTH(dates) = ?";
		
		System.out.println ("Enter the Employee ID: ");
		id = sc.nextInt ();
		sc.nextLine ();
		
		System.out.println ("Enter the month: ");
		month = sc.nextInt ();
		sc.nextLine ();
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		st.setInt(2, month);
		
		ResultSet res = st.executeQuery();
		
		while ( res.next() ) {
			System.out.println("Attendance ID: "+res.getInt("attendance_id"));
			System.out.println ("Employee ID: "+res.getInt("employee_id"));
			System.out.println("Date: "+res.getString("dates"));
			System.out.println("Status: "+res.getString("status"));
			System.out.println();
		}
	}
	
	public static void dailyAttendance ( Connection con, Scanner sc ) throws SQLException {
		String date;
		String query = "select * from attendance where dates = ?";
		
		System.out.println("Enter the date (YYYY-MM-DD): ");
		sc.nextLine (); // carriage return
		date = sc.nextLine ();
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setString(1, date);
		
		ResultSet res = st.executeQuery ();
		
		while ( res.next() ) {
			System.out.println("Attendance ID: "+res.getInt("attendance_id"));
			System.out.println ("Employee ID: "+res.getInt("employee_id"));
			System.out.println("Date: "+res.getString("dates"));
			System.out.println("Status: "+res.getString("status"));
			System.out.println();
		}
	}
}
