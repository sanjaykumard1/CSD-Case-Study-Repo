package attendance;

import java.sql.*;
import java.util.*;

public class Attendance {
	public static void recordAttendance ( Connection con, Scanner sc ) throws SQLException {
		int id;
		int emp_id;
		String date;
		String attendance;
		
		System.out.println ("Enter the Attendance ID: ");
		id = sc.nextInt();
		sc.nextLine();
		
		System.out.println ("Enter the Employee ID: ");
		emp_id = sc.nextInt();
		sc.nextLine ();
		
		System.out.println ("Enter the date ( YYYY-MM-DD ) :");
		date = sc.nextLine();
		
		System.out.println("Attendance (present/absent): ");
		attendance = sc.nextLine();
		
		String query = "insert into attendance (attendance_id, employee_id, dates, status) values (?, ?, ?, ?)";
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		st.setInt(2, emp_id);
		st.setString(3, date);
		st.setString(4, attendance);
		
		st.executeUpdate();
	}
	
	public static void viewAttendance ( Connection con, Scanner sc ) throws SQLException {
		int id;
		
		System.out.println ("Enter the Employee ID: ");
		id = sc.nextInt();
		
		String query = "select * from attendance where employee_id = ?";
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		
		ResultSet res = st.executeQuery();
		
		System.out.println();
		
		while ( res.next() ) {
			System.out.println("Attendance ID: "+res.getInt("attendance_id"));
			System.out.println ("Employee ID: "+res.getInt("employee_id"));
			System.out.println("Date: "+res.getString("dates"));
			System.out.println("Status: "+res.getString("status"));
			System.out.println();
		}
	}
	
	public static void updateAttendance ( Connection con, Scanner sc ) throws SQLException {
		int id;
		int employee_id;
		String dates;
		String status;
		
		System.out.println("Enter the Attendance ID: ");
		id = sc.nextInt();
		sc.nextLine(); // carriage return
		
		
		System.out.println("Enter the Employee ID: ");
		employee_id = sc.nextInt ();
		sc.nextLine ();
		
		System.out.println("Enter the Date: ");
		dates = sc.nextLine ();
		
		System.out.println("Enter the status (present/absent): ");
		status = sc.nextLine ();
		
		String query = "update attendance set employee_id = ?, dates = ?, status = ? where attendance_id = ?";
		
		PreparedStatement st = con.prepareStatement (query);
		
		st.setInt(1, employee_id);
		st.setString(2, dates);
		st.setString(3, status);
		st.setInt(4, id);
		
		st.executeUpdate();
	}
	
	public static void deleteAttendance ( Connection con, Scanner sc ) throws SQLException {
		String query = "delete from attendance where attendance_id = ?";
		int id;
		
		System.out.println("Enter the Attendance ID: ");
		id = sc.nextInt();
		
		PreparedStatement st = con.prepareStatement(query);
		
		st.setInt(1, id);
		
		st.executeUpdate ();
	}
}
