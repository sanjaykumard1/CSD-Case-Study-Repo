package attendance;
import java.sql.*;
import java.util.*;
public class AttendanceMain {
	
	public static void employeeManagement ( Connection con, Scanner sc ) throws SQLException {
		while (true) {
			System.out.println ("1. Add Employee");
			System.out.println ("2. View Employee Details");
			System.out.println ("3. Update Employee information");
			System.out.println ("4. Delete Employee");
			System.out.println ("5. Exit");
			
			int choice = sc.nextInt();
			//Employee emp = new Employee ();
			
			switch (choice) {
			case 1:
				Employee.addEmployee (con, sc);
				break;
			case 2:
				Employee.viewEmployee (con, sc);
				break;
			case 3:
				Employee.updateEmployee (con, sc);
				break;
			case 4:
				Employee.deleteEmployee (con, sc);
				break;
			case 5:
				return;
			default:
				System.out.println("Invalid Input");
			}
		}
	}
	
	public static void attendanceManagement (Connection con, Scanner sc) throws SQLException {
		while (true) {
			System.out.println ("1. Record Attendacnce: ");
			System.out.println ("2. View Attendance Details: ");
			System.out.println ("3. Update Attendance Record: ");
			System.out.println ("4. Delete Attendance Record: ");
			System.out.println ("5. Exit");
			
			int choice;
			choice = sc.nextInt();
			sc.nextLine();
			
			switch ( choice ) {
			case 1:
				Attendance.recordAttendance (con, sc);
				break;
			case 2:
				Attendance.viewAttendance (con, sc);
				break;
			case 3:
				Attendance.updateAttendance (con, sc);
				break;
			case 4:
				Attendance.deleteAttendance (con, sc);
				break;
			case 5:
				return;
			default:
				System.out.println ("Invalid Input");
			}
		}
	}
	
	public static void attendanceReport (Connection con, Scanner sc) throws SQLException {
		while (true) {
			int choice;
			
			 System.out.println ("1. Generate Monthly Attendance. ");
			 System.out.println ("2. Generate Daily Attendance. ");
			 System.out.println ("3. Exit.");
			 
			 choice = sc.nextInt ();
			 
			 switch (choice) {
			 case 1:
				 AttendanceReport.monthlyAttendance (con, sc);
				 break;
			 case 2:
				 AttendanceReport.dailyAttendance(con, sc);
				 break;
			 case 3:
				 return;
			 default:
				 System.out.println ("Invalid Input");
			 }
 	    }
	}
	

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		String url = "jdbc:mysql://localhost/management";
		String username = "root";
		String password = "Petchi@11";
		//String query = "select * from bill";
		
		Connection con = DriverManager.getConnection(url, username, password);
		//Statement st = con.createStatement ();
		//ResultSet rs = st.executeQuery(query);
		/*while (rs.next())
			System.out.println(rs.getString ("bill_id"));
		*/
		
		int choice;
		
		do {
			Scanner sc = new Scanner (System.in);
			
			System.out.println ("Attendance Manangement System");
			System.out.println ("1. Employee Management");
			System.out.println ("2. Attendance Management");
			System.out.println ("3. Attendance Report");
			System.out.println ("4. Exit");
			
			choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				employeeManagement (con, sc);
				break;
			case 2:
				attendanceManagement (con, sc);
				break;
			case 3:
				attendanceReport (con, sc);
				break;
			case 4:
				System.out.println ("Exiting...");
				break;
			default:
				System.out.println ("Invalid Choice");
			}
		
		} while (choice != 4);
		
		con.close();
	}

}
