import java.sql.*;
import java.util.Scanner;

public class GymManagementSystem {
    private static final String URL = "jdbc:mysql://localhost:3306/gym_management";
    private static final String USER = "root";
    private static final String PASSWORD = "rudyxGG@komradez101";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Gym Management System");
            System.out.println("1. Member Management");
            System.out.println("2. Trainer Management");
            System.out.println("3. Class Schedule Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageMembers();
                    break;
                case 2:
                    manageTrainers();
                    break;
                case 3:
                    manageClassSchedules();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageMembers() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Member Management");
            System.out.println("1. Register new member");
            System.out.println("2. View member details");
            System.out.println("3. Update member information");
            System.out.println("4. Delete member");
            System.out.println("5. Back to main menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    registerMember();
                    break;
                case 2:
                    viewMemberDetails();
                    break;
                case 3:
                    updateMemberInformation();
                    break;
                case 4:
                    deleteMember();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageTrainers() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Trainer Management");
            System.out.println("1. Add new trainer");
            System.out.println("2. View trainer details");
            System.out.println("3. Update trainer information");
            System.out.println("4. Delete trainer");
            System.out.println("5. Back to main menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    addTrainer();
                    break;
                case 2:
                    viewTrainerDetails();
                    break;
                case 3:
                    updateTrainerInformation();
                    break;
                case 4:
                    deleteTrainer();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageClassSchedules() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Class Schedule Management");
            System.out.println("1. Create new class schedule");
            System.out.println("2. View class schedules");
            System.out.println("3. Update class information");
            System.out.println("4. Cancel class");
            System.out.println("5. Back to main menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    createClassSchedule();
                    break;
                case 2:
                    viewClassSchedules();
                    break;
                case 3:
                    updateClassInformation();
                    break;
                case 4:
                    cancelClass();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Member management functions
    private static void registerMember() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            System.out.print("Enter membership type: ");
            String membershipType = scanner.nextLine();

            String sql = "INSERT INTO Member (name, contact_number, email, membership_type) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, contactNumber);
                pstmt.setString(3, email);
                pstmt.setString(4, membershipType);
                pstmt.executeUpdate();
                System.out.println("Member registered successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewMemberDetails() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();
            String sql = "SELECT * FROM Member WHERE member_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, memberId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Member ID: " + rs.getInt("member_id"));
                        System.out.println("Name: " + rs.getString("name"));
                        System.out.println("Contact Number: " + rs.getString("contact_number"));
                        System.out.println("Email: " + rs.getString("email"));
                        System.out.println("Membership Type: " + rs.getString("membership_type"));
                    } else {
                        System.out.println("Member not found.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateMemberInformation() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new membership type: ");
            String membershipType = scanner.nextLine();

            String sql = "UPDATE Member SET name = ?, contact_number = ?, email = ?, membership_type = ? WHERE member_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, contactNumber);
                pstmt.setString(3, email);
                pstmt.setString(4, membershipType);
                pstmt.setInt(5, memberId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Member information updated successfully.");
                } else {
                    System.out.println("Member not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteMember() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();
            String sql = "DELETE FROM Member WHERE member_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, memberId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Member deleted successfully.");
                } else {
                    System.out.println("Member not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Trainer management functions
    private static void addTrainer() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            System.out.print("Enter speciality: ");
            String speciality = scanner.nextLine();

            String sql = "INSERT INTO Trainer (name, contact_number, email, speciality) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, contactNumber);
                pstmt.setString(3, email);
                pstmt.setString(4, speciality);
                pstmt.executeUpdate();
                System.out.println("Trainer added successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewTrainerDetails() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter trainer ID: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine();
            String sql = "SELECT * FROM Trainer WHERE trainer_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, trainerId);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                        System.out.println("Name: " + rs.getString("name"));
                        System.out.println("Contact Number: " + rs.getString("contact_number"));
                        System.out.println("Email: " + rs.getString("email"));
                        System.out.println("Speciality: " + rs.getString("speciality"));
                    } else {
                        System.out.println("Trainer not found.");
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateTrainerInformation() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter trainer ID: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new speciality: ");
            String speciality = scanner.nextLine();

            String sql = "UPDATE Trainer SET name = ?, contact_number = ?, email = ?, speciality = ? WHERE trainer_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, contactNumber);
                pstmt.setString(3, email);
                pstmt.setString(4, speciality);
                pstmt.setInt(5, trainerId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Trainer information updated successfully.");
                } else {
                    System.out.println("Trainer not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteTrainer() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter trainer ID: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine();
            String sql = "DELETE FROM Trainer WHERE trainer_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, trainerId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Trainer deleted successfully.");
                } else {
                    System.out.println("Trainer not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Class schedule management functions
    private static void createClassSchedule() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter class name: ");
            String className = scanner.nextLine();
            System.out.print("Enter trainer ID: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter day of week: ");
            String dayOfWeek = scanner.nextLine();
            System.out.print("Enter start time (HH:MM:SS): ");
            String startTime = scanner.nextLine();
            System.out.print("Enter end time (HH:MM:SS): ");
            String endTime = scanner.nextLine();

            String sql = "INSERT INTO ClassSchedule (class_name, trainer_id, day_of_week, start_time, end_time) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, className);
                pstmt.setInt(2, trainerId);
                pstmt.setString(3, dayOfWeek);
                pstmt.setTime(4, Time.valueOf(startTime));
                pstmt.setTime(5, Time.valueOf(endTime));
                pstmt.executeUpdate();
                System.out.println("Class schedule created successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewClassSchedules() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM ClassSchedule")) {
            while (rs.next()) {
                System.out.println("Schedule ID: " + rs.getInt("schedule_id"));
                System.out.println("Class Name: " + rs.getString("class_name"));
                System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                System.out.println("Day of Week: " + rs.getString("day_of_week"));
                System.out.println("Start Time: " + rs.getTime("start_time"));
                System.out.println("End Time: " + rs.getTime("end_time"));
                System.out.println();
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateClassInformation() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter schedule ID: ");
            int scheduleId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new class name: ");
            String className = scanner.nextLine();
            System.out.print("Enter new trainer ID: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new day of week: ");
            String dayOfWeek = scanner.nextLine();
            System.out.print("Enter new start time (HH:MM:SS): ");
            String startTime = scanner.nextLine();
            System.out.print("Enter new end time (HH:MM:SS): ");
            String endTime = scanner.nextLine();

            String sql = "UPDATE ClassSchedule SET class_name = ?, trainer_id = ?, day_of_week = ?, start_time = ?, end_time = ? WHERE schedule_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, className);
                pstmt.setInt(2, trainerId);
                pstmt.setString(3, dayOfWeek);
                pstmt.setTime(4, Time.valueOf(startTime));
                pstmt.setTime(5, Time.valueOf(endTime));
                pstmt.setInt(6, scheduleId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Class information updated successfully.");
                } else {
                    System.out.println("Schedule not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void cancelClass() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter schedule ID: ");
            int scheduleId = scanner.nextInt();

            String sql = "DELETE FROM ClassSchedule WHERE schedule_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, scheduleId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Class cancelled successfully.");
                } else {
                    System.out.println("Schedule not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
