/**
 * 
 */
/**
 * 
 */
module package_delivery_management {
	 requires java.sql;
	 exports com.packagedelivery;
}