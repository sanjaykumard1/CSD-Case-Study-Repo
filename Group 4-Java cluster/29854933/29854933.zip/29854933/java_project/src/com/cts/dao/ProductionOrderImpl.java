package com.cts.dao;

import com.cts.managment.Production_order;
import com.cts.util.DBConnection;
import java.sql.*;

public class ProductionOrderImpl implements ProductionOrderDAO{
    Connection connection = DBConnection.getConnection();
    @Override
    public void addProductionOrder(Production_order order) {
        String query = "INSERT INTO productionorder (product_id, supplier_id, order_date, due_date, status) VALUES (?, ?, ?, ?, ?)";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, order.getProduct_id());
            preparedStatement.setInt(2, order.getSupplier_id());
            preparedStatement.setDate(3, new java.sql.Date(order.getOrder_date().getTime()));// converts milliseconds to java.sql.Date obj
            preparedStatement.setDate(4, new java.sql.Date(order.getDue_date().getTime()));
            preparedStatement.setString(5, order.getStatus());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void updateProductionOrder(Production_order order) {
        String query = "UPDATE productionorder SET product_id = ?, supplier_id = ?, order_date = ?, due_date = ?, status = ? WHERE order_id = ?";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, order.getProduct_id());
            preparedStatement.setInt(2, order.getSupplier_id());
            preparedStatement.setDate(3, new java.sql.Date(order.getOrder_date().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(order.getDue_date().getTime()));
            preparedStatement.setString(5, order.getStatus());
            preparedStatement.setInt(6, order.getOrder_id());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Production_order getProductionOrderById(int orderId) {
        String query = "SELECT * FROM productionorder WHERE order_id = ?";
        Production_order order = null;
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, orderId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                order = new Production_order();
                order.setOrder_id(resultSet.getInt("order_id"));
                order.setProduct_id(resultSet.getInt("product_id"));
                order.setSupplier_id(resultSet.getInt("supplier_id"));
                order.setOrder_date(resultSet.getDate("order_date"));
                order.setDue_date(resultSet.getDate("due_date"));
                order.setStatus(resultSet.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return order;
    }

}

