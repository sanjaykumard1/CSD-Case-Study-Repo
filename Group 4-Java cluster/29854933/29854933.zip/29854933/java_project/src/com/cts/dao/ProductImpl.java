package com.cts.dao;

import com.cts.managment.Product;
import java.sql.*;
import com.cts.util.DBConnection;
public class ProductImpl implements ProductDAO{
    private Connection connection = DBConnection.getConnection();
    @Override
    public void addProduct(Product product) {
        String query = "INSERT INTO product (name, description, unit_price, quantity_in_stock) VALUES (?, ?, ?, ?)";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, product.getName());
            preparedStatement.setString(2, product.getDescription());
            preparedStatement.setDouble(3, product.getUnit_price());
            preparedStatement.setInt(4, product.getQuantity_in_stock());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public Product getProductById(int productId) {
        String query = "SELECT * FROM product WHERE product_id = ?";
        Product product = null;
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query) ;
            preparedStatement.setInt(1, productId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                product = new Product();
                product.setProduct_id(resultSet.getInt("product_id"));
                product.setName(resultSet.getString("name"));
                product.setDescription(resultSet.getString("description"));
                product.setUnit_price(resultSet.getDouble("unit_price"));
                product.setQuantity_in_stock(resultSet.getInt("quantity_in_stock"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }


    @Override
    public void updateProduct(Product product) {
        String query = "UPDATE product SET name = ?, description = ?, unit_price = ?, quantity_in_stock = ? WHERE product_id = ?";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query) ;
            preparedStatement.setString(1, product.getName());
            preparedStatement.setString(2, product.getDescription());
            preparedStatement.setDouble(3, product.getUnit_price());
            preparedStatement.setInt(4, product.getQuantity_in_stock());
            preparedStatement.setInt(5, product.getProduct_id());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteProduct(int productId) {
        String query = "DELETE FROM product WHERE product_id = ?";
        try{
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
