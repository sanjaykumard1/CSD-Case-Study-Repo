package com.cts.dao;

import com.cts.managment.Product;
import com.cts.managment.Supplier;

public interface SupplierDAO {
    /* adds new supplier*/
    public void addSupplier(Supplier supplier);
    /* returns supplier by its ID */
    public Supplier getSupplierById(int supplierId);
    /* updates supplier information */
    public void updateSupplier(Supplier supplier);
    /* deletes supplier */
    public void deleteSupplier(int supplierId);
}
