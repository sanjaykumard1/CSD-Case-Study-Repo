package com.cts.managment;

public class Product {
    private int product_id;
    private String name;
    private String description;
    private double unit_price;
    private int quantity_in_stock;

    //Constructor
    public Product(){
    }

    //setter and getter methods
    public int getProduct_id(){
        return this.product_id;
    }
    public void setProduct_id(int product_id){
        this.product_id=product_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity_in_stock() {
        return quantity_in_stock;
    }

    public void setQuantity_in_stock(int quantity_in_stock) {
        this.quantity_in_stock = quantity_in_stock;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
    }
}
