package com.cts.dao;

import com.cts.managment.Production_order;

public interface ProductionOrderDAO {
    // adds new production order
public void addProductionOrder(Production_order order);
// returns production order by its ID
public Production_order getProductionOrderById(int orderId);
// updates production order information
public void updateProductionOrder(Production_order order);

}
