package com.cts.dao;

import com.cts.managment.Supplier;
import java.sql.*;
import com.cts.util.DBConnection;
public class SupplierImpl implements SupplierDAO{
    Connection connection = DBConnection.getConnection();
    @Override
    public void addSupplier(Supplier supplier) {
        String query = "INSERT INTO Supplier (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, supplier.getName());
            preparedStatement.setString(2, supplier.getEmail());
            preparedStatement.setString(3, supplier.getPhone_number());
            preparedStatement.setString(4, supplier.getAddress());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public Supplier getSupplierById(int supplierId) {
        String query = "SELECT * FROM Supplier WHERE supplier_id = ?";
        Supplier supplier = null;
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, supplierId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                supplier = new Supplier();
                supplier.setSupplier_id(resultSet.getInt("supplier_id"));
                supplier.setName(resultSet.getString("name"));
                supplier.setEmail(resultSet.getString("email"));
                supplier.setPhone_number(resultSet.getString("phone_number"));
                supplier.setAddress(resultSet.getString("address"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return supplier;

    }

    @Override
    public void updateSupplier(Supplier supplier) {
        String query = "UPDATE Supplier SET name = ?, email = ?, phone_number = ?, address = ? WHERE supplier_id = ?";
        try {
             PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, supplier.getName());
            preparedStatement.setString(2, supplier.getEmail());
            preparedStatement.setString(3, supplier.getPhone_number());
            preparedStatement.setString(4, supplier.getAddress());
            preparedStatement.setInt(5, supplier.getSupplier_id());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteSupplier(int supplierId) {
        String query = "DELETE FROM supplier WHERE supplier_id = ?";
        try{
             PreparedStatement preparedStatement = connection.prepareStatement(query) ;
            preparedStatement.setInt(1, supplierId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
