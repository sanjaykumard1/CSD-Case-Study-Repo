package com.cts.dao;

import com.cts.managment.Product;

public interface ProductDAO {
    /* adds new product*/

    public void addProduct(Product product);
    /* returns product by its ID */
    public Product getProductById(int productId);
    /* updates product information */
    public void updateProduct(Product product);
    /* deletes product */
    public void deleteProduct(int productId);
}
