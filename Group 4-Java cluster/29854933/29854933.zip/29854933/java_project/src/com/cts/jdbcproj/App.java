package com.cts.jdbcproj;
import java.sql.Date;
import java.util.Scanner;
import com.cts.managment.*;
import com.cts.dao.*;
public class App {
    // Manufacture Management System
    private static final Scanner s=new Scanner(System.in);
    private static final ProductDAO productDao=new ProductImpl();
    private static final SupplierDAO supplierDao=new SupplierImpl();
    private static final ProductionOrderDAO orderDao=new ProductionOrderImpl();

    public static void main(String[] args){
        while(true){
            printMenu();// displays Menu
            System.out.print("Enter your choice: ");
            int choice=Integer.parseInt(s.nextLine());
            switch(choice){
                case 1:manageProducts();// managing Products
                       break;
                case 2:manageSupplier();// managing Supplier
                       break;
                case 3:manageProductionOrder();//managing ProductionOrder
                       break;
                case 4:System.out.println("Quitting the Application");
                System.exit(0);
                default:System.out.println("Invalid choice!Please try Again.");
            }

        }


    }
    private static void printMenu(){
        System.out.println("Manufacturing Management System");
        System.out.println("1. Manage Products");
        System.out.println("2. Manage Suppliers");
        System.out.println("3. Manage Production Orders");
        System.out.println("4. Quit");
    }
    private static void manageProducts(){
        System.out.println("Product Management");
        System.out.println("1. Add a new Product");
        System.out.println("2. View Product Details");
        System.out.println("3. Update Product Info.");
        System.out.println("4. Delete a Product");
        System.out.print("Enter your choice: ");
        int choice=Integer.parseInt(s.nextLine());
        switch(choice){
            case 1:addProduct();
            break;
            case 2:viewProductDetails();
            break;
            case 3:updateProduct();
            break;
            case 4:deleteProduct();
            break;
            default:System.out.println("Invalid choice!.Please try Again.");
        }
    }
    private static void addProduct(){
        //adding a new Product
        System.out.print("Enter product name: ");
        String name=s.nextLine();
        System.out.print("Enter product description: ");
        String description=s.nextLine();
        System.out.print("Enter unit price: ");
        double price=Double.parseDouble(s.nextLine());
        System.out.print("Enter quantity in stock: ");
        int quantity=Integer.parseInt(s.nextLine());
        Product product=new Product();
        product.setName(name);
        product.setDescription(description);
        product.setUnit_price(price);
        product.setQuantity_in_stock(quantity);
        productDao.addProduct(product);
        System.out.println("Product added successfully");
    }
    private static void viewProductDetails(){
        //displaying product details
        System.out.print("Enter the product ID: ");
        int productId=Integer.parseInt(s.nextLine());
        Product product=productDao.getProductById(productId);
        if(product!=null){
            System.out.println("Product ID: "+product.getProduct_id());
            System.out.println("Product Name: "+product.getName());
            System.out.println("Product Description: "+product.getDescription());
            System.out.println("Product unit_price: "+product.getUnit_price());
            System.out.println("Quantity in stock: "+product.getQuantity_in_stock());
        }
        else
            System.out.println("No such Product found.");
    }
    private static void updateProduct(){
        //Updating product information
     System.out.print("Enter productID to update: ");
     int productId=Integer.parseInt(s.nextLine());
     Product product=productDao.getProductById(productId);
     if(product!=null){
         System.out.println("Current Product Details");
         System.out.println("Name: "+product.getName());
         System.out.println("Description: "+product.getDescription());
         System.out.println("Unit Price: "+product.getUnit_price());
         System.out.println("Quantity in Stock: "+product.getQuantity_in_stock());
         System.out.print("Enter new product name(or press Enter to keep current): ");
         String name=s.nextLine();
         if(!name.isEmpty()){
             product.setName(name);
         }
         System.out.print("Enter new product description(or press Enter to keep current): ");
         String description=s.nextLine();
         if(!description.isEmpty()){
             product.setDescription(description);
         }
         System.out.print("Enter new unit price(or press Enter to keep current): ");
         String price=s.nextLine();
         if(!price.isEmpty()){
             product.setUnit_price(Double.parseDouble(price));
         }
         System.out.print("Enter new quantity in stock(or press Enter to keep current): ");
         String quantity=s.nextLine();
         if(!quantity.isEmpty()){
             product.setQuantity_in_stock(Integer.parseInt(name));
         }
         productDao.updateProduct(product);
         System.out.println("Product Updated successfully");
     }
     else{
         System.out.println("No such product found");
     }
    }
    private static void deleteProduct(){
        // deleting a product
        System.out.print("Enter productId to delete: ");
        int productId=Integer.parseInt(s.nextLine());
        Product product=productDao.getProductById(productId);
        if(product!=null){
            productDao.deleteProduct(productId);
            System.out.println("Product deleted Successfully");
        }
        else{
            System.out.println("No such Product found");
        }
    }
    private static void manageSupplier(){
        System.out.println("Supplier Management");
        System.out.println("1. Add a new Supplier");
        System.out.println("2. View Supplier Details");
        System.out.println("3. Update Supplier Info.");
        System.out.println("4. Delete a Supplier");
        System.out.print("Enter your choice: ");
        int choice=Integer.parseInt(s.nextLine());
        switch(choice){
            case 1:addSupplier();
                break;
            case 2:viewSupplierDetails();
                break;
            case 3:updateSupplier();
                break;
            case 4:deleteSupplier();
                break;
            default:System.out.println("Invalid choice!.Please try Again.");
        }
    }
    private static void addSupplier() {
        //adding a new supplier
        System.out.print("Enter supplier name: ");
        String name = s.nextLine();
        System.out.print("Enter supplier email: ");
        String email = s.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = s.nextLine();
        System.out.print("Enter Supplier Address: ");
        String address = s.nextLine();
        Supplier supplier = new Supplier();
        supplier.setName(name);
        supplier.setEmail(email);
        supplier.setPhone_number(phoneNumber);
        supplier.setAddress(address);
        supplierDao.addSupplier(supplier);
        System.out.println("Supplier added successfully!");
    }
    private static void viewSupplierDetails(){
        //displaying supplier details
        System.out.print("Enter supplier ID: ");
        int supplierId=Integer.parseInt(s.nextLine());
        Supplier supplier=supplierDao.getSupplierById(supplierId);
        if(supplier!=null){
            System.out.println("Supplier ID: "+supplier.getSupplier_id());
            System.out.println("Name: "+supplier.getName());
            System.out.println("Email: "+supplier.getEmail());
            System.out.println("Phone Number: "+supplier.getPhone_number());
            System.out.println("Address: "+supplier.getAddress());
        }
        else{
            System.out.println("No such Supplier Found");
        }
    }
    private static void updateSupplier(){
        //Updating supplier information
        System.out.print("Enter SupplierId to update: ");
        int supplierId=Integer.parseInt(s.nextLine());
        Supplier supplier=supplierDao.getSupplierById(supplierId);
        if(supplier!=null){
            System.out.println("Current Supplier Details");
            System.out.println("Name: "+supplier.getName());
            System.out.println("Email: "+supplier.getEmail());
            System.out.println("Phone number:"+supplier.getPhone_number());
            System.out.println("Address: "+supplier.getAddress());
            System.out.print("Enter new Supplier name(or press Enter to keep current): ");
            String name=s.nextLine();
            if(!name.isEmpty()){
                supplier.setName(name);
            }
            System.out.print("Enter new Supplier email(or press Enter to keep current): ");
            String email=s.nextLine();
            if(!email.isEmpty()){
                supplier.setEmail(email);
            }
            System.out.print("Enter new Supplier phone number(or press Enter to keep current): ");
            String phoneNumber=s.nextLine();
            if(!phoneNumber.isEmpty()){
                supplier.setPhone_number(phoneNumber);
            }
            System.out.print("Enter new Supplier address(or press Enter to keep current): ");
            String address=s.nextLine();
            if(!address.isEmpty()){
                supplier.setAddress(address);
            }
            supplierDao.updateSupplier(supplier);
            System.out.println("Supplier details updated successfully!");
        }
        else{
            System.out.println("No such Supplier Found");
        }
    }
    private static void deleteSupplier(){
        //deleting Supplier Details
        System.out.println("Enter supplierId to delete: ");
        int supplierId=Integer.parseInt(s.nextLine());
        Supplier supplier=supplierDao.getSupplierById(supplierId);
        if(supplier!=null){
            supplierDao.deleteSupplier(supplierId);
            System.out.println("Supplier details deleted Successfully");
        }
        else{
            System.out.println("No such Supplier found");
        }
    }
    private static void manageProductionOrder(){
        System.out.println("ProductionOrder Management");
        System.out.println("1. Add a new ProductionOrder");
        System.out.println("2. View ProductionOrder Details");
        System.out.println("3. Update ProductionOrder Info.");
        System.out.println("4. Cancel a ProductionOrder");
        System.out.print("Enter your choice: ");
        int choice=Integer.parseInt(s.nextLine());
        switch(choice){
            case 1:createProductionOrder();
                break;
            case 2:viewProductionOrderDetails();
                break;
            case 3:updateProductionOrder();
                break;
            case 4:cancelProductionOrder();
                break;
            default:System.out.println("Invalid choice!.Please try Again.");
        }
    }
    private static void createProductionOrder(){
        //creating new productionOrder
        System.out.print("Enter product ID: ");
        int productId=Integer.parseInt(s.nextLine());
        System.out.print("Enter supplier ID: ");
        int supplierId=Integer.parseInt(s.nextLine());
        System.out.print("Enter order date (YYYY-MM-DD): ");
        String orderDate=s.nextLine();
        System.out.print("Enter due date (YYYY-MM-DD): ");
        String dueDate=s.nextLine();
        System.out.print("Enter status (open/closed): ");
        String status=s.nextLine();

        Production_order order=new Production_order();
        order.setProduct_id(productId);
        order.setSupplier_id(supplierId);
        order.setOrder_date(Date.valueOf(orderDate));
        order.setDue_date(Date.valueOf(dueDate));
        order.setStatus(status);
        orderDao.addProductionOrder(order);
        System.out.println("ProductionOrder created successfully");
    }
    private static void viewProductionOrderDetails(){
        //displaying productionOrder details
        System.out.print("Enter the production_order ID: ");
        int production_orderId=Integer.parseInt(s.nextLine());
        Production_order order=orderDao.getProductionOrderById(production_orderId);
        if(order!=null){
            System.out.println("Order ID: "+order.getOrder_id());
            System.out.println("Product ID: "+order.getProduct_id());
            System.out.println("Supplier ID: "+order.getSupplier_id());
            System.out.println("Order Date: "+order.getOrder_date());
            System.out.println("Due Date: "+order.getDue_date());
            System.out.println("Status: "+order.getStatus());
        }
        else
            System.out.println("No such ProductionOrder found.");
    }
    private static void updateProductionOrder(){
        //Updating productionOrder details with new details
        System.out.print("Enter productionID to update: ");
        int productionId=Integer.parseInt(s.nextLine());
        Production_order order=orderDao.getProductionOrderById(productionId);
        if(order!=null){
            System.out.println("Current ProductionOrder Details");
            System.out.println("Product ID: "+ order.getProduct_id());
            System.out.println("Supplier ID: "+ order.getSupplier_id());
            System.out.println("Order Date: "+order.getOrder_date());
            System.out.println("Due date:  "+order.getDue_date());
            System.out.println("Status:  "+order.getStatus());
            System.out.print("Enter new product ID(or press Enter to keep current): ");
            String productId=s.nextLine();
            if(!productId.isEmpty()){
                order.setProduct_id(Integer.parseInt(productId));
            }
            System.out.print("Enter new supplier ID(or press Enter to keep current): ");
            String supplierId=s.nextLine();
            if(!supplierId.isEmpty()){
                order.setSupplier_id(Integer.parseInt(supplierId));
            }
            System.out.print("Enter new order date(or press Enter to keep current): ");
            String order_date=s.nextLine();
            if(!order_date.isEmpty()){
                order.setOrder_date(Date.valueOf(order_date));
            }
            System.out.print("Enter new due date(or press Enter to keep current): ");
            String due_date=s.nextLine();
            if(!due_date.isEmpty()){
                order.setDue_date(Date.valueOf(due_date));
            }
            orderDao.updateProductionOrder(order);
            System.out.println("Production Order Updated successfully");
        }
        else{
            System.out.println("No such production order found");
        }
    }
    private static void cancelProductionOrder(){
        // canceling or completing a Production Order
        System.out.println("Enter production orderId to delete: ");
        int orderId=Integer.parseInt(s.nextLine());
        Production_order order=orderDao.getProductionOrderById(orderId);
        if(order!=null){
            //  Updating productionOrder status as closed if it is open
            if(order.getStatus().equals("open")){
            order.setStatus("closed");
            orderDao.updateProductionOrder(order);

            //Updating product's quantity_in_stock
                Product product=productDao.getProductById(order.getProduct_id());
                if(product!=null){
                    //Assuming quantity of product in productionOrder to be 1
                    product.setQuantity_in_stock(product.getQuantity_in_stock()+1);
                    productDao.updateProduct(product);
                }
            System.out.println("ProductionOrder canceled and stock updated Successfully");
        }
            else{
                System.out.println("Production order is already closed");
            }
        }
        else{
            System.out.println("No such ProductionOrder found");
        }
    }






}
