package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBConnection {
    private static Connection connection = null;
    private static String url = "jdbc:mysql://127.0.0.1:3306/management_system";
    private static String username = "root";
    private static String password = "harshitha";
    public static Connection getConnection(){
        try{
            connection= DriverManager.getConnection(url,username,password);
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return connection;
    }
}
