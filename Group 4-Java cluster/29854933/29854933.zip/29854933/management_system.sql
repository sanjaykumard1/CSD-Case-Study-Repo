CREATE TABLE `management_system`.`product` (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(65),
    description longtext,
    unit_price DECIMAL(10, 2),
    quantity_in_stock INT
);

CREATE TABLE `management_system`.`supplier` (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(65),
    email VARCHAR(100),
    phone_number VARCHAR(15),
    address VARCHAR(100)
);
CREATE TABLE `management_system`.`productionorder` (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    supplier_id INT,
    order_date DATE,
    due_date DATE,
    status VARCHAR(10),
    FOREIGN KEY (product_id) REFERENCES product(product_id),
    FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id)
);