
# Manufacturing Management System
 

Develop a menu-based console application to assess your proficiency in Core Java, MySQL, and JDBC. The application will simulate a manufacturing management system, allowing users to manage products, suppliers, and production orders

## Functionalities
1. **Product Management:**
   - Add a new product
   - View product details
   - Update product information
   - Delete a product

2. **Supplier Management:**
   - Add a new supplier
   - View supplier details
   - Update supplier information
   - Delete a supplier

3. **Production Order Management:**
   - Create a new production order
   - View production order details
   - Update production order information
   - Cancel a production order

## Database Schema
### Product Table
- `product_id` (Primary Key)
- `name`
- `description`
- `unit_price`
- `quantity_in_stock`

### Supplier Table
- `supplier_id` (Primary Key)
- `name`
- `email`
- `phone_number`
- `address`

### ProductionOrder Table
- `order_id` (Primary Key)
- `product_id` (Foreign Key references Product Table)
- `supplier_id` (Foreign Key references Supplier Table)
- `order_date`
- `due_date`
- `quantity`
- `status` (open/closed)

## Setup Instructions

### Prerequisites
- Java Development Kit (JDK) installed
- MySQL Server installed
- MySQL Workbench installed
- A MySQL user with the necessary privileges to create databases and tables

### Database Setup

1. Open MySQL Workbench and connect to your MySQL server.
2. Create a new database:
   ```sql
   CREATE DATABASE management_system;
   ```
3. Use the newly created database
4. Create the required tables.
    ```sql
    CREATE TABLE product (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(65),
    description longtext,
    unit_price DECIMAL(10, 2),
    quantity_in_stock INT);

    CREATE TABLE supplier (
    supplier_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(65),
    email VARCHAR(100),
    phone_number VARCHAR(15),
    address VARCHAR(100));

    CREATE TABLE productionorder (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    supplier_id INT,
    order_date DATE,
    due_date DATE,
    status VARCHAR(10),
    FOREIGN KEY (product_id) REFERENCES product(product_id),
    FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id));
    ```
### Usage Instructions
1. **Start the Application:**

Run the main class to start the console application. The main menu will be displayed with options to manage products, suppliers, and production orders.

2. **Navigate the Menu:**
Use the keyboard to select options from the menu. Enter the corresponding number for the action you want to perform.

3. **Follow Prompts:**
Follow the prompts to add, view, update, or delete products, suppliers, and production orders. Input the required information as instructed.

### Error Handling
The application includes basic error handling to manage:
- Invalid inputs
- SQL exceptions
- General exceptions

Ensure to provide valid data formats as prompted by the application to avoid errors.

## Source Code Structure
- **App.java**: Contains the main method and the menu logic.
- **Product.java**: Contains the Product class.
- **Supplier.java**: Contains the Supplier class.
- **ProductionOrder.java**: Contains the ProductionOrder class.
- **ProductDAO.java**: Contains abstract methods to perform CRUD operations on the Product table.
- **SupplierDAO.java**: Contains abstract methods to perform CRUD operations on the Supplier table.
- **ProductionOrderDAO.java**: Contains abstract methods to perform CRUD operations on the ProductionOrder table.
- **ProductImpl**: Contains implementation classes of ProductDAO.
- **SupplierImpl**: Contains implementation classes of SupplierDAO .
- **ProductionOrderImpl**: Contains implementation classes of ProductionOrderDAO.
- **DBConnection.java**: Contains the database connection logic.




    


