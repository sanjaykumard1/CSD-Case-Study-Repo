package com.company.customerservice.main;

import com.company.customerservice.dao.CustomerDAO;
import com.company.customerservice.model.Customer;
import com.company.customerservice.service.CustomerService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class MainMenu {
    private static Connection connection;
    private static CustomerService customerService;

    public static void main(String[] args) {
        try {
            // Set up the database connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/CustomerService", "root", "vishnu2");
            customerService = new CustomerService(new CustomerDAO(connection));

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("1. Add Customer");
                System.out.println("2. View Customer");
                System.out.println("3. Update Customer");
                System.out.println("4. Delete Customer");
                System.out.println("5. List All Customers");
                System.out.println("6. Exit");
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        addCustomer(scanner);
                        break;
                    case 2:
                        viewCustomer(scanner);
                        break;
                    case 3:
                        updateCustomer(scanner);
                        break;
                    case 4:
                        deleteCustomer(scanner);
                        break;
                    case 5:
                        listAllCustomers();
                        break;
                    case 6:
                        return;
                    default:
                        System.out.println("Invalid choice.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addCustomer(Scanner scanner) {
        System.out.println("Enter customer name:");
        String name = scanner.next();
        System.out.println("Enter email:");
        String email = scanner.next();
        System.out.println("Enter phone:");
        String phone = scanner.next();
        Customer customer = new Customer();
        customer.setCustomerName(name);
        customer.setEmail(email);
        customer.setPhone(phone);
        try {
            customerService.addCustomer(customer);
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewCustomer(Scanner scanner) {
        System.out.println("Enter customer ID:");
        int id = scanner.nextInt();
        try {
            Customer customer = customerService.getCustomer(id);
            if (customer != null) {
                System.out.println("Customer ID: " + customer.getCustomerId());
                System.out.println("Name: " + customer.getCustomerName());
                System.out.println("Email: " + customer.getEmail());
                System.out.println("Phone: " + customer.getPhone());
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCustomer(Scanner scanner) {
        System.out.println("Enter customer ID:");
        int id = scanner.nextInt();
        try {
            Customer customer = customerService.getCustomer(id);
            if (customer != null) {
                System.out.println("Enter new name:");
                customer.setCustomerName(scanner.next());
                System.out.println("Enter new email:");
                customer.setEmail(scanner.next());
                System.out.println("Enter new phone:");
                customer.setPhone(scanner.next());
                customerService.updateCustomer(customer);
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteCustomer(Scanner scanner) {
        System.out.println("Enter customer ID:");
        int id = scanner.nextInt();
        try {
            customerService.deleteCustomer(id);
            System.out.println("Customer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void listAllCustomers() {
        try {
            customerService.getAllCustomers().forEach(customer -> {
                System.out.println("Customer ID: " + customer.getCustomerId());
                System.out.println("Name: " + customer.getCustomerName());
                System.out.println("Email: " + customer.getEmail());
                System.out.println("Phone: " + customer.getPhone());
                System.out.println("-------------------------------");
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
