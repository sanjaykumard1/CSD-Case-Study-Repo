package com.company.customerservice.dao;

import com.company.customerservice.model.Assignment;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDAO {
    private Connection connection;

    public AssignmentDAO(Connection connection) {
        this.connection = connection;
    }

    public void createAssignment(Assignment assignment) throws SQLException {
        String sql = "INSERT INTO Assignment (ticket_id, representative_id, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, assignment.getTicketId());
            stmt.setInt(2, assignment.getRepresentativeId());
            stmt.setString(3, assignment.getStatus());
            stmt.executeUpdate();
        }
    }

    public Assignment getAssignment(int assignmentId) throws SQLException {
        String sql = "SELECT * FROM Assignment WHERE assignment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Assignment assignment = new Assignment();
                assignment.setAssignmentId(rs.getInt("assignment_id"));
                assignment.setTicketId(rs.getInt("ticket_id"));
                assignment.setRepresentativeId(rs.getInt("representative_id"));
                assignment.setAssignmentDate(rs.getTimestamp("assignment_date"));
                assignment.setStatus(rs.getString("status"));
                return assignment;
            }
        }
        return null;
    }

    public void updateAssignment(Assignment assignment) throws SQLException {
        String sql = "UPDATE Assignment SET ticket_id = ?, representative_id = ?, status = ? WHERE assignment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, assignment.getTicketId());
            stmt.setInt(2, assignment.getRepresentativeId());
            stmt.setString(3, assignment.getStatus());
            stmt.setInt(4, assignment.getAssignmentId());
            stmt.executeUpdate();
        }
    }

    public void deleteAssignment(int assignmentId) throws SQLException {
        String sql = "DELETE FROM Assignment WHERE assignment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, assignmentId);
            stmt.executeUpdate();
        }
    }

    public List<Assignment> getAllAssignments() throws SQLException {
        String sql = "SELECT * FROM Assignment";
        List<Assignment> assignments = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Assignment assignment = new Assignment();
                assignment.setAssignmentId(rs.getInt("assignment_id"));
                assignment.setTicketId(rs.getInt("ticket_id"));
                assignment.setRepresentativeId(rs.getInt("representative_id"));
                assignment.setAssignmentDate(rs.getTimestamp("assignment_date"));
                assignment.setStatus(rs.getString("status"));
                assignments.add(assignment);
            }
        }
        return assignments;
    }
}
