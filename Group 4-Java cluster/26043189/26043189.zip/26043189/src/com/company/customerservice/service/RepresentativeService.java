package com.company.customerservice.service;

import com.company.customerservice.dao.RepresentativeDAO;
import com.company.customerservice.model.Representative;

import java.sql.SQLException;
import java.util.List;

public class RepresentativeService {
    private RepresentativeDAO representativeDAO;

    public RepresentativeService(RepresentativeDAO representativeDAO) {
        this.representativeDAO = representativeDAO;
    }

    public void addRepresentative(Representative representative) throws SQLException {
        representativeDAO.createRepresentative(representative);
    }

    public Representative getRepresentative(int representativeId) throws SQLException {
        return representativeDAO.getRepresentative(representativeId);
    }

    public void updateRepresentative(Representative representative) throws SQLException {
        representativeDAO.updateRepresentative(representative);
    }

    public void deleteRepresentative(int representativeId) throws SQLException {
        representativeDAO.deleteRepresentative(representativeId);
    }

    public List<Representative> getAllRepresentatives() throws SQLException {
        return representativeDAO.getAllRepresentatives();
    }
}
