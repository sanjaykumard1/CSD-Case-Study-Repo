package com.company.customerservice.service;

import com.company.customerservice.dao.TicketDAO;
import com.company.customerservice.model.Ticket;

import java.sql.SQLException;
import java.util.List;

public class TicketService {
    private TicketDAO ticketDAO;

    public TicketService(TicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }

    public void addTicket(Ticket ticket) throws SQLException {
        ticketDAO.createTicket(ticket);
    }

    public Ticket getTicket(int ticketId) throws SQLException {
        return ticketDAO.getTicket(ticketId);
    }

    public void updateTicket(Ticket ticket) throws SQLException {
        ticketDAO.updateTicket(ticket);
    }

    public void deleteTicket(int ticketId) throws SQLException {
        ticketDAO.deleteTicket(ticketId);
    }

    public List<Ticket> getAllTickets() throws SQLException {
        return ticketDAO.getAllTickets();
    }
}
