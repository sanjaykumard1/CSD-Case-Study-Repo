package com.company.customerservice.service;

import com.company.customerservice.dao.AssignmentDAO;
import com.company.customerservice.model.Assignment;

import java.sql.SQLException;
import java.util.List;

public class AssignmentService {
    private AssignmentDAO assignmentDAO;

    public AssignmentService(AssignmentDAO assignmentDAO) {
        this.assignmentDAO = assignmentDAO;
    }

    public void addAssignment(Assignment assignment) throws SQLException {
        assignmentDAO.createAssignment(assignment);
    }

    public Assignment getAssignment(int assignmentId) throws SQLException {
        return assignmentDAO.getAssignment(assignmentId);
    }

    public void updateAssignment(Assignment assignment) throws SQLException {
        assignmentDAO.updateAssignment(assignment);
    }

    public void deleteAssignment(int assignmentId) throws SQLException {
        assignmentDAO.deleteAssignment(assignmentId);
    }

    public List<Assignment> getAllAssignments() throws SQLException {
        return assignmentDAO.getAllAssignments();
    }
}
