package com.company.customerservice.dao;

import com.company.customerservice.model.Resolution;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResolutionDAO {
    private Connection connection;

    public ResolutionDAO(Connection connection) {
        this.connection = connection;
    }

    public void createResolution(Resolution resolution) throws SQLException {
        String sql = "INSERT INTO Resolution (ticket_id, resolution_details, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, resolution.getTicketId());
            stmt.setString(2, resolution.getResolutionDetails());
            stmt.setString(3, resolution.getStatus());
            stmt.executeUpdate();
        }
    }

    public Resolution getResolution(int resolutionId) throws SQLException {
        String sql = "SELECT * FROM Resolution WHERE resolution_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, resolutionId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Resolution resolution = new Resolution();
                resolution.setResolutionId(rs.getInt("resolution_id"));
                resolution.setTicketId(rs.getInt("ticket_id"));
                resolution.setResolutionDate(rs.getTimestamp("resolution_date"));
                resolution.setResolutionDetails(rs.getString("resolution_details"));
                resolution.setStatus(rs.getString("status"));
                return resolution;
            }
        }
        return null;
    }

    public void updateResolution(Resolution resolution) throws SQLException {
        String sql = "UPDATE Resolution SET ticket_id = ?, resolution_details = ?, status = ? WHERE resolution_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, resolution.getTicketId());
            stmt.setString(2, resolution.getResolutionDetails());
            stmt.setString(3, resolution.getStatus());
            stmt.setInt(4, resolution.getResolutionId());
            stmt.executeUpdate();
        }
    }

    public void deleteResolution(int resolutionId) throws SQLException {
        String sql = "DELETE FROM Resolution WHERE resolution_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, resolutionId);
            stmt.executeUpdate();
        }
    }

    public List<Resolution> getAllResolutions() throws SQLException {
        String sql = "SELECT * FROM Resolution";
        List<Resolution> resolutions = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Resolution resolution = new Resolution();
                resolution.setResolutionId(rs.getInt("resolution_id"));
                resolution.setTicketId(rs.getInt("ticket_id"));
                resolution.setResolutionDate(rs.getTimestamp("resolution_date"));
                resolution.setResolutionDetails(rs.getString("resolution_details"));
                resolution.setStatus(rs.getString("status"));
                resolutions.add(resolution);
            }
        }
        return resolutions;
    }
}
