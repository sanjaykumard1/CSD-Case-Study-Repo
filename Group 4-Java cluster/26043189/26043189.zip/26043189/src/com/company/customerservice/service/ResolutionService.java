package com.company.customerservice.service;

import com.company.customerservice.dao.ResolutionDAO;
import com.company.customerservice.model.Resolution;

import java.sql.SQLException;
import java.util.List;

public class ResolutionService {
    private ResolutionDAO resolutionDAO;

    public ResolutionService(ResolutionDAO resolutionDAO) {
        this.resolutionDAO = resolutionDAO;
    }

    public void addResolution(Resolution resolution) throws SQLException {
        resolutionDAO.createResolution(resolution);
    }

    public Resolution getResolution(int resolutionId) throws SQLException {
        return resolutionDAO.getResolution(resolutionId);
    }

    public void updateResolution(Resolution resolution) throws SQLException {
        resolutionDAO.updateResolution(resolution);
    }

    public void deleteResolution(int resolutionId) throws SQLException {
        resolutionDAO.deleteResolution(resolutionId);
    }

    public List<Resolution> getAllResolutions() throws SQLException {
        return resolutionDAO.getAllResolutions();
    }
}
