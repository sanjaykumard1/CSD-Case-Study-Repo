package com.company.customerservice.dao;

import com.company.customerservice.model.Representative;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepresentativeDAO {
    private Connection connection;

    public RepresentativeDAO(Connection connection) {
        this.connection = connection;
    }

    public void createRepresentative(Representative representative) throws SQLException {
        String sql = "INSERT INTO Representative (rep_name, email, phone) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, representative.getRepName());
            stmt.setString(2, representative.getEmail());
            stmt.setString(3, representative.getPhone());
            stmt.executeUpdate();
        }
    }

    public Representative getRepresentative(int representativeId) throws SQLException {
        String sql = "SELECT * FROM Representative WHERE representative_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, representativeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Representative representative = new Representative();
                representative.setRepresentativeId(rs.getInt("representative_id"));
                representative.setRepName(rs.getString("rep_name"));
                representative.setEmail(rs.getString("email"));
                representative.setPhone(rs.getString("phone"));
                return representative;
            }
        }
        return null;
    }

    public void updateRepresentative(Representative representative) throws SQLException {
        String sql = "UPDATE Representative SET rep_name = ?, email = ?, phone = ? WHERE representative_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, representative.getRepName());
            stmt.setString(2, representative.getEmail());
            stmt.setString(3, representative.getPhone());
            stmt.setInt(4, representative.getRepresentativeId());
            stmt.executeUpdate();
        }
    }

    public void deleteRepresentative(int representativeId) throws SQLException {
        String sql = "DELETE FROM Representative WHERE representative_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, representativeId);
            stmt.executeUpdate();
        }
    }

    public List<Representative> getAllRepresentatives() throws SQLException {
        String sql = "SELECT * FROM Representative";
        List<Representative> representatives = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Representative representative = new Representative();
                representative.setRepresentativeId(rs.getInt("representative_id"));
                representative.setRepName(rs.getString("rep_name"));
                representative.setEmail(rs.getString("email"));
                representative.setPhone(rs.getString("phone"));
                representatives.add(representative);
            }
        }
        return representatives;
    }
}
