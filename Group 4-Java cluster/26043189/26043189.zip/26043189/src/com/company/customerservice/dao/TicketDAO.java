package com.company.customerservice.dao;

import com.company.customerservice.model.Ticket;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TicketDAO {
    private Connection connection;

    public TicketDAO(Connection connection) {
        this.connection = connection;
    }

    public void createTicket(Ticket ticket) throws SQLException {
        String sql = "INSERT INTO Ticket (customer_id, issue_description, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ticket.getCustomerId());
            stmt.setString(2, ticket.getIssueDescription());
            stmt.setString(3, ticket.getStatus());
            stmt.executeUpdate();
        }
    }

    public Ticket getTicket(int ticketId) throws SQLException {
        String sql = "SELECT * FROM Ticket WHERE ticket_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ticketId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Ticket ticket = new Ticket();
                ticket.setTicketId(rs.getInt("ticket_id"));
                ticket.setCustomerId(rs.getInt("customer_id"));
                ticket.setCreationDate(rs.getTimestamp("creation_date"));
                ticket.setIssueDescription(rs.getString("issue_description"));
                ticket.setStatus(rs.getString("status"));
                return ticket;
            }
        }
        return null;
    }

    public void updateTicket(Ticket ticket) throws SQLException {
        String sql = "UPDATE Ticket SET customer_id = ?, issue_description = ?, status = ? WHERE ticket_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ticket.getCustomerId());
            stmt.setString(2, ticket.getIssueDescription());
            stmt.setString(3, ticket.getStatus());
            stmt.setInt(4, ticket.getTicketId());
            stmt.executeUpdate();
        }
    }

    public void deleteTicket(int ticketId) throws SQLException {
        String sql = "DELETE FROM Ticket WHERE ticket_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, ticketId);
            stmt.executeUpdate();
        }
    }

    public List<Ticket> getAllTickets() throws SQLException {
        String sql = "SELECT * FROM Ticket";
        List<Ticket> tickets = new ArrayList<>();
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Ticket ticket = new Ticket();
                ticket.setTicketId(rs.getInt("ticket_id"));
                ticket.setCustomerId(rs.getInt("customer_id"));
                ticket.setCreationDate(rs.getTimestamp("creation_date"));
                ticket.setIssueDescription(rs.getString("issue_description"));
                ticket.setStatus(rs.getString("status"));
                tickets.add(ticket);
            }
        }
        return tickets;
    }
}
