module casestudy48 {
    // Export packages to make them available to other modules
    exports com.company.customerservice.dao;
    exports com.company.customerservice.model;
    exports com.company.customerservice.service;
    exports com.company.customerservice.main;

    // Require necessary modules
    requires java.sql;
}
