package connection;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.Scanner;

	public class AccountManager {
	    private Connection connection;

	    public AccountManager() {
	        try {
	            connection = DBConnection.getConnection();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void addAccount() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter customer Name: ");
	        String customer_name = scanner.nextLine();
	        System.out.print("Enter customer Phone: ");
	        long phone = scanner.nextLong();
	        System.out.print("Enter Address: ");
	        String address = scanner.nextLine();
	        System.out.print("Enter account type (Savings/Checking): ");
	        String accountType = scanner.next();
	        System.out.print("Enter intial balance ");
	        double user_balance = scanner.nextDouble();
	    
	        String sql = "INSERT INTO bank_details.customer_details (customer_name, phone, address, account_type, balance) VALUES (?, ?,  ?, ?, ?)";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setString(1, customer_name);
	            stmt.setLong(2, phone);
	            stmt.setString(3, address);
	            stmt.setString(4, accountType);
	            stmt.setDouble(5, user_balance);
	            stmt.executeUpdate();
	            System.out.println("Account added successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void viewAccountDetails(long user_phone) {
	        String sql = "SELECT * FROM bank_details.customer_details WHERE phone = ?";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setLong(1, user_phone);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                System.out.println("Customer id " + rs.getInt("customer_id"));
	                System.out.println("Customer Name: " + rs.getString("customer_name"));
	                System.out.println("phone: " + rs.getLong("phone"));
	                System.out.println("balance: " + rs.getDouble("balance"));
	            } else {
	                System.out.println("Account not found.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    

	    
	}

