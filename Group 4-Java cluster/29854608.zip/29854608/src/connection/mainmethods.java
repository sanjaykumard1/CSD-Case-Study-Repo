package connection;


	import java.util.Scanner;

	public class mainmethods {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        AccountManager accountManager = new AccountManager();
	        TransactionManager transactionManager = new TransactionManager();
	        boolean start = true;
	        while (start) {
	            System.out.println("1. Add Account");
	            System.out.println("2. View Account Details");
	            System.out.println("3. Deposit");
	            System.out.println("4. Withdraw");
	            System.out.println("5. View Transaction History");
	            System.out.println("6. Exit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();

	            switch (choice) {
	                case 1:
	                    accountManager.addAccount();
	                    break;
	                case 2:
	                    System.out.print("Enter your phone number: ");
	                    long user_phone = scanner.nextLong();
	                    accountManager.viewAccountDetails(user_phone);
	                    break;
	                case 3:
	                    transactionManager.deposit();
	                    break;
	                case 4:
	                    transactionManager.withdraw();
	                    break;
	                case 5:
	                	System.out.print("Enter your phone number: ");
	                    long phone = scanner.nextLong();
	                    transactionManager.viewTransactionHistory(phone);
	                    break;
	                case 6:
	                    start = false;
	                    System.out.println("..............You are exited successfully............");
	               

	            }}}}
