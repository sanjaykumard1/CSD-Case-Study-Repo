package connection;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
	import java.util.Scanner;

	public class TransactionManager {
	    private Connection connection;

	    public TransactionManager() {
	        try {
	            connection = DBConnection.getConnection();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void deposit() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter phone: ");
	        long phone = scanner.nextLong();
	        System.out.print("Enter amount to deposit: ");
	        double amount = scanner.nextDouble();

	        String sql = "UPDATE bank_details.customer_details SET balance = balance + ? WHERE phone = ?";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setDouble(1, amount);
	            stmt.setLong(2, phone);
	            stmt.executeUpdate();
	            logTransaction(phone, amount);
	            System.out.println("Deposit successful.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void withdraw() {
	    	 Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter phone: ");
		        long phone = scanner.nextLong();
		        System.out.print("Enter amount to withdraw: ");
		        double amount = scanner.nextDouble();

		        String sql = "UPDATE bank_details.customer_details SET balance = balance - ? WHERE phone = ?";
		        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		            stmt.setDouble(1, amount);
		            stmt.setLong(2, phone);
		            stmt.executeUpdate();
		            logTransaction(phone, amount);
		            System.out.println("withdraw successful.");
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
	    }

	   

	    public void viewTransactionHistory(long phone) {
	    	String sql = "SELECT * FROM bank_details.transaction_history WHERE user_phone = ?";
	    	 try (PreparedStatement stmt = connection.prepareStatement(sql)) {
		            stmt.setLong(1, phone);
		            ResultSet rs = stmt.executeQuery();
		            if (rs.next()) {
		                System.out.println("Transaction amount: " + rs.getInt("amount"));
		                System.out.println("Transaction date: " + rs.getTimestamp("transaction_date"));
		            }
		            
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
	    }

	    private void logTransaction(long phone, double amount) {
	        String sql = "INSERT INTO bank_details.transaction_history (amount, user_phone) VALUES (?, ?)";
	        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
	            stmt.setDouble(1, amount);
	            stmt.setLong(2, phone);
	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}


