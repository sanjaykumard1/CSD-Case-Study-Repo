# Basic Banking System
 This project is used to connect the java and my sql to perform the operation of the Banking process like creating account,withdrawl,deposit etc..

#Requirements
1.Install the eclipse ide for java.
2.next install the MySQL workbench to perform the operation of MySQL
3.Finally install the jdbc to connect the java and my sql.


# project setup
 There is only one  file in this project that contains multiple classes for different operaions using java and mysql

# Running the project 
  Just click on run button to execute the project and based on the queries it will provide the output.
 
  
