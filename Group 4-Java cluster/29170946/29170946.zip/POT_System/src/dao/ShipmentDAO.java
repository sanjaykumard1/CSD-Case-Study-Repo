package dao;

import db.DBConnection;
import models.Shipment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShipmentDAO {

    public void addShipment(Shipment shipment) throws SQLException {
        String query = "INSERT INTO Shipments (order_id, shipment_date, estimated_delivery_date, actual_delivery_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, shipment.getOrderId());
            stmt.setDate(2, shipment.getShipmentDate());
            stmt.setDate(3, shipment.getEstimatedDeliveryDate());
            stmt.setDate(4, shipment.getActualDeliveryDate());
            stmt.setString(5, shipment.getStatus());
            stmt.executeUpdate();
        }
    }

    public Shipment getShipment(int shipmentId) throws SQLException {
        String query = "SELECT * FROM Shipments WHERE shipment_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, shipmentId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Shipment shipment = new Shipment();
                    shipment.setShipmentId(rs.getInt("shipment_id"));
                    shipment.setOrderId(rs.getInt("order_id"));
                    shipment.setShipmentDate(rs.getDate("shipment_date"));
                    shipment.setEstimatedDeliveryDate(rs.getDate("estimated_delivery_date"));
                    shipment.setActualDeliveryDate(rs.getDate("actual_delivery_date"));
                    shipment.setStatus(rs.getString("status"));
                    return shipment;
                }
            }
        }
        return null;
    }

    public List<Shipment> getAllShipments() throws SQLException {
        List<Shipment> shipments = new ArrayList<>();
        String query = "SELECT * FROM Shipments";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Shipment shipment = new Shipment();
                shipment.setShipmentId(rs.getInt("shipment_id"));
                shipment.setOrderId(rs.getInt("order_id"));
                shipment.setShipmentDate(rs.getDate("shipment_date"));
                shipment.setEstimatedDeliveryDate(rs.getDate("estimated_delivery_date"));
                shipment.setActualDeliveryDate(rs.getDate("actual_delivery_date"));
                shipment.setStatus(rs.getString("status"));
                shipments.add(shipment);
            }
        }
        return shipments;
    }

    public void updateShipment(Shipment shipment) throws SQLException {
        String query = "UPDATE Shipments SET order_id = ?, shipment_date = ?, estimated_delivery_date = ?, actual_delivery_date = ?, status = ? WHERE shipment_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, shipment.getOrderId());
            stmt.setDate(2, shipment.getShipmentDate());
            stmt.setDate(3, shipment.getEstimatedDeliveryDate());
            stmt.setDate(4, shipment.getActualDeliveryDate());
            stmt.setString(5, shipment.getStatus());
            stmt.setInt(6, shipment.getShipmentId());
            stmt.executeUpdate();
        }
    }

    public void deleteShipment(int shipmentId) throws SQLException {
        String query = "DELETE FROM Shipments WHERE shipment_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, shipmentId);
            stmt.executeUpdate();
        }
    }
}
