package src;

import models.Order;
import models.Shipment;
import services.OrderService;
import services.ShipmentService;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final OrderService orderService = new OrderService();
    private static final ShipmentService shipmentService = new ShipmentService();

    public static void main(String[] args) {
        displayMenu();
    }

    private static void displayMenu() {
        int choice;
        do {
            System.out.println("\n===== Menu =====");
            System.out.println("1. Place a new order");
            System.out.println("2. View order details");
            System.out.println("3. Update order information");
            System.out.println("4. Cancel an order");
            System.out.println("5. Track shipment status");
            System.out.println("6. View shipment details");
            System.out.println("7. Update shipment status");
            System.out.println("8. Cancel shipment");
            System.out.println("9. Update order status");
            System.out.println("10. View order status history");
            System.out.println("11. Cancel order status update");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (choice) {
                case 1:
                    placeNewOrder();
                    break;
                case 2:
                    viewOrderDetails();
                    break;
                case 3:
                    updateOrder();
                    break;
                case 4:
                    cancelOrder();
                    break;
                case 5:
                    trackShipmentStatus();
                    break;
                case 6:
                    viewShipmentDetails();
                    break;
                case 7:
                    updateShipmentStatus();
                    break;
                case 8:
                    cancelShipment();
                    break;
                case 9:
                    updateOrderStatus();
                    break;
                case 10:
                    viewOrderStatusHistory();
                    break;
                case 11:
                    cancelOrderStatusUpdate();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 0);
    }

    private static void placeNewOrder() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        Order order = new Order();
        try {
            orderService.placeOrder(order);
            System.out.println("Order placed successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to place order: " + e.getMessage());
        }
    }

    private static void viewOrderDetails() {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            Order order = orderService.viewOrder(orderId);
            if (order != null) {
                System.out.println("Order Details:");
                System.out.println("Order ID: " + order.getOrderId());
                System.out.println("Customer ID: " + order.getCustomerId());
                System.out.println("Product ID: " + order.getProductId());
                System.out.println("Order Date: " + order.getOrderDate());
                System.out.println("Status: " + order.getStatus());
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            System.out.println("Failed to view order details: " + e.getMessage());
        }
    }

    private static void updateOrder() {
        System.out.print("Enter order ID to update: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter new customer ID: ");
        int newCustomerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter new product ID: ");
        int newProductId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        Order updatedOrder = new Order();
        try {
            orderService.updateOrder(updatedOrder);
            System.out.println("Order updated successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to update order: " + e.getMessage());
        }
    }

    private static void cancelOrder() {
        System.out.print("Enter order ID to cancel: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            orderService.cancelOrder(orderId);
            System.out.println("Order canceled successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to cancel order: " + e.getMessage());
        }
    }

    private static void trackShipmentStatus() {
        System.out.print("Enter order ID to track shipment: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            shipmentService.trackShipment(orderId);
        } catch (SQLException e) {
            System.out.println("Failed to track shipment: " + e.getMessage());
        }
    }

    private static void viewShipmentDetails() {
        System.out.print("Enter shipment ID: ");
        int shipmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            Shipment shipment = shipmentService.viewShipment(shipmentId);
            if (shipment != null) {
                System.out.println("Shipment Details:");
                System.out.println("Shipment ID: " + shipment.getShipmentId());
                System.out.println("Order ID: " + shipment.getOrderId());
                System.out.println("Shipment Date: " + shipment.getShipmentDate());
                System.out.println("Estimated Delivery Date: " + shipment.getEstimatedDeliveryDate());
                System.out.println("Actual Delivery Date: " + shipment.getActualDeliveryDate());
                System.out.println("Status: " + shipment.getStatus());
            } else {
                System.out.println("Shipment not found.");
            }
        } catch (SQLException e) {
            System.out.println("Failed to view shipment details: " + e.getMessage());
        }
    }

    private static void updateShipmentStatus() {
        System.out.print("Enter shipment ID to update: ");
        int shipmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter new status (e.g., in transit, delivered): ");
        String newStatus = scanner.nextLine();

        try {
            shipmentService.updateShipmentStatus(shipmentId, newStatus);
            System.out.println("Shipment status updated successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to update shipment status: " + e.getMessage());
        }
    }

    private static void cancelShipment() {
        System.out.print("Enter shipment ID to cancel: ");
        int shipmentId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            shipmentService.cancelShipment(shipmentId);
            System.out.println("Shipment canceled successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to cancel shipment: " + e.getMessage());
        }
    }

    private static void updateOrderStatus() {
        System.out.print("Enter order ID to update status: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter new status (processing, shipped, delivered): ");
        String newStatus = scanner.nextLine();

        try {
            orderService.updateOrderStatus(orderId, newStatus);
            System.out.println("Order status updated successfully.");
        } catch (SQLException e) {
            System.out.println("Failed to update order status: " + e.getMessage());
        }
    }

    private static void viewOrderStatusHistory() {
        System.out.print("Enter order ID to view status history: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        List<String> statusHistory = orderService.getOrderStatusHistory(orderId);
        System.out.println("Order Status History:");
        for (String status : statusHistory) {
            System.out.println("- " + status);
        }
    }

    private static void cancelOrderStatusUpdate() {
        System.out.print("Enter order ID to cancel status update: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter current status: ");
        String currentStatus = scanner.nextLine();

        orderService.cancelOrderStatusUpdate(orderId, currentStatus);
    }
}
