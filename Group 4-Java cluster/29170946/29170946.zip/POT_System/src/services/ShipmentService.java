package services;

import dao.ShipmentDAO;
import models.Shipment;

import java.sql.SQLException;
import java.util.List;

public class ShipmentService {
    private ShipmentDAO shipmentDAO = new ShipmentDAO();

    public void addShipment(Shipment shipment) throws SQLException {
        shipmentDAO.addShipment(shipment);
    }

    public Shipment viewShipment(int shipmentId) throws SQLException {
        return shipmentDAO.getShipment(shipmentId);
    }

    public List<Shipment> getAllShipments() throws SQLException {
        return shipmentDAO.getAllShipments();
    }

    public void updateShipmentStatus(int shipmentId, String status) throws SQLException {
        Shipment shipment = shipmentDAO.getShipment(shipmentId);
        if (shipment != null) {
            shipment.setStatus(status);
            shipmentDAO.updateShipment(shipment);
        }
    }

    public void trackShipment(int orderId) throws SQLException {
        List<Shipment> shipments = shipmentDAO.getAllShipments();
        for (Shipment shipment : shipments) {
            if (shipment.getOrderId() == orderId) {
                System.out.println("Shipment ID: " + shipment.getShipmentId());
                System.out.println("Order ID: " + shipment.getOrderId());
                System.out.println("Shipment Date: " + shipment.getShipmentDate());
                System.out.println("Estimated Delivery Date: " + shipment.getEstimatedDeliveryDate());
                System.out.println("Actual Delivery Date: " + shipment.getActualDeliveryDate());
                System.out.println("Status: " + shipment.getStatus());
            }
        }
    }

    public void cancelShipment(int shipmentId) throws SQLException {
        shipmentDAO.deleteShipment(shipmentId);
    }
}
