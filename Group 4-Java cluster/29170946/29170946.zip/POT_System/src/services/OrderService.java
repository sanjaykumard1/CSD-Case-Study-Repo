package services;

import dao.OrderDAO;
import models.Order;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private OrderDAO orderDAO = new OrderDAO();

    public void placeOrder(Order order) throws SQLException {
        orderDAO.addOrder(order);
    }

    public Order viewOrder(int orderId) throws SQLException {
        return orderDAO.getOrder(orderId);
    }

    public List<Order> getAllOrders() throws SQLException {
        return orderDAO.getAllOrders();
    }

    public void updateOrder(Order order) throws SQLException {
        orderDAO.updateOrder(order);
    }

    public void cancelOrder(int orderId) throws SQLException {
        orderDAO.deleteOrder(orderId);
    }

    // Functionality to update order status
    public void updateOrderStatus(int orderId, String newStatus) throws SQLException {
        Order order = orderDAO.getOrder(orderId);
        if (order != null) {
            order.setStatus(newStatus);
            orderDAO.updateOrder(order);
        }
    }

    // Functionality to view order status history (simulated with a list)
    public List<String> getOrderStatusHistory(int orderId) {
        // Simulated order status history
        List<String> statusHistory = new ArrayList<>();
        statusHistory.add("Order placed");
        statusHistory.add("Order processing");
        statusHistory.add("Order shipped");
        statusHistory.add("Order delivered");
        return statusHistory;
    }

    // Functionality to cancel order status update (simulated canceling)
    public void cancelOrderStatusUpdate(int orderId, String currentStatus) {
        // Simulated canceling by reverting to previous status or not taking action
        System.out.println("Order status update canceled for order ID: " + orderId);
    }
}
