package com.cts.constants;

public class AppConstants {
    public static final String SAVEPOLICY_QUERY="INSERT INTO POLICY VALUES (?,?,?,?,?)";
    public static final String GETPOLICYBYID_QUERY="SELECT * FROM POLICY WHERE policy_id = ?";
    public static final String UPDATEPOLICYBYID_QUERY="UPDATE POLICY SET policy_number=?,type=?,coverage_amount=?,premium_amount=? WHERE policy_id=?";
    public static final String DELETEPOLICYBYID_QUERY="DELETE FROM POLICY WHERE policy_id= ?";
    public static final String SAVECUSTOMER_QUERY="INSERT INTO CUSTOMER VALUES(?,?,?,?,?)";
    public static final String GETCUSTOMERBYID_QUERY="SELECT * FROM CUSTOMER WHERE customer_id = ?";
    public static final String UPDATECUSTOMERYBYID_QUERY="UPDATE CUSTOMER SET name=?,email=?,phone_number=?,address=? WHERE customer_id=?";
    public static final String DELETECUSTOMERBYID_QUERY="DELETE FROM CUSTOMER WHERE customer_id= ?";
    public static final String SAVECLAIM_QUERY="INSERT INTO CLAIM VALUES(?,?,?,?,?)";
    public static final String GETCLAIMBYID_QUERY="SELECT * FROM CLAIM WHERE customer_id = ?";
    public static final String UPDATECLAIMYBYID_QUERY="UPDATE CLAIM SET policy_id=?,customer_id=?,claim_date=?,status=? WHERE claim_id=?";
    public static final String DELETECLAIMBYID_QUERY="DELETE FROM CLAIM WHERE claim_id= ?";
}
