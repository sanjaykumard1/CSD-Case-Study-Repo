package com.cts.entity;

public class Policy {
    private int policy_id;
    private String policy_number;
    private String type;
    private String coverage_amount;
    private String premium_amount;

    public int getPolicy_id() {
        return policy_id;
    }

    public void setPolicy_id(int policy_id) {
        this.policy_id = policy_id;
    }

    public String getPolicy_number() {
        return policy_number;
    }

    public void setPolicy_number(String policy_number) {
        this.policy_number = policy_number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCoverage_amount() {
        return coverage_amount;
    }

    public void setCoverage_amount(String coverage_amount) {
        this.coverage_amount = coverage_amount;
    }

    public String getPremium_amount() {
        return premium_amount;
    }

    public void setPremium_amount(String premium_amount) {
        this.premium_amount = premium_amount;
    }

    @Override
    public String toString() {
        return "Policy{" +
                "policy_id=" + policy_id +
                ", policy_number='" + policy_number + '\'' +
                ", type='" + type + '\'' +
                ", coverage_amount='" + coverage_amount + '\'' +
                ", premium_amount='" + premium_amount + '\'' +
                '}';
    }
}
