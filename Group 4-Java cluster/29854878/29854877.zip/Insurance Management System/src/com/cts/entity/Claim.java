package com.cts.entity;

public class Claim {
    private int claim_id;
    private String policy_id;
    private String customer_id;
    private String claim_date;
    private String status;

    public int getClaim_id() {
        return claim_id;
    }

    public void setClaim_id(int claim_id) {
        this.claim_id = claim_id;
    }

    public String getPolicy_id() {
        return policy_id;
    }

    public void setPolicy_id(String policy_id) {
        this.policy_id = policy_id;
    }

    public String getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(String customer_id) {
        this.customer_id = customer_id;
    }

    public String getClaim_date() {
        return claim_date;
    }

    public void setClaim_date(String claim_date) {
        this.claim_date = claim_date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Claim{" +
                "claim_id=" + claim_id +
                ", policy_id='" + policy_id + '\'' +
                ", customer_id='" + customer_id + '\'' +
                ", claim_date='" + claim_date + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
