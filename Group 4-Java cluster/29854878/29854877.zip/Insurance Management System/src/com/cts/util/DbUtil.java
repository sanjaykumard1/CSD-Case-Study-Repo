package com.cts.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {

    public static Connection getConnection() throws SQLException {
        String password = "Subhajit@123";
        String user = "root";
        String url = "jdbc:mysql://localhost:3306/test";
        return DriverManager.getConnection(url, user, password);
    }
}