package com.cts.dao;

import com.cts.entity.Claim;

import java.util.Optional;

public interface ClaimRepo {
    Claim saveClaim(Claim claim);

    Optional<Claim> findById(Integer claimId);

    Claim updateClaim(Claim claim);

    void deleteClaim(Integer claimId);
}
