package com.cts.dao;

import com.cts.entity.Policy;

import java.util.Optional;

public interface PolicyRepo {
    Policy savePolicy(Policy policy);

    Optional<Policy> getPolicy(Integer policyId);

    Policy updatePolicy(Policy policy);

    void deletePolicy(Integer policyId);

}
