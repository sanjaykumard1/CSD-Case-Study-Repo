package com.cts.dao;

import com.cts.entity.Customer;
import com.cts.entity.Policy;

import java.util.Optional;

public interface CustomerRepo {
    Customer saveCustomer(Customer customer);

    Optional<Customer> findById(Integer customerId);

    Customer updateCustomer(Customer customer);

    void deleteCustomer(Integer customerId);
}
