package com.cts.service;

import com.cts.constants.AppConstants;
import com.cts.dao.ClaimRepo;
import com.cts.entity.Claim;
import com.cts.entity.Customer;
import com.cts.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.logging.Logger;

public class ClaimService implements ClaimRepo {
    Logger logger = Logger.getLogger(CustomerService.class.getName());
    private final Connection connection = DbUtil.getConnection();

    public ClaimService() throws SQLException {
    }

    @Override
    public Claim saveClaim(Claim claim) {
        PreparedStatement preparedStatement = null;
        int status = 0;
        try {
            preparedStatement = connection.prepareStatement(AppConstants.SAVECLAIM_QUERY);
            preparedStatement.setInt(1, claim.getClaim_id());
            preparedStatement.setString(2, claim.getPolicy_id());
            preparedStatement.setString(3, claim.getCustomer_id());
            preparedStatement.setString(4, claim.getClaim_date());
            preparedStatement.setString(5, claim.getStatus());
            status = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (status == 1) {
            logger.info("Claim has been saved");
            return claim;
        } else {
            throw new RuntimeException("Claim has not been saved");
        }
    }

    @Override
    public Optional<Claim> findById(Integer claimId) {
        PreparedStatement preparedStatement = null;
        Claim claim = null;
        Optional<Claim> claimById = Optional.empty();
        try {
            preparedStatement = connection.prepareStatement(AppConstants.GETCLAIMBYID_QUERY);
            preparedStatement.setInt(1, claimId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                logger.info("Claim found");
                claim = new Claim();
                claim.setClaim_id(resultSet.getInt(1));
                claim.setPolicy_id(resultSet.getString(2));
                claim.setCustomer_id(resultSet.getString(3));
                claim.setClaim_date(resultSet.getString(4));
                claim.setStatus(resultSet.getString(5));
                claimById = Optional.of(claim);
            } else {
                logger.info("No claim Available with id " + claimId);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return claimById;
    }

    @Override
    public Claim updateClaim(Claim claim) {
        PreparedStatement preparedStatement = null;
        try {
            Optional<Claim> claimById = findById(claim.getClaim_id());
            if (claimById.isPresent()) {
                preparedStatement = connection.prepareStatement(AppConstants.UPDATECLAIMYBYID_QUERY);
                preparedStatement.setString(1, claim.getPolicy_id());
                preparedStatement.setString(2, claim.getCustomer_id());
                preparedStatement.setString(3, claim.getClaim_date());
                preparedStatement.setString(4, claim.getStatus());
                preparedStatement.setInt(5, claim.getClaim_id());
                int status = preparedStatement.executeUpdate();
                if (status == 1) {
                    logger.info("Claim updated successfully");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return claim;
    }

    @Override
    public void deleteClaim(Integer claimId) {
        PreparedStatement preparedStatement = null;
        Customer customer = null;
        try {
            customer = new Customer();
            preparedStatement = connection.prepareStatement(AppConstants.DELETECLAIMBYID_QUERY);
            preparedStatement.setInt(1, claimId);
            int status = preparedStatement.executeUpdate();
            if (status == 1) {
                logger.info("Claim deleted successfully");
            } else {
                throw new RuntimeException("Claim could not be deleted with policy id " + claimId);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

