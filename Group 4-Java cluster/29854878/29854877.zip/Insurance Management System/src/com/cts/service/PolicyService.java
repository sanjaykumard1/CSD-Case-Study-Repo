package com.cts.service;

import com.cts.constants.AppConstants;
import com.cts.dao.PolicyRepo;
import com.cts.entity.Policy;
import com.cts.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.logging.Logger;

public class PolicyService implements PolicyRepo {
    Logger logger = Logger.getLogger(PolicyService.class.getName());
    private final Connection connection = DbUtil.getConnection();

    public PolicyService() throws SQLException {
    }

    @Override
    public Policy savePolicy(Policy policy) {
        PreparedStatement preparedStatement = null;
        int status = 0;
        try {
            preparedStatement = connection.prepareStatement(AppConstants.SAVEPOLICY_QUERY);
            preparedStatement.setInt(1, policy.getPolicy_id());
            preparedStatement.setString(2, policy.getPolicy_number());
            preparedStatement.setString(3, policy.getType());
            preparedStatement.setString(4, policy.getCoverage_amount());
            preparedStatement.setString(5, policy.getPremium_amount());
            status = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (status == 1) {
            logger.info("Policy added successfully");
            return policy;
        } else {
            throw new RuntimeException("Policy could not be added");
        }
    }

    @Override
    public Optional<Policy> getPolicy(Integer policyId) {
        PreparedStatement preparedStatement = null;
        Policy policy = null;
        Optional<Policy> policyById = Optional.empty();
        try {
            preparedStatement = connection.prepareStatement(AppConstants.GETPOLICYBYID_QUERY);
            preparedStatement.setInt(1, policyId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                logger.info("Policy found");
                policy = new Policy();
                policy.setPolicy_id(resultSet.getInt(1));
                policy.setPolicy_number(resultSet.getString(2));
                policy.setType(resultSet.getString(3));
                policy.setCoverage_amount(resultSet.getString(4));
                policy.setPremium_amount(resultSet.getString(5));
                policyById = Optional.of(policy);
            } else {
                logger.info("No Policy Available with id " + policyId);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return policyById;
    }

    @Override
    public Policy updatePolicy(Policy policy) {
        PreparedStatement preparedStatement = null;
        try {
            Optional<Policy> policyById = getPolicy(policy.getPolicy_id());
            if (policyById.isPresent()) {
                preparedStatement = connection.prepareStatement(AppConstants.UPDATEPOLICYBYID_QUERY);
                preparedStatement.setString(1, policy.getPolicy_number());
                preparedStatement.setString(2, policy.getType());
                preparedStatement.setString(3, policy.getCoverage_amount());
                preparedStatement.setString(4, policy.getPremium_amount());
                preparedStatement.setInt(5, policy.getPolicy_id());
                int status = preparedStatement.executeUpdate();
                if (status == 1) {
                    logger.info("Policy updated successfully");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return policy;
    }

    @Override
    public void deletePolicy(Integer policyId) {
        PreparedStatement preparedStatement = null;
        Policy policy = null;
        try {
            policy = new Policy();
            preparedStatement = connection.prepareStatement(AppConstants.DELETEPOLICYBYID_QUERY);
            preparedStatement.setInt(1, policyId);
            int status = preparedStatement.executeUpdate();
            if (status == 1) {
                logger.info("Policy deleted successfully");
            } else {
                throw new RuntimeException("Policy could not be deleted with policy id " + policy.getPolicy_id());
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
