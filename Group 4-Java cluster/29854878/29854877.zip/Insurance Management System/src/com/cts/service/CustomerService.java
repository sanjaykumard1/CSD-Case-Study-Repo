package com.cts.service;

import com.cts.constants.AppConstants;
import com.cts.dao.CustomerRepo;
import com.cts.entity.Customer;
import com.cts.util.DbUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.logging.Logger;

public class CustomerService implements CustomerRepo {
    Logger logger = Logger.getLogger(CustomerService.class.getName());
    private final Connection connection = DbUtil.getConnection();

    public CustomerService() throws SQLException {
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        PreparedStatement preparedStatement = null;
        int status = 0;
        try {
            preparedStatement = connection.prepareStatement(AppConstants.SAVECUSTOMER_QUERY);
            preparedStatement.setInt(1, customer.getCustomer_id());
            preparedStatement.setString(2, customer.getName());
            preparedStatement.setString(3, customer.getEmail());
            preparedStatement.setString(4, customer.getPhone_number());
            preparedStatement.setString(5, customer.getAddress());
            status = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        if (status == 1) {
            logger.info("Customer has been saved");
            return customer;
        } else {
            throw new RuntimeException("Customer has not been saved");
        }
    }

    @Override
    public Optional<Customer> findById(Integer customerId) {
        PreparedStatement preparedStatement = null;
        Customer customer = null;
        Optional<Customer> customerById = Optional.empty();
        try {
            preparedStatement = connection.prepareStatement(AppConstants.GETCUSTOMERBYID_QUERY);
            preparedStatement.setInt(1, customerId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                logger.info("Customer found");
                customer = new Customer();
                customer.setCustomer_id(resultSet.getInt(1));
                customer.setName(resultSet.getString(2));
                customer.setEmail(resultSet.getString(3));
                customer.setPhone_number(resultSet.getString(4));
                customer.setAddress(resultSet.getString(5));
                customerById = Optional.of(customer);
            } else {
                logger.info("No Customer Available with id " + customerId);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return customerById;
    }

    @Override
    public Customer updateCustomer(Customer customer) {
        PreparedStatement preparedStatement = null;
        try {
            Optional<Customer> customerById = findById(customer.getCustomer_id());
            if (customerById.isPresent()) {
                preparedStatement = connection.prepareStatement(AppConstants.UPDATECUSTOMERYBYID_QUERY);
                preparedStatement.setString(1, customer.getName());
                preparedStatement.setString(2, customer.getEmail());
                preparedStatement.setString(3, customer.getPhone_number());
                preparedStatement.setString(4, customer.getAddress());
                preparedStatement.setInt(5, customer.getCustomer_id());
                int status = preparedStatement.executeUpdate();
                if (status == 1) {
                    logger.info("Customer updated successfully");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return customer;
    }

    @Override
    public void deleteCustomer(Integer customerId) {
        PreparedStatement preparedStatement = null;
        Customer customer = null;
        try {
            customer = new Customer();
            preparedStatement = connection.prepareStatement(AppConstants.DELETECUSTOMERBYID_QUERY);
            preparedStatement.setInt(1, customerId);
            int status = preparedStatement.executeUpdate();
            if (status == 1) {
                logger.info("Customer deleted successfully");
            } else {
                logger.info("No customer Found with id " + customerId);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

