import com.cts.dao.ClaimRepo;
import com.cts.dao.CustomerRepo;
import com.cts.dao.PolicyRepo;
import com.cts.entity.Claim;
import com.cts.entity.Customer;
import com.cts.entity.Policy;
import com.cts.service.ClaimService;
import com.cts.service.CustomerService;
import com.cts.service.PolicyService;

import java.sql.SQLException;
import java.util.Optional;
import java.util.Scanner;

public class InsuranceApplication {
    public static void main(String[] args) throws SQLException {
        System.out.println("Program Started...");
        int ch = 0;
        int innerCh;
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("---Insurance Management System---");
            System.out.println("1.Policy Management\n2.Customer Management\n3.Claim Management\n4.Terminate");
            System.out.println("Please enter your choice:");
            ch = sc.nextInt();
            switch (ch) {
                case 1:
                    while (true) {
                        // Policy Management
                        System.out.println("Welcome to Policy Management!");
                        System.out.println("1.Create Policy\n2.View Policy \n3.Update Policy\n4.Delete Policy\n5.Exit");
                        System.out.println("Enter your choice:");
                        innerCh = sc.nextInt();
                        PolicyRepo policyRepo = new PolicyService();
                        Integer policyId = null;
                        Policy policy = null;
                        switch (innerCh) {
                            case 1:
                                System.out.println("---Enter details to create policy---");
                                policy = new Policy();
                                System.out.println("Enter policy Id:");
                                policy.setPolicy_id(sc.nextInt());
                                System.out.println("Enter policy number:");
                                policy.setPolicy_number(sc.next());
                                System.out.println("Enter policy type:");
                                policy.setType(sc.next());
                                System.out.println("Enter policy coverage_amount:");
                                policy.setCoverage_amount(sc.next());
                                System.out.println("Enter policy premium_amount:");
                                policy.setPremium_amount(sc.next());
                                Policy savedPolicy = policyRepo.savePolicy(policy);
                                System.out.println(savedPolicy);
                                break;
                            case 2:
                                System.out.println("---Enter details to view policy---");
                                System.out.println("Enter policy Id:");
                                policyId = sc.nextInt();
                                Optional<Policy> policyById = policyRepo.getPolicy(policyId);
                                if (policyById.isPresent()) {
                                    System.out.println(policyById.get());
                                } else {
                                    System.out.println("Policy not found");
                                }
                                break;
                            case 3:
                                System.out.println("---Enter details to update policy---");
                                policy = new Policy();
                                System.out.println("Enter policy Id:");
                                policy.setPolicy_id(sc.nextInt());
                                System.out.println("Enter policy number:");
                                policy.setPolicy_number(sc.next());
                                System.out.println("Enter policy type:");
                                policy.setType(sc.next());
                                System.out.println("Enter policy coverage_amount:");
                                policy.setCoverage_amount(sc.next());
                                System.out.println("Enter policy premium_amount:");
                                policy.setPremium_amount(sc.next());
                                Policy updatedPolicy = policyRepo.updatePolicy(policy);
                                System.out.println(updatedPolicy);
                                break;
                            case 4:
                                System.out.println("---Enter policy Details to delete policy---");
                                System.out.println("Enter policy Id:");
                                policyId = sc.nextInt();
                                policyRepo.deletePolicy(policyId);
                                System.out.println("Policy deleted successfully");
                                break;
                            case 5:
                                System.out.println("Returning to main menu...");
                                break;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                                break;

                        }
                        if (innerCh == 5) {
                            break;
                        }
                    }
                    break;
                case 2:
                    while (true) {
                        // Customer Management
                        System.out.println("Welcome to Customer Management!");
                        System.out.println("1.Register Customer\n2.View Customer\n3.Update Customer\n4.Delete Customer\n5.Exit");
                        System.out.println("Enter your choice:");
                        innerCh = sc.nextInt();
                        Customer customer = null;
                        Integer customerId = null;
                        CustomerRepo customerRepo = new CustomerService();
                        switch (innerCh) {
                            case 1:
                                System.out.println("---Register Customer Details----");
                                customer = new Customer();
                                System.out.println("Enter customer Id:");
                                customer.setCustomer_id(sc.nextInt());
                                System.out.println("Enter customer name:");
                                customer.setName(sc.next());
                                System.out.println("Enter customer email:");
                                customer.setEmail(sc.next());
                                System.out.println("Enter customer Phone number:");
                                customer.setPhone_number(sc.next());
                                System.out.println("Enter customer address:");
                                customer.setAddress(sc.next());
                                Customer savedCustomer = customerRepo.saveCustomer(customer);
                                System.out.println(savedCustomer);
                                break;
                            case 2:
                                System.out.println("---View Customer Details----");
                                System.out.println("Enter Customer Id:");
                                customerId = sc.nextInt();
                                Optional<Customer> customerById = customerRepo.findById(customerId);
                                if (customerById.isPresent()) {
                                    System.out.println(customerById.get());
                                } else {
                                    System.out.println("Customer not found");
                                }
                                break;
                            case 3:
                                System.out.println("---Update Customer Details----");
                                customer = new Customer();
                                System.out.println("Enter customer Id:");
                                customer.setCustomer_id(sc.nextInt());
                                System.out.println("Enter customer name:");
                                customer.setName(sc.next());
                                System.out.println("Enter customer email:");
                                customer.setEmail(sc.next());
                                System.out.println("Enter customer Phone number:");
                                customer.setPhone_number(sc.next());
                                System.out.println("Enter customer address:");
                                customer.setAddress(sc.next());
                                Customer updatedCustomer = customerRepo.updateCustomer(customer);
                                System.out.println(updatedCustomer);
                                break;
                            case 4:
                                System.out.println("---Delete Customer Details----");
                                System.out.println("Enter customer Id:");
                                customerId = sc.nextInt();
                                customerRepo.deleteCustomer(customerId);
                                System.out.println("Customer deleted successfully");
                                break;
                            case 5:
                                System.out.println("Returning to main menu...");
                                break;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                                break;

                        }
                        if (innerCh == 5) {
                            break;
                        }
                    }
                    break;
                case 3:
                    while (true) {
                        // Claim Management
                        System.out.println("Welcome to Claim Management!");
                        System.out.println("1.Submit New Claim\n2.View Claim\n3.Update Claim \n4.Delete Claim\n5.Exit");
                        System.out.println("Enter your choice:");
                        innerCh = sc.nextInt();
                        Claim claim = null;
                        ClaimRepo claimRepo = new ClaimService();
                        Integer claimId = null;
                        switch (innerCh) {
                            case 1:
                                System.out.println("---Submit new claim----");
                                claim = new Claim();
                                System.out.println("Enter claim Id:");
                                claim.setClaim_id(sc.nextInt());
                                System.out.println("Enter claim policyId:");
                                claim.setPolicy_id(sc.next());
                                System.out.println("Enter claim customerId:");
                                claim.setCustomer_id(sc.next());
                                System.out.println("Enter claim Phone claimDate(Format should be yyyy-MM-dd:");
                                claim.setClaim_date(sc.next());
                                System.out.println("Enter claim status(submitted/processed):");
                                claim.setStatus(sc.next());
                                Claim savedClaim = claimRepo.saveClaim(claim);
                                System.out.println(savedClaim);
                                break;
                            case 2:
                                System.out.println("---View Claim Details----");
                                System.out.println("Enter claim Id:");
                                claimId = sc.nextInt();
                                Optional<Claim> claimById = claimRepo.findById(claimId);
                                if (claimById.isPresent()) {
                                    System.out.println(claimById.get());
                                } else {
                                    System.out.println("Claim not found.");
                                }
                                break;
                            case 3:
                                System.out.println("---Update Claim Details----");
                                claim = new Claim();
                                System.out.println("Enter claim Id:");
                                claim.setClaim_id(sc.nextInt());
                                System.out.println("Enter claim policyId:");
                                claim.setPolicy_id(sc.next());
                                System.out.println("Enter claim customerId:");
                                claim.setCustomer_id(sc.next());
                                System.out.println("Enter claim Phone claimDate(Format should be yyyy-MM-dd:");
                                claim.setClaim_date(sc.next());
                                System.out.println("Enter claim status(submitted/processed):");
                                claim.setStatus(sc.next());
                                Claim updatedClaim = claimRepo.updateClaim(claim);
                                System.out.println(updatedClaim);
                                break;
                            case 4:
                                System.out.println("---Delete Claim Details----");
                                System.out.println("Enter claim Id:");
                                claimId = sc.nextInt();
                                claimRepo.deleteClaim(claimId);
                                System.out.println("Claim deleted successfully");
                                break;
                            case 5:
                                System.out.println("Returning to main menu...");
                                break;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                                break;

                        }
                        if (innerCh == 5) {
                            break;
                        }
                    }
                    break;
                case 4:
                    System.exit(0);
                    break;
            }
        }
    }
}

