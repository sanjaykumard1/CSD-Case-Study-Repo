# Insurance Management System

## Objective

This project is a menu-based console application that simulates an insurance management system. It allows users to manage policies, customers, and claims using Core Java, MySQL, and JDBC.

## Functionalities

### Policy Management
- Add a new policy
- View policy details
- Update policy information
- Delete a policy

### Customer Management
- Register a new customer
- View customer details
- Update customer information
- Delete a customer

### Claim Management
- Submit a new claim
- View claim details
- Update claim information
- Delete a claim

## Database Schema

### Policy Table
- policy_id (Primary Key)
- policy_number
- type
- coverage_amount
- premium_amount

### Customer Table
- customer_id (Primary Key)
- name
- email
- phone_number
- address

### Claim Table
- claim_id (Primary Key)
- policy_id (Foreign Key references Policy Table)
- customer_id (Foreign Key references Customer Table)
- claim_date
- status (submitted/processed)

## Features Implemented

- Develop a menu-based console application using Core Java.
- Use JDBC for interactions with the MySQL database.
- Implement menu options for managing policies, customers, and claims.
- Ensure that the application updates the status in the Claim table appropriately after a claim is submitted or processed.
- Handle exceptions effectively and provide user-friendly error messages.
- Ensure the application code is clean, well-documented, and follows standard coding conventions.

## Setup and Usage Instructions

### Prerequisites

- Java Development Kit (JDK) 8 or higher
- MySQL database
- JDBC driver for MySQL

### Database Setup

1. Create a MySQL database named insurance_management.
2. Create the following tables:

```sql
CREATE TABLE Policy (
    policy_id INT PRIMARY KEY,
    policy_number VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    coverage_amount VARCHAR(255) NOT NULL,
    premium_amount VARCHAR(255) NOT NULL
);

CREATE TABLE Customer (
    customer_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    address VARCHAR(255) NOT NULL
);

CREATE TABLE Claim (
    claim_id INT PRIMARY KEY,
    policy_id INT,
    customer_id INT,
    claim_date DATE,
    status VARCHAR(20) CHECK (status IN ('submitted', 'processed')),
    FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);
```
### Exception Handling

The application includes robust exception handling to provide user-friendly error messages and ensure smooth operation.

### Usage
1. The application will display a menu with options for managing policies, customers, and claims.
2. Select the desired option by entering the corresponding number.
3. Follow the prompts to add, view, update, or delete policies, customers, and claims.
4. Use the appropriate options to submit or process claims.

### Run Application
Clone the project navigate to the following directory and the run the InsuranceApplication file as Java Application.