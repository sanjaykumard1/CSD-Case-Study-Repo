
Home Insurance Management System

Overview
The Home Insurance Management System is a Java-based application designed to manage homeowner insurance policies, claims, and related data. This system provides functionalities to create and manage homeowners, their policies, and claims, as well as to connect to a database for persistent storage.

Project Structure
- .classpath: Configuration file for the Java classpath.
- .vscode/: Directory containing VS Code-specific configurations.
  - `launch.json`: Configuration for debugging the application using VS Code.
- bin/: Directory containing compiled Java class files.
  - `com/homeinsurance/`: Package containing compiled class files.
    - `Claim.class`
    - `ClaimManagement.class`
    - `DatabaseConnection.class`
    - `Homeowner.class`
    - `HomeownerManagement.class`
    - `Main.class`
    - `Policy.class`
    - `PolicyManagement.class`
- lib/: Directory containing external libraries.
  - `mysql-connector-j-9.0.0.jar`: MySQL Connector library for database connectivity.
- src/: Directory containing source code files.
  - `com/homeinsurance/`: Package containing source code files.
    - `Claim.java`: Defines the Claim class representing an insurance claim.
    - `ClaimManagement.java`: Provides functionalities to manage claims.
    - `DatabaseConnection.java`: Handles database connectivity.
    - `Homeowner.java`: Defines the Homeowner class representing a homeowner.
    - `HomeownerManagement.java`: Provides functionalities to manage homeowners.
    - `Main.java`: Main class to run the application.
    - `Policy.java`: Defines the Policy class representing an insurance policy.
    - `PolicyManagement.java`: Provides functionalities to manage policies.

 Prerequisites
- Java Development Kit (JDK) 8 or higher
- MySQL database
- MySQL Connector/J library (included in `lib` directory)
- Visual Studio Code (VS Code) with Java extensions installed


