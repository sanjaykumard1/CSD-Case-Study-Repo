package com.homeinsurance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class ClaimManagement {

    public void submitClaim() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter homeowner ID: ");
            int homeownerId = scanner.nextInt();
            System.out.print("Enter claim date (yyyy-mm-dd): ");
            String claimDateStr = scanner.next();
            Date claimDate = java.sql.Date.valueOf(claimDateStr);

            String sql = "INSERT INTO Claim (policy_id, homeowner_id, claim_date, status) VALUES (?, ?, ?, 'submitted')";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, policyId);
                pstmt.setInt(2, homeownerId);
                pstmt.setDate(3, (java.sql.Date) claimDate);
                pstmt.executeUpdate();
                System.out.println("Claim submitted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewClaimDetails() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter claim ID: ");
            int claimId = scanner.nextInt();

            String sql = "SELECT * FROM Claim WHERE claim_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, claimId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Claim ID: " + rs.getInt("claim_id"));
                    System.out.println("Policy ID: " + rs.getInt("policy_id"));
                    System.out.println("Homeowner ID: " + rs.getInt("homeowner_id"));
                    System.out.println("Claim Date: " + rs.getDate("claim_date"));
                    System.out.println("Status: " + rs.getString("status"));
                } else {
                    System.out.println("Claim not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateClaim() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter claim ID to update: ");
            int claimId = scanner.nextInt();
            System.out.print("Enter new status (submitted/processed): ");
            String status = scanner.next();

            String sql = "UPDATE Claim SET status = ? WHERE claim_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, status);
                pstmt.setInt(2, claimId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Claim updated successfully!");
                } else {
                    System.out.println("Claim not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteClaim() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter claim ID to delete: ");
            int claimId = scanner.nextInt();

            String sql = "DELETE FROM Claim WHERE claim_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, claimId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Claim deleted successfully!");
                } else {
                    System.out.println("Claim not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
