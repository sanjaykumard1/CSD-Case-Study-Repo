package com.homeinsurance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PolicyManagement {

    public void addPolicy() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter type: ");
            String type = scanner.nextLine();
            System.out.print("Enter coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter premium amount: ");
            double premiumAmount = scanner.nextDouble();

            String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, policyNumber);
                pstmt.setString(2, type);
                pstmt.setDouble(3, coverageAmount);
                pstmt.setDouble(4, premiumAmount);
                pstmt.executeUpdate();
                System.out.println("Policy added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPolicyDetails() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();

            String sql = "SELECT * FROM Policy WHERE policy_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, policyId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Policy ID: " + rs.getInt("policy_id"));
                    System.out.println("Policy Number: " + rs.getString("policy_number"));
                    System.out.println("Type: " + rs.getString("type"));
                    System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                    System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
                } else {
                    System.out.println("Policy not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePolicy() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter policy ID to update: ");
            int policyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter new type: ");
            String type = scanner.nextLine();
            System.out.print("Enter new coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter new premium amount: ");
            double premiumAmount = scanner.nextDouble();

            String sql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, policyNumber);
                pstmt.setString(2, type);
                pstmt.setDouble(3, coverageAmount);
                pstmt.setDouble(4, premiumAmount);
                pstmt.setInt(5, policyId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Policy updated successfully!");
                } else {
                    System.out.println("Policy not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePolicy() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter policy ID to delete: ");
            int policyId = scanner.nextInt();

            String sql = "DELETE FROM Policy WHERE policy_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, policyId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Policy deleted successfully!");
                } else {
                    System.out.println("Policy not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
