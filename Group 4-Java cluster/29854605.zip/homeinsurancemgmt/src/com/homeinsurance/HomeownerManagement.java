package com.homeinsurance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class HomeownerManagement {

    public void addHomeowner() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter address: ");
            String address = scanner.nextLine();

            String sql = "INSERT INTO Homeowner (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, phoneNumber);
                pstmt.setString(4, address);
                pstmt.executeUpdate();
                System.out.println("Homeowner added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewHomeownerDetails() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter homeowner ID: ");
            int homeownerId = scanner.nextInt();

            String sql = "SELECT * FROM Homeowner WHERE homeowner_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, homeownerId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Homeowner ID: " + rs.getInt("homeowner_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Address: " + rs.getString("address"));
                } else {
                    System.out.println("Homeowner not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateHomeowner() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter homeowner ID to update: ");
            int homeownerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new phone number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new address: ");
            String address = scanner.nextLine();

            String sql = "UPDATE Homeowner SET name = ?, email = ?, phone_number = ?, address = ? WHERE homeowner_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, phoneNumber);
                pstmt.setString(4, address);
                pstmt.setInt(5, homeownerId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Homeowner updated successfully!");
                } else {
                    System.out.println("Homeowner not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteHomeowner() {
        try (Connection conn = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter homeowner ID to delete: ");
            int homeownerId = scanner.nextInt();

            String sql = "DELETE FROM Homeowner WHERE homeowner_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, homeownerId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Homeowner deleted successfully!");
                } else {
                    System.out.println("Homeowner not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
