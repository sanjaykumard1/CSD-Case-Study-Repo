package com.homeinsurance;

import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PolicyManagement policyManagement = new PolicyManagement();
        HomeownerManagement homeownerManagement = new HomeownerManagement();
        ClaimManagement claimManagement = new ClaimManagement();

        do {
            try {
                System.out.println("\nHome Insurance Management System");
                System.out.println("1. Policy Management");
                System.out.println("2. Homeowner Management");
                System.out.println("3. Claim Management");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");

                if (scanner.hasNextInt()) {
                    int choice = scanner.nextInt();
                    scanner.nextLine();  // Consume newline

                    switch (choice) {
                        case 1:
                            policyMenu(policyManagement, scanner);
                            break;
                        case 2:
                            homeownerMenu(homeownerManagement, scanner);
                            break;
                        case 3:
                            claimMenu(claimManagement, scanner);
                            break;
                        case 4:
                            System.out.println("Exiting...");
                            scanner.close();
                            System.exit(0);
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // Clear the invalid input
                }
            } catch (NoSuchElementException e) {
                System.out.println("No input received. Please try again.");
                break;  // Exit the loop on this unexpected condition
            }
        } while (true);

        scanner.close();
    }

    private static void policyMenu(PolicyManagement policyManagement, Scanner scanner) {
        System.out.println("1. Add Policy");
        System.out.println("2. View Policy Details");
        System.out.println("3. Update Policy");
        System.out.println("4. Delete Policy");
        System.out.print("Choose an option: ");

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    policyManagement.addPolicy();
                    break;
                case 2:
                    policyManagement.viewPolicyDetails();
                    break;
                case 3:
                    policyManagement.updatePolicy();
                    break;
                case 4:
                    policyManagement.deletePolicy();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } else {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Clear the invalid input
        }
    }

    private static void homeownerMenu(HomeownerManagement homeownerManagement, Scanner scanner) {
        System.out.println("1. Register Homeowner");
        System.out.println("2. View Homeowner Details");
        System.out.println("3. Update Homeowner");
        System.out.println("4. Delete Homeowner");
        System.out.print("Choose an option: ");

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    homeownerManagement.addHomeowner();
                    break;
                case 2:
                    homeownerManagement.viewHomeownerDetails();
                    break;
                case 3:
                    homeownerManagement.updateHomeowner();
                    break;
                case 4:
                    homeownerManagement.deleteHomeowner();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } else {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Clear the invalid input
        }
    }

    private static void claimMenu(ClaimManagement claimManagement, Scanner scanner) {
        System.out.println("1. Submit Claim");
        System.out.println("2. View Claim Details");
        System.out.println("3. Update Claim");
        System.out.println("4. Delete Claim");
        System.out.print("Choose an option: ");

        if (scanner.hasNextInt()) {
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    claimManagement.submitClaim();
                    break;
                case 2:
                    claimManagement.viewClaimDetails();
                    break;
                case 3:
                    claimManagement.updateClaim();
                    break;
                case 4:
                    claimManagement.deleteClaim();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } else {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Clear the invalid input
        }
    }
}