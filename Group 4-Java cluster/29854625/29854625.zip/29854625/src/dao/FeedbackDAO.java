package dao;

import db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FeedbackDAO {

    // Check if customer exists
    private boolean customerExists(int customerId) {
        boolean exists = false;
        String query = "SELECT 1 FROM customer WHERE customer_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, customerId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                exists = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return exists;
    }

    // Insert new customer
    private void insertCustomer(int customerId, String customerName, String customerEmail) {
        String query = "INSERT INTO customer (customer_id, customer_name, customer_email) VALUES (?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, customerId);
            preparedStatement.setString(2, customerName);
            preparedStatement.setString(3, customerEmail);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Submit feedback
    public void submitFeedback(int customerId, String customerName, String customerEmail, String feedbackText, int rating) {
        if (!customerExists(customerId)) {
            insertCustomer(customerId, customerName, customerEmail);
        }

        String query = "INSERT INTO feedback (customer_id, feedback_text, rating) VALUES (?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, customerId);
            preparedStatement.setString(2, feedbackText);
            preparedStatement.setInt(3, rating);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View feedback
    public void viewFeedback() {
        String query = "SELECT * FROM feedback";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int feedbackId = resultSet.getInt("feedback_id");
                int customerId = resultSet.getInt("customer_id");
                String feedbackText = resultSet.getString("feedback_text");
                int rating = resultSet.getInt("rating");

                System.out.println("Feedback ID: " + feedbackId);
                System.out.println("Customer ID: " + customerId);
                System.out.println("Feedback Text: " + feedbackText);
                System.out.println("Rating: " + rating);
                System.out.println("--------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update feedback
    public void updateFeedback(int feedbackId, String feedbackText, int rating) {
        String query = "UPDATE feedback SET feedback_text = ?, rating = ? WHERE feedback_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, feedbackText);
            preparedStatement.setInt(2, rating);
            preparedStatement.setInt(3, feedbackId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete feedback
    public void deleteFeedback(int feedbackId) {
        String query = "DELETE FROM feedback WHERE feedback_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, feedbackId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
