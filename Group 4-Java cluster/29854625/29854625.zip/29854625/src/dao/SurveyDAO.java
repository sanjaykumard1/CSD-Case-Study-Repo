package dao;

import db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SurveyDAO {

    public void createSurvey(String surveyName, String surveyDescription, String status) {
        String query = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, surveyName);
            statement.setString(2, surveyDescription);
            statement.setString(3, status);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSurveys() {
        String query = "SELECT * FROM Survey";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                System.out.println("Survey ID: " + resultSet.getInt("survey_id"));
                System.out.println("Survey Name: " + resultSet.getString("survey_name"));
                System.out.println("Survey Description: " + resultSet.getString("survey_description"));
                System.out.println("Status: " + resultSet.getString("status"));
                System.out.println("---------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateSurvey(int surveyId, String surveyName, String surveyDescription, String status) {
        String query = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, surveyName);
            statement.setString(2, surveyDescription);
            statement.setString(3, status);
            statement.setInt(4, surveyId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteSurvey(int surveyId) {
        String query = "DELETE FROM Survey WHERE survey_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, surveyId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
