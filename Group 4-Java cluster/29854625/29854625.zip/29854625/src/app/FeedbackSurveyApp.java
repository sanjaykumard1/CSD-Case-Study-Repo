package app;

import dao.FeedbackDAO;
import dao.SurveyDAO;

import java.util.Scanner;

public class FeedbackSurveyApp {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    handleFeedbackSubmission();
                    break;
                case 2:
                    handleSurveyManagement();
                    break;
                case 3:
                    handleAnalysisAndReporting();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("Menu:");
        System.out.println("1. Feedback Submission");
        System.out.println("2. Survey Management");
        System.out.println("3. Analysis and Reporting");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void handleFeedbackSubmission() {
        FeedbackDAO feedbackDAO = new FeedbackDAO();

        System.out.println("Feedback Submission:");
        System.out.println("1. Submit New Feedback");
        System.out.println("2. View Feedback");
        System.out.println("3. Update Feedback");
        System.out.println("4. Delete Feedback");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                System.out.print("Enter Customer Name: ");
                String customerName = scanner.nextLine();

                System.out.print("Enter Customer Email: ");
                String customerEmail = scanner.nextLine();

                System.out.print("Enter Feedback Text: ");
                String feedbackText = scanner.nextLine();

                System.out.print("Enter Rating: ");
                int rating = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                feedbackDAO.submitFeedback(customerId, customerName, customerEmail, feedbackText, rating);
                System.out.println("Feedback submitted successfully.");
                break;
            case 2:
                feedbackDAO.viewFeedback();
                break;
            case 3:
                System.out.print("Enter Feedback ID: ");
                int feedbackId = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                System.out.print("Enter New Feedback Text: ");
                feedbackText = scanner.nextLine();

                System.out.print("Enter New Rating: ");
                rating = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                feedbackDAO.updateFeedback(feedbackId, feedbackText, rating);
                System.out.println("Feedback updated successfully.");
                break;
            case 4:
                System.out.print("Enter Feedback ID: ");
                feedbackId = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                feedbackDAO.deleteFeedback(feedbackId);
                System.out.println("Feedback deleted successfully.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void handleSurveyManagement() {
        SurveyDAO surveyDAO = new SurveyDAO();

        System.out.println("Survey Management:");
        System.out.println("1. Create New Survey");
        System.out.println("2. View Surveys");
        System.out.println("3. Update Survey");
        System.out.println("4. Delete Survey");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Survey Name: ");
                String surveyName = scanner.nextLine();

                System.out.print("Enter Survey Description: ");
                String surveyDescription = scanner.nextLine();

                System.out.print("Enter Survey Status: ");
                String status = scanner.nextLine();

                surveyDAO.createSurvey(surveyName, surveyDescription, status);
                System.out.println("Survey created successfully.");
                break;
            case 2:
                surveyDAO.viewSurveys();
                break;
            case 3:
                System.out.print("Enter Survey ID: ");
                int surveyId = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                System.out.print("Enter New Survey Name: ");
                surveyName = scanner.nextLine();

                System.out.print("Enter New Survey Description: ");
                surveyDescription = scanner.nextLine();

                System.out.print("Enter New Survey Status: ");
                status = scanner.nextLine();

                surveyDAO.updateSurvey(surveyId, surveyName, surveyDescription, status);
                System.out.println("Survey updated successfully.");
                break;
            case 4:
                System.out.print("Enter Survey ID: ");
                surveyId = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                surveyDAO.deleteSurvey(surveyId);
                System.out.println("Survey deleted successfully.");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void handleAnalysisAndReporting() {
        System.out.println("Analysis and Reporting:");
        // Placeholder for analysis and reporting functionality
        System.out.println("This functionality is under development.");
    }
}
