import java.util.*;
import java.sql.*;

class PropertyInsurance{

    public static void main(String args[]){
        
        Scanner sc=new Scanner(System.in);

        try{

        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/casestudy","root","balaji");
        Statement stmt=con.createStatement();


        int c=-1;

        do{
            System.out.println("\n\n----------------------------Property Insurance Management System--------------------------------------------");
            System.out.println("\nEnter 1 to perform Policy related Operations");
            System.out.println("Enter 2 to perform Property owner related Operations");
            System.out.println("Enter 3 to perform Claim related Operations");
            System.out.println("Enter 4 to Exit");
            System.out.println("\nEnter your choice: ");
            
            c=sc.nextInt();

            switch(c){
                case 1: PropertyInsurance.typeOfOperation(c, stmt); break;
                case 2: PropertyInsurance.typeOfOperation(c, stmt); break;
                case 3: PropertyInsurance.typeOfOperation(c, stmt); break;
                case 4: System.out.println("\nThank You for visiting\n\nShutting Down...\n\n"); break;
                default : System.out.println("\nInvalid choice"); break;
            }    
        }while(c!=4);

        
        }catch(Exception e){
            System.out.println(e);
        }

    }

    static void typeOfOperation(int c, Statement stmt){
        Scanner sc=new Scanner(System.in);

        String domain="";
        if(c==1)
            domain="Policy";
        else if(c==2)
            domain="Owner";
        else
            domain="Claim";

        
        int op=-1;

        do{
            System.out.println("\n\nEnter 1 to add new "+ domain);
            System.out.println("Enter 2 to view a "+ domain);
            System.out.println("Enter 3 to update a "+ domain);
            System.out.println("Enter 4 to delete a "+ domain);
            System.out.println("Enter 5 to go back");
            // System.out.println("Enter 1 to add new "+ domain);
            
            System.out.println("\nEnter your choice: ");
            op=sc.nextInt();
            switch(op){
                case 1: 
                    PropertyInsurance.addAnEntry(c, stmt);
                    break;
                case 2:
                    PropertyInsurance.viewAnEntry(c, stmt);
                    break;
                case 3:
                    PropertyInsurance.updateAnEntry(c, stmt);
                    break;
                case 4:
                    PropertyInsurance.deleteAnEntry(c, stmt);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("\nInvalid choice");
                    break;
            }
        }while(op!=5);
    }

    static void addAnEntry(int c, Statement stmt){
        String query="";

    }
    static void viewAnEntry(int c, Statement stmt){
        System.out.println("Entry displayed");
    }
    static void updateAnEntry(int c, Statement stmt){
        System.out.println("Entry updated");
    }
    static void deleteAnEntry(int c, Statement stmt){
        System.out.println("Entry deleted");
    }


}
