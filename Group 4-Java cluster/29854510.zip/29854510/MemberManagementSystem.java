import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MemberManagementSystem {
    private List<Member> members;
    private int nextMemberId;

    // Constructor
    public MemberManagementSystem() {
        members = new ArrayList<>();
        nextMemberId = 1; // Initial member id starts from 1
    }

    // Method to register a new member
    public void registerMember(String memberName, String memberEmail, String memberPhone) {
        Member newMember = new Member(nextMemberId, memberName, memberEmail, memberPhone);
        members.add(newMember);
        nextMemberId++;
        System.out.println("Member registered successfully.");
    }

    // Method to view member details
    public void viewMemberDetails(int memberId) {
        boolean found = false;
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                System.out.println("Member details:");
                System.out.println(member);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Member with ID " + memberId + " not found.");
        }
    }

    // Method to update member information
    public void updateMember(int memberId, String memberName, String memberEmail, String memberPhone) {
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                member.setMemberName(memberName);
                member.setMemberEmail(memberEmail);
                member.setMemberPhone(memberPhone);
                System.out.println("Member information updated successfully.");
                return;
            }
        }
        System.out.println("Member with ID " + memberId + " not found. Update failed.");
    }

    // Method to delete a member
    public void deleteMember(int memberId) {
        for (Member member : members) {
            if (member.getMemberId() == memberId) {
                members.remove(member);
                System.out.println("Member deleted successfully.");
                return;
            }
        }
        System.out.println("Member with ID " + memberId + " not found. Deletion failed.");
    }

    // Method to display all members
    public void displayAllMembers() {
        if (members.isEmpty()) {
            System.out.println("No members found.");
        } else {
            System.out.println("List of Members:");
            for (Member member : members) {
                System.out.println(member);
            }
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        MemberManagementSystem memberManagementSystem = new MemberManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMember Management System");
            System.out.println("1. Register a new member");
            System.out.println("2. View member details");
            System.out.println("3. Update member information");
            System.out.println("4. Delete a member");
            System.out.println("5. Display all members");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter member name: ");
                    String memberName = scanner.nextLine();
                    System.out.print("Enter member email: ");
                    String memberEmail = scanner.nextLine();
                    System.out.print("Enter member phone: ");
                    String memberPhone = scanner.nextLine();
                    memberManagementSystem.registerMember(memberName, memberEmail, memberPhone);
                    break;
                case 2:
                    System.out.print("Enter member ID to view details: ");
                    int memberIdToView = scanner.nextInt();
                    memberManagementSystem.viewMemberDetails(memberIdToView);
                    break;
                case 3:
                    System.out.print("Enter member ID to update: ");
                    int memberIdToUpdate = scanner.nextInt();
                    scanner.nextLine(); // Consume newline character
                    System.out.print("Enter new member name: ");
                    memberName = scanner.nextLine();
                    System.out.print("Enter new member email: ");
                    memberEmail = scanner.nextLine();
                    System.out.print("Enter new member phone: ");
                    memberPhone = scanner.nextLine();
                    memberManagementSystem.updateMember(memberIdToUpdate, memberName, memberEmail, memberPhone);
                    break;
                case 4:
                    System.out.print("Enter member ID to delete: ");
                    int memberIdToDelete = scanner.nextInt();
                    memberManagementSystem.deleteMember(memberIdToDelete);
                    break;
                case 5:
                    memberManagementSystem.displayAllMembers();
                    break;
                case 6:
                    System.out.println("Exiting Member Management System. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 6.");
            }
        }
    }
}
