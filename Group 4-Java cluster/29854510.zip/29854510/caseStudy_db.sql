CREATE DATABASE caseStudy_db;
USE caseStudy_db;
-- Creating the Policy table
CREATE TABLE Policy (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_number VARCHAR(20) NOT NULL,
    type VARCHAR(50) NOT NULL,
    coverage_amount DECIMAL(10,2),
    premium_amount DECIMAL(10,2)
);

-- Creating the Member table
CREATE TABLE Member (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    email VARCHAR(100),
    phone_number VARCHAR(20)
);

-- Creating the Claim table
CREATE TABLE Claim (
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_id INT,
    member_id INT,
    claim_date DATE,
    status VARCHAR(50),
    FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
    FOREIGN KEY (member_id) REFERENCES Member(member_id)
);
