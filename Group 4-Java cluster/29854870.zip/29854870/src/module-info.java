/**
 * 
 */
/**
 * 
 */
module product_application {
	requires java.sql;
}