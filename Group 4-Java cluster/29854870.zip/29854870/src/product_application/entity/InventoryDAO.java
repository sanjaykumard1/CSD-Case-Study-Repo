package product_application.entity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import product_application.entity.Inventory;
import product_application.util.Dbutil;

public class InventoryDAO {
	private Connection connection=Dbutil.getConnection();
	public void createInventory(Inventory inventory) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO Inventory VALUES(?,?,?,?)");
			ps.setInt(1, inventory.getInventory_id());
			ps.setInt(2, inventory.getProduct_id());
			ps.setInt(3, inventory.getQuantity());
			ps.setDate(4, inventory.getDate_added());
			ps.executeUpdate();
			ps.close();	
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		public List<Inventory> getAllInventory() {
	        List<Inventory> inventory1 = new ArrayList<>();
	        try {
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery("SELECT * FROM inventory");
	            while (resultSet.next()) {
	                Inventory inventory = new Inventory();
	            	inventory.setInventory_id(resultSet.getInt("inventory_id"));
	            	inventory.setProduct_id(resultSet.getInt("product_id"));
	            	inventory.setQuantity(resultSet.getInt("quantity"));
	            	inventory.setDate_added(resultSet.getDate("date_added"));

	                inventory1.add(inventory);
	            }
	            resultSet.close();
	            statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return inventory1;
		}
	        public void updateInventory(Inventory inventory) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("UPDATE inventory SET product_id = ?, quantity = ?, date_added = ?  WHERE inventory_id = ?");
	    			ps.setInt(1, inventory.getProduct_id());
	    			ps.setInt(2, inventory.getQuantity());
	    			ps.setDate(3, inventory.getDate_added());
	    			ps.setInt(3, inventory.getInventory_id());
	    			ps.executeUpdate();	
	    			ps.close();	
	    		} catch (SQLException e) {
	    			e.printStackTrace();
	    		}
	    	}
	    	
	    	public void deleteInventory(int inventory_id) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("DELETE FROM inventory WHERE inventory_id=?");
	                ps.setInt(1, inventory_id);
	                ps.executeUpdate();
	                ps.close();
	                System.out.println("Deleted successfully");
	            } catch (SQLException e) {
	                e.printStackTrace();
	          }
	    	}

}
