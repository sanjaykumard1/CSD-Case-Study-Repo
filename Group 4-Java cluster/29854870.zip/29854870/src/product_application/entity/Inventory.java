package product_application.entity;

import java.sql.Date;

public class Inventory {
	private int inventory_id;
    private int product_id;
    private int quantity;
    private Date date_added;
	/*public Inventory(int inventory_id, int product_id, int quantity, Date date_added) {
		super();
		this.inventory_id = inventory_id;
		this.product_id = product_id;
		this.quantity = quantity;
		this.date_added = date_added;
	}
	*/
	public int getInventory_id() {
		return inventory_id;
	}
	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getDate_added() {
		return date_added;
	}
	public void setDate_added(Date date_added) {
		this.date_added = date_added;
	}
	//@Override
	
	public String toString() {
		return "Inventory [inventory_id=" + inventory_id + ", product_id=" + product_id + ", quantity=" + quantity
				+ ", date_added=" + date_added + "]";
				
	}
	
    
}
