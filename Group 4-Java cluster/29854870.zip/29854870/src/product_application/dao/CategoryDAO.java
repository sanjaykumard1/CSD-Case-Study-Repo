package product_application.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import product_application.entity.Category;
import product_application.util.Dbutil;

public class CategoryDAO {
	private Connection connection=Dbutil.getConnection();
	public void createCategory(Category category) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO category_ct VALUES(?,?,?)");
			ps.setInt(1, category.getCategory_id());
			ps.setString(2, category.getName());
			ps.setString(3, category.getDescription());
			ps.executeUpdate();
			ps.close();	
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		public List<Category> getAllCategory() {
	        List<Category> category1 = new ArrayList<>();
	        try {
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery("SELECT * FROM category_ct");
	            while (resultSet.next()) {
	                Category category = new Category();
	            	category.setCategory_id(resultSet.getInt("category_id"));
	            	category.setName(resultSet.getString("name"));
	            	category.setDescription(resultSet.getString("description"));
	                category1.add(category);
	            }
	            resultSet.close();
	            statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return category1;
		}
	        public void updateCategory(Category category) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("UPDATE category_ct SET name = ?, description = ?  WHERE category_id = ?");
	    			ps.setString(1, category.getName());
	    			ps.setString(2, category.getDescription());
	    			ps.setInt(3, category.getCategory_id());
	    			ps.executeUpdate();	
	    			ps.close();	
	    		} catch (SQLException e) {
	    			e.printStackTrace();
	    		}
	    	}
	    	
	    	public void deleteCategory(int category_id) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("DELETE FROM product WHERE category_id=?");
	                ps.setInt(1, category_id);
	                ps.executeUpdate();
	                ps.close();
	                System.out.println("Deleted successfully");
	            } catch (SQLException e) {
	                e.printStackTrace();
	          }
	}
}
