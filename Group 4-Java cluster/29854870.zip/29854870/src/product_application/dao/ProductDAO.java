package product_application.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import product_application.entity.Category;
//import product_application.entity.Category;
import product_application.entity.Product;
import product_application.util.Dbutil;

public class ProductDAO {
  private Connection connection=Dbutil.getConnection();
	public void createProduct(Product product) {
		PreparedStatement ps=null;
		try {
			ps=connection.prepareStatement("INSERT INTO product VALUES(?,?,?,?,?)");
			ps.setInt(1, product.getProduct_id());
			ps.setString(2, product.getName());
			ps.setInt(3, product.getCategory_id());
			ps.setDouble(4, product.getPrice());
			ps.setInt(5, product.getStock_quantity());
			ps.executeUpdate();
			ps.close();	
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		public List<Product> getAllProduct() {
	        List<Product> product1 = new ArrayList<>();
	        try {
	            Statement statement = connection.createStatement();
	            ResultSet resultSet = statement.executeQuery("SELECT * FROM product");
	            while (resultSet.next()) {
	                Product product = new Product();
	            	product.setProduct_id(resultSet.getInt("product_id"));
	            	product.setName(resultSet.getString("name"));
	            	product.setCategory_id(resultSet.getInt("category_id"));
	            	product.setPrice(resultSet.getDouble("price"));
	            	product.setPrice(resultSet.getInt("stock_quantity"));
	                product1.add(product);
	            }
	            resultSet.close();
	            statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return product1;
		}
		 public void updateProduct(Product product) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("UPDATE product SET name = ?, category_id = ?, price = ?, stock_quantity = ?  WHERE product_id = ?");
	    			ps.setString(1, product.getName());
	    			ps.setInt(2, product.getCategory_id());
	    			ps.setDouble(3, product.getPrice());
	    			ps.setInt(4, product.getStock_quantity());
	    			ps.setInt(5, product.getProduct_id());
	    			ps.executeUpdate();	
	    			ps.close();	
	    		} catch (SQLException e) {
	    			e.printStackTrace();
	    		}
	    	}
	    	
	    	public void deleteProduct(int product_id) {
	    		PreparedStatement ps=null;
	    		try {
	    			ps=connection.prepareStatement("DELETE FROM product WHERE product_id=?");
	                ps.setInt(1, product_id);
	                ps.executeUpdate();
	                ps.close();
	                System.out.println("Deleted successfully");
	            } catch (SQLException e) {
	                e.printStackTrace();
	          }

}
}

