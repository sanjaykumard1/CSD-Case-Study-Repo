package product_application;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;
import java.sql.Date;
import java.sql.PreparedStatement;


import product_application.dao.CategoryDAO;
import product_application.entity.Category;
import product_application.dao.ProductDAO;
import product_application.entity.Product;
import product_application.entity.InventoryDAO;
import product_application.entity.Inventory;

public class Main {
	public static boolean isValidDate(String date) {
        try {
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
	        java.util.Date utilDate = sdf.parse(date);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

	public static void main(String[] args) {
		Category category = new Category();
		CategoryDAO categoryDAO = new CategoryDAO();
		Product product = new Product();
		ProductDAO productDAO = new ProductDAO();
		Inventory inventory = new Inventory();
		InventoryDAO inventoryDAO = new InventoryDAO();
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("1.Category");
			System.out.println("2.Product");
			System.out.println("3.Inventory");
            System.out.println("4.Exit");
            System.out.println("Enter choice");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("1) add a new category");
			System.out.println("2) view category details");
			System.out.println("3) update category info");
			System.out.println("4) delete a category");
			int choice1 = sc.nextInt();
			if(choice1==1)
			{
				System.out.println("1)Enter category_id :");
				category.setCategory_id(sc.nextInt());
				System.out.println("2)Enter name:");
				category.setName(sc.next());
				System.out.println("3)Enter Description:");
				category.setDescription(sc.next());
				categoryDAO.createCategory(category);
				System.out.println("category added successfully");
			}
			if(choice1==2)
			{
				 List<Category> allcategory1 = categoryDAO.getAllCategory();
				  System.out.println("\nAll Categories:"); 
				  for(Category categoryd : allcategory1) {
				 System.out.println(categoryd); 
				 }
			}
		    if(choice1 == 3)
		    {
		    	System.out.print("Enter Category id: ");
				category.setCategory_id(sc.nextInt());
				
				System.out.print("Enter name: ");
				category.setName(sc.next());
										
				System.out.print("Enter description: ");
				category.setDescription(sc.next());
				
				categoryDAO.updateCategory(category);	
				System.out.println("Category details updated successfully");
		    
		    }
		    if(choice1 == 4)
		    {
		    	System.out.print("Enter Category id: ");
				int id = sc.nextInt();
				categoryDAO.deleteCategory(id);
				System.out.println("Category details deleted successfully");
		    }
		case 2:
			System.out.println("1) add a new category");
			System.out.println("2) view category details");
			System.out.println("3) update category info");
			System.out.println("4) delete a category");
			int choice2 = sc.nextInt();
			if(choice2==1)
			{
				System.out.println("1)Enter product_id :");
				product.setProduct_id(sc.nextInt());
				System.out.println("2)Enter name:");
				product.setName(sc.next());
				System.out.println("3)Enter category_id:");
				product.setCategory_id(sc.nextInt());
				System.out.println("4)Enter price:");
				product.setPrice(sc.nextDouble());
				System.out.println("5)Enter stock_quantity:");
				product.setStock_quantity(sc.nextInt());
				productDAO.createProduct(product);
				System.out.println("product added successfully");
				}
			if(choice2==2)
			{
				 List<Product> allproduct1 = productDAO.getAllProduct();
				  System.out.println("\nAll Categories:"); 
				  for(Product productd : allproduct1) {
				 System.out.println(productd); 
				 }
			}
			if(choice2 == 3)
		    {
		    	System.out.print("Enter Product id: ");
				product.setProduct_id(sc.nextInt());
				
				System.out.print("Enter name: ");
				product.setName(sc.next());
										
				System.out.print("Enter Category id: ");
				product.setCategory_id(sc.nextInt());
				
				System.out.print("Enter Price: ");
				product.setPrice(sc.nextDouble());
				
				System.out.print("Enter Stock quantity: ");
				product.setPrice(sc.nextInt());
				
				productDAO.updateProduct(product);	
				System.out.println("Product details updated successfully");
		    
		    }
		    if(choice2 == 4)
		    {
		    	System.out.print("Enter Product id: ");
				int id = sc.nextInt();
				productDAO.deleteProduct(id);
				System.out.println("Product details deleted successfully");
		    }
		case 3:
			System.out.println("1) add a new category");
			System.out.println("2) view category details");
			System.out.println("3) update category info");
			System.out.println("4) delete a category");
			int choice3 = sc.nextInt();
			if(choice3==1)
			{
				System.out.println("1)Enter inventory_id :");
				inventory.setInventory_id(sc.nextInt());
				System.out.println("2)Enter product_id:");
				inventory.setProduct_id(sc.nextInt());
				System.out.println("3)Enter quantity:");
				inventory.setQuantity(sc.nextInt());
				System.out.print("Enter Enrollment date in (yyyy-mm-dd) format: ");
				String date=sc.next();
				if (!isValidDate(date)) {
		            System.out.println("The date is invalid.");
		            break;
		        }
				//inventory.setInventoryDate(Date.valueOf(date));
				inventory.setDate_added(Date.valueOf(date));
				inventoryDAO.createInventory(inventory);
				System.out.println("inventory added successfully");
				}
			if(choice3==2)
			{
				 List<Inventory> allinventory1 = inventoryDAO.getAllInventory();
				  System.out.println("\nAll Inventories:"); 
				  for(Inventory inventoryd : allinventory1) {
				 System.out.println(inventoryd); 
				 }
			}
			if(choice3 == 3)
		    {
		    	System.out.print("Enter Inventory id: ");
				inventory.setInventory_id(sc.nextInt());
				
				System.out.print("Enter Product id: ");
				inventory.setProduct_id(sc.nextInt());
										
				System.out.print("Enter Quantity: ");
				inventory.setQuantity(sc.nextInt());
				System.out.print("Enter Enrollment date in (yyyy-mm-dd) format: ");
				String date=sc.next();
				if (!isValidDate(date)) {
		            System.out.println("The date is invalid.");
		            break;
		        }
				inventory.setDate_added(Date.valueOf(date));
				
				inventoryDAO.updateInventory(inventory);	
				System.out.println("Inventory details updated successfully");
		    
		    }
		    if(choice3 == 4)
		    {
		    	System.out.print("Enter Inventory id: ");
				int id = sc.nextInt();
				inventoryDAO.deleteInventory(id);
				System.out.println("Product details deleted successfully");
		    }
		}		
		}
	}
}
		
		
		
	
