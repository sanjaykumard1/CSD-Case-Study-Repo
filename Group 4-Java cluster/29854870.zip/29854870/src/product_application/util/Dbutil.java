package product_application.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbutil {
	private static Connection connection= null;
	private static final String URL = "jdbc:mysql://localhost:3306/product_inventory_system";
    private static final String USER = "root";
    private static final String PASSWORD = "Anu@2603";
    public static Connection getConnection() {
    	try {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
       // System.out.println("connection created");
    } catch(Exception e){
    	System.out.println("connection not created");
    }
    	return connection;
    }
   /* public static void main(String[]args) {
    	System.out.println(Dbutil.getConnection());
    }*/
}
