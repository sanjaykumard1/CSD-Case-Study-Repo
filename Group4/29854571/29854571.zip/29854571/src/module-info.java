/**
 * 
 */
/**
 * 
 */
module InsuranceAgencyManagementSystem {
	requires java.sql;
}