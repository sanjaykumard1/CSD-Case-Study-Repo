package com.insuranceagency;

import java.sql.*;
import java.util.Scanner;

public class ClaimManagement {
    private Connection connection;
    private Scanner scanner;

    public ClaimManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void submitClaim() {
        try {
            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter client ID: ");
            int clientId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter claim date (YYYY-MM-DD): ");
            String claimDate = scanner.nextLine();
            String status = "submitted";

            String sql = "INSERT INTO Claim (policy_id, client_id, claim_date, status) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, policyId);
            statement.setInt(2, clientId);
            statement.setDate(3, Date.valueOf(claimDate));
            statement.setString(4, status);
            statement.executeUpdate();
            System.out.println("Claim submitted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewClaim() {
        try {
            System.out.print("Enter claim ID: ");
            int claimId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Claim WHERE claim_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, claimId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Claim ID: " + resultSet.getInt("claim_id"));
                System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
                System.out.println("Client ID: " + resultSet.getInt("client_id"));
                System.out.println("Claim Date: " + resultSet.getDate("claim_date"));
                System.out.println("Status: " + resultSet.getString("status"));
            } else {
                System.out.println("Claim not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateClaim() {
        try {
            System.out.print("Enter claim ID: ");
            int claimId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter new status (submitted/processed): ");
            String status = scanner.nextLine();

            String sql = "UPDATE Claim SET status = ? WHERE claim_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, status);
            statement.setInt(2, claimId);
            statement.executeUpdate();
            System.out.println("Claim updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteClaim() {
        try {
            System.out.print("Enter claim ID: ");
            int claimId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Claim WHERE claim_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, claimId);
            statement.executeUpdate();
            System.out.println("Claim deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
