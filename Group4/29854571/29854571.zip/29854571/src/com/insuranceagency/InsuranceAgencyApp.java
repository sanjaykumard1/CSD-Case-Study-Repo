package com.insuranceagency;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class InsuranceAgencyApp {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            PolicyManagement policyManagement = new PolicyManagement(connection, scanner);
            ClientManagement clientManagement = new ClientManagement(connection, scanner);
            ClaimManagement claimManagement = new ClaimManagement(connection, scanner);

            while (true) {
                System.out.println("Insurance Agency Management System");
                System.out.println("1. Policy Management");
                System.out.println("2. Client Management");
                System.out.println("3. Claim Management");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        managePolicies(policyManagement, scanner);
                        break;
                    case 2:
                        manageClients(clientManagement, scanner);
                        break;
                    case 3:
                        manageClaims(claimManagement, scanner);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
        	
            e.printStackTrace();
        }
    }

    private static void managePolicies(PolicyManagement policyManagement, Scanner scanner) {
        while (true) {
            System.out.println("Policy Management");
            System.out.println("1. Add Policy");
            System.out.println("2. View Policy");
            System.out.println("3. Update Policy");
            System.out.println("4. Delete Policy");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    policyManagement.addPolicy();
                    break;
                case 2:
                    policyManagement.viewPolicy();
                    break;
                case 3:
                    policyManagement.updatePolicy();
                    break;
                case 4:
                    policyManagement.deletePolicy();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageClients(ClientManagement clientManagement, Scanner scanner) {
        while (true) {
            System.out.println("Client Management");
            System.out.println("1. Register Client");
            System.out.println("2. View Client");
            System.out.println("3. Update Client");
            System.out.println("4. Delete Client");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    clientManagement.registerClient();
                    break;
                case 2:
                    clientManagement.viewClient();
                    break;
                case 3:
                    clientManagement.updateClient();
                    break;
                case 4:
                    clientManagement.deleteClient();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageClaims(ClaimManagement claimManagement, Scanner scanner) {
        while (true) {
            System.out.println("Claim Management");
            System.out.println("1. Submit Claim");
            System.out.println("2. View Claim");
            System.out.println("3. Update Claim");
            System.out.println("4. Delete Claim");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    claimManagement.submitClaim();
                    break;
                case 2:
                    claimManagement.viewClaim();
                    break;
                case 3:
                    claimManagement.updateClaim();
                    break;
                case 4:
                    claimManagement.deleteClaim();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
