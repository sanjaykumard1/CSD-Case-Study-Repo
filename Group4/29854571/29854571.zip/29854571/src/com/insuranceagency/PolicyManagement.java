package com.insuranceagency;

import java.sql.*;
import java.util.Scanner;

public class PolicyManagement {
    private Connection connection;
    private Scanner scanner;

    public PolicyManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void addPolicy() {
        try {
            System.out.print("Enter policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter policy type: ");
            String type = scanner.nextLine();
            System.out.print("Enter coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter premium amount: ");
            double premiumAmount = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, policyNumber);
            statement.setString(2, type);
            statement.setDouble(3, coverageAmount);
            statement.setDouble(4, premiumAmount);
            statement.executeUpdate();
            System.out.println("Policy added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPolicy() {
        try {
            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Policy WHERE policy_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, policyId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Policy ID: " + resultSet.getInt("policy_id"));
                System.out.println("Policy Number: " + resultSet.getString("policy_number"));
                System.out.println("Type: " + resultSet.getString("type"));
                System.out.println("Coverage Amount: " + resultSet.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + resultSet.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePolicy() {
        try {
            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new policy number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter new policy type: ");
            String type = scanner.nextLine();
            System.out.print("Enter new coverage amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter new premium amount: ");
            double premiumAmount = scanner.nextDouble();
            scanner.nextLine(); // Consume newline

            String sql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, policyNumber);
            statement.setString(2, type);
            statement.setDouble(3, coverageAmount);
            statement.setDouble(4, premiumAmount);
            statement.setInt(5, policyId);
            statement.executeUpdate();
            System.out.println("Policy updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePolicy() {
        try {
            System.out.print("Enter policy ID: ");
            int policyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Policy WHERE policy_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, policyId);
            statement.executeUpdate();
            System.out.println("Policy deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

