package com.insuranceagency;

import java.sql.*;
import java.util.Scanner;

public class ClientManagement {
    private Connection connection;
    private Scanner scanner;

    public ClientManagement(Connection connection, Scanner scanner) {
        this.connection = connection;
        this.scanner = scanner;
    }

    public void registerClient() {
        try {
            System.out.print("Enter client name: ");
            String name = scanner.nextLine();
            System.out.print("Enter client email: ");
            String email = scanner.nextLine();
            System.out.print("Enter client phone number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter client address: ");
            String address = scanner.nextLine();

            String sql = "INSERT INTO Client (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setString(4, address);
            statement.executeUpdate();
            System.out.println("Client registered successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewClient() {
        try {
            System.out.print("Enter client ID: ");
            int clientId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Client WHERE client_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, clientId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Client ID: " + resultSet.getInt("client_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                System.out.println("Address: " + resultSet.getString("address"));
            } else {
                System.out.println("Client not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateClient() {
        try {
            System.out.print("Enter client ID: ");
            int clientId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new client name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new client email: ");
            String email = scanner.nextLine();
            System.out.print("Enter new client phone number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new client address: ");
            String address = scanner.nextLine();

            String sql = "UPDATE Client SET name = ?, email = ?, phone_number = ?, address = ? WHERE client_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setString(4, address);
            statement.setInt(5, clientId);
            statement.executeUpdate();
            System.out.println("Client updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteClient() {
        try {
            System.out.print("Enter client ID: ");
            int clientId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Client WHERE client_id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, clientId);
            statement.executeUpdate();
            System.out.println("Client deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
