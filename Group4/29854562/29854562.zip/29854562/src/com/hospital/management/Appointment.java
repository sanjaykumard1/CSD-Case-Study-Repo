package com.hospital.management;

import java.sql.*;
import java.util.Scanner;

public class Appointment {
    private int appointment_id;
    private int doctor_id;
    private int patient_id;
    private Date appointment_date;
    private Time appointment_time;

    public Appointment() {}

    public Appointment(int appointment_id, int doctor_id, int patient_id, Date appointment_date, Time appointment_time) {
        this.appointment_id = appointment_id;
        this.doctor_id = doctor_id;
        this.patient_id = patient_id;
        this.appointment_date = appointment_date;
        this.appointment_time = appointment_time;
    }

    public void scheduleAppointment() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "INSERT INTO Appointment (doctor_id, patient_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Doctor ID:");
            int doctorId = scanner.nextInt();
            System.out.println("Enter Patient ID:");
            int patientId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter Appointment Date (YYYY-MM-DD):");
            String date = scanner.nextLine();
            System.out.println("Enter Appointment Time (HH:MM:SS):");
            String time = scanner.nextLine();

            // Add validation for doctor and patient availability here

            preparedStatement.setInt(1, doctorId);
            preparedStatement.setInt(2, patientId);
            preparedStatement.setDate(3, Date.valueOf(date));
            preparedStatement.setTime(4, Time.valueOf(time));
            preparedStatement.executeUpdate();
            System.out.println("Appointment scheduled successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAppointments() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "SELECT * FROM Appointment";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                System.out.println("Appointment ID: " + resultSet.getInt("appointment_id"));
                System.out.println("Doctor ID: " + resultSet.getInt("doctor_id"));
                System.out.println("Patient ID: " + resultSet.getInt("patient_id"));
                System.out.println("Appointment Date: " + resultSet.getDate("appointment_date"));
                System.out.println("Appointment Time: " + resultSet.getTime("appointment_time"));
                System.out.println("------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAppointment() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "UPDATE Appointment SET doctor_id = ?, patient_id = ?, appointment_date = ?, appointment_time = ? WHERE appointment_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Appointment ID to Update:");
            int id = scanner.nextInt();
            System.out.println("Enter New Doctor ID:");
            int doctorId = scanner.nextInt();
            System.out.println("Enter New Patient ID:");
            int patientId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter New Appointment Date (YYYY-MM-DD):");
            String date = scanner.nextLine();
            System.out.println("Enter New Appointment Time (HH:MM:SS):");
            String time = scanner.nextLine();

            preparedStatement.setInt(1, doctorId);
            preparedStatement.setInt(2, patientId);
            preparedStatement.setDate(3, Date.valueOf(date));
            preparedStatement.setTime(4, Time.valueOf(time));
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
            System.out.println("Appointment updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAppointment() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "DELETE FROM Appointment WHERE appointment_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Appointment ID to Delete:");
            int id = scanner.nextInt();

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Appointment deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
