package com.hospital.management;


import java.sql.*;
import java.util.Scanner;

public class Doctor {
    private int doctor_id;
    private String name;
    private String specialization;
    private String contact_number;

    public Doctor() {}

    public Doctor(int doctor_id, String name, String specialization, String contact_number) {
        this.doctor_id = doctor_id;
        this.name = name;
        this.specialization = specialization;
        this.contact_number = contact_number;
    }

    // CRUD operations
    public void addDoctor() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "INSERT INTO Doctor (name, specialization, contact_number) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Doctor Name:");
            String name = scanner.nextLine();
            System.out.println("Enter Specialization:");
            String specialization = scanner.nextLine();
            System.out.println("Enter Contact Number:");
            String contact = scanner.nextLine();

            preparedStatement.setString(1, name);
            preparedStatement.setString(2, specialization);
            preparedStatement.setString(3, contact);
            preparedStatement.executeUpdate();
            System.out.println("Doctor added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewDoctor() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "SELECT * FROM Doctor";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                System.out.println("Doctor ID: " + resultSet.getInt("doctor_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Specialization: " + resultSet.getString("specialization"));
                System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                System.out.println("------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDoctor() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "UPDATE Doctor SET name = ?, specialization = ?, contact_number = ? WHERE doctor_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Doctor ID to Update:");
            int id = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter New Name:");
            String name = scanner.nextLine();
            System.out.println("Enter New Specialization:");
            String specialization = scanner.nextLine();
            System.out.println("Enter New Contact Number:");
            String contact = scanner.nextLine();

            preparedStatement.setString(1, name);
            preparedStatement.setString(2, specialization);
            preparedStatement.setString(3, contact);
            preparedStatement.setInt(4, id);
            preparedStatement.executeUpdate();
            System.out.println("Doctor updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDoctor() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "DELETE FROM Doctor WHERE doctor_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Doctor ID to Delete:");
            int id = scanner.nextInt();

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Doctor deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
