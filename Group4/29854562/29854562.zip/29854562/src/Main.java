import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Patient patient = new Patient();
        Doctor doctor = new Doctor();
        Appointment appointment = new Appointment();

        while (true) {
            System.out.println("1. Patient Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Appointment Scheduling");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("1. Add Patient");
                    System.out.println("2. View Patients");
                    System.out.println("3. Update Patient");
                    System.out.println("4. Delete Patient");
                    System.out.print("Enter your choice: ");
                    int patientChoice = scanner.nextInt();
                    switch (patientChoice) {
                        case 1:
                            patient.addPatient();
                            break;
                        case 2:
                            patient.viewPatient();
                            break;
                        case 3:
                            patient.updatePatient();
                            break;
                        case 4:
                            patient.deletePatient();
                            break;
                    }
                    break;
                case 2:
                    System.out.println("1. Add Doctor");
                    System.out.println("2. View Doctors");
                    System.out.println("3. Update Doctor");
                    System.out.println("4. Delete Doctor");
                    System.out.print("Enter your choice: ");
                    int doctorChoice = scanner.nextInt();
                    switch (doctorChoice) {
                        case 1:
                            doctor.addDoctor();
                            break;
                        case 2:
                            doctor.viewDoctor();
                            break;
                        case 3:
                            doctor.updateDoctor();
                            break;
                        case 4:
                            doctor.deleteDoctor();
                            break;
                    }
                    break;
                case 3:
                    System.out.println("1. Schedule Appointment");
                    System.out.println("2. View Appointments");
                    System.out.println("3. Update Appointment");
                    System.out.println("4. Delete Appointment");
                    System.out.print("Enter your choice: ");
                    int appointmentChoice = scanner.nextInt();
                    switch (appointmentChoice) {
                        case 1:
                            appointment.scheduleAppointment();
                            break;
                        case 2:
                            appointment.viewAppointments();
                            break;
                        case 3:
                            appointment.updateAppointment();
                            break;
                        case 4:
                            appointment.deleteAppointment();
                            break;
                    }
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
