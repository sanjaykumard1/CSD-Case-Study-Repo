import java.sql.*;
import java.util.Scanner;

public class Patient {
    private int patient_id;
    private String name;
    private Date date_of_birth;
    private String gender;
    private String contact_number;

    

    public Patient(int patient_id, String name, Date date_of_birth, String gender, String contact_number) {
        this.patient_id = patient_id;
        this.name = name;
        this.date_of_birth = date_of_birth;
        this.gender = gender;
        this.contact_number = contact_number;
    }

    // CRUD operations
    public void addPatient() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "INSERT INTO Patient (name, date_of_birth, gender, contact_number) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Patient Name:");
            String name = scanner.nextLine();
            System.out.println("Enter Date of Birth (YYYY-MM-DD):");
            String dob = scanner.nextLine();
            System.out.println("Enter Gender:");
            String gender = scanner.nextLine();
            System.out.println("Enter Contact Number:");
            String contact = scanner.nextLine();

            preparedStatement.setString(1, name);
            preparedStatement.setDate(2, Date.valueOf(dob));
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, contact);
            preparedStatement.executeUpdate();
            System.out.println("Patient added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPatient() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "SELECT * FROM Patient";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                System.out.println("Patient ID: " + resultSet.getInt("patient_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Date of Birth: " + resultSet.getDate("date_of_birth"));
                System.out.println("Gender: " + resultSet.getString("gender"));
                System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                System.out.println("------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePatient() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "UPDATE Patient SET name = ?, date_of_birth = ?, gender = ?, contact_number = ? WHERE patient_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Patient ID to Update:");
            int id = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter New Name:");
            String name = scanner.nextLine();
            System.out.println("Enter New Date of Birth (YYYY-MM-DD):");
            String dob = scanner.nextLine();
            System.out.println("Enter New Gender:");
            String gender = scanner.nextLine();
            System.out.println("Enter New Contact Number:");
            String contact = scanner.nextLine();

            preparedStatement.setString(1, name);
            preparedStatement.setDate(2, Date.valueOf(dob));
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, contact);
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
            System.out.println("Patient updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePatient() {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "DELETE FROM Patient WHERE patient_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter Patient ID to Delete:");
            int id = scanner.nextInt();

            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Patient deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
