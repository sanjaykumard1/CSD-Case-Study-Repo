package com.example.carservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AppointmentManager {
    private Connection connection;

    public AppointmentManager(Connection connection) {
        this.connection = connection;
    }

    public void scheduleAppointment(int customerId, int serviceId, String appointmentDate, String appointmentTime) throws SQLException {
        String sql = "INSERT INTO Appointment (customer_id, service_id, appointment_date, appointment_time) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            statement.setString(3, appointmentDate);
            statement.setString(4, appointmentTime);
            statement.executeUpdate();
            System.out.println("Appointment scheduled successfully.");
        }
    }

    public List<Appointment> getAppointments() throws SQLException {
        String sql = "SELECT * FROM Appointment";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {
            List<Appointment> appointments = new ArrayList<>();
            while (resultSet.next()) {
                int appointmentId = resultSet.getInt("appointment_id");
                int customerId = resultSet.getInt("customer_id");
                int serviceId = resultSet.getInt("service_id");
                String appointmentDate = resultSet.getString("appointment_date");
                String appointmentTime = resultSet.getString("appointment_time");
                Appointment appointment = new Appointment(appointmentId, customerId, serviceId, appointmentDate, appointmentTime);
                appointments.add(appointment);
            }
            return appointments;
        }
    }

    public void updateAppointment(int appointmentId, int customerId, int serviceId, String appointmentDate, String appointmentTime) throws SQLException {
        String sql = "UPDATE Appointment SET customer_id = ?, service_id = ?, appointment_date = ?, appointment_time = ? WHERE appointment_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            statement.setString(3, appointmentDate);
            statement.setString(4, appointmentTime);
            statement.setInt(5, appointmentId);
            statement.executeUpdate();
            System.out.println("Appointment updated successfully.");
        }
    }

    public void cancelAppointment(int appointmentId) throws SQLException {
        String sql = "DELETE FROM Appointment WHERE appointment_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, appointmentId);
            statement.executeUpdate();
            System.out.println("Appointment canceled successfully.");
        }
    }
}
