package com.example.carservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceManager {
    private Connection connection;

    public ServiceManager(Connection connection) {
        this.connection = connection;
    }

    public void addService(String serviceName, String description, int duration, double price) throws SQLException {
        String sql = "INSERT INTO Service (service_name, description, duration, price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, serviceName);
            statement.setString(2, description);
            statement.setInt(3, duration);
            statement.setDouble(4, price);
            statement.executeUpdate();
            System.out.println("Service added successfully.");
        }
    }

    public List<Service> getServices() throws SQLException {
        String sql = "SELECT * FROM Service";
        try (PreparedStatement statement = connection.prepareStatement(sql); ResultSet resultSet = statement.executeQuery()) {
            List<Service> services = new ArrayList<>();
            while (resultSet.next()) {
                int serviceId = resultSet.getInt("service_id");
                String serviceName = resultSet.getString("service_name");
                String description = resultSet.getString("description");
                int duration = resultSet.getInt("duration");
                double price = resultSet.getDouble("price");
                Service service = new Service(serviceId, serviceName, description, duration, price);
                services.add(service);
            }
            return services;
        }
    }

    public void updateService(int serviceId, String serviceName, String description, int duration, double price) throws SQLException {
        String sql = "UPDATE Service SET service_name = ?, description = ?, duration = ?, price = ? WHERE service_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, serviceName);
            statement.setString(2, description);
            statement.setInt(3, duration);
            statement.setDouble(4, price);
            statement.setInt(5, serviceId);
            statement.executeUpdate();
            System.out.println("Service updated successfully.");
        }
    }

    public void deleteService(int serviceId) throws SQLException {
        String sql = "DELETE FROM Service WHERE service_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, serviceId);
            statement.executeUpdate();
            System.out.println("Service deleted successfully.");
        }
    }
}
