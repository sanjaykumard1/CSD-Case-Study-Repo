package com.example.carservice;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerManager {
    private Connection connection;

    public CustomerManager(Connection connection) {
        this.connection = connection;
    }

    public int createCustomer(String customerName, String email, String phoneNumber) throws SQLException {
        String sql = "INSERT INTO customer (customer_name, email, phone_number) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, customerName);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.executeUpdate();

            ResultSet generatedKeys = statement.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1); 
            } else {
                throw new SQLException("Creating customer failed, no ID obtained.");
            }
        }
    }

    public List<Customer> getCustomers() throws SQLException {
        String sql = "SELECT * FROM customer";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            List<Customer> customers = new ArrayList<>();
            while (resultSet.next()) {
                int customerId = resultSet.getInt("customer_id");
                String customerName = resultSet.getString("customer_name");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");
                Customer customer = new Customer(customerId, customerName, email, phoneNumber);
                customers.add(customer);
            }
            return customers;
        }
    }

    public void updateCustomer(int customerId, String customerName, String email, String phoneNumber) throws SQLException {
        String sql = "UPDATE customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customerName);
            statement.setString(2, email);
            statement.setString(3, phoneNumber);
            statement.setInt(4, customerId);
            statement.executeUpdate();
            System.out.println("Customer updated successfully.");
        }
    }

    public void deleteCustomer(int customerId) throws SQLException {
        String sql = "DELETE FROM customer WHERE customer_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, customerId);
            statement.executeUpdate();
            System.out.println("Customer deleted successfully.");
        }
    }
}
