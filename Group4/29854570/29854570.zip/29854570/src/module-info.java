/**
 * 
 */
/**
 * 
 */
module CarServiceAppointment {
	requires java.sql;
}