package com.example.carservice;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            CustomerManager customerManager = new CustomerManager(connection);
            ServiceManager serviceManager = new ServiceManager(connection);
            AppointmentManager appointmentManager = new AppointmentManager(connection);

            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                System.out.println("1. Register Customer");
                System.out.println("2. Add Service");
                System.out.println("3. Schedule Appointment");
                System.out.println("4. View Customers");
                System.out.println("5. View Services");
                System.out.println("6. View Appointments");
                System.out.println("7. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter customer name: ");
                        scanner.nextLine(); 
                        String customerName = scanner.nextLine();
                        System.out.print("Enter email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter phone number: ");
                        String phoneNumber = scanner.nextLine();
                        try {
                            int customerId = customerManager.createCustomer(customerName, email, phoneNumber);
                            System.out.println("Customer registered with ID: " + customerId);
                        } catch (SQLException e) {
                            System.err.println("Error registering customer: " + e.getMessage());
                        }
                        break;
                    case 2:
                        System.out.print("Enter service name: ");
                        scanner.nextLine(); // Consume newline character
                        String serviceName = scanner.nextLine();
                        System.out.print("Enter description: ");
                        String description = scanner.nextLine();
                        System.out.print("Enter duration (in minutes): ");
                        int duration = scanner.nextInt();
                        System.out.print("Enter price: ");
                        double price = scanner.nextDouble();
                        try {
                            serviceManager.addService(serviceName, description, duration, price);
                            System.out.println("Service added successfully.");
                        } catch (SQLException e) {
                            System.err.println("Error adding service: " + e.getMessage());
                        }
                        break;
                    case 3:
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        System.out.print("Enter service ID: ");
                        int serviceId = scanner.nextInt();
                        scanner.nextLine(); // Consume newline character
                        System.out.print("Enter appointment date (YYYY-MM-DD): ");
                        String appointmentDate = scanner.nextLine();
                        System.out.print("Enter appointment time (HH:MM): ");
                        String appointmentTime = scanner.nextLine();
                        try {
                            appointmentManager.scheduleAppointment(customerId, serviceId, appointmentDate, appointmentTime);
                            System.out.println("Appointment scheduled successfully.");
                        } catch (SQLException e) {
                            System.err.println("Error scheduling appointment: " + e.getMessage());
                        }
                        break;
                    case 4:
                        try {
                            List<Customer> customers = customerManager.getCustomers();
                            for (Customer customer : customers) {
                                System.out.println(customer);
                            }
                        } catch (SQLException e) {
                            System.err.println("Error fetching customers: " + e.getMessage());
                        }
                        break;
                    case 5:
                        try {
                            List<Service> services = serviceManager.getServices();
                            for (Service service : services) {
                                System.out.println(service);
                            }
                        } catch (SQLException e) {
                            System.err.println("Error fetching services: " + e.getMessage());
                        }
                        break;
                    case 6:
                        try {
                            List<Appointment> appointments = appointmentManager.getAppointments();
                            for (Appointment appointment : appointments) {
                                System.out.println(appointment);
                            }
                        } catch (SQLException e) {
                            System.err.println("Error fetching appointments: " + e.getMessage());
                        }
                        break;
                    case 7:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 7.");
                        break;
                }
            } while (choice != 7);

        } catch (SQLException e) {
            System.err.println("Error connecting to database: " + e.getMessage());
        }
    }
}
