package com.courier_management;
import java.sql.*;
import java.util.Scanner;

public class ParcelManagement {

    // Menu to handle parcel management options
    public static void handleParcelManagement(Scanner scanner) {
        while (true) {
            System.out.println("\nParcel Management");
            System.out.println("1. Add New Parcel");
            System.out.println("2. View Parcel Details");
            System.out.println("3. Update Parcel Information");
            System.out.println("4. Delete Parcel");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewParcel(scanner);
                    break;
                case 2:
                    viewParcelDetails(scanner);
                    break;
                case 3:
                    updateParcelInformation(scanner);
                    break;
                case 4:
                    deleteParcel(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Function to add new parcel
    private static void addNewParcel(Scanner scanner) {
        System.out.print("Enter sender name: ");
        String senderName = scanner.nextLine();
        System.out.print("Enter sender address: ");
        String senderAddress = scanner.nextLine();
        System.out.print("Enter recipient name: ");
        String recipientName = scanner.nextLine();
        System.out.print("Enter recipient address: ");
        String recipientAddress = scanner.nextLine();
        System.out.print("Enter weight: ");
        double weight = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter status (Scheduled, In Transit, Delivered): ");
        String status = scanner.nextLine();

        String query = "INSERT INTO Parcel (sender_name, sender_address, recipient_name, recipient_address, weight, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, senderName);
            pstmt.setString(2, senderAddress);
            pstmt.setString(3, recipientName);
            pstmt.setString(4, recipientAddress);
            pstmt.setDouble(5, weight);
            pstmt.setString(6, status);
            pstmt.executeUpdate();
            System.out.println("Parcel added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding parcel: " + e.getMessage());
        }
    }

    // Function to view parcel details
    private static void viewParcelDetails(Scanner scanner) {
        System.out.print("Enter parcel ID: ");
        int parcelId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Parcel WHERE parcel_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Parcel ID: " + rs.getInt("parcel_id"));
                System.out.println("Sender Name: " + rs.getString("sender_name"));
                System.out.println("Sender Address: " + rs.getString("sender_address"));
                System.out.println("Recipient Name: " + rs.getString("recipient_name"));
                System.out.println("Recipient Address: " + rs.getString("recipient_address"));
                System.out.println("Weight: " + rs.getDouble("weight"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Parcel not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving parcel details: " + e.getMessage());
        }
    }

    // Function to update parcel information
    private static void updateParcelInformation(Scanner scanner) {
        System.out.print("Enter parcel ID: ");
        int parcelId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new sender name: ");
        String senderName = scanner.nextLine();
        System.out.print("Enter new sender address: ");
        String senderAddress = scanner.nextLine();
        System.out.print("Enter new recipient name: ");
        String recipientName = scanner.nextLine();
        System.out.print("Enter new recipient address: ");
        String recipientAddress = scanner.nextLine();
        System.out.print("Enter new weight: ");
        double weight = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new status (Scheduled, In Transit, Delivered): ");
        String status = scanner.nextLine();

        String query = "UPDATE Parcel SET sender_name = ?, sender_address = ?, recipient_name = ?, recipient_address = ?, weight = ?, status = ? WHERE parcel_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, senderName);
            pstmt.setString(2, senderAddress);
            pstmt.setString(3, recipientName);
            pstmt.setString(4, recipientAddress);
            pstmt.setDouble(5, weight);
            pstmt.setString(6, status);
            pstmt.setInt(7, parcelId);
            pstmt.executeUpdate();
            System.out.println("Parcel updated successfully.");
        } catch (SQLException e) {
            System.out.println("Error updating parcel: " + e.getMessage());
        }
    }

    // Function to delete parcel
    private static void deleteParcel(Scanner scanner) {
        System.out.print("Enter parcel ID: ");
        int parcelId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM Parcel WHERE parcel_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            pstmt.executeUpdate();
            System.out.println("Parcel deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting parcel: " + e.getMessage());
        }
    }
}

