package com.courier_management;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Courier Service Management System");
            System.out.println("1. Parcel Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Delivery Operations");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    ParcelManagement.handleParcelManagement(scanner);
                    break;
                case 2:
                    CustomerManagement.handleCustomerManagement(scanner);
                    break;
                case 3:
                    DeliveryManagement.handleDeliveryOperations(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
