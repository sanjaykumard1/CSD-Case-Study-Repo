package com.courier_management;
import java.sql.*;
import java.util.Scanner;

public class DeliveryManagement {

    // Menu to handle delivery operations
    public static void handleDeliveryOperations(Scanner scanner) {
        while (true) {
            System.out.println("\nDelivery Operations");
            System.out.println("1. Schedule Parcel Delivery");
            System.out.println("2. Update Delivery Status");
            System.out.println("3. View Delivery History");
            System.out.println("4. Calculate Delivery Cost");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    scheduleParcelDelivery(scanner);
                    break;
                case 2:
                    updateDeliveryStatus(scanner);
                    break;
                case 3:
                    viewDeliveryHistory(scanner);
                    break;
                case 4:
                    calculateDeliveryCost(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    // Function to schedule parcel delivery
    private static void scheduleParcelDelivery(Scanner scanner) {
        System.out.print("Enter parcel ID: ");
        int parcelId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter delivery date (YYYY-MM-DD): ");
        String deliveryDate = scanner.nextLine();
        System.out.print("Enter delivery status: ");
        String deliveryStatus = scanner.nextLine();
        System.out.print("Enter delivery cost: ");
        double deliveryCost = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        String query = "INSERT INTO Delivery (parcel_id, customer_id, delivery_date, delivery_status, delivery_cost) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, parcelId);
            pstmt.setInt(2, customerId);
            pstmt.setDate(3, Date.valueOf(deliveryDate));
            pstmt.setString(4, deliveryStatus);
            pstmt.setDouble(5, deliveryCost);
            pstmt.executeUpdate();
            System.out.println("Parcel delivery scheduled successfully.");
        } catch (SQLException e) {
            System.out.println("Error scheduling parcel delivery: " + e.getMessage());
        }
    }

    // Function to update delivery status
    private static void updateDeliveryStatus(Scanner scanner) {
        System.out.print("Enter delivery ID: ");
        int deliveryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new delivery status: ");
        String deliveryStatus = scanner.nextLine();

        String query = "UPDATE Delivery SET delivery_status = ? WHERE delivery_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, deliveryStatus);
            pstmt.setInt(2, deliveryId);
            pstmt.executeUpdate();
            System.out.println("Delivery status updated successfully.");
        } catch (SQLException e) {
            System.out.println("Error updating delivery status: " + e.getMessage());
        }
    }

    // Function to view delivery history
    private static void viewDeliveryHistory(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Delivery WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Delivery ID: " + rs.getInt("delivery_id"));
                System.out.println("Parcel ID: " + rs.getInt("parcel_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Delivery Date: " + rs.getDate("delivery_date"));
                System.out.println("Delivery Status: " + rs.getString("delivery_status"));
                System.out.println("Delivery Cost: " + rs.getDouble("delivery_cost"));
                System.out.println("-------------------------------------------------");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving delivery history: " + e.getMessage());
        }
    }

    // Function to calculate delivery cost
    private static void calculateDeliveryCost(Scanner scanner) {
        System.out.print("Enter delivery ID: ");
        int deliveryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT delivery_cost FROM Delivery WHERE delivery_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, deliveryId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                double deliveryCost = rs.getDouble("delivery_cost");
                System.out.println("Delivery Cost: " + deliveryCost);
            } else {
                System.out.println("Delivery not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error calculating delivery cost: " + e.getMessage());
        }
    }
}
