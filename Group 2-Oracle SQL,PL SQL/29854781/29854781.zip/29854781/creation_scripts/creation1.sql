-----1.	ProductionOrders Table:
----o	ORDER_ID: Number, Primary Key
--o	PRODUCT_ID: Number
--o	ORDER_DATE: Date
--o	QUANTITY: Number
--o	STATUS: Varchar2(50)


CREATE TABLE ProductionOrders(ORDER_ID NUMBER PRIMARY KEY, 
PRODUCT_ID NUMBER, 
ORDER_DATE DATE, 
QUANTITY NUMBER, 
STATUS VARCHAR2(50));


-- 2.	ProductionProgress Table:
-- o	LOG_ID: Number, Primary Key
-- o	ORDER_ID: Number, Foreign Key References ProductionOrders(ORDER_ID)
-- o	STAGE: Varchar2(50)
-- o	LOG_DATE: Date
-- o	NOTES: Varchar2(255)


CREATE TABLE ProductionProgress(LOG_ID NUMBER, 
ORDER_ID NUMBER,
STAGE VARCHAR2(50),
LOG_DATE DATE,
NOTES Varchar2(50),
Foreign key(ORDER_ID) References ProductionOrders(ORDER_ID));


select * from productionProgress;

-- 3.	ProductionOutputs Table:
-- o	OUTPUT_ID: Number, Primary Key
-- o	ORDER_ID: Number, Foreign Key References ProductionOrders(ORDER_ID)
-- o	OUTPUT_DATE: Date
-- o	QUANTITY_PRODUCED: Number
-- o	QUALITY_STATUS: Varchar2(50)


CREATE TABLE ProductionOutputs (
    OUTPUT_ID NUMBER PRIMARY KEY,
    ORDER_ID NUMBER,
    OUTPUT_DATE DATE,
    QUANTITY_PRODUCED NUMBER,
    QUALITY_STATUS VARCHAR2(50),
    FOREIGN KEY (ORDER_ID) REFERENCES ProductionOrders(ORDER_ID)
);


select * from PRODUCTIONOUTPUTS;



