
INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (3, 1, 'In Progress', '03-JUL-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (4, 1, 'In Progress', '05-JUL-2023', 'Quality check started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (5, 2, 'In Progress', '07-JUL-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (6, 2, 'Completed', '10-JUL-2023', 'Quality check completed');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (7, 3, 'Started', '11-JUL-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (8, 3, 'In Progress', '12-JUL-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (9, 4, 'Started', '16-JUL-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (10, 4, 'In Progress', '17-JUL-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (11, 5, 'Started', '21-JUL-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (12, 5, 'In Progress', '22-JUL-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (13, 6, 'Started', '26-JUL-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (14, 6, 'Cancelled', '27-JUL-2023', 'Order cancelled');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (15, 7, 'Started', '31-JUL-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (16, 7, 'In Progress', '01-AUG-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (17, 8, 'Started', '06-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (18, 8, 'In Progress', '07-AUG-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (19, 9, 'Started', '11-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (20, 9, 'In Progress', '12-AUG-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (21, 10, 'Started', '16-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (22, 10, 'Cancelled', '17-AUG-2023', 'Order cancelled');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (23, 11, 'Started', '21-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (24, 11, 'In Progress', '22-AUG-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (25, 12, 'Started', '26-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (26, 12, 'In Progress', '27-AUG-2023', 'Assembly started');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (27, 13, 'Started', '31-AUG-2023', 'Initial ');

INSERT INTO ProductionProgress (LOG_ID, ORDER_ID, STAGE, LOG_DATE, NOTES)
VALUES (28, 13, 'In Progress', '01-SEP-2023', 'Assembly started');
