create or replace NONEDITIONABLE PROCEDURE PRODUCTION_PROGRESS 
(
  P_LOG_ID IN NUMBER 
, P_ORDER_ID IN NUMBER 
, P_STAGE IN VARCHAR2 
, P_LOG_DATE IN DATE 
, P_NOTES IN VARCHAR2 
) AS 
BEGIN
    INSERT INTO productionprogress(LOG_ID, ORDER_ID, STAGE,LOG_DATE,NOTES)
    VALUES (p_log_id, p_order_id, p_stage, p_log_date, p_notes);
    
    UPDATE productionorders
    SET status = p_stage
    WHERE  order_id = p_order_id;
    
END PRODUCTION_PROGRESS;