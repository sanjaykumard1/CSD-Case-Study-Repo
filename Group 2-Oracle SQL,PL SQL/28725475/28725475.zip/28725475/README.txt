Install and Open Oracle SQL Developer.
Open the Files SQL query and Insert statement files.
Execute them to create tables and insert values.
Now open the procedures file run the procedures.
Execute them based on the requirement.