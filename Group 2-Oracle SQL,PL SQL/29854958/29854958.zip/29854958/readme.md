# Case Study Report

This repository contains the case study report documenting the database schema creation, data insertion, and PL/SQL procedures for managing employee and department data.

## Files

- `case study report.docx`: The main document containing the SQL and PL/SQL code for the case study.

## Content Overview

### 1. Creation of Tables

The document includes SQL scripts for creating the following tables:
- `Department`
- `Employee`
- `Employee_Assignment`

### 2. Inserting Data

SQL scripts for inserting sample data into the tables:
- Sample departments
- Sample employees
- Sample employee assignments

### 3. Displaying Tables

SQL scripts for displaying the contents of the tables:
- `Department`
- `Employee`
- `Employee_Assignment`

### 4. Creating Procedures in PL/SQL

PL/SQL procedures for managing employees:
- `transfer_employee`: Procedure to transfer an employee to a new department.
- `promote_employee`: Procedure to promote an employee with a new job ID and salary.

### 5. Testing Procedures

Examples of how to test the `transfer_employee` and `promote_employee` procedures, along with verification queries.

## Usage

1. **Clone the repository**:
    ```bash
    git clone https://github.com/yourusername/case-study-report.git
    ```

2. **Open the document**:
    - Open `case study report.docx` to view the SQL and PL/SQL code.

3. **Run SQL and PL/SQL scripts**:
    - Use your preferred SQL client to execute the scripts provided in the document.

## License

This project is licensed under the MIT License.
