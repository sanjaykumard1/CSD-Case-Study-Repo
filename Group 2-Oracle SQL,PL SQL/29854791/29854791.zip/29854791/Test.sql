-- Adding Products
BEGIN
    add_product(3, 'Product 3', 'Description of Product 3', 30.00, 300);
END;
/
-- Verifying added product
SELECT * FROM Products WHERE PRODUCT_ID = 3;

-- Updating a Product
BEGIN
    update_product(1, 'Updated Product 1', 'Updated Description of Product 1', 15.00, 150);
END;
/
-- Verifying updated product
SELECT * FROM Products WHERE PRODUCT_ID = 1;

-- Deleting a Product
BEGIN
    delete_product(2);
END;
/
-- Verifying deleted product
SELECT * FROM Products WHERE PRODUCT_ID = 2;

-- Adding a Customer
BEGIN
    add_customer(3, 'Alice', 'Johnson', 'alice.johnson@example.com', '1112223333');
END;
/
-- Verifying added customer
SELECT * FROM Customers WHERE CUSTOMER_ID = 3;

-- Processing an Order
BEGIN
    process_order(1, 3, 1, 10, SYSDATE, 'Pending');
END;
/
-- Verifying processed order
SELECT * FROM Orders WHERE ORDER_ID = 1;

-- Verifying updated product inventory
SELECT * FROM Products WHERE PRODUCT_ID = 1;

-- Verifying updated inventory table
SELECT * FROM Inventory WHERE PRODUCT_ID = 1;

