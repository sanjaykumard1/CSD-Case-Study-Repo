-- Procedure to Process an Order
CREATE OR REPLACE PROCEDURE process_order(
    p_order_id NUMBER,
    p_customer_id NUMBER,
    p_product_id NUMBER,
    p_quantity NUMBER,
    p_order_date DATE,
    p_status VARCHAR2
) IS
BEGIN
    INSERT INTO Orders (ORDER_ID, CUSTOMER_ID, PRODUCT_ID, QUANTITY, ORDER_DATE, STATUS)
    VALUES (p_order_id, p_customer_id, p_product_id, p_quantity, p_order_date, p_status);

    UPDATE Products
    SET AVAILABLE_QUANTITY = AVAILABLE_QUANTITY - p_quantity
    WHERE PRODUCT_ID = p_product_id;

    UPDATE Inventory
    SET AVAILABLE_QUANTITY = AVAILABLE_QUANTITY - p_quantity
    WHERE PRODUCT_ID = p_product_id;
END process_order;
