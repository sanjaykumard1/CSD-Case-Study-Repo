-- Create Products Table
CREATE TABLE Products (
    PRODUCT_ID NUMBER PRIMARY KEY,
    NAME VARCHAR2(100),
    DESCRIPTION CLOB,
    PRICE NUMBER,
    AVAILABLE_QUANTITY NUMBER
);

-- Create Customers Table
CREATE TABLE Customers (
    CUSTOMER_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    EMAIL VARCHAR2(100),
    PHONE_NUMBER VARCHAR2(15)
);

-- Create Orders Table
CREATE TABLE Orders (
    ORDER_ID NUMBER PRIMARY KEY,
    CUSTOMER_ID NUMBER,
    PRODUCT_ID NUMBER,
    QUANTITY NUMBER,
    ORDER_DATE DATE,
    STATUS VARCHAR2(50),
    FOREIGN KEY (CUSTOMER_ID) REFERENCES Customers(CUSTOMER_ID),
    FOREIGN KEY (PRODUCT_ID) REFERENCES Products(PRODUCT_ID)
);

-- Create Inventory Table 
CREATE TABLE Inventory (
    PRODUCT_ID NUMBER PRIMARY KEY,
    NAME VARCHAR2(100),
    DESCRIPTION CLOB,
    PRICE NUMBER,
    AVAILABLE_QUANTITY NUMBER
);
-- Insert sample data into Products Table
INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, AVAILABLE_QUANTITY)
VALUES (1, 'Product 1', 'Description of Product 1', 10.00, 100);
INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, AVAILABLE_QUANTITY)
VALUES (2, 'Product 2', 'Description of Product 2', 20.00, 200);

-- Insert sample data into Customers Table
INSERT INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER)
VALUES (1, 'John', 'Doe', 'john.doe@example.com', '1234567890');
INSERT INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER)
VALUES (2, 'Jane', 'Smith', 'jane.smith@example.com', '0987654321');

-- Insert sample data into Inventory Table
INSERT INTO Inventory (PRODUCT_ID, NAME, DESCRIPTION, PRICE, AVAILABLE_QUANTITY)
VALUES (1, 'Product 1', 'Description of Product 1', 10.00, 100);
INSERT INTO Inventory (PRODUCT_ID, NAME, DESCRIPTION, PRICE, AVAILABLE_QUANTITY)
VALUES (2, 'Product 2', 'Description of Product 2', 20.00, 200);
