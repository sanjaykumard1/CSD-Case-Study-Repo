-- Procedure to Add a Product
CREATE OR REPLACE PROCEDURE add_product(
    p_product_id NUMBER,
    p_name VARCHAR2,
    p_description CLOB,
    p_price NUMBER,
    p_available_quantity NUMBER
) IS
BEGIN
    INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, AVAILABLE_QUANTITY)
    VALUES (p_product_id, p_name, p_description, p_price, p_available_quantity);
END add_product;

-- Procedure to Update a Product
CREATE OR REPLACE PROCEDURE update_product(
    p_product_id NUMBER,
    p_name VARCHAR2,
    p_description CLOB,
    p_price NUMBER,
    p_available_quantity NUMBER
) IS
BEGIN
    UPDATE Products
    SET NAME = p_name,
        DESCRIPTION = p_description,
        PRICE = p_price,
        AVAILABLE_QUANTITY = p_available_quantity
    WHERE PRODUCT_ID = p_product_id;
END update_product;

-- Procedure to Delete a Product
CREATE OR REPLACE PROCEDURE delete_product(p_product_id NUMBER) IS
BEGIN
    DELETE FROM Products WHERE PRODUCT_ID = p_product_id;
END delete_product;
