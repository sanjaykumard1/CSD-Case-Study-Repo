-- Procedure to Add a Customer
CREATE OR REPLACE PROCEDURE add_customer(
    p_customer_id NUMBER,
    p_first_name VARCHAR2,
    p_last_name VARCHAR2,
    p_email VARCHAR2,
    p_phone_number VARCHAR2
) IS
BEGIN
    INSERT INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER)
    VALUES (p_customer_id, p_first_name, p_last_name, p_email, p_phone_number);
END add_customer;

-- Procedure to Update a Customer
CREATE OR REPLACE PROCEDURE update_customer(
    p_customer_id NUMBER,
    p_first_name VARCHAR2,
    p_last_name VARCHAR2,
    p_email VARCHAR2,
    p_phone_number VARCHAR2
) IS
BEGIN
    UPDATE Customers
    SET FIRST_NAME = p_first_name,
        LAST_NAME = p_last_name,
        EMAIL = p_email,
        PHONE_NUMBER = p_phone_number
    WHERE CUSTOMER_ID = p_customer_id;
END update_customer;

-- Procedure to Delete a Customer
CREATE OR REPLACE PROCEDURE delete_customer(p_customer_id NUMBER) IS
BEGIN
    DELETE FROM Customers WHERE CUSTOMER_ID = p_customer_id;
END delete_customer;
