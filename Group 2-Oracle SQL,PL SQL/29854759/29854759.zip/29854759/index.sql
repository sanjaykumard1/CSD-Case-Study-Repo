
-- Already inserted sample datas to view execute following statement

select * from appointments;
select * from doctors;
select * from medical_records;
select * from patients;

--AS per instruction i created 3 procedures 

/*this procedure is to create appointment 
  this will check for doctor availability and schedule the appointment
  and also update in medical record */
execute CREATE_APPIOINTMENT(&patient_id, &doctor_id,'&time_', '&date_');

/* this procdedure is to admit patient with inserting patient record and creating appointment
   this also updates medical records*/
execute PATIENT_ADMISSION( &PATIENT_ID, '&FIRST_NAME', '&LAST_NAME', '&DOB', '&GENDER', '&ADDRESS', '&PHONE_NUMBER', &DOCTOR_ID, '&DATE', '&TIME');

/* this procedure is to get every information of a patient including info of doctors consulted with*/
execute patient_details(&id);


