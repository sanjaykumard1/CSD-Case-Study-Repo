--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Trigger CREATING_MR_FROM_APPOINTMENTS
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "C##AZHAR"."CREATING_MR_FROM_APPOINTMENTS" AFTER INSERT ON appointments for each ROW
BEGIN
  insert into medical_records (patient_id, doctor_id, date_of_visit) values (:new.patient_id, :new.doctor_id, :new.appointment_date);
END;
/
ALTER TRIGGER "C##AZHAR"."CREATING_MR_FROM_APPOINTMENTS" ENABLE;
