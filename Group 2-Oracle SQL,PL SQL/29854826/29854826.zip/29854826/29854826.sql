CREATE TABLE Patients (
    PATIENT_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    DOB DATE,
    GENDER VARCHAR2(10),
    PHONE_NUMBER VARCHAR2(15),
    EMAIL VARCHAR2(100)
);
-- Create Doctors Table
CREATE TABLE Doctors (
    DOCTOR_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    SPECIALIZATION VARCHAR2(100),
    PHONE_NUMBER VARCHAR2(15),
    EMAIL VARCHAR2(100)
);

-- Create Appointments Table
CREATE TABLE Appointments (
    APPOINTMENT_ID NUMBER PRIMARY KEY,
    PATIENT_ID NUMBER,
    DOCTOR_ID NUMBER,
    APPOINTMENT_DATE DATE,
    APPOINTMENT_TIME VARCHAR2(10),
    STATUS VARCHAR2(20),
    CONSTRAINT fk_patient FOREIGN KEY (PATIENT_ID) REFERENCES Patients(PATIENT_ID),
    CONSTRAINT fk_doctor FOREIGN KEY (DOCTOR_ID) REFERENCES Doctors(DOCTOR_ID)
);
-- Insert sample data into Patients Table
INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DOB, GENDER, PHONE_NUMBER, EMAIL) VALUES (1, 'John', 'Doe', TO_DATE('1980-01-01', 'YYYY-MM-DD'), 'Male', '1234567890', 'john.doe@example.com');
INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DOB, GENDER, PHONE_NUMBER, EMAIL) VALUES (2, 'Jane', 'Smith', TO_DATE('1990-02-02', 'YYYY-MM-DD'), 'Female', '0987654321', 'jane.smith@example.com');

-- Insert sample data into Doctors Table
INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALIZATION, PHONE_NUMBER, EMAIL) VALUES (1, 'Alice', 'Johnson', 'Cardiology', '1112223333', 'alice.johnson@example.com');
INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALIZATION, PHONE_NUMBER, EMAIL) VALUES (2, 'Bob', 'Williams', 'Dermatology', '4445556666', 'bob.williams@example.com');

-- Insert sample data into Appointments Table
INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES (1, 1, 1, TO_DATE('2024-07-15', 'YYYY-MM-DD'), '10:00 AM', 'Scheduled');
INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES (2, 2, 2, TO_DATE('2024-07-16', 'YYYY-MM-DD'), '11:00 AM', 'Scheduled');
CREATE OR REPLACE PROCEDURE add_patient (
    p_patient_id IN NUMBER,
    p_first_name IN VARCHAR2,
    p_last_name IN VARCHAR2,
    p_dob IN DATE,
    p_gender IN VARCHAR2,
    p_phone_number IN VARCHAR2,
    p_email IN VARCHAR2
) AS
BEGIN
    INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DOB, GENDER, PHONE_NUMBER, EMAIL)
    VALUES (p_patient_id, p_first_name, p_last_name, p_dob, p_gender, p_phone_number, p_email);
END;
CREATE OR REPLACE PROCEDURE schedule_appointment (
    p_appointment_id IN NUMBER,
    p_patient_id IN NUMBER,
    p_doctor_id IN NUMBER,
    p_appointment_date IN DATE,
    p_appointment_time IN VARCHAR2,
    p_status IN VARCHAR2
) AS
BEGIN
    INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS)
    VALUES (p_appointment_id, p_patient_id, p_doctor_id, p_appointment_date, p_appointment_time, p_status);
END;

CREATE OR REPLACE PROCEDURE generate_medical_report (
    p_patient_id IN NUMBER
) AS
    CURSOR c_appointments IS
        SELECT a.APPOINTMENT_ID, a.APPOINTMENT_DATE, a.APPOINTMENT_TIME, a.STATUS,
               d.FIRST_NAME AS DOCTOR_FIRST_NAME, d.LAST_NAME AS DOCTOR_LAST_NAME, d.SPECIALIZATION
        FROM Appointments a
        JOIN Doctors d ON a.DOCTOR_ID = d.DOCTOR_ID
        WHERE a.PATIENT_ID = p_patient_id;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Medical Report for Patient ID: ' || p_patient_id);

    FOR r_appointment IN c_appointments LOOP
        DBMS_OUTPUT.PUT_LINE('Appointment ID: ' || r_appointment.APPOINTMENT_ID);
        DBMS_OUTPUT.PUT_LINE('Appointment Date: ' || r_appointment.APPOINTMENT_DATE);
        DBMS_OUTPUT.PUT_LINE('Appointment Time: ' || r_appointment.APPOINTMENT_TIME);
        DBMS_OUTPUT.PUT_LINE('Status: ' || r_appointment.STATUS);
        DBMS_OUTPUT.PUT_LINE('Doctor: ' || r_appointment.DOCTOR_FIRST_NAME || ' ' || r_appointment.DOCTOR_LAST_NAME);
        DBMS_OUTPUT.PUT_LINE('Specialization: ' || r_appointment.SPECIALIZATION);
        DBMS_OUTPUT.PUT_LINE('------------------------------');
    END LOOP;
END;
-- Procedure for Patient Discharge
CREATE OR REPLACE PROCEDURE discharge_patient (
    p_patient_id IN NUMBER
) AS
BEGIN
    DELETE FROM Appointments WHERE PATIENT_ID = p_patient_id;
    DELETE FROM Patients WHERE PATIENT_ID = p_patient_id;
END;
EXEC add_patient(3, 'Michael', 'Brown', TO_DATE('1975-03-03', 'YYYY-MM-DD'), 'Male', '2223334444', 'michael.brown@example.com');
SELECT * FROM Patients WHERE PATIENT_ID = 3;
EXEC schedule_appointment(3, 3, 1, TO_DATE('2024-07-17', 'YYYY-MM-DD'), '02:00 PM', 'Scheduled');

EXEC discharge_patient(3);

EXEC generate_medical_report(1);
