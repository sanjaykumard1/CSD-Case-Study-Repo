--add,update,delete
-- Add driver procedure
CREATE OR REPLACE PROCEDURE AddDriver(
    p_FirstName IN VARCHAR2,
    p_LastName IN VARCHAR2,
    p_LicenseNumber IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
    v_Count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_Count FROM Drivers WHERE LICENSE_NUMBER = p_LicenseNumber;
    IF v_Count = 0 THEN
        INSERT INTO Drivers (DRIVER_ID, FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS)
        VALUES (Drivers_SEQ.NEXTVAL, p_FirstName, p_LastName, p_LicenseNumber, p_Status);
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Driver with License Number ' || p_LicenseNumber || ' already exists.');
    END IF;
END;
/

-- Update driver procedure
CREATE OR REPLACE PROCEDURE UpdateDriver(
    p_DriverID IN NUMBER,
    p_FirstName IN VARCHAR2,
    p_LastName IN VARCHAR2,
    p_LicenseNumber IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    UPDATE Drivers
    SET FIRST_NAME = p_FirstName,
        LAST_NAME = p_LastName,
        LICENSE_NUMBER = p_LicenseNumber,
        STATUS = p_Status
    WHERE DRIVER_ID = p_DriverID;
    COMMIT;
END;
/

-- Delete driver procedure
CREATE OR REPLACE PROCEDURE DeleteDriver(
    p_DriverID IN NUMBER
) IS
BEGIN
    DELETE FROM Trips WHERE DRIVER_ID = p_DriverID;
    DELETE FROM Drivers WHERE DRIVER_ID = p_DriverID;
    COMMIT;
    
END;
/

-- Search driver procedure
CREATE OR REPLACE PROCEDURE SearchDriver(
    p_DriverID IN NUMBER
) IS
    v_FirstName Drivers.FIRST_NAME%TYPE;
    v_LastName Drivers.LAST_NAME%TYPE;
    v_LicenseNumber Drivers.LICENSE_NUMBER%TYPE;
    v_Status Drivers.STATUS%TYPE;
BEGIN
    SELECT FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS
    INTO v_FirstName, v_LastName, v_LicenseNumber, v_Status
    FROM Drivers
    WHERE DRIVER_ID = p_DriverID;

    DBMS_OUTPUT.PUT_LINE('Driver ID: ' || p_DriverID);
    DBMS_OUTPUT.PUT_LINE('First Name: ' || v_FirstName);
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || v_LastName);
    
END;
/

--Queries
-- Add a vehicle
BEGIN
    AddVehicle('Honda', 'Accord', 2024, 'DEF9876', 'Active');
END;
/

-- Add a driver
BEGIN
    AddDriver('Emily', 'Johnson', 'D3456789', 'Active');
END;
/

-- Update a driver
BEGIN
    UpdateDriver(3, 'Emily', 'Smith', 'D3456789', 'Inactive');
END;
/

-- Delete a driver
BEGIN
    DeleteDriver(3);
END;
/

-- Search for a driver
BEGIN
    SearchDriver(1);
    SearchDriver(2);
END;
/