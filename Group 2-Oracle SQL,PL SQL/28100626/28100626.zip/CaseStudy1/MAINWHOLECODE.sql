-- Drop tables and sequences if they exist
BEGIN
    -- Drop tables if they exist
    EXECUTE IMMEDIATE 'DROP TABLE Vehicles CASCADE CONSTRAINTS';
    EXECUTE IMMEDIATE 'DROP TABLE Drivers CASCADE CONSTRAINTS';
    EXECUTE IMMEDIATE 'DROP TABLE Maintenance CASCADE CONSTRAINTS';
    EXECUTE IMMEDIATE 'DROP TABLE Trips CASCADE CONSTRAINTS';

    -- Drop sequences if they exist
    EXECUTE IMMEDIATE 'DROP SEQUENCE Vehicles_SEQ';
    EXECUTE IMMEDIATE 'DROP SEQUENCE Drivers_SEQ';
    EXECUTE IMMEDIATE 'DROP SEQUENCE Maintenance_SEQ';
    EXECUTE IMMEDIATE 'DROP SEQUENCE Trips_SEQ';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE != -942 THEN
            RAISE;
        END IF;
END;
/

-- Create tables
--vehicles
CREATE TABLE Vehicles (
    VEHICLE_ID NUMBER PRIMARY KEY,
    MAKE VARCHAR2(50),
    MODEL VARCHAR2(50),
    YEAR NUMBER,
    LICENSE_PLATE VARCHAR2(20) UNIQUE,
    STATUS VARCHAR2(20)
);
--drivers
CREATE TABLE Drivers (
    DRIVER_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    LICENSE_NUMBER VARCHAR2(20) UNIQUE,
    STATUS VARCHAR2(20)
);
--maintence
CREATE TABLE Maintenance (
    MAINTENANCE_ID NUMBER PRIMARY KEY,
    VEHICLE_ID NUMBER,
    MAINTENANCE_DATE DATE,
    DESCRIPTION VARCHAR2(255),
    STATUS VARCHAR2(20),
    FOREIGN KEY (VEHICLE_ID) REFERENCES Vehicles(VEHICLE_ID)
);
--trips
CREATE TABLE Trips (
    TRIP_ID NUMBER PRIMARY KEY,
    VEHICLE_ID NUMBER,
    DRIVER_ID NUMBER,
    TRIP_DATE DATE,
    START_LOCATION VARCHAR2(100),
    END_LOCATION VARCHAR2(100),
    DISTANCE NUMBER,
    FOREIGN KEY (VEHICLE_ID) REFERENCES Vehicles(VEHICLE_ID),
    FOREIGN KEY (DRIVER_ID) REFERENCES Drivers(DRIVER_ID)
);

-- Create sequences
CREATE SEQUENCE Vehicles_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE Drivers_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE Maintenance_SEQ START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE Trips_SEQ START WITH 1 INCREMENT BY 1;

-- Insert sample data
INSERT INTO Vehicles (VEHICLE_ID, MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS)
VALUES (Vehicles_SEQ.NEXTVAL, 'Toyota', 'Prius', 2022, 'XYZ1234', 'Active');

INSERT INTO Vehicles (VEHICLE_ID, MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS)
VALUES (Vehicles_SEQ.NEXTVAL, 'Ford', 'F-150', 2021, 'ABC5678', 'Active');

INSERT INTO Drivers (DRIVER_ID, FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS)
VALUES (Drivers_SEQ.NEXTVAL, 'John', 'Doe', 'D1234567', 'Active');

INSERT INTO Drivers (DRIVER_ID, FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS)
VALUES (Drivers_SEQ.NEXTVAL, 'Jane', 'Smith', 'D2345678', 'Active');

INSERT INTO Maintenance (MAINTENANCE_ID, VEHICLE_ID, MAINTENANCE_DATE, DESCRIPTION, STATUS)
VALUES (Maintenance_SEQ.NEXTVAL, 1, TO_DATE('2024-06-20', 'YYYY-MM-DD'), 'Oil Change', 'Completed');

INSERT INTO Maintenance (MAINTENANCE_ID, VEHICLE_ID, MAINTENANCE_DATE, DESCRIPTION, STATUS)
VALUES (Maintenance_SEQ.NEXTVAL, 2, TO_DATE('2024-07-10', 'YYYY-MM-DD'), 'Tire Replacement', 'Completed');

INSERT INTO Trips (TRIP_ID, VEHICLE_ID, DRIVER_ID, TRIP_DATE, START_LOCATION, END_LOCATION, DISTANCE)
VALUES (Trips_SEQ.NEXTVAL, 1, 1, TO_DATE('2024-08-01', 'YYYY-MM-DD'), 'New York', 'Los Angeles', 4500);

INSERT INTO Trips (TRIP_ID, VEHICLE_ID, DRIVER_ID, TRIP_DATE, START_LOCATION, END_LOCATION, DISTANCE)
VALUES (Trips_SEQ.NEXTVAL, 2, 2, TO_DATE('2024-08-05', 'YYYY-MM-DD'), 'Chicago', 'Houston', 1500);


--tables
SELECT * FROM Vehicles;
SELECT * FROM Drivers;
SELECT * FROM Maintenance;
SELECT * FROM Trips;

-- PL/SQL Procedures
-- Add vehicle procedure
CREATE OR REPLACE PROCEDURE AddVehicle(
    p_Make IN VARCHAR2,
    p_Model IN VARCHAR2,
    p_Year IN NUMBER,
    p_LicensePlate IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
    v_Count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_Count FROM Vehicles WHERE LICENSE_PLATE = p_LicensePlate;
    IF v_Count = 0 THEN
        INSERT INTO Vehicles (VEHICLE_ID, MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS)
        VALUES (Vehicles_SEQ.NEXTVAL, p_Make, p_Model, p_Year, p_LicensePlate, p_Status);
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Vehicle with License Plate ' || p_LicensePlate || ' already exists.');
    END IF;
END;
/

-- Update vehicle procedure
CREATE OR REPLACE PROCEDURE UpdateVehicle(
    p_VehicleID IN NUMBER,
    p_Make IN VARCHAR2,
    p_Model IN VARCHAR2,
    p_Year IN NUMBER,
    p_LicensePlate IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    UPDATE Vehicles
    SET MAKE = p_Make,
        MODEL = p_Model,
        YEAR = p_Year,
        LICENSE_PLATE = p_LicensePlate,
        STATUS = p_Status
    WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

-- Delete vehicle procedure
CREATE OR REPLACE PROCEDURE DeleteVehicle(
    p_VehicleID IN NUMBER
) IS
BEGIN
    DELETE FROM Trips WHERE VEHICLE_ID = p_VehicleID;
    DELETE FROM Maintenance WHERE VEHICLE_ID = p_VehicleID;
    DELETE FROM Vehicles WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

-- Search vehicle procedure
CREATE OR REPLACE PROCEDURE SearchVehicle(
    p_VehicleID IN NUMBER
) IS
    v_Make Vehicles.MAKE%TYPE;
    v_Model Vehicles.MODEL%TYPE;
    v_Year Vehicles.YEAR%TYPE;
    v_LicensePlate Vehicles.LICENSE_PLATE%TYPE;
    v_Status Vehicles.STATUS%TYPE;
BEGIN
    SELECT MAKE, MODEL, YEAR, LICENSE_PLATE, STATUS
    INTO v_Make, v_Model, v_Year, v_LicensePlate, v_Status
    FROM Vehicles
    WHERE VEHICLE_ID = p_VehicleID;

    DBMS_OUTPUT.PUT_LINE('Vehicle ID: ' || p_VehicleID);
    DBMS_OUTPUT.PUT_LINE('Make: ' || v_Make);
    DBMS_OUTPUT.PUT_LINE('Model: ' || v_Model);
    DBMS_OUTPUT.PUT_LINE('Year: ' || v_Year);
    DBMS_OUTPUT.PUT_LINE('License Plate: ' || v_LicensePlate);
    DBMS_OUTPUT.PUT_LINE('Status: ' || v_Status);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Vehicle with ID ' || p_VehicleID || ' not found.');
END;
/

-- Add driver procedure
CREATE OR REPLACE PROCEDURE AddDriver(
    p_FirstName IN VARCHAR2,
    p_LastName IN VARCHAR2,
    p_LicenseNumber IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
    v_Count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_Count FROM Drivers WHERE LICENSE_NUMBER = p_LicenseNumber;
    IF v_Count = 0 THEN
        INSERT INTO Drivers (DRIVER_ID, FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS)
        VALUES (Drivers_SEQ.NEXTVAL, p_FirstName, p_LastName, p_LicenseNumber, p_Status);
        COMMIT;
    ELSE
        DBMS_OUTPUT.PUT_LINE('Driver with License Number ' || p_LicenseNumber || ' already exists.');
    END IF;
END;
/

-- Update driver procedure
CREATE OR REPLACE PROCEDURE UpdateDriver(
    p_DriverID IN NUMBER,
    p_FirstName IN VARCHAR2,
    p_LastName IN VARCHAR2,
    p_LicenseNumber IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    UPDATE Drivers
    SET FIRST_NAME = p_FirstName,
        LAST_NAME = p_LastName,
        LICENSE_NUMBER = p_LicenseNumber,
        STATUS = p_Status
    WHERE DRIVER_ID = p_DriverID;
    COMMIT;
END;
/

-- Delete driver procedure
CREATE OR REPLACE PROCEDURE DeleteDriver(
    p_DriverID IN NUMBER
) IS
BEGIN
    DELETE FROM Trips WHERE DRIVER_ID = p_DriverID;
    DELETE FROM Drivers WHERE DRIVER_ID = p_DriverID;
    COMMIT;
    
END;
/

-- Search driver procedure
CREATE OR REPLACE PROCEDURE SearchDriver(
    p_DriverID IN NUMBER
) IS
    v_FirstName Drivers.FIRST_NAME%TYPE;
    v_LastName Drivers.LAST_NAME%TYPE;
    v_LicenseNumber Drivers.LICENSE_NUMBER%TYPE;
    v_Status Drivers.STATUS%TYPE;
BEGIN
    SELECT FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS
    INTO v_FirstName, v_LastName, v_LicenseNumber, v_Status
    FROM Drivers
    WHERE DRIVER_ID = p_DriverID;

    DBMS_OUTPUT.PUT_LINE('Driver ID: ' || p_DriverID);
    DBMS_OUTPUT.PUT_LINE('First Name: ' || v_FirstName);
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || v_LastName);
    
END;
/

--Queries
-- Add a vehicle
BEGIN
    AddVehicle('Honda', 'Accord', 2024, 'DEF9876', 'Active');
END;
/


-- Update a vehicle
BEGIN
    UpdateVehicle(3, 'Honda', 'Civic', 2024, 'GHI5432', 'Active');
END;
/

-- Delete a vehicle
BEGIN
    DeleteVehicle(3);
END;
/

-- Search for a vehicle
BEGIN
    SearchVehicle(1);
END;
/

-- Add a driver
BEGIN
    AddDriver('Emily', 'Johnson', 'D3456789', 'Active');
END;
/

-- Update a driver
BEGIN
    UpdateDriver(3, 'Emily', 'Smith', 'D3456789', 'Inactive');
END;
/

-- Delete a driver
BEGIN
    DeleteDriver(3);
END;
/

-- Search for a driver
BEGIN
    SearchDriver(1);
END;
/
SELECT * FROM Vehicles;--after add,update,delete
SELECT * FROM Drivers;--after add,update,delete;

-- PL/SQL Procedures (Continued)
-- Vehicle allocation procedure
CREATE OR REPLACE PROCEDURE AllocateVehicle(
    p_TripID IN NUMBER,
    p_VehicleID IN NUMBER,
    p_DriverID IN NUMBER
) IS
BEGIN
    UPDATE Trips
    SET VEHICLE_ID = p_VehicleID,
        DRIVER_ID = p_DriverID
    WHERE TRIP_ID = p_TripID;
    COMMIT;
END;
/

-- Maintenance tracking procedure
CREATE OR REPLACE PROCEDURE TrackMaintenance(
    p_VehicleID IN NUMBER,
    p_MaintenanceDate IN DATE,
    p_Description IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    INSERT INTO Maintenance (MAINTENANCE_ID, VEHICLE_ID, MAINTENANCE_DATE, DESCRIPTION, STATUS)
    VALUES (Maintenance_SEQ.NEXTVAL, p_VehicleID, p_MaintenanceDate, p_Description, p_Status);
    UPDATE Vehicles
    SET STATUS = p_Status
    WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

-- Trip report generation procedure
CREATE OR REPLACE PROCEDURE GenerateTripReport(
    p_TripID IN NUMBER
) IS
    v_TripDate Trips.TRIP_DATE%TYPE;
    v_StartLocation Trips.START_LOCATION%TYPE;
    v_EndLocation Trips.END_LOCATION%TYPE;
    v_VehicleModel Vehicles.MODEL%TYPE;
    v_LicensePlate Vehicles.LICENSE_PLATE%TYPE;
    v_DriverName VARCHAR2(100);
BEGIN
    SELECT TRIP_DATE, START_LOCATION, END_LOCATION
    INTO v_TripDate, v_StartLocation, v_EndLocation
    FROM Trips
    WHERE TRIP_ID = p_TripID;

    SELECT v.MODEL, v.LICENSE_PLATE, d.FIRST_NAME || ' ' || d.LAST_NAME
    INTO v_VehicleModel, v_LicensePlate, v_DriverName
    FROM Vehicles v
    JOIN Trips t ON v.VEHICLE_ID = t.VEHICLE_ID
    JOIN Drivers d ON t.DRIVER_ID = d.DRIVER_ID
    WHERE t.TRIP_ID = p_TripID;

    DBMS_OUTPUT.PUT_LINE('Trip ID: ' || p_TripID);
    DBMS_OUTPUT.PUT_LINE('Trip Date: ' || TO_CHAR(v_TripDate, 'YYYY-MM-DD'));
    DBMS_OUTPUT.PUT_LINE('Start Location: ' || v_StartLocation);
    DBMS_OUTPUT.PUT_LINE('End Location: ' || v_EndLocation);
    DBMS_OUTPUT.PUT_LINE('Vehicle Model: ' || v_VehicleModel);
    DBMS_OUTPUT.PUT_LINE('License Plate: ' || v_LicensePlate);
    DBMS_OUTPUT.PUT_LINE('Driver: ' || v_DriverName);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Trip with ID ' || p_TripID || ' not found.');
END;
/

-- Example usage of procedures
-- Allocate a vehicle for a trip
BEGIN
    AllocateVehicle(2, 2, 2); -- Assigns Vehicle ID 2 and Driver ID 2 to Trip ID 2
END;
/

-- Track maintenance for a vehicle
BEGIN
    TrackMaintenance(1, TO_DATE('2024-07-14', 'YYYY-MM-DD'), 'Brake Pad Replacement', 'Maintenance');
END;
/

-- Generate a trip report
BEGIN
    GenerateTripReport(2); -- Generates a report for Trip ID 2
END;
/

-- Example queries

-- Get all trips with vehicle and driver details
SELECT t.TRIP_ID, t.TRIP_DATE, t.START_LOCATION, t.END_LOCATION,
       v.MODEL AS VEHICLE_MODEL, v.LICENSE_PLATE,
       d.FIRST_NAME || ' ' || d.LAST_NAME AS DRIVER_NAME
FROM Trips t
INNER JOIN Vehicles v ON t.VEHICLE_ID = v.VEHICLE_ID
INNER JOIN Drivers d ON t.DRIVER_ID = d.DRIVER_ID;

-- List vehicles and their maintenance records
SELECT v.VEHICLE_ID, v.MODEL, v.LICENSE_PLATE,
       m.MAINTENANCE_DATE, m.DESCRIPTION
FROM Vehicles v
LEFT JOIN Maintenance m ON v.VEHICLE_ID = m.VEHICLE_ID;




