-- PL/SQL Procedures (Continued)
-- 1.Vehicle allocation procedure
CREATE OR REPLACE PROCEDURE AllocateVehicle(
    p_TripID IN NUMBER,
    p_VehicleID IN NUMBER,
    p_DriverID IN NUMBER
) IS
BEGIN
    UPDATE Trips
    SET VEHICLE_ID = p_VehicleID,
        DRIVER_ID = p_DriverID
    WHERE TRIP_ID = p_TripID;
    COMMIT;
END;
/

--2.Maintenance tracking procedure
CREATE OR REPLACE PROCEDURE TrackMaintenance(
    p_VehicleID IN NUMBER,
    p_MaintenanceDate IN DATE,
    p_Description IN VARCHAR2,
    p_Status IN VARCHAR2
) IS
BEGIN
    INSERT INTO Maintenance (MAINTENANCE_ID, VEHICLE_ID, MAINTENANCE_DATE, DESCRIPTION, STATUS)
    VALUES (Maintenance_SEQ.NEXTVAL, p_VehicleID, p_MaintenanceDate, p_Description, p_Status);
    UPDATE Vehicles
    SET STATUS = p_Status
    WHERE VEHICLE_ID = p_VehicleID;
    COMMIT;
END;
/

--3.Trip report generation procedure
CREATE OR REPLACE PROCEDURE GenerateTripReport(
    p_TripID IN NUMBER
) IS
    v_TripDate Trips.TRIP_DATE%TYPE;
    v_StartLocation Trips.START_LOCATION%TYPE;
    v_EndLocation Trips.END_LOCATION%TYPE;
    v_VehicleModel Vehicles.MODEL%TYPE;
    v_LicensePlate Vehicles.LICENSE_PLATE%TYPE;
    v_DriverName VARCHAR2(100);
BEGIN
    SELECT TRIP_DATE, START_LOCATION, END_LOCATION
    INTO v_TripDate, v_StartLocation, v_EndLocation
    FROM Trips
    WHERE TRIP_ID = p_TripID;

    SELECT v.MODEL, v.LICENSE_PLATE, d.FIRST_NAME || ' ' || d.LAST_NAME
    INTO v_VehicleModel, v_LicensePlate, v_DriverName
    FROM Vehicles v
    JOIN Trips t ON v.VEHICLE_ID = t.VEHICLE_ID
    JOIN Drivers d ON t.DRIVER_ID = d.DRIVER_ID
    WHERE t.TRIP_ID = p_TripID;

    DBMS_OUTPUT.PUT_LINE('Trip ID: ' || p_TripID);
    DBMS_OUTPUT.PUT_LINE('Trip Date: ' || TO_CHAR(v_TripDate, 'YYYY-MM-DD'));
    DBMS_OUTPUT.PUT_LINE('Start Location: ' || v_StartLocation);
    DBMS_OUTPUT.PUT_LINE('End Location: ' || v_EndLocation);
    DBMS_OUTPUT.PUT_LINE('Vehicle Model: ' || v_VehicleModel);
    DBMS_OUTPUT.PUT_LINE('License Plate: ' || v_LicensePlate);
    DBMS_OUTPUT.PUT_LINE('Driver: ' || v_DriverName);
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Trip with ID ' || p_TripID || ' not found.');
END;
/

-- Example usage of procedures
-- Allocate a vehicle for a trip
BEGIN
    AllocateVehicle(2, 2, 2); -- Assigns Vehicle ID 2 and Driver ID 2 to Trip ID 2
END;
/

-- Track maintenance for a vehicle
BEGIN
    TrackMaintenance(1, TO_DATE('2024-07-14', 'YYYY-MM-DD'), 'Brake Pad Replacement', 'Maintenance');
END;
/

-- Generate a trip report
BEGIN
    GenerateTripReport(2); --3.Generates a report for Trip ID 2
END;
/

-- Example queries

--1.Get all trips with vehicle and driver details
SELECT t.TRIP_ID, t.TRIP_DATE, t.START_LOCATION, t.END_LOCATION,
       v.MODEL AS VEHICLE_MODEL, v.LICENSE_PLATE,
       d.FIRST_NAME || ' ' || d.LAST_NAME AS DRIVER_NAME
FROM Trips t
INNER JOIN Vehicles v ON t.VEHICLE_ID = v.VEHICLE_ID
INNER JOIN Drivers d ON t.DRIVER_ID = d.DRIVER_ID;

--2.List vehicles and their maintenance records
SELECT v.VEHICLE_ID, v.MODEL, v.LICENSE_PLATE,
       m.MAINTENANCE_DATE, m.DESCRIPTION
FROM Vehicles v
LEFT JOIN Maintenance m ON v.VEHICLE_ID = m.VEHICLE_ID;
