-- Insert sample data into authors table
INSERT ALL
    INTO authors (author_id, author_name) VALUES (1, 'J.K. Rowling')
    INTO authors (author_id, author_name) VALUES (2, 'George Orwell')
    INTO authors (author_id, author_name) VALUES (3, 'Jane Austen')
    INTO authors (author_id, author_name) VALUES (4, 'J.R.R. Tolkien')
    INTO authors (author_id, author_name) VALUES (5, 'F. Scott Fitzgerald')
    INTO authors (author_id, author_name) VALUES (6, 'Harper Lee')
    INTO authors (author_id, author_name) VALUES (7, 'Mark Twain')
    INTO authors (author_id, author_name) VALUES (8, 'Mary Shelley')
    INTO authors (author_id, author_name) VALUES (9, 'Leo Tolstoy')
    INTO authors (author_id, author_name) VALUES (10, 'Charles Dickens')
SELECT * FROM dual;


-- Insert sample data into books table
INSERT ALL
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (100, 'Harry Potter and the Philosopher''s Stone', 1, 100, 200)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (101, '1984', 2, 120, 150)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (102, 'Pride and Prejudice', 3, 150, 175)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (103, 'The Hobbit', 4, 145, 280)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (104, 'The Great Gatsby', 5, 130, 160)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (105, 'To Kill a Mockingbird', 6, 110, 190)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (106, 'The Adventures of Tom Sawyer', 7, 170, 270)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (107, 'Frankenstein', 8, 200, 185)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (108, 'War and Peace', 9, 170, 230)
    INTO books (book_id, title, author_id, price, stock_quantity) VALUES (109, 'A Tale of Two Cities', 10, 115, 250)
SELECT * FROM dual;

-- Insert sample data into customers table

INSERT ALL 
INTO customers (customer_id, customer_name, email) VALUES (1000, 'John Doe', 'john.doe.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1001, 'John Smith', 'john.smith.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1002, 'David Wilson', 'david.wilson.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1003, 'James Wilson', 'james.wilson.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1004, 'Daniel Defo', 'daniel.defo.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1005, 'Daniel Willms', 'daniel.willms.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1006, 'James Watson', 'james.watson.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1007, 'Emily Davis', 'emily.davis.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1008, 'Sarah Johnson', 'sarah.johnson.2020@gmail.com')
INTO customers (customer_id, customer_name, email) VALUES (1009, 'Emma White', 'emma.white.2020@gmail.com')
SELECT * FROM dual;


-- Insert sample data into orders table
INSERT ALL 
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (10,1000,TO_DATE('2024-02-10', 'YYYY-MM-DD'),1000)
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (11,1001,TO_DATE('2024-02-13', 'YYYY-MM-DD'),2000)
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (12,1002,TO_DATE('2024-02-15', 'YYYY-MM-DD'),3000)
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (13,1003,TO_DATE('2024-03-11', 'YYYY-MM-DD'),2000)
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (14,1004,TO_DATE('2024-03-13', 'YYYY-MM-DD'),4000)
INTO orders (order_id, customer_id, order_date, total_amount) VALUES (15,1005,TO_DATE('2024-04-12', 'YYYY-MM-DD'),1000)

SELECT * FROM dual;


--Insert sample data into order_items table

INSERT ALL 
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (20,10,100,6)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (21,10,107,5)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (22,11,100,10)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (23,11,101,5)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (24,11,102,6)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (25,12,101,7)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (26,12,105,7)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (27,13,106,4)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (28,13,109,10)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (29,13,108,12)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (30,14,109,10)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (31,14,106,10)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (32,15,106,5)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (33,15,107,6)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (34,15,108,5)
INTO order_items (order_item_id, order_id, book_id, quantity) VALUES (35,15,109,10)
SELECT * FROM dual;