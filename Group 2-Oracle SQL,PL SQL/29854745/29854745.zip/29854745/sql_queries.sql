--	Write SQL queries to:

--o	Retrieve the list of all books.
select title from books;

--o	Retrieve the total number of books in stock.
select sum(stock_quantity) as total_number_of_books_in_stock from books;

--o	Retrieve the list of customers who have placed orders..
select distinct customers.customer_id,customers.customer_name from customers join orders on customers.customer_id=orders.customer_id;

--o	Calculate the total revenue generated from orders.
select sum(total_amount) as total_revenue_generated from orders;
