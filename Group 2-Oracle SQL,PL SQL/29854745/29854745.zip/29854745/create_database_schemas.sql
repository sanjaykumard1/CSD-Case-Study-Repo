-- Authors table
CREATE TABLE authors (
    
    author_id NUMBER PRIMARY KEY,
    author_name VARCHAR2(100)
);

-- Books table
CREATE TABLE books (
    book_id NUMBER PRIMARY KEY,
    title VARCHAR2(255),
    author_id NUMBER,
    price NUMBER,
    stock_quantity NUMBER,
    FOREIGN KEY (author_id) REFERENCES authors(author_id)
);

-- Customers table
CREATE TABLE customers (
    customer_id NUMBER PRIMARY KEY,
    customer_name VARCHAR2(100),
    email VARCHAR2(255)
);

-- Orders table
CREATE TABLE orders (
    order_id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    order_date DATE,
    total_amount NUMBER,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Order items table
CREATE TABLE order_items (
    order_item_id NUMBER PRIMARY KEY,
    order_id NUMBER,
    book_id NUMBER,
    quantity NUMBER,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);

commit;