set SERVEROUTPUT ON;

-- Test the manage_loan_application procedure
BEGIN
    manage_loan_application('INSERT', NULL, 104, 25000, TO_DATE('2024-01-04', 'YYYY-MM-DD'), 'Pending');
    manage_loan_application('SEARCH', 4);
    manage_loan_application('UPDATE', 4, 104, 30000, TO_DATE('2024-01-04', 'YYYY-MM-DD'), 'Pending');
    manage_loan_application('SEARCH', 4);
    manage_loan_application('DELETE', 4);
    manage_loan_application('SEARCH', 4);
END;
/

-- Test the process_loan_application procedure
BEGIN
    process_loan_application(1, TO_DATE('2024-01-10', 'YYYY-MM-DD'), 'Approved', 'Approved after second review');
END;
/

-- Test the generate_loan_report procedure
BEGIN
    generate_loan_report;
END;
/
