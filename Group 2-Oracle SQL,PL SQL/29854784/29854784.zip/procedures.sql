set SERVEROUTPUT ON;
-- Procedure to Manage Loan Applications
CREATE OR REPLACE PROCEDURE manage_loan_application (
    p_action IN VARCHAR2,
    p_application_id IN NUMBER,
    p_customer_id IN NUMBER DEFAULT NULL,
    p_loan_amount IN NUMBER DEFAULT NULL,
    p_application_date IN DATE DEFAULT NULL,
    p_status IN VARCHAR2 DEFAULT NULL
) IS
BEGIN
    IF p_action = 'INSERT' THEN
        INSERT INTO LoanApplications1 (APPLICATION_ID, CUSTOMER_ID, LOAN_AMOUNT, APPLICATION_DATE, STATUS)
        VALUES (LoanApplications1_SEQ.NEXTVAL, p_customer_id, p_loan_amount, p_application_date, p_status);
    ELSIF p_action = 'UPDATE' THEN
        UPDATE LoanApplications1
        SET CUSTOMER_ID = p_customer_id,
            LOAN_AMOUNT = p_loan_amount,
            APPLICATION_DATE = p_application_date,
            STATUS = p_status
        WHERE APPLICATION_ID = p_application_id;
    ELSIF p_action = 'DELETE' THEN
        DELETE FROM LoanApplications1
        WHERE APPLICATION_ID = p_application_id;
    ELSIF p_action = 'SEARCH' THEN
        DBMS_OUTPUT.PUT_LINE('Loan Application Details:');
        FOR rec IN (SELECT * FROM LoanApplications1 WHERE APPLICATION_ID = p_application_id) LOOP
            DBMS_OUTPUT.PUT_LINE('APPLICATION_ID: ' || rec.APPLICATION_ID || ', CUSTOMER_ID: ' || rec.CUSTOMER_ID ||
                                 ', LOAN_AMOUNT: ' || rec.LOAN_AMOUNT || ', APPLICATION_DATE: ' || rec.APPLICATION_DATE ||
                                 ', STATUS: ' || rec.STATUS);
        END LOOP;
    END IF;
END;
/

-- Procedure to Process Loan Applications
CREATE OR REPLACE PROCEDURE process_loan_application (
    p_application_id IN NUMBER,
    p_processing_date IN DATE,
    p_decision IN VARCHAR2,
    p_remarks IN VARCHAR2
) IS
    v_processing_id NUMBER;
BEGIN
    -- Get the next processing ID from the sequence
    SELECT LoanProcessings1_SEQ.NEXTVAL INTO v_processing_id FROM dual;

    -- Insert a new processing record
    INSERT INTO LoanProcessings1 (PROCESSING_ID, APPLICATION_ID, PROCESSING_DATE, DECISION, REMARKS)
    VALUES (v_processing_id, p_application_id, p_processing_date, p_decision, p_remarks);

    -- Update the status of the loan application
    UPDATE LoanApplications1
    SET STATUS = p_decision
    WHERE APPLICATION_ID = p_application_id;
END;
/

-- Procedure to Generate Loan Reports
CREATE OR REPLACE PROCEDURE generate_loan_report IS
    v_total_applications NUMBER;
    v_approved_loans NUMBER;
    v_rejected_loans NUMBER;
    v_pending_applications NUMBER;
    v_report_date DATE := SYSDATE;
BEGIN
    -- Calculate total loan applications
    SELECT COUNT(*)
    INTO v_total_applications
    FROM LoanApplications1;

    -- Calculate approved loans
    SELECT COUNT(*)
    INTO v_approved_loans
    FROM LoanApplications1
    WHERE STATUS = 'Approved';

    -- Calculate rejected loans
    SELECT COUNT(*)
    INTO v_rejected_loans
    FROM LoanApplications1
    WHERE STATUS = 'Rejected';

    -- Calculate pending applications
    SELECT COUNT(*)
    INTO v_pending_applications
    FROM LoanApplications1
    WHERE STATUS = 'Pending';

    -- Insert the report into LoanReports
    INSERT INTO LoanReports1 (REPORT_ID, REPORT_DATE, TOTAL_APPLICATIONS, APPROVED_LOANS, REJECTED_LOANS, PENDING_APPLICATIONS)
    VALUES (LoanReports1_SEQ.NEXTVAL, v_report_date, v_total_applications, v_approved_loans, v_rejected_loans, v_pending_applications);
    
    DBMS_OUTPUT.PUT_LINE('Loan report generated successfully.');
END;
/
