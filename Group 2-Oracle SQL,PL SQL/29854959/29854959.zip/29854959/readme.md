# Logistics Case Study

## Overview

This repository contains SQL scripts and PL/SQL procedures for managing a logistics system. The case study includes creating tables, inserting sample data, and procedures for tracking shipments, allocating vehicles, and generating delivery reports.

## Table of Contents

- [Logistics Case Study](#logistics-case-study)
  - [Overview](#overview)
  - [Table of Contents](#table-of-contents)
  - [Setup](#setup)
  - [Tables](#tables)
    - [Shipments Table](#shipments-table)
    - [Vehicles Table](#vehicles-table)
    - [Drivers Table](#drivers-table)
    - [Routes Table](#routes-table)
  - [Sample Data](#sample-data)
  - [Procedures](#procedures)
    - [Track Shipment](#track-shipment)
    - [Allocate Vehicle](#allocate-vehicle)
    - [Generate Delivery Report](#generate-delivery-report)
  - [Testing Procedures](#testing-procedures)

## Setup

To set up the database tables and insert sample data, run the provided SQL scripts.

## Tables

### Shipments Table

- **Columns**: SHIPMENT_ID, SHIPMENT_DATE, ORIGIN, DESTINATION, STATUS, ESTIMATED_DELIVERY_DATE

### Vehicles Table

- **Columns**: VEHICLE_ID, TYPE, CAPACITY, STATUS, CURRENT_LOCATION

### Drivers Table

- **Columns**: DRIVER_ID, FIRST_NAME, LAST_NAME, LICENSE_NUMBER, STATUS

### Routes Table

- **Columns**: ROUTE_ID, START_LOCATION, END_LOCATION, DISTANCE, ESTIMATED_TRAVEL_TIME

## Sample Data

Insert sample data into the tables using the provided SQL insert statements.

## Procedures

### Track Shipment

Updates the status and current location of a shipment.

### Allocate Vehicle

Allocates a vehicle and a driver to a shipment.

### Generate Delivery Report

Generates a report of all shipments, including related vehicle and driver information.

## Testing Procedures

To test the procedures, use the provided SQL EXEC commands.
