REM   Script: HealthCare Management System
REM   HealthCare Management System

CREATE TABLE Patients ( 
    PATIENT_ID NUMBER PRIMARY KEY, 
    FIRST_NAME VARCHAR2(50), 
    LAST_NAME VARCHAR2(50), 
    DATE_OF_BIRTH DATE, 
    GENDER VARCHAR2(10), 
    PHONE_NUMBER VARCHAR2(15), 
    EMAIL VARCHAR2(100) 
);

INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE_NUMBER, EMAIL) VALUES 
(1, 'John', 'Doe', TO_DATE('1980-01-15', 'YYYY-MM-DD'), 'Male', '1234567890', 'john.doe@example.com');

INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE_NUMBER, EMAIL) VALUES 
(2, 'Jane', 'Smith', TO_DATE('1990-02-20', 'YYYY-MM-DD'), 'Female', '0987654321', 'jane.smith@example.com');

SELECT *FROM Patients;

CREATE TABLE Doctors ( 
    DOCTOR_ID NUMBER PRIMARY KEY, 
    FIRST_NAME VARCHAR2(50), 
    LAST_NAME VARCHAR2(50), 
    SPECIALTY VARCHAR2(50), 
    PHONE_NUMBER VARCHAR2(15), 
    EMAIL VARCHAR2(100) 
);

INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALTY, PHONE_NUMBER, EMAIL) VALUES 
(1, 'Alice', 'Brown', 'Cardiology', '1122334455', 'alice.brown@example.com');

INSERT INTO Doctors (DOCTOR_ID, FIRST_NAME, LAST_NAME, SPECIALTY, PHONE_NUMBER, EMAIL) VALUES 
(2, 'Bob', 'Johnson', 'Neurology', '5566778899', 'bob.johnson@example.com');

CREATE TABLE Appointments ( 
    APPOINTMENT_ID NUMBER PRIMARY KEY, 
    PATIENT_ID NUMBER, 
    DOCTOR_ID NUMBER, 
    APPOINTMENT_DATE DATE, 
    APPOINTMENT_TIME VARCHAR2(10), 
    STATUS VARCHAR2(20), 
    FOREIGN KEY (PATIENT_ID) REFERENCES Patients(PATIENT_ID), 
    FOREIGN KEY (DOCTOR_ID) REFERENCES Doctors(DOCTOR_ID) 
);

INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES 
(2, 2, 2, TO_DATE('2024-07-16', 'YYYY-MM-DD'), '11:00 AM', 'Scheduled');

INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) VALUES 
(1, 1, 1, TO_DATE('2024-07-15', 'YYYY-MM-DD'), '10:00 AM', 'Scheduled');

CREATE TABLE MedicalRecords ( 
    RECORD_ID NUMBER PRIMARY KEY, 
    PATIENT_ID NUMBER, 
    DOCTOR_ID NUMBER, 
    VISIT_DATE DATE, 
    DIAGNOSIS CLOB, 
    PRESCRIPTION CLOB, 
    NOTES CLOB, 
    FOREIGN KEY (PATIENT_ID) REFERENCES Patients(PATIENT_ID), 
    FOREIGN KEY (DOCTOR_ID) REFERENCES Doctors(DOCTOR_ID) 
);

INSERT INTO MedicalRecords (RECORD_ID, PATIENT_ID, DOCTOR_ID, VISIT_DATE, DIAGNOSIS, PRESCRIPTION, NOTES) VALUES 
(2, 2, 2, TO_DATE('2024-07-11', 'YYYY-MM-DD'), 'Migraine', 'Medication B', 'Follow up in 1 month');

INSERT INTO MedicalRecords (RECORD_ID, PATIENT_ID, DOCTOR_ID, VISIT_DATE, DIAGNOSIS, PRESCRIPTION, NOTES) VALUES 
(1, 1, 1, TO_DATE('2024-07-10', 'YYYY-MM-DD'), 'Hypertension', 'Medication A', 'Follow up in 2 weeks');

SELECT *FROM MedicalRecords;

CREATE SEQUENCE Patients_SEQ 
START WITH 1 
INCREMENT BY 1 
NOCACHE;

CREATE OR REPLACE PROCEDURE add_patient ( 
    p_FIRST_NAME IN Patients.FIRST_NAME%TYPE, 
    p_LAST_NAME IN Patients.LAST_NAME%TYPE, 
    p_DATE_OF_BIRTH IN Patients.DATE_OF_BIRTH%TYPE, 
    p_GENDER IN Patients.GENDER%TYPE, 
    p_PHONE_NUMBER IN Patients.PHONE_NUMBER%TYPE, 
    p_EMAIL IN Patients.EMAIL%TYPE 
) IS 
BEGIN 
    INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE_NUMBER, EMAIL) 
    VALUES (Patients_SEQ.NEXTVAL, p_FIRST_NAME, p_LAST_NAME, p_DATE_OF_BIRTH, p_GENDER, p_PHONE_NUMBER, p_EMAIL); 
END;
/

select*from Patients;

select*from Patients;

select*from Patients;

BEGIN 
    add_patient('Jimmy', 'Doe', TO_DATE('1980-01-01', 'YYYY-MM-DD'), 'Male', '1234567891', 'jimmy.doe@example.com'); 
END;
/

select*from Patients;

CREATE OR REPLACE PROCEDURE update_patient ( 
    p_PATIENT_ID IN Patients.PATIENT_ID%TYPE, 
    p_FIRST_NAME IN Patients.FIRST_NAME%TYPE, 
    p_LAST_NAME IN Patients.LAST_NAME%TYPE, 
    p_DATE_OF_BIRTH IN Patients.DATE_OF_BIRTH%TYPE, 
    p_GENDER IN Patients.GENDER%TYPE, 
    p_PHONE_NUMBER IN Patients.PHONE_NUMBER%TYPE, 
    p_EMAIL IN Patients.EMAIL%TYPE 
) IS 
BEGIN 
    UPDATE Patients 
    SET FIRST_NAME = p_FIRST_NAME, 
        LAST_NAME = p_LAST_NAME, 
        DATE_OF_BIRTH = p_DATE_OF_BIRTH, 
        GENDER = p_GENDER, 
        PHONE_NUMBER = p_PHONE_NUMBER, 
        EMAIL = p_EMAIL 
    WHERE PATIENT_ID = p_PATIENT_ID; 
END;
/

CREATE OR REPLACE PROCEDURE delete_patient (p_PATIENT_ID IN Patients.PATIENT_ID%TYPE) IS 
BEGIN 
    DELETE FROM Patients WHERE PATIENT_ID = p_PATIENT_ID; 
END;
/

CREATE OR REPLACE PROCEDURE delete_patient (p_PATIENT_ID IN Patients.PATIENT_ID%TYPE) IS 
BEGIN 
    DELETE FROM Patients WHERE PATIENT_ID = p_PATIENT_ID; 
END;
/

CREATE OR REPLACE PROCEDURE search_patient (p_PATIENT_ID IN Patients.PATIENT_ID%TYPE) IS 
    v_FIRST_NAME Patients.FIRST_NAME%TYPE; 
    v_LAST_NAME Patients.LAST_NAME%TYPE; 
    v_DATE_OF_BIRTH Patients.DATE_OF_BIRTH%TYPE; 
    v_GENDER Patients.GENDER%TYPE; 
    v_PHONE_NUMBER Patients.PHONE_NUMBER%TYPE; 
    v_EMAIL Patients.EMAIL%TYPE; 
BEGIN 
    SELECT FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE_NUMBER, EMAIL 
    INTO v_FIRST_NAME, v_LAST_NAME, v_DATE_OF_BIRTH, v_GENDER, v_PHONE_NUMBER, v_EMAIL 
    FROM Patients 
    WHERE PATIENT_ID = p_PATIENT_ID; 
     
    DBMS_OUTPUT.PUT_LINE('Patient Details:'); 
    DBMS_OUTPUT.PUT_LINE('First Name: ' || v_FIRST_NAME); 
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || v_LAST_NAME); 
    DBMS_OUTPUT.PUT_LINE('Date of Birth: ' || v_DATE_OF_BIRTH); 
    DBMS_OUTPUT.PUT_LINE('Gender: ' || v_GENDER); 
    DBMS_OUTPUT.PUT_LINE('Phone Number: ' || v_PHONE_NUMBER); 
    DBMS_OUTPUT.PUT_LINE('Email: ' || v_EMAIL); 
END;
/

CREATE SEQUENCE Appointments_SEQ 
START WITH 1 
INCREMENT BY 1 
NOCACHE;

CREATE OR REPLACE PROCEDURE schedule_appointment ( 
    p_PATIENT_ID IN Appointments.PATIENT_ID%TYPE, 
    p_DOCTOR_ID IN Appointments.DOCTOR_ID%TYPE, 
    p_APPOINTMENT_DATE IN Appointments.APPOINTMENT_DATE%TYPE, 
    p_APPOINTMENT_TIME IN Appointments.APPOINTMENT_TIME%TYPE, 
    p_STATUS IN Appointments.STATUS%TYPE 
) IS 
BEGIN 
    INSERT INTO Appointments (APPOINTMENT_ID, PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS) 
    VALUES (Appointments_SEQ.NEXTVAL, p_PATIENT_ID, p_DOCTOR_ID, p_APPOINTMENT_DATE, p_APPOINTMENT_TIME, p_STATUS); 
END;
/

CREATE OR REPLACE PROCEDURE cancel_appointment (p_APPOINTMENT_ID IN Appointments.APPOINTMENT_ID%TYPE) IS 
BEGIN 
    DELETE FROM Appointments WHERE APPOINTMENT_ID = p_APPOINTMENT_ID; 
END;
/

CREATE OR REPLACE PROCEDURE update_appointment ( 
    p_APPOINTMENT_ID IN Appointments.APPOINTMENT_ID%TYPE, 
    p_PATIENT_ID IN Appointments.PATIENT_ID%TYPE, 
    p_DOCTOR_ID IN Appointments.DOCTOR_ID%TYPE, 
    p_APPOINTMENT_DATE IN Appointments.APPOINTMENT_DATE%TYPE, 
    p_APPOINTMENT_TIME IN Appointments.APPOINTMENT_TIME%TYPE, 
    p_STATUS IN Appointments.STATUS%TYPE 
) IS 
BEGIN 
    UPDATE Appointments 
    SET PATIENT_ID = p_PATIENT_ID, 
        DOCTOR_ID = p_DOCTOR_ID, 
        APPOINTMENT_DATE = p_APPOINTMENT_DATE, 
        APPOINTMENT_TIME = p_APPOINTMENT_TIME, 
        STATUS = p_STATUS 
    WHERE APPOINTMENT_ID = p_APPOINTMENT_ID; 
END;
/

CREATE OR REPLACE PROCEDURE search_appointment ( 
    p_APPOINTMENT_ID IN Appointments.APPOINTMENT_ID%TYPE 
) IS 
    v_PATIENT_ID Appointments.PATIENT_ID%TYPE; 
    v_DOCTOR_ID Appointments.DOCTOR_ID%TYPE; 
    v_APPOINTMENT_DATE Appointments.APPOINTMENT_DATE%TYPE; 
    v_APPOINTMENT_TIME Appointments.APPOINTMENT_TIME%TYPE; 
    v_STATUS Appointments.STATUS%TYPE; 
BEGIN 
    -- Select the appointment details into the variables 
    SELECT PATIENT_ID, DOCTOR_ID, APPOINTMENT_DATE, APPOINTMENT_TIME, STATUS 
    INTO v_PATIENT_ID, v_DOCTOR_ID, v_APPOINTMENT_DATE, v_APPOINTMENT_TIME, v_STATUS 
    FROM Appointments 
    WHERE APPOINTMENT_ID = p_APPOINTMENT_ID; 
 
    -- Display the appointment details 
    DBMS_OUTPUT.PUT_LINE('Appointment ID: ' || p_APPOINTMENT_ID); 
    DBMS_OUTPUT.PUT_LINE('Patient ID: ' || v_PATIENT_ID); 
    DBMS_OUTPUT.PUT_LINE('Doctor ID: ' || v_DOCTOR_ID); 
    DBMS_OUTPUT.PUT_LINE('Appointment Date: ' || TO_CHAR(v_APPOINTMENT_DATE, 'YYYY-MM-DD')); 
    DBMS_OUTPUT.PUT_LINE('Appointment Time: ' || v_APPOINTMENT_TIME); 
    DBMS_OUTPUT.PUT_LINE('Status: ' || v_STATUS); 
 
EXCEPTION 
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE('No appointment found with ID: ' || p_APPOINTMENT_ID); 
END;
/

CREATE SEQUENCE MedicalRecords_SEQ 
START WITH 1 
INCREMENT BY 1 
NOCACHE;

CREATE OR REPLACE PROCEDURE update_medical_record ( 
    p_RECORD_ID IN MedicalRecords.RECORD_ID%TYPE, 
    p_PATIENT_ID IN MedicalRecords.PATIENT_ID%TYPE, 
    p_DOCTOR_ID IN MedicalRecords.DOCTOR_ID%TYPE, 
    p_VISIT_DATE IN MedicalRecords.VISIT_DATE%TYPE, 
    p_DIAGNOSIS IN MedicalRecords.DIAGNOSIS%TYPE, 
    p_PRESCRIPTION IN MedicalRecords.PRESCRIPTION%TYPE, 
    p_NOTES IN MedicalRecords.NOTES%TYPE 
) IS 
BEGIN 
    UPDATE MedicalRecords 
    SET PATIENT_ID = p_PATIENT_ID, 
        DOCTOR_ID = p_DOCTOR_ID, 
        VISIT_DATE = p_VISIT_DATE, 
        DIAGNOSIS = p_DIAGNOSIS, 
        PRESCRIPTION = p_PRESCRIPTION, 
        NOTES = p_NOTES 
    WHERE RECORD_ID = p_RECORD_ID; 
END;
/

CREATE OR REPLACE PROCEDURE insert_medical_record ( 
    p_PATIENT_ID IN MedicalRecords.PATIENT_ID%TYPE, 
    p_DOCTOR_ID IN MedicalRecords.DOCTOR_ID%TYPE, 
    p_VISIT_DATE IN MedicalRecords.VISIT_DATE%TYPE, 
    p_DIAGNOSIS IN MedicalRecords.DIAGNOSIS%TYPE, 
    p_PRESCRIPTION IN MedicalRecords.PRESCRIPTION%TYPE, 
    p_NOTES IN MedicalRecords.NOTES%TYPE 
) IS 
BEGIN 
    INSERT INTO MedicalRecords (RECORD_ID, PATIENT_ID, DOCTOR_ID, VISIT_DATE, DIAGNOSIS, PRESCRIPTION, NOTES) 
    VALUES (MedicalRecords_SEQ.NEXTVAL, p_PATIENT_ID, p_DOCTOR_ID, p_VISIT_DATE, p_DIAGNOSIS, p_PRESCRIPTION, p_NOTES); 
END;
/

CREATE OR REPLACE PROCEDURE search_medical_record ( 
    p_RECORD_ID IN MedicalRecords.RECORD_ID%TYPE 
) IS 
    v_PATIENT_ID MedicalRecords.PATIENT_ID%TYPE; 
    v_DOCTOR_ID MedicalRecords.DOCTOR_ID%TYPE; 
    v_VISIT_DATE MedicalRecords.VISIT_DATE%TYPE; 
    v_DIAGNOSIS MedicalRecords.DIAGNOSIS%TYPE; 
    v_PRESCRIPTION MedicalRecords.PRESCRIPTION%TYPE; 
    v_NOTES MedicalRecords.NOTES%TYPE; 
BEGIN 
    SELECT PATIENT_ID, DOCTOR_ID, VISIT_DATE, DIAGNOSIS, PRESCRIPTION, NOTES 
    INTO v_PATIENT_ID, v_DOCTOR_ID, v_VISIT_DATE, v_DIAGNOSIS, v_PRESCRIPTION, v_NOTES 
    FROM MedicalRecords 
    WHERE RECORD_ID = p_RECORD_ID; 
     
    DBMS_OUTPUT.PUT_LINE('Medical Record Details:'); 
    DBMS_OUTPUT.PUT_LINE('Patient ID: ' || v_PATIENT_ID); 
    DBMS_OUTPUT.PUT_LINE('Doctor ID: ' || v_DOCTOR_ID); 
    DBMS_OUTPUT.PUT_LINE('Visit Date: ' || v_VISIT_DATE); 
    DBMS_OUTPUT.PUT_LINE('Diagnosis: ' || v_DIAGNOSIS); 
    DBMS_OUTPUT.PUT_LINE('Prescription: ' || v_PRESCRIPTION); 
    DBMS_OUTPUT.PUT_LINE('Notes: ' || v_NOTES); 
END;
/

BEGIN 
    update_patient( 
        p_PATIENT_ID => 1,  -- Replace with the appropriate PATIENT_ID 
        p_FIRST_NAME => 'Johnathan', 
        p_LAST_NAME => 'Doe', 
        p_DATE_OF_BIRTH => TO_DATE('1980-01-01', 'YYYY-MM-DD'), 
        p_GENDER => 'Male', 
        p_PHONE_NUMBER => '1112223333', 
        p_EMAIL => 'johnathan.doe@example.com' 
    ); 
END;
/

 SELECT *FROM Patients WHERE PATIENT_ID = 1;

SELECT *FROM Patients WHERE PATIENT_ID = 1;

BEGIN 
    delete_patient(p_PATIENT_ID => 3);  
END;
/

SELECT *FROM Patients;

BEGIN 
    search_patient(p_PATIENT_ID => 1);  -- Replace 1 with the appropriate PATIENT_ID 
END;
/

SELECT *FROM Appointments;

SELECT Appointments_SEQ.NEXTVAL FROM dual;

DROP SEQUENCE Appointments_SEQ;

DROP SEQUENCE Appointments_SEQ;

CREATE SEQUENCE Appointments_SEQ 
START WITH 6 
INCREMENT BY 1 
NOCACHE;

BEGIN 
    schedule_appointment( 
        p_PATIENT_ID => 1,   
        p_DOCTOR_ID => 1,    
        p_APPOINTMENT_DATE => TO_DATE('2023-07-20', 'YYYY-MM-DD'), 
        p_APPOINTMENT_TIME => '10:00', 
        p_STATUS => 'Scheduled' 
    ); 
END;
/

CREATE SEQUENCE Appointments_SEQ 
START WITH 4 
INCREMENT BY 1 
NOCACHE;

BEGIN 
    schedule_appointment( 
        p_PATIENT_ID => 1,   
        p_DOCTOR_ID => 1,    
        p_APPOINTMENT_DATE => TO_DATE('2023-07-20', 'YYYY-MM-DD'), 
        p_APPOINTMENT_TIME => '10:00', 
        p_STATUS => 'Scheduled' 
    ); 
END;
/

SELECT *FROM Appointments;

SELECT * FROM Appointments;

BEGIN 
    cancel_appointment(p_APPOINTMENT_ID => 6 ); 
END;
/

SELECT * FROM Appointments;

BEGIN 
    search_appointment(p_APPOINTMENT_ID => 4); 
END;
/

BEGIN 
    search_appointment(p_APPOINTMENT_ID => 11); 
END;
/

SELECT *FROM MedicalRecords;

SELECT *FROM Patients;

SELECT *FROM MedicalRecords;

SELECT *FROM Patients;

INSERT INTO Patients (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE_NUMBER, EMAIL) VALUES 
(3, 'Jack', 'Doe', TO_DATE('1980-01-15', 'YYYY-MM-DD'), 'Male', '1234567800', 'jack.doe@example.com');

SELECT *FROM Patients;

SELECT *FROM MedicalRecords;

DROP SEQUENCE MedicalRecords_SEQ;

CREATE SEQUENCE MedicalRecords_SEQ 
START WITH 1 
INCREMENT BY 1 
NOCACHE;

DROP SEQUENCE MedicalRecords_SEQ;

CREATE SEQUENCE MedicalRecords_SEQ 
START WITH 3 
INCREMENT BY 1 
NOCACHE;

BEGIN 
    insert_medical_record( 
        p_PATIENT_ID => 3, 
        p_DOCTOR_ID => 1, 
        p_VISIT_DATE => TO_DATE('2023-07-22', 'YYYY-MM-DD'), 
        p_DIAGNOSIS => 'Flu', 
        p_PRESCRIPTION => 'Rest and hydration', 
        p_NOTES => 'Patient is advised to rest for a week.' 
    ); 
END;
/

SELECT * FROM MedicalRecords WHERE PATIENT_ID = 3;

SELECT *FROM MedicalRecords;

BEGIN 
    update_medical_record( 
        p_RECORD_ID => 1, 
        p_PATIENT_ID => 1, 
        p_DOCTOR_ID => 2, 
        p_VISIT_DATE => TO_DATE('2023-07-23', 'YYYY-MM-DD'), 
        p_DIAGNOSIS => 'Cold', 
        p_PRESCRIPTION => 'Rest and medication', 
        p_NOTES => 'Patient should rest for three days.' 
    ); 
END;
/

SELECT * FROM MedicalRecords WHERE RECORD_ID = 1;

BEGIN 
    search_medical_record(p_RECORD_ID => 1); 
END;
/

BEGIN 
    update_appointment( 
        p_APPOINTMENT_ID => 1, 
        p_PATIENT_ID => 2, 
        p_DOCTOR_ID => 2, 
        p_APPOINTMENT_DATE => TO_DATE('2023-08-01', 'YYYY-MM-DD'), 
        p_APPOINTMENT_TIME => '14:00', 
        p_STATUS => 'Rescheduled' 
    ); 
END;
/

SELECT * FROM Appointments WHERE APPOINTMENT_ID = 1;

BEGIN 
    cancel_appointment(p_APPOINTMENT_ID => 6 ); 
END;
/

SELECT * FROM Appointments;

