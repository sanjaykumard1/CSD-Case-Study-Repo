CREATE TABLE InsuranceClaims (
    CLAIM_ID NUMBER PRIMARY KEY,
    POLICY_NUMBER VARCHAR2(50),
    CLAIM_DATE DATE,
    CLAIM_AMOUNT NUMBER,
    STATUS VARCHAR2(50)
);

SELECT *FROM InsuranceClaims;

CREATE TABLE ClaimProcessings (
    PROCESSING_ID NUMBER PRIMARY KEY,
    CLAIM_ID NUMBER,
    PROCESSING_DATE DATE,
    PROCESSING_NOTES VARCHAR2(255),
    PROCESSING_STATUS VARCHAR2(50),
    FOREIGN KEY (CLAIM_ID) REFERENCES InsuranceClaims(CLAIM_ID)
);

CREATE TABLE ClaimsReports (
    REPORT_ID NUMBER PRIMARY KEY,
    REPORT_DATE DATE,
    TOTAL_CLAIMS NUMBER,
    AVERAGE_CLAIM_AMOUNT NUMBER,
    CLAIMS_STATUS_BREAKDOWN CLOB
);


CREATE SEQUENCE SEQ_REPORT_ID START WITH 1;

SELECT *FROM InsuranceClaims;
SELECT * FROM ClaimProcessings;
Select * FROM ClaimsReports;



INSERT INTO InsuranceClaims (CLAIM_ID, POLICY_NUMBER, CLAIM_DATE, CLAIM_AMOUNT, STATUS) VALUES (1, 'POL123456', TO_DATE('2023-01-01', 'YYYY-MM-DD'), 1500, 'Pending');
INSERT INTO InsuranceClaims (CLAIM_ID, POLICY_NUMBER, CLAIM_DATE, CLAIM_AMOUNT, STATUS) VALUES (2, 'POL654321', TO_DATE('2023-02-15', 'YYYY-MM-DD'), 2500, 'Approved');
INSERT INTO InsuranceClaims (CLAIM_ID, POLICY_NUMBER, CLAIM_DATE, CLAIM_AMOUNT, STATUS) VALUES (3, 'POL789012', TO_DATE('2023-03-10', 'YYYY-MM-DD'), 1200, 'Rejected');

TRUNCATE TABLE ClaimProcessings;

INSERT INTO ClaimProcessings (PROCESSING_ID, CLAIM_ID, PROCESSING_DATE, PROCESSING_NOTES, PROCESSING_STATUS)VALUES (1, 1, TO_DATE('2023-01-02', 'YYYY-MM-DD'), 'Initial review', 'In Progress');
INSERT INTO ClaimProcessings (PROCESSING_ID, CLAIM_ID, PROCESSING_DATE, PROCESSING_NOTES, PROCESSING_STATUS)VALUES(2, 2, TO_DATE('2023-02-16', 'YYYY-MM-DD'), 'Approved by manager', 'Approved');
INSERT INTO ClaimProcessings (PROCESSING_ID, CLAIM_ID, PROCESSING_DATE, PROCESSING_NOTES, PROCESSING_STATUS)VALUES(3, 3, TO_DATE('2023-03-11', 'YYYY-MM-DD'), 'Rejected due to lack of documentation', 'Rejected');


SELECT * FROM InsuranceClaims;
SELECT * FROM ClaimProcessings;
SELECT * FROM ClaimsReports;

CREATE OR REPLACE PROCEDURE ManageClaim (
    p_claim_id IN NUMBER,
    p_policy_number IN VARCHAR2,
    p_claim_date IN DATE,
    p_claim_amount IN NUMBER,
    p_status IN VARCHAR2,
    p_action IN VARCHAR2
) IS
BEGIN
    IF p_action = 'INSERT' THEN
        INSERT INTO InsuranceClaims (CLAIM_ID, POLICY_NUMBER, CLAIM_DATE, CLAIM_AMOUNT, STATUS) VALUES 
        (p_claim_id, p_policy_number, p_claim_date, p_claim_amount, p_status);
    ELSIF p_action = 'UPDATE' THEN
        UPDATE InsuranceClaims
        SET POLICY_NUMBER = p_policy_number, CLAIM_DATE = p_claim_date, CLAIM_AMOUNT = p_claim_amount, STATUS = p_status
        WHERE CLAIM_ID = p_claim_id;
    ELSIF p_action = 'DELETE' THEN
        DELETE FROM InsuranceClaims WHERE CLAIM_ID = p_claim_id;
    END IF;
END;
/

CREATE OR REPLACE PROCEDURE ProcessClaim (
    p_processing_id IN NUMBER,
    p_claim_id IN NUMBER,
    p_processing_date IN DATE,
    p_processing_notes IN VARCHAR2,
    p_processing_status IN VARCHAR2
) IS
BEGIN
    INSERT INTO ClaimProcessings (PROCESSING_ID, CLAIM_ID, PROCESSING_DATE, PROCESSING_NOTES, PROCESSING_STATUS) VALUES 
    (p_processing_id, p_claim_id, p_processing_date, p_processing_notes, p_processing_status);

    UPDATE InsuranceClaims
    SET STATUS = p_processing_status
    WHERE CLAIM_ID = p_claim_id;
END;
/

CREATE OR REPLACE PROCEDURE GenerateClaimsReport IS
    v_total_claims NUMBER;
    v_avg_claim_amount NUMBER;
    v_claims_status_breakdown CLOB;
BEGIN
    SELECT COUNT(*), AVG(CLAIM_AMOUNT) INTO v_total_claims, v_avg_claim_amount FROM InsuranceClaims;

    SELECT LISTAGG(STATUS || ': ' || COUNT(*), ', ') WITHIN GROUP (ORDER BY STATUS) 
    INTO v_claims_status_breakdown
    FROM InsuranceClaims
    GROUP BY STATUS;

    INSERT INTO ClaimsReports (REPORT_ID, REPORT_DATE, TOTAL_CLAIMS, AVERAGE_CLAIM_AMOUNT, CLAIMS_STATUS_BREAKDOWN)
    VALUES (SEQ_REPORT_ID.NEXTVAL, SYSDATE, v_total_claims, v_avg_claim_amount, v_claims_status_breakdown);

    COMMIT; -- Ensure changes are committed
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error in GenerateClaimsReport: ' || SQLERRM);
END;
/

--testing
BEGIN
    -- Insert a new claim
    ManageClaim(4, 'POL345678', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 1800, 'Pending', 'INSERT');
    -- Update an existing claim
    ManageClaim(4, 'POL345678', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 1800, 'Approved', 'UPDATE');
    -- Delete a claim
    ManageClaim(4, 'POL345678', TO_DATE('2023-04-01', 'YYYY-MM-DD'), 1800, 'Approved', 'DELETE');
END;
/

BEGIN
    ProcessClaim(4, 1, TO_DATE('2023-01-03', 'YYYY-MM-DD'), 'Further review', 'In Progress');
END;
/

BEGIN
    GenerateClaimsReport;
END;
/

