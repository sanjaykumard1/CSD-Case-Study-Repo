--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure GENERATECLAIMSREPORT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."GENERATECLAIMSREPORT" IS
    v_total_claims NUMBER;
    v_avg_claim_amount NUMBER;
    v_claims_status_breakdown CLOB;
BEGIN
    SELECT COUNT(*), AVG(CLAIM_AMOUNT) INTO v_total_claims, v_avg_claim_amount FROM InsuranceClaims;

    SELECT LISTAGG(STATUS || ': ' || COUNT(*), ', ') WITHIN GROUP (ORDER BY STATUS) 
    INTO v_claims_status_breakdown
    FROM InsuranceClaims
    GROUP BY STATUS;

    INSERT INTO ClaimsReports (REPORT_ID, REPORT_DATE, TOTAL_CLAIMS, AVERAGE_CLAIM_AMOUNT, CLAIMS_STATUS_BREAKDOWN)
    VALUES (SEQ_REPORT_ID.NEXTVAL, SYSDATE, v_total_claims, v_avg_claim_amount, v_claims_status_breakdown);

    COMMIT; -- Ensure changes are committed
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error in GenerateClaimsReport: ' || SQLERRM);
END;

/
