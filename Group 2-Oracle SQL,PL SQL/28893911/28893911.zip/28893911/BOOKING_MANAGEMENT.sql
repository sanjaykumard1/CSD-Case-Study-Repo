--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure BOOKING_MANAGEMENT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."BOOKING_MANAGEMENT" (
    p_action IN VARCHAR2,
    p_booking_id IN NUMBER,
    p_customer_id IN NUMBER,
    p_room_id IN NUMBER,
    p_check_in_date IN DATE,
    p_check_out_date IN DATE,
    p_status IN VARCHAR2,
    p_availability IN BOOLEAN

) AS
BEGIN
    IF p_action = 'INSERT' THEN
        BEGIN
            INSERT INTO Booking (BOOKING_ID, CUSTOMER_ID, ROOM_ID, CHECK_IN_DATE, CHECK_OUT_DATE, STATUS)
            VALUES (p_booking_id, p_customer_id, p_room_id, p_check_in_date, p_check_out_date, p_status);
        EXCEPTION
            WHEN DUP_VAL_ON_INDEX THEN
                DBMS_OUTPUT.PUT_LINE('Error: Duplicate booking ID');
        END;
    ELSIF p_action = 'UPDATE' THEN
        UPDATE Booking SET CUSTOMER_ID = p_customer_id, ROOM_ID = p_room_id, CHECK_IN_DATE = p_check_in_date, CHECK_OUT_DATE = p_check_out_date, STATUS = p_status
        WHERE BOOKING_ID = p_booking_id;
    ELSIF p_action = 'DELETE' THEN
        DELETE FROM Booking WHERE BOOKING_ID = p_booking_id;
    END IF;
END BOOKING_MANAGEMENT;

/
