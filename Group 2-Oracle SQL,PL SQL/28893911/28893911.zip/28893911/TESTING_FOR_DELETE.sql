--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure TEST4
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."TEST4" AS 
BEGIN
  BOOKING_MANAGEMENT(
        p_action => 'DELETE',
        p_booking_id => 4,
        p_customer_id => 9,
        p_room_id => 106,
        p_check_in_date => TO_DATE('2021-07-25', 'YYYY-MM-DD'),
        p_check_out_date => TO_DATE('2021-07-28', 'YYYY-MM-DD'),
        p_status => 'Checked In'
    );

END TEST4;

/
