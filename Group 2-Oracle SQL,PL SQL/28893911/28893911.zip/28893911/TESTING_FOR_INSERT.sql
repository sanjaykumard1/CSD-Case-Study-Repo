--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure TEST2
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."TEST2" AS 
BEGIN
  BOOKING_MANAGEMENT(
       p_action => 'INSERT',
        p_booking_id => 5,
       p_customer_id => 7,
        p_room_id => 103,
       p_check_in_date => TO_DATE('2024-07-25', 'YYYY-MM-DD'),
       p_check_out_date => TO_DATE('2024-07-2', 'YYYY-MM-DD'),
        p_status => ('Confirm in')
    
   
        
    

END TEST2;

/
