--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure TEST1
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."TEST1" AS 
BEGIN
    CUSTOMER_REG(
        p_customer_id => 3,
        p_first_name => 'David',
        p_last_name => 'Brown',
        p_email => 'david.brown@example.com',
        p_phone_number => '2222334456',
        p_address => '977 Oak St'
    );

END TEST1;

/
