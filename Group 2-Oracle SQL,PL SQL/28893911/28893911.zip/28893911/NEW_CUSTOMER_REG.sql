--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure CUSTOMER_REG
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."CUSTOMER_REG" (
    p_customer_id IN NUMBER,
    p_first_name IN VARCHAR2,
    p_last_name IN VARCHAR2,
    p_email IN VARCHAR2,
    p_phone_number IN VARCHAR2,
    p_address IN VARCHAR2
) AS
BEGIN
    DBMS_OUTPUT.PUT_LINE('Customer ID: ' || p_customer_id);
    DBMS_OUTPUT.PUT_LINE('First Name: ' || p_first_name);
    DBMS_OUTPUT.PUT_LINE('Last Name: ' || p_last_name);
    DBMS_OUTPUT.PUT_LINE('Email: ' || p_email);
    DBMS_OUTPUT.PUT_LINE('Phone Number: ' || p_phone_number);
    DBMS_OUTPUT.PUT_LINE('Address: ' || p_address);

        IF p_customer_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Customer ID cannot be NULL');
    END IF;

    INSERT INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER, ADDRESS)
    VALUES (p_customer_id, p_first_name, p_last_name, p_email, p_phone_number, p_address);

    DBMS_OUTPUT.PUT_LINE('Customer registered successfully');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: Duplicate customer ID');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);

END CUSTOMER_REG;

/
