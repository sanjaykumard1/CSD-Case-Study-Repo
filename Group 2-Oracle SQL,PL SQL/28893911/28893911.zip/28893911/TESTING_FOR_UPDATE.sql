--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure TEST3
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."TEST3" AS 
BEGIN
  BOOKING_MANAGEMENT(
        p_action => 'UPDATE',
        p_booking_id => 1,
        p_customer_id => 1,
        p_room_id => 107,
        p_check_in_date => TO_DATE('2021-07-25', 'YYYY-MM-DD'),
        p_check_out_date => TO_DATE('2021-07-28', 'YYYY-MM-DD'),
        p_status => 'Checked In');
END TEST3;

/
