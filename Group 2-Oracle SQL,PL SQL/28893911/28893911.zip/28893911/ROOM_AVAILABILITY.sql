--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure UPDATE_ROOM_AVAILABILITY
--------------------------------------------------------
set define off;

  CREATE OR REPLACE NONEDITIONABLE PROCEDURE "SYSTEM"."UPDATE_ROOM_AVAILABILITY" (
   p_room_id IN NUMBER,
  p_availability  IN VARCHAR2)   AS
BEGIN
  UPDATE Rooms
  SET AVAILABLE = p_availability
  WHERE ROOM_ID = p_room_id;
  
  
END UPDATE_ROOM_AVAILABILITY;

/
