--------------------------------------------------------
--  File created - Monday-July-15-2024   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure TEST5
--------------------------------------------------------
set define off;

  CREATE OR REPLACE  PROCEDURE "SYSTEM"."TEST5" AS
BEGIN
     UPDATE_ROOM_AVAILABILITY(104,0);

    
END TEST5;

/
