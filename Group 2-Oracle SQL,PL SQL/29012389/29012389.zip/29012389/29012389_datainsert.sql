-- Insert sample data into Facilities
INSERT INTO Facilities (FACILITY_ID, FACILITY_NAME, LOCATION, CAPACITY, AVAILABLE)
VALUES (1, 'Terminal 1', 'North Wing', 500, 200);

INSERT INTO Facilities (FACILITY_ID, FACILITY_NAME, LOCATION, CAPACITY, AVAILABLE)
VALUES (2, 'Terminal 2', 'South Wing', 600, 300);

--Inserting sample data into Flights
INSERT INTO Flights (FLIGHT_ID, FLIGHT_NUMBER, AIRLINE, ORIGIN, DESTINATION, DEPARTURE_TIME, ARRIVAL_TIME)
VALUES (1, 'AI101', 'Air India', 'Delhi', 'Mumbai', TO_DATE('2024-07-15 06:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-07-15 08:00:00', 'YYYY-MM-DD HH24:MI:SS'));

INSERT INTO Flights (FLIGHT_ID, FLIGHT_NUMBER, AIRLINE, ORIGIN, DESTINATION, DEPARTURE_TIME, ARRIVAL_TIME)
VALUES (2, 'BA202', 'British Airways', 'London', 'Delhi', TO_DATE('2024-07-15 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2024-07-25 21:00:00', 'YYYY:MM:DD HH24:MI:SS'));

--INserting sample data into Services
INSERT INTO Services (SERVICE_ID, SERVICE_TYPE, DESCRIPTION, LOCATION, AVAILABILITY)
VALUES (1, 'Baggage Handling', 'Handles all baggage-related services', 'Terminal 1', 1);

INSERT INTO Services (SERVICE_ID, SERVICE_TYPE, DESCRIPTION, LOCATION, AVAILABILITY)
VALUES (2, 'Food Court', 'Variety of dinning options available', 'Terminal 2', 1);

