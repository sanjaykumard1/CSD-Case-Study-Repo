------------Create Insurance Policies Table
create table insurance_policies(
policy_id number primary key,
customer_id number,
policy_type varchar2(50),
start_date date,
end_date date,
status varchar2(50)
);
-------------insert values into insurance policy table
insert into insurance_policies values(100,234,'health insurance','12/10/2020','12/10/2024','Active');
insert into insurance_policies values(101,235,'home insurance','24/06/2021','12/12/2022','Expired');
insert into insurance_policies values(102,236,'car insurance','31/01/2022','18/12/2023','Expired');
insert into insurance_policies values(103,237,'bike insurance','07/5/2019','31/10/2024','Active');
insert into insurance_policies values(104,238,'pet insurance','12/10/2020','12/10/2024','Pending');
insert into insurance_policies values(105,239,'long-term insurance','24/06/2021','12/12/2024','Pending');
select * from insurance_policies;
----------------------create table for processing reports
create table policy_processing_table(
processing_id number primary key,
processing_date date,
desicion varchar2(50),
remarks varchar2(255),
policy_id number,
constraint fk_policy_id foreign key(policy_id) references insurance_policies(policy_id)
);
insert into policy_processing_table values(200,sysdate,'Active','your policy activated',100);
insert into policy_processing_table values(201,sysdate,'Active','your policy activated',103);
insert into policy_processing_table values(202,sysdate,'Expired','your policy expired',101);
insert into policy_processing_table values(203,sysdate,'Expired','your policy expired',102);
insert into policy_processing_table values(205,sysdate,'Pending','your policy is in pending state',105);
insert into policy_processing_table values(208,sysdate,'Pending','your policy is in pending state',104);
select * from policy_processing_table;
---------------------------------create table for insurance reports 
create table policy_reports_table(
report_id number primary key,
report_date date,
total_policies number,
active_policies number,
expired_policies number,
pending_requests number
);

select * from policy_reports_table;


