

CREATE TABLE Suppliers ( 
    SUPPLIER_ID NUMBER PRIMARY KEY, 
    NAME VARCHAR2(100) NOT NULL, 
    CONTACT_PERSON VARCHAR2(50), 
    PHONE_NUMBER VARCHAR2(15), 
    EMAIL VARCHAR2(100) 
);

CREATE TABLE Products ( 
    PRODUCT_ID NUMBER PRIMARY KEY, 
    NAME VARCHAR2(100) NOT NULL, 
    DESCRIPTION VARCHAR2(255), 
    PRICE NUMBER NOT NULL, 
    STOCK_QUANTITY NUMBER , 
    SUPPLIER_ID NUMBER, 
    CONSTRAINT fk_supplier FOREIGN KEY (SUPPLIER_ID) REFERENCES Suppliers(SUPPLIER_ID) 
);

CREATE TABLE Orders ( 
    ORDER_ID NUMBER PRIMARY KEY, 
    PRODUCT_ID NUMBER, 
    SUPPLIER_ID NUMBER, 
    ORDER_DATE DATE, 
    QUANTITY NUMBER, 
    STATUS VARCHAR2(20), 
    CONSTRAINT fk_product FOREIGN KEY (PRODUCT_ID) REFERENCES Products(PRODUCT_ID), 
    CONSTRAINT fk_O_supplier FOREIGN KEY (SUPPLIER_ID) REFERENCES Suppliers(SUPPLIER_ID) 
);

INSERT INTO Suppliers (SUPPLIER_ID, NAME, CONTACT_PERSON, PHONE_NUMBER, EMAIL) VALUES (1, 'AAA', 'AA', '1111111111', 'AA@mail.com');

INSERT INTO Suppliers (SUPPLIER_ID, NAME, CONTACT_PERSON, PHONE_NUMBER, EMAIL)  
VALUES (2, 'BBB', 'BB', '2222222222', 'BB@mail.com');

INSERT INTO Suppliers (SUPPLIER_ID, NAME, CONTACT_PERSON, PHONE_NUMBER, EMAIL)  
VALUES (3, 'CCC', 'CC', '3333333333', 'CC@mail.com');

INSERT INTO Suppliers (SUPPLIER_ID, NAME, CONTACT_PERSON, PHONE_NUMBER, EMAIL)  
VALUES (4, 'DDD', 'DD', '4444444444', 'DD@mail.com');

INSERT INTO Suppliers (SUPPLIER_ID, NAME, CONTACT_PERSON, PHONE_NUMBER, EMAIL)  
VALUES (5, 'EEE', 'EE', '5555555555', 'EE@mail.com');

select * from Suppliers;

INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, STOCK_QUANTITY, SUPPLIER_ID) VALUES 
(101, 'Pen', 'smooth', 200, 50, 1);

INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, STOCK_QUANTITY, SUPPLIER_ID) VALUES 
(102, 'Pencil', 'write', 20, 300, 2);

INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, STOCK_QUANTITY, SUPPLIER_ID) VALUES 
(103, 'Books', 'engineering', 100, 200, 3);

INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, STOCK_QUANTITY, SUPPLIER_ID) VALUES 
(104, 'Paper', 'A4', 2, 200, 4);

INSERT INTO Products (PRODUCT_ID, NAME, DESCRIPTION, PRICE, STOCK_QUANTITY, SUPPLIER_ID) VALUES 
(105, 'Notes', 'blank', 5, 200, 5);

INSERT INTO Orders (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, ORDER_DATE, QUANTITY, STATUS) VALUES 
(1, 101, 1, TO_DATE('2024-07-01', 'YYYY-MM-DD'), 100, 'Pending');

INSERT INTO Orders (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, ORDER_DATE, QUANTITY, STATUS) VALUES 
(2, 102, 2, TO_DATE('2024-07-02', 'YYYY-MM-DD'), 50, 'Completed');

INSERT INTO Orders (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, ORDER_DATE, QUANTITY, STATUS) VALUES 
(3, 103, 3, TO_DATE('2024-07-03', 'YYYY-MM-DD'), 150, 'Pending');

INSERT INTO Orders (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, ORDER_DATE, QUANTITY, STATUS) VALUES 
(4, 104, 4, TO_DATE('2024-07-04', 'YYYY-MM-DD'), 200, 'Pending');

INSERT INTO Orders (ORDER_ID, PRODUCT_ID, SUPPLIER_ID, ORDER_DATE, QUANTITY, STATUS) VALUES 
(5, 105, 5, TO_DATE('2024-07-05', 'YYYY-MM-DD'), 100, 'Processing');




CREATE OR REPLACE PROCEDURE generate_inventory_report AS 
BEGIN 
    FOR i IN ( 
        SELECT p.PRODUCT_ID, p.NAME AS PRODUCT_NAME, p.DESCRIPTION, p.PRICE, p.STOCK_QUANTITY, s.NAME AS SUPPLIER_NAME, 
               o.ORDER_DATE, o.QUANTITY, o.STATUS 
        FROM Products p 
        JOIN Suppliers s ON p.SUPPLIER_ID = s.SUPPLIER_ID 
        LEFT JOIN Orders o ON p.PRODUCT_ID = o.PRODUCT_ID 
    ) LOOP 
        DBMS_OUTPUT.PUT_LINE('Product ID: ' || i.PRODUCT_ID); 
        DBMS_OUTPUT.PUT_LINE('Product Name: ' || i.PRODUCT_NAME); 
        DBMS_OUTPUT.PUT_LINE('Description: ' || i.DESCRIPTION); 
        DBMS_OUTPUT.PUT_LINE('Price: ' || i.PRICE); 
        DBMS_OUTPUT.PUT_LINE('Stock Quantity: ' || i.STOCK_QUANTITY); 
        DBMS_OUTPUT.PUT_LINE('Supplier Name: ' || i.SUPPLIER_NAME); 
         
        DBMS_OUTPUT.PUT_LINE('Order Date: ' || i.ORDER_DATE); 
        DBMS_OUTPUT.PUT_LINE('Order Quantity: ' || i.QUANTITY); 
        DBMS_OUTPUT.PUT_LINE('Order Status: ' || i.STATUS); 
         
         
    END LOOP; 
	 DBMS_OUTPUT.PUT_LINE(' '); 
         
END;
/

BEGIN 
    generate_inventory_report; 
END;
/

CREATE OR REPLACE PROCEDURE manage_stock ( 
    p_product_id IN NUMBER, 
    p_quantity IN NUMBER 
) AS 
BEGIN 
    UPDATE Products 
    SET STOCK_QUANTITY = STOCK_QUANTITY + p_quantity 
    WHERE PRODUCT_ID = p_product_id; 
     
    DBMS_OUTPUT.PUT_LINE('Stock updated successfully.'); 
END;
/

BEGIN 
    manage_stock(1, 20);  
END;
/

CREATE OR REPLACE PROCEDURE order_product ( 
    p_product_id IN NUMBER, 
    p_quantity IN NUMBER 
) AS 
    v_stock_quantity NUMBER; 
BEGIN 
    SELECT sq INTO v_stock_quantity FROM Products WHERE PRODUCT_ID = p_product_id; 
           
    UPDATE Products 
    SET sq = sq - p_quantity 
    WHERE PRODUCT_ID = p_product_id;        
    DBMS_OUTPUT.PUT_LINE('Order placed successfully.'); 
END;
/

CREATE OR REPLACE PROCEDURE order_product ( 
    p_product_id IN NUMBER, 
    p_quantity IN NUMBER 
) AS 
    v_stock_quantity NUMBER; 
BEGIN 
     
    SELECT STOCK_QUANTITY INTO v_stock_quantity FROM Products WHERE PRODUCT_ID = p_product_id; 
     
    IF v_stock_quantity >= p_quantity THEN 
        UPDATE Products 
        SET STOCK_QUANTITY = STOCK_QUANTITY - p_quantity 
        WHERE PRODUCT_ID = p_product_id; 
         
        DBMS_OUTPUT.PUT_LINE('Order placed successfully.'); 
    ELSE 
        DBMS_OUTPUT.PUT_LINE('Insufficient stock.'); 
    END IF; 
END; 



BEGIN 
    order_product(101, 5);  
END; 

/

BEGIN 
    generate_inventory_report; 
END; 

/

