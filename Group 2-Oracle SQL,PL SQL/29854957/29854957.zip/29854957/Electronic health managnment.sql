-- creating table of patients
CREATE TABLE patients (
    Patient_ID NUMBER PRIMARY KEY,
    First_Name VARCHAR2(50),
    Last_Name VARCHAR2(50),
    Date_of_Birth DATE
);


--Creating Table for health record
CREATE TABLE health_record (
    Record_ID NUMBER PRIMARY KEY,
    Patient_ID NUMBER,
    visit_date DATE,
    diagnosis CLOB,
    treatment CLOB,
    medication CLOB,
    FOREIGN KEY (Patient_ID) REFERENCES patients (Patient_ID)
);

--Creating table for diagnosis
CREATE TABLE diagnosis (
    Diagnosis_ID NUMBER PRIMARY KEY,
    Patient_ID NUMBER,
    Diagnosis_DATE DATE,
    Diagnosis_DESCRIPTION CLOB,
    Diagnosis_STATUS VARCHAR2(50),
    FOREIGN KEY (Patient_ID) REFERENCES patients (Patient_ID)
);

--Creating table for medication
CREATE TABLE medication (
    Medication_ID NUMBER PRIMARY KEY,
    Patient_ID NUMBER,
    Medication_NAME VARCHAR2(100),
    DOSAGE VARCHAR2(50),
    FREQUENCY VARCHAR2(50),
    START_DATE DATE,
    FOREIGN KEY (Patient_ID) REFERENCES patients (Patient_ID)
);

-- Inserting values in patient table
INSERT INTO patients (Patient_ID, First_Name, Last_Name, Date_of_Birth)
VALUES (101, 'John', 'Doe', TO_DATE('1980-01-01', 'YYYY-MM-DD'));

INSERT INTO patients (Patient_ID, First_Name, Last_Name, Date_of_Birth)
VALUES (102, 'Jane', 'Smith', TO_DATE('1985-02-15', 'YYYY-MM-DD'));

INSERT INTO patients (Patient_ID, First_Name, Last_Name, Date_of_Birth)
VALUES (103, 'Emily', 'Jones', TO_DATE('1990-03-20', 'YYYY-MM-DD'));

INSERT INTO patients (Patient_ID, First_Name, Last_Name, Date_of_Birth)
VALUES (104, 'Michael', 'Brown', TO_DATE('1995-04-25', 'YYYY-MM-DD'));

--Inserting values in health_record table
INSERT INTO health_record (Record_ID, Patient_ID, visit_date, diagnosis, treatment, medication)
VALUES (1, 101, TO_DATE('2023-07-12', 'YYYY-MM-DD'), 'Pneumonia', 'Antibiotics and rest', 'Amoxicillin');

INSERT INTO health_record (Record_ID, Patient_ID, visit_date, diagnosis, treatment, medication)
VALUES (2, 102, TO_DATE('2023-07-13', 'YYYY-MM-DD'), 'Flu', 'Rest and fluids', 'Tamiflu');

INSERT INTO health_record (Record_ID, Patient_ID, visit_date, diagnosis, treatment, medication)
VALUES (3, 103, TO_DATE('2023-07-14', 'YYYY-MM-DD'), 'Headache', 'Pain relievers', 'Ibuprofen');

INSERT INTO health_record (Record_ID, Patient_ID, visit_date, diagnosis, treatment, medication)
VALUES (4, 104, TO_DATE('2023-07-15', 'YYYY-MM-DD'), 'Stomach Ache', 'Antacids', 'Tums');

--Inserting values in diagnosis table
INSERT INTO diagnosis (Diagnosis_ID, Patient_ID, Diagnosis_DATE, Diagnosis_DESCRIPTION, Diagnosis_STATUS)
VALUES (1, 101, TO_DATE('2023-01-15', 'YYYY-MM-DD'), 'Upper Respiratory Infection', 'Active');

INSERT INTO diagnosis (Diagnosis_ID, Patient_ID, Diagnosis_DATE, Diagnosis_DESCRIPTION, Diagnosis_STATUS)
VALUES (2, 102, TO_DATE('2023-01-16', 'YYYY-MM-DD'), 'Bronchitis', 'Resolved');

INSERT INTO diagnosis (Diagnosis_ID, Patient_ID, Diagnosis_DATE, Diagnosis_DESCRIPTION, Diagnosis_STATUS)
VALUES (3, 103, TO_DATE('2023-01-17', 'YYYY-MM-DD'), 'Diabetes Type 2', 'Ongoing');

INSERT INTO diagnosis (Diagnosis_ID, Patient_ID, Diagnosis_DATE, Diagnosis_DESCRIPTION, Diagnosis_STATUS)
VALUES (4, 104, TO_DATE('2023-01-18', 'YYYY-MM-DD'), 'Hypertension', 'Active');

--Inserting values into medication table
INSERT INTO medication (Medication_ID, Patient_ID, Medication_NAME, DOSAGE, FREQUENCY, START_DATE)
VALUES (1, 101, 'Amoxicillin', '500 mg', 'Twice daily', TO_DATE('2023-07-12', 'YYYY-MM-DD'));

INSERT INTO medication (Medication_ID, Patient_ID, Medication_NAME, DOSAGE, FREQUENCY, START_DATE)
VALUES (2, 102, 'Ibuprofen', '200 mg', 'Once daily', TO_DATE('2023-07-13', 'YYYY-MM-DD'));

INSERT INTO medication (Medication_ID, Patient_ID, Medication_NAME, DOSAGE, FREQUENCY, START_DATE)
VALUES (3, 103, 'Azithromycin', '250 mg', 'Once daily', TO_DATE('2023-07-14', 'YYYY-MM-DD'));

INSERT INTO medication (Medication_ID, Patient_ID, Medication_NAME, DOSAGE, FREQUENCY, START_DATE)
VALUES (4, 104, 'Metformin', '500 mg', 'Twice daily', TO_DATE('2023-07-15', 'YYYY-MM-DD'));


--Creating a procedure to manage medication
CREATE OR REPLACE PROCEDURE ManageMedication (
    p_Action IN VARCHAR2,           
    p_Medication_ID IN NUMBER,      
    p_Patient_ID IN NUMBER,        
    p_Medication_NAME IN VARCHAR2, 
    p_DOSAGE IN VARCHAR2,           
    p_FREQUENCY IN VARCHAR2,        
    p_START_DATE IN DATE            
) AS
BEGIN
    IF p_Action = 'INSERT' THEN
        INSERT INTO medication (
            Medication_ID, Patient_ID, Medication_NAME, DOSAGE, FREQUENCY, START_DATE
        ) VALUES (
            p_Medication_ID, p_Patient_ID, p_Medication_NAME, p_DOSAGE, p_FREQUENCY, p_START_DATE
        );
        DBMS_OUTPUT.PUT_LINE('Medication record inserted successfully.');

    ELSIF p_Action = 'UPDATE' THEN
        UPDATE medication
        SET
            Patient_ID = p_Patient_ID,
            Medication_NAME = p_Medication_NAME,
            DOSAGE = p_DOSAGE,
            FREQUENCY = p_FREQUENCY,
            START_DATE = p_START_DATE
        WHERE Medication_ID = p_Medication_ID;
        DBMS_OUTPUT.PUT_LINE('Medication record updated successfully.');

    ELSIF p_Action = 'DELETE' THEN
        DELETE FROM medication
        WHERE Medication_ID = p_Medication_ID;
        DBMS_OUTPUT.PUT_LINE('Medication record deleted successfully.');

    ELSE
        DBMS_OUTPUT.PUT_LINE('Invalid action specified. Use INSERT, UPDATE, or DELETE.');
    END IF;
END;
/

--Creating a procedure to manage health_record
CREATE OR REPLACE PROCEDURE ManageHealth_Record (
    p_Action IN VARCHAR2,           
    p_Record_ID IN NUMBER,          
    p_Patient_ID IN NUMBER,        
    p_visit_date IN DATE,          
    p_diagnosis IN CLOB,           
    p_treatment IN CLOB,           
    p_medication IN CLOB           
) AS
BEGIN
    IF p_Action = 'INSERT' THEN
        INSERT INTO health_record (
            Record_ID, Patient_ID, visit_date, diagnosis, treatment, medication
        ) VALUES (
            p_Record_ID, p_Patient_ID, p_visit_date, p_diagnosis, p_treatment, p_medication
        );
        DBMS_OUTPUT.PUT_LINE('Health record inserted successfully.');

    ELSIF p_Action = 'UPDATE' THEN
        UPDATE health_record
        SET
            Patient_ID = p_Patient_ID,
            visit_date = p_visit_date,
            diagnosis = p_diagnosis,
            treatment = p_treatment,
            medication = p_medication
        WHERE Record_ID = p_Record_ID;
        DBMS_OUTPUT.PUT_LINE('Health record updated successfully.');

    ELSIF p_Action = 'DELETE' THEN
        DELETE FROM health_record
        WHERE Record_ID = p_Record_ID;
        DBMS_OUTPUT.PUT_LINE('Health record deleted successfully.');

    ELSE
        DBMS_OUTPUT.PUT_LINE('Invalid action');
    END IF;
END;
/
--Retrieve records for July 12, 2023
SELECT *
FROM health_record
WHERE Visit_Date = TO_DATE('2023-07-12', 'YYYY-MM-DD');

--Create a procedure to manage diagnosis
CREATE OR REPLACE PROCEDURE ManageDiagnosis (
    p_Action IN VARCHAR2,              
    p_Diagnosis_ID IN NUMBER,          
    p_Patient_ID IN NUMBER,            
    p_Diagnosis_DATE IN DATE,          
    p_Diagnosis_DESCRIPTION IN CLOB,   
    p_Diagnosis_STATUS IN VARCHAR2     
) AS
BEGIN
    IF p_Action = 'INSERT' THEN
        INSERT INTO diagnosis (
            Diagnosis_ID, Patient_ID, Diagnosis_DATE, Diagnosis_DESCRIPTION, Diagnosis_STATUS
        ) VALUES (
            p_Diagnosis_ID, p_Patient_ID, p_Diagnosis_DATE, p_Diagnosis_DESCRIPTION, p_Diagnosis_STATUS
        );
        DBMS_OUTPUT.PUT_LINE('Diagnosis record inserted successfully.');

    ELSIF p_Action = 'UPDATE' THEN
        UPDATE diagnosis
        SET
            Patient_ID = p_Patient_ID,
            Diagnosis_DATE = p_Diagnosis_DATE,
            Diagnosis_DESCRIPTION = p_Diagnosis_DESCRIPTION,
            Diagnosis_STATUS = p_Diagnosis_STATUS
        WHERE Diagnosis_ID = p_Diagnosis_ID;
        DBMS_OUTPUT.PUT_LINE('Diagnosis record updated successfully.');

    ELSE
        DBMS_OUTPUT.PUT_LINE('Invalid action.');
    END IF;
END;
/

-- retrive patient record
SELECT * FROM patients WHERE Patient_ID = 104;

INSERT INTO patients (Patient_ID, First_Name, Last_Name, Date_of_Birth)
VALUES (105, 'Alice', 'Green', TO_DATE('1982-07-15', 'YYYY-MM-DD'));

BEGIN
    ManageDiagnosis(
        p_Action => 'INSERT',
        p_Diagnosis_ID => 5,
        p_Patient_ID => 105,
        p_Diagnosis_DATE => TO_DATE('2024-05-01', 'YYYY-MM-DD'),
        p_Diagnosis_DESCRIPTION => 'Chronic Fatigue Syndrome',
        p_Diagnosis_STATUS => 'Active'
    );
END;
/

---- Retrieve records for the year 2023
SELECT *
FROM health_record
WHERE Visit_Date BETWEEN TO_DATE('2023-01-01', 'YYYY-MM-DD')
                     AND TO_DATE('2023-12-31', 'YYYY-MM-DD');
