CREATE TABLE CUSTOMERS(
    CUSTOMER_ID NUMBER PRIMARY KEY,
    FIRST_NAME VARCHAR2(50),
    LAST_NAME VARCHAR2(50),
    EMAIL VARCHAR2(100),
    PHONE_NUMBER VARCHAR2(15),
    ADDRESS VARCHAR2(200)
    );
    
CREATE TABLE ITINERARIES(
    ITINERARY_ID NUMBER PRIMARY KEY,
    DESTINATION VARCHAR2(100),
    DEPARTURE_DATE DATE,
    RETURN_DATE DATE,
    TRANSPORTATION VARCHAR2(100),
    ACCOMODATION VARCHAR2(100)
);

CREATE TABLE BOOKINGS(
    BOOKING_ID NUMBER PRIMARY KEY,
    CUSTOMER_ID NUMBER,
    ITINERARY_ID NUMBER,
    BOOKING_DATE DATE,
    DEPARTURE_DATE DATE,
    RETURN_DATE DATE,
    STATUS VARCHAR2(50),
    FOREIGN KEY (CUSTOMER_ID) REFERENCES CUSTOMERS(CUSTOMER_ID),
    FOREIGN KEY (ITINERARY_ID) REFERENCES ITINERARIES(ITINERARY_ID)
);

/*
INSERT INTO CUSTOMERS VALUES(1001,'Ashlene','Rachel','ashlenerachel@gmail.com','7632488543','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1002,'Ramya','Joseph','ramyajoseph@gmail.com','5644332277','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1003,'Beerl','Kensington','berlyken@gmail.com','8877332200','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1004,'Catherine','Leese','cl@gmail.com','3311775533','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1005,'Diana','Matthew','dm@gmail.com','0033115448','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1006,'Elizabeth','Noah','en@gmail.com','5522117755','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1007,'Fiona','Oliver','fo@gmail.com','0055336677','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1008,'Ginny','Peter','gp@gmail.com','9944223366','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1009,'Helena','Quince','hq@gmail.com','9874234433','123 steet park avenue, colony');
INSERT INTO CUSTOMERS VALUES(1010,'Iduna','Samiel','is@gmail.com','7632488543','123 steet park avenue, colony');*/
select * from customers;
SELECT * FROM ITINERARIES;
SELECT * FROM BOOKINGS;