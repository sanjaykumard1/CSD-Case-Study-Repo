-- RawMaterials Table
CREATE TABLE RawMaterials (
    MATERIAL_ID NUMBER PRIMARY KEY,
    NAME VARCHAR2(100),
    DESCRIPTION VARCHAR2(255),
    UNIT_COST NUMBER,
    QUANTITY_IN_STOCK NUMBER
);

-- FinishedProducts Table
CREATE TABLE FinishedProducts (
    PRODUCT_ID NUMBER PRIMARY KEY,
    NAME VARCHAR2(100),
    CATEGORY VARCHAR2(100),
    UNIT_PRICE NUMBER,
    QUANTITY_IN_STOCK NUMBER
);

-- InventoryMovements Table
CREATE TABLE InventoryMovements (
    MOVEMENT_ID NUMBER PRIMARY KEY,
    ITEM_ID NUMBER,
    MOVEMENT_TYPE VARCHAR2(10),
    QUANTITY NUMBER,
    MOVEMENT_DATE DATE,
    DESCRIPTION VARCHAR2(255),
    CONSTRAINT fk_item FOREIGN KEY (ITEM_ID) REFERENCES RawMaterials(MATERIAL_ID) ON DELETE CASCADE
);

-- Sample Data for RawMaterials
INSERT INTO RawMaterials (MATERIAL_ID, NAME, DESCRIPTION, UNIT_COST, QUANTITY_IN_STOCK)
VALUES (1, 'Steel', 'High quality steel', 50, 1000);

INSERT INTO RawMaterials (MATERIAL_ID, NAME, DESCRIPTION, UNIT_COST, QUANTITY_IN_STOCK)
VALUES (2, 'Plastic', 'Durable plastic', 20, 5000);

-- Sample Data for FinishedProducts
INSERT INTO FinishedProducts (PRODUCT_ID, NAME, CATEGORY, UNIT_PRICE, QUANTITY_IN_STOCK)
VALUES (1, 'Bicycle', 'Transportation', 150, 200);

INSERT INTO FinishedProducts (PRODUCT_ID, NAME, CATEGORY, UNIT_PRICE, QUANTITY_IN_STOCK)
VALUES (2, 'Chair', 'Furniture', 50, 300);

-- Sample Data for InventoryMovements
INSERT INTO InventoryMovements (MOVEMENT_ID, ITEM_ID, MOVEMENT_TYPE, QUANTITY, MOVEMENT_DATE, DESCRIPTION)
VALUES (1, 1, 'Entry', 100, SYSDATE, 'Initial stock of Steel');

INSERT INTO InventoryMovements (MOVEMENT_ID, ITEM_ID, MOVEMENT_TYPE, QUANTITY, MOVEMENT_DATE, DESCRIPTION)
VALUES (2, 2, 'Entry', 500, SYSDATE, 'Initial stock of Plastic');

select * from RawMaterials;
select * from FinishedProducts;
select * from InventoryMovements;