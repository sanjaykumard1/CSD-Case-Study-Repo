REM   Script: Case Study
REM   Case Study procedures.

CREATE TABLE Products ( 
    PRODUCT_ID NUMBER PRIMARY KEY, 
    NAME VARCHAR2(100), 
    CATEGORY VARCHAR2(50), 
    DESCRIPTION VARCHAR2(255), 
    MANUFACTURING_DATE DATE, 
    BATCH_NUMBER VARCHAR2(50) 
);

CREATE TABLE Inspections ( 
    INSPECTION_ID NUMBER PRIMARY KEY, 
    PRODUCT_ID NUMBER, 
    INSPECTION_DATE DATE, 
    INSPECTOR_NAME VARCHAR2(100), 
    RESULT VARCHAR2(50), 
    CONSTRAINT fk_product_inspection FOREIGN KEY (PRODUCT_ID) REFERENCES Products(PRODUCT_ID) 
);

CREATE TABLE Defects ( 
    DEFECT_ID NUMBER PRIMARY KEY, 
    INSPECTION_ID NUMBER, 
    DESCRIPTION VARCHAR2(255), 
    SEVERITY VARCHAR2(50), 
    STATUS VARCHAR2(50), 
    CONSTRAINT fk_inspection_defect FOREIGN KEY (INSPECTION_ID) REFERENCES Inspections(INSPECTION_ID) 
);

CREATE TABLE CorrectiveActions ( 
    ACTION_ID NUMBER PRIMARY KEY, 
    DEFECT_ID NUMBER, 
    DESCRIPTION VARCHAR2(255), 
    RESPONSIBLE_PERSON VARCHAR2(100), 
    ACTION_DATE DATE, 
    STATUS VARCHAR2(50), 
    CONSTRAINT fk_defect_action FOREIGN KEY (DEFECT_ID) REFERENCES Defects(DEFECT_ID) 
);

INSERT INTO Products (PRODUCT_ID, NAME, CATEGORY, DESCRIPTION, MANUFACTURING_DATE, BATCH_NUMBER) 
VALUES (1, 'Product A', 'Category X', 'Description of Product A', TO_DATE('2023-01-15', 'YYYY-MM-DD'), 'BATCH001');

INSERT INTO CorrectiveActions (ACTION_ID, DEFECT_ID, DESCRIPTION, RESPONSIBLE_PERSON, ACTION_DATE, STATUS) 
VALUES (1, 1, 'Polish affected area', 'Maintenance Team', TO_DATE('2024-07-16', 'YYYY-MM-DD'), 'Closed');

INSERT INTO Inspections (INSPECTION_ID, PRODUCT_ID, INSPECTION_DATE, INSPECTOR_NAME, RESULT) 
VALUES (1, 1, TO_DATE('2024-07-15', 'YYYY-MM-DD'), 'John Doe', 'Pass');

INSERT INTO Defects (DEFECT_ID, INSPECTION_ID, DESCRIPTION, SEVERITY, STATUS) 
VALUES (1, 1, 'Scratch on surface', 'Minor', 'Open');

CREATE OR REPLACE PROCEDURE ScheduleInspection ( 
    p_product_id IN NUMBER, 
    p_inspection_date IN DATE, 
    p_inspector_name IN VARCHAR2, 
    p_result IN VARCHAR2 
) AS 
    v_inspection_id NUMBER; 
BEGIN 
    SELECT MAX(INSPECTION_ID) + 1 INTO v_inspection_id FROM Inspections; 
    INSERT INTO Inspections (INSPECTION_ID, PRODUCT_ID, INSPECTION_DATE, INSPECTOR_NAME, RESULT) 
    VALUES (v_inspection_id, p_product_id, p_inspection_date, p_inspector_name, p_result); 
END ScheduleInspection; 
 

/

CREATE OR REPLACE PROCEDURE LogDefect ( 
    p_inspection_id IN NUMBER, 
    p_description IN VARCHAR2, 
    p_severity IN VARCHAR2, 
    p_status IN VARCHAR2 
) AS 
BEGIN 
    INSERT INTO Defects (DEFECT_ID, INSPECTION_ID, DESCRIPTION, SEVERITY, STATUS) 
    VALUES ((SELECT NVL(MAX(DEFECT_ID), 0) + 1 FROM Defects), p_inspection_id, p_description, p_severity, p_status); 
    UPDATE Inspections SET RESULT = 'Fail' WHERE INSPECTION_ID = p_inspection_id; 
END LogDefect; 

/

CREATE OR REPLACE PROCEDURE GenerateQualityReport AS 
BEGIN 
    FOR rec IN (SELECT p.NAME, i.INSPECTION_DATE, i.RESULT, d.DESCRIPTION, d.SEVERITY, d.STATUS 
                FROM Products p 
                JOIN Inspections i ON p.PRODUCT_ID = i.PRODUCT_ID 
                LEFT JOIN Defects d ON i.INSPECTION_ID = d.INSPECTION_ID) LOOP 
        DBMS_OUTPUT.PUT_LINE('Product Name: ' || rec.NAME); 
        DBMS_OUTPUT.PUT_LINE('Inspection Date: ' || TO_CHAR(rec.INSPECTION_DATE, 'YYYY-MM-DD')); 
        DBMS_OUTPUT.PUT_LINE('Result: ' || rec.RESULT); 
        IF rec.DESCRIPTION IS NOT NULL THEN 
            DBMS_OUTPUT.PUT_LINE('Defect: ' || rec.DESCRIPTION); 
            DBMS_OUTPUT.PUT_LINE('Severity: ' || rec.SEVERITY); 
            DBMS_OUTPUT.PUT_LINE('Status: ' || rec.STATUS); 
        END IF; 
        DBMS_OUTPUT.PUT_LINE('-----------------------------'); 
    END LOOP; 
END GenerateQualityReport; 
 
 
BEGIN 
    ScheduleInspection(1, TO_DATE('2024-07-16', 'YYYY-MM-DD'), 'Alice Smith', 'Pass'); 
    DBMS_OUTPUT.PUT_LINE('Inspection scheduled successfully.'); 
EXCEPTION 
    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('Error scheduling inspection: ' || SQLERRM); 
END; 
 
BEGIN 
    LogDefect(1, 'Crack on the surface', 'Major', 'Open'); 
    DBMS_OUTPUT.PUT_LINE('Defect logged successfully.'); 
EXCEPTION 
    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('Error logging defect: ' || SQLERRM); 
END; 
 
BEGIN 
    GenerateQualityReport; 
END;
/

CREATE OR REPLACE PROCEDURE GenerateQualityReport AS 
BEGIN 
    FOR rec IN (SELECT p.NAME, i.INSPECTION_DATE, i.RESULT, d.DESCRIPTION, d.SEVERITY, d.STATUS 
                FROM Products p 
                JOIN Inspections i ON p.PRODUCT_ID = i.PRODUCT_ID 
                LEFT JOIN Defects d ON i.INSPECTION_ID = d.INSPECTION_ID) LOOP 
        DBMS_OUTPUT.PUT_LINE('Product Name: ' || rec.NAME); 
        DBMS_OUTPUT.PUT_LINE('Inspection Date: ' || TO_CHAR(rec.INSPECTION_DATE, 'YYYY-MM-DD')); 
        DBMS_OUTPUT.PUT_LINE('Result: ' || rec.RESULT); 
        IF rec.DESCRIPTION IS NOT NULL THEN 
            DBMS_OUTPUT.PUT_LINE('Defect: ' || rec.DESCRIPTION); 
            DBMS_OUTPUT.PUT_LINE('Severity: ' || rec.SEVERITY); 
            DBMS_OUTPUT.PUT_LINE('Status: ' || rec.STATUS); 
        END IF; 
        DBMS_OUTPUT.PUT_LINE('-----------------------------'); 
    END LOOP; 
END GenerateQualityReport; 

/

BEGIN 
    LogDefect(1, 'Crack on the surface', 'Major', 'Open'); 
    DBMS_OUTPUT.PUT_LINE('Defect logged successfully.'); 
EXCEPTION 
    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('Error logging defect: ' || SQLERRM); 
END;
/

BEGIN 
    ScheduleInspection(1, TO_DATE('2024-07-16', 'YYYY-MM-DD'), 'Alice Smith', 'Pass'); 
    DBMS_OUTPUT.PUT_LINE('Inspection scheduled successfully.'); 
EXCEPTION 
    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('Error scheduling inspection: ' || SQLERRM); 
END;
/

BEGIN 
    GenerateQualityReport; 
END;
/

