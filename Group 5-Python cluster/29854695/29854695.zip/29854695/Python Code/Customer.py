from mysql.connector import Error

class Customer:
    def __init__(self, customerId, name, email, address):
        self.customerId = customerId
        self.name = name
        self.email = email
        self.address = address

    def add_customer(self, connection):
        try:
            cursor = connection.cursor()
            query = """INSERT INTO customers (name, email, address)
                       VALUES (%s, %s, %s)"""
            cursor.execute(query, (self.name, self.email, self.address))
            connection.commit()
            query2 = """SELECT customerId FROM customers ORDER BY customerId DESC LIMIT 1;"""
            cursor.execute(query2)
            customerid = cursor.fetchall()
            print(f"Customer added successfully. Your CustomerId is : {customerid[0]}")
        except Error as e:
            print(f"Error: {e}")
    
    def update_customer(self, connection):
        try:
            cursor = connection.cursor()
            query = """UPDATE customers SET name = %s, email = %s, address = %s
                       WHERE customerId = %s"""
            cursor.execute(query, (self.name, self.email, self.address, self.customerId))
            connection.commit()
            print("Customer updated successfully.")
        except Error as e:
            print(f"Error: {e}")
    
    def delete_customer(self, connection):
        try:
            cursor = connection.cursor()
            query = "DELETE FROM customers WHERE customerId = %s"
            cursor.execute(query, (self.customerId,))
            connection.commit()
            print("Customer deleted successfully.")
        except Error as e:
            print(f"Error: {e}")

    @staticmethod
    def show_all_customers(connection):
        try:
            cursor = connection.cursor()
            query = "SELECT * FROM customers"
            cursor.execute(query)
            customers = cursor.fetchall()
            if not customers:
                print("No customers found.")
            else:
                print("\nCustomer Details:")
                print("--------------------------------------------------")
                for customer in customers:
                    print(f"Customer ID: {customer[0]}")
                    print(f"Name: {customer[1]}")
                    print(f"Email: {customer[2]}")
                    print(f"Address: {customer[3]}")
                    print("--------------------------------------------------")
        except Error as e:
            print(f"Error: {e}")

