import mysql.connector
from mysql.connector import Error
def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='ecommerce',
            user='root',
            password='admin123'
        )
        if connection.is_connected():
            print("Connected to MySQL database")
            return connection
    except Error as e:
        print(f"Error: {e}")
        return None