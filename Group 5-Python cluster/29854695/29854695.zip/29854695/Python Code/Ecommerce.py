import Connection  #this module connects to the database
from datetime import date
from Customer import Customer
from Orders import Order
from Product import Product

def main():
    # Establish database connection
    connection = Connection.connect_to_db()
    if not connection:
        return
    
    while True:
        print("\nEcommerce Management System")
        print("1. Customer Details (Add, Update, Delete, Show)")
        print("2. Product Details (Add, Update, Delete, Show)")
        print("3. Order Details (Place Order, Delete Order, Show Orders)")
        print("4. Exit")

        Mainchoice = input("Enter your choice: ")

        if Mainchoice == '1':
            # Customer Management System
            while True:
                print("\nE-commerce Customer Management System")
                print("1. Add Customer")
                print("2. Update Customer")
                print("3. Delete Customer")
                print("4. Show All Customers")
                print("5. Exit")

                choice = input("Enter your choice: ")

                if choice == '1':
                    # Add Customer
                    name = input("Enter customer name: ")
                    email = input("Enter customer email: ")
                    address = input("Enter customer address: ")
                    customer = Customer(None, name, email, address)
                    customer.add_customer(connection)

                elif choice == '2':
                    # Update Customer
                    customerId = int(input("Enter customer ID to update: "))
                    name = input("Enter new customer name: ")
                    email = input("Enter new customer email: ")
                    address = input("Enter new customer address: ")
                    customer = Customer(customerId, name, email, address)
                    customer.update_customer(connection)

                elif choice == '3':
                    # Delete Customer
                    customerId = int(input("Enter customer ID to delete: "))
                    customer = Customer(customerId, None, None, None)
                    customer.delete_customer(connection)

                elif choice == '4':
                    # Show All Customers
                    Customer.show_all_customers(connection)

                elif choice == '5':
                    # Exit Customer Management
                    break

                else:
                    print("Invalid choice. Please try again.")

        elif Mainchoice == '2':
            # Product Management System
            while True:
                print("\nE-commerce Product Management System")
                print("1. Add Product")
                print("2. Update Product")
                print("3. Delete Product")
                print("4. Show All Products")
                print("5. Exit")

                choice = input("Enter your choice: ")

                if choice == '1':
                    # Add Product
                    name = input("Enter product name: ")
                    description = input("Enter product description: ")
                    price = float(input("Enter product price: "))
                    stockQuantity = int(input("Enter stock quantity: "))
                    product = Product(None, name, description, price, stockQuantity)
                    product.add_product(connection)

                elif choice == '2':
                    # Update Product
                    productId = int(input("Enter product ID to update: "))
                    name = input("Enter new product name: ")
                    description = input("Enter new product description: ")
                    price = float(input("Enter new product price: "))
                    stockQuantity = int(input("Enter new stock quantity: "))
                    product = Product(productId, name, description, price, stockQuantity)
                    product.update_product(connection)

                elif choice == '3':
                    # Delete Product
                    productId = int(input("Enter product ID to delete: "))
                    product = Product(productId, None, None, None, None)
                    product.delete_product(connection)
                
                elif choice == '4':
                    # Show All Products
                    Product.show_all_products(connection)

                elif choice == '5':
                    # Exit Product Management
                    break

                else:
                    print("Invalid choice. Please try again.")

        elif Mainchoice == '3':
            # Order Management System
            while True:
                print("\nE-commerce Order Management System")
                print("1. Place Order")
                print("2. Delete Order")
                print("3. Show All Orders")
                print("4. Exit")

                choice = input("Enter your choice: ")

                if choice == '1':
                    # Place Order
                    customerId = int(input("Enter customer ID: "))
                    productId = int(input("Enter product ID: "))
                    quantity = int(input("Enter quantity: "))
                    orderDate = date.today().isoformat()
                    order = Order(None, customerId, productId, orderDate, quantity)
                    order.place_order(connection)

                elif choice == '2':
                    # Delete Order
                    orderId = int(input("Enter order ID to delete: "))
                    order = Order(orderId, None, None, None, None)
                    order.delete_order(connection)

                elif choice == '3':
                    # Show All Orders
                    Order.show_all_orders(connection)

                elif choice == '4':
                    # Exit Order Management
                    break

                else:
                    print("Invalid choice. Please try again.")
        
        elif Mainchoice == '4':
            # Exit the program
            break

        else:
            print("Invalid choice. Please try again.")

    # Close database connection when exiting
    connection.close()

if __name__ == "__main__":
    main()
