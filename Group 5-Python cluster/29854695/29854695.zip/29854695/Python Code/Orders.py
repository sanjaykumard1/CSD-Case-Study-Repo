from mysql.connector import Error
from datetime import date
class Order:
    def __init__(self, orderId, customerId, productId, orderDate, quantity):
        self.orderId = orderId
        self.customerId = customerId
        self.productId = productId
        self.orderDate = orderDate
        self.quantity = quantity

    def place_order(self, connection):
        try:
            cursor = connection.cursor()

            # Insert order into orders table
            insert_query = """INSERT INTO orders (customerId, productId, orderDate, quantity)
                              VALUES (%s, %s, %s, %s)"""
            cursor.execute(insert_query, (self.customerId, self.productId, self.orderDate, self.quantity))
            connection.commit()
            
            # Update product stock quantity
            update_query = """UPDATE products SET stockQuantity = stockQuantity - %s
                              WHERE productId = %s"""
            cursor.execute(update_query, (self.quantity, self.productId))
            connection.commit()

            print("Order placed successfully.")
        except Error as e:
            if f"Error: {e}"=="Error: 1690 (22003): BIGINT UNSIGNED value is out of range in '(`ecommerce`.`products`.`stockQuantity` - 100)'":
                print("Product out of Stock")
            else:
                print(f"Error: {e}")
    
    def delete_order(self, connection):
        try:
            cursor = connection.cursor()

            # Get order details before deletion
            select_query = "SELECT productId, quantity FROM orders WHERE orderId = %s"
            cursor.execute(select_query, (self.orderId,))
            order_details = cursor.fetchone()

            if not order_details:
                print(f"No order found with ID {self.orderId}.")
                return

            productId, quantity = order_details

            # Delete order from orders table
            delete_query = "DELETE FROM orders WHERE orderId = %s"
            cursor.execute(delete_query, (self.orderId,))
            connection.commit()

            # Update product stock quantity
            update_query = """UPDATE products SET stockQuantity = stockQuantity + %s
                              WHERE productId = %s"""
            cursor.execute(update_query, (quantity, productId))
            connection.commit()

            print("Order deleted successfully.")
        except Error as e:
            print(f"Error: {e}")
    
    @staticmethod
    def show_all_orders(connection):
        try:
            cursor = connection.cursor()
            query = "select C.name,O.customerId,P.name,O.orderId, O.orderdate, O.quantity from Orders O join Customers C on o.customerID=C.customerID join Products P on P.productId = O.customerId "
            cursor.execute(query)
            orders = cursor.fetchall()
            if not orders:
                print("No orders found.")
            else:
                print("\nOrder Details:")
                print("--------------------------------------------------")
                for order in orders:
                    print(f"Customer Name: {order[0]}")
                    print(f"Customer ID: {order[1]}")
                    print(f"Product Name: {order[2]}")
                    print(f"Order Id: {order[3]}")
                    print(f"Order Date: {order[4]}")
                    print(f"Quantity: {order[5]}")
                    print("--------------------------------------------------")
        except Error as e:
            print(f"Error: {e}")

class Product:
    def __init__(self, productId, name, description, price, stockQuantity):
        self.productId = productId
        self.name = name
        self.description = description
        self.price = price
        self.stockQuantity = stockQuantity

    def update_stockQuantity(self, connection):
        try:
            cursor = connection.cursor()
            query = """UPDATE products SET stockQuantity = %s
                       WHERE productId = %s"""
            cursor.execute(query, (self.stockQuantity, self.productId))
            connection.commit()
            print("Stock quantity updated successfully.")
        except Error as e:
            print(f"Error: {e}")


