
from mysql.connector import Error
import Connection
class Product:
    def __init__(self, productId, name, description, price, stockQuantity):
        self.productId = productId
        self.name = name
        self.description = description
        self.price = price
        self.stockQuantity = stockQuantity

    def add_product(self, connection):
        try:
            cursor = connection.cursor()
            query = """INSERT INTO products (name, description, price, stockQuantity)
                       VALUES (%s, %s, %s, %s)"""
            cursor.execute(query, (self.name, self.description, self.price, self.stockQuantity))
            connection.commit()
            query2 = """SELECT productId FROM products ORDER BY productId DESC LIMIT 1;"""
            cursor.execute(query2)
            productid = cursor.fetchall()
            print(f"Product added successfully. Your ProductId is : {productid[0]}")
        except Error as e:
            print(f"Error: {e}")
    
    def update_product(self, connection):
        try:
            cursor = connection.cursor()
            query = """UPDATE products SET name = %s, description = %s, price = %s, stockQuantity = %s
                       WHERE productId = %s"""
            cursor.execute(query, (self.name, self.description, self.price, self.stockQuantity, self.productId))
            connection.commit()
            print("Product updated successfully.")
        except Error as e:
            print(f"Error: {e}")
    
    def delete_product(self, connection):
        try:
            cursor = connection.cursor()
            query = "DELETE FROM products WHERE productId = %s"
            cursor.execute(query, (self.productId,))
            connection.commit()
            print("Product deleted successfully.")
        except Error as e:
            print(f"Error: {e}")

    @staticmethod
    def show_all_products(connection):
        try:

            cursor = connection.cursor()
            cursor.execute("SELECT * FROM products")
            products = cursor.fetchall()
            if products:
                print("\nAll Products:")
                print("{:<10} {:<20} {:<50} {:<10} {:<15}".format("Product ID", "Name", "Description", "Price", "Stock Quantity"))
                print("="*100)
                for product in products:
                    print("{:<10} {:<20} {:<50} {:<10} {:<15}".format(product[0], product[1], product[2], product[3], product[4]))
                print("="*100)
            else:
                print("No products found.")
        except Error as e:
            print(f"Error: {e}")