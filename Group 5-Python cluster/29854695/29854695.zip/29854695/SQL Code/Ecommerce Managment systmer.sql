Create database ecommerce;
show databases;
use ecommerce;

CREATE TABLE products (
    productId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stockQuantity INT NOT NULL
);
Create Table Customers (
	customerId INT AUTO_INCREMENT PRIMARY KEY,
    name varchar(255) NOT NULL,
    email varchar(255) NOT NULL,
    address varchar(255) NOT NULL);

CREATE TABLE orders (
    orderId INT AUTO_INCREMENT PRIMARY KEY,
    customerId INT,
    productId INT,
    orderDate DATE,
    quantity INT,
    FOREIGN KEY (customerId) REFERENCES customers(customerId),
    FOREIGN KEY (productId) REFERENCES products(productId)
);

-- ADD Data in Tables;

INSERT INTO products (name, description, price, stockQuantity) VALUES
('Laptop', 'A high-end laptop with 16GB RAM and 512GB SSD', 1200.00, 50),
('Smartphone', 'A latest model smartphone with 5G support', 800.00, 100),
('Headphones', 'Noise-cancelling over-ear headphones', 150.00, 200),
('Smartwatch', 'A smartwatch with various health tracking features', 200.00, 75),
('Tablet', 'A 10-inch tablet with 4GB RAM and 64GB storage', 300.00, 80);

Select * From products;

INSERT INTO customers (name, email, address) VALUES
('John Doe', 'john.doe@example.com', '123 Elm Street, Springfield, IL'),
('Jane Smith', 'jane.smith@example.com', '456 Oak Avenue, Metropolis, NY'),
('Alice Johnson', 'alice.johnson@example.com', '789 Maple Road, Gotham, NJ'),
('Bob Brown', 'bob.brown@example.com', '101 Pine Lane, Star City, CA'),
('Carol White', 'carol.white@example.com', '202 Birch Boulevard, Central City, TX');

Select * from customers;

INSERT INTO orders (customerId, productId, orderDate, quantity) VALUES
(1, 1, '2024-07-01', 2),
(2, 3, '2024-07-02', 1),
(3, 5, '2024-07-03', 3),
(4, 2, '2024-07-04', 1),
(5, 4, '2024-07-05', 2),
(1, 2, '2024-07-06', 1),
(2, 4, '2024-07-07', 1),
(3, 1, '2024-07-08', 2),
(4, 5, '2024-07-09', 3),
(5, 3, '2024-07-10', 2);

Select * from orders;

-- Queries for Problem statements

-- Write a query to find the total sales revenue generated in a specific month.
SELECT SUM(O.quantity * P.price) AS TotalSalesRvenue
FROM orders O JOIN products P ON O.productId = P.productId
WHERE MONTH(O.orderDate) = 7 AND YEAR(O.orderDate) = 2024;

-- Write a query to find the customers who have placed more than five orders.
Select c.name,c.email,c.address  from Customers C join orders o on o.customerID = C.customerID
Group by o.customerID,c.name,c.email,c.address having count(o.orderID)>=5;

-- Write a query to find the products that need restocking (stock_quantity < 10).
Select * from Products where stockQuantity<10;

-- Write a query to find the most popular products (most ordered).
SELECT p.productId, p.name,p.description,p.price,COUNT(o.orderId) AS Ordercount
FROM products p JOIN orders o ON p.productId = o.productId
GROUP BY p.productId, p.name ORDER BY Ordercount DESC LIMIT 1;

--  Write a query to find the details of orders placed by a specific customer.
Select * from Orders where customerID=2;


