import datetime

# Class to represent a Vehicle
class Vehicle:
    def __init__(self, vehicle_id, make, model, year, rental_price_per_day, available=True):
        self.vehicle_id = vehicle_id
        self.make = make
        self.model = model
        self.year = year
        self.rental_price_per_day = rental_price_per_day
        self.available = available

    def __str__(self):
        return f"Vehicle ID: {self.vehicle_id}, {self.year} {self.make} {self.model}, Price per day: ₹{self.rental_price_per_day}, {'Available' if self.available else 'Vehicle Rented'}"

# Class to represent a Customer
class Customer:
    def __init__(self, customer_id, name, contact_number, email):
        self.customer_id = customer_id
        self.name = name
        self.contact_number = contact_number
        self.email = email

    def __str__(self):
        return f"Customer ID: {self.customer_id}, Name: {self.name}, Contact Number: {self.contact_number}, Email: {self.email}"

# Class to represent a Rental Transaction
class RentalTransaction:
    def __init__(self, transaction_id, customer_id, vehicle_id, rental_date, return_date=None):
        self.transaction_id = transaction_id
        self.customer_id = customer_id
        self.vehicle_id = vehicle_id
        self.rental_date = rental_date
        self.return_date = return_date

    def __str__(self):
        return (f"Transaction ID: {self.transaction_id}, Customer ID: {self.customer_id}, Vehicle ID: {self.vehicle_id}, "
                f"Rental Date: {self.rental_date}, Return Date: {self.return_date if self.return_date else 'Vehicle Not Returned'}")

# Class to manage vehicle-related operations
class VehicleManagement:
    def __init__(self):
        self.vehicles = {}

    def add_vehicle(self, vehicle_id, make, model, year, rental_price_per_day, available=True):
        if vehicle_id in self.vehicles:
            print(f"Vehicle with ID {vehicle_id} already exists.")
        else:
            new_vehicle = Vehicle(vehicle_id, make, model, year, rental_price_per_day, available)
            self.vehicles[vehicle_id] = new_vehicle
            print(f"Added vehicle: {new_vehicle}")

    def update_vehicle(self, vehicle_id, make=None, model=None, year=None, rental_price_per_day=None, available=None):
        if vehicle_id in self.vehicles:
            vehicle = self.vehicles[vehicle_id]
            if make is not None:
                vehicle.make = make
            if model is not None:
                vehicle.model = model
            if year is not None:
                vehicle.year = year
            if rental_price_per_day is not None:
                vehicle.rental_price_per_day = rental_price_per_day
            if available is not None:
                vehicle.available = available
            print(f"Updated vehicle: {vehicle}")
        else:
            print(f"Vehicle with ID {vehicle_id} not found.")

    def delete_vehicle(self, vehicle_id):
        if vehicle_id in self.vehicles:
            deleted_vehicle = self.vehicles.pop(vehicle_id)
            print(f"Deleted vehicle: {deleted_vehicle}")
        else:
            print(f"Vehicle with ID {vehicle_id} not found.")

    def display_vehicles(self):
        if not self.vehicles:
            print("No vehicles available.")
        else:
            for vehicle in self.vehicles.values():
                print(vehicle)

    def generate_rented_vehicles_report(self):
        rented_vehicles = [vehicle for vehicle in self.vehicles.values() if not vehicle.available]
        if not rented_vehicles:
            print("No vehicles are currently rented out.")
        else:
            print("Vehicles currently rented out:")
            for vehicle in rented_vehicles:
                print(vehicle)

# Class to manage customer-related operations
class CustomerManagement:
    def __init__(self):
        self.customers = {}

    def add_customer(self, customer_id, name, contact_number, email):
        if customer_id in self.customers:
            print(f"Customer with ID {customer_id} already exists.")
        else:
            new_customer = Customer(customer_id, name, contact_number, email)
            self.customers[customer_id] = new_customer
            print(f"Added customer: {new_customer}")

    def update_customer(self, customer_id, name=None, contact_number=None, email=None):
        if customer_id in self.customers:
            customer = self.customers[customer_id]
            if name is not None:
                customer.name = name
            if contact_number is not None:
                customer.contact_number = contact_number
            if email is not None:
                customer.email = email
            print(f"Updated customer: {customer}")
        else:
            print(f"Customer with ID {customer_id} not found.")

    def delete_customer(self, customer_id):
        if customer_id in self.customers:
            deleted_customer = self.customers.pop(customer_id)
            print(f"Deleted customer: {deleted_customer}")
        else:
            print(f"Customer with ID {customer_id} not found.")

    def display_customers(self):
        if not self.customers:
            print("No customers available.")
        else:
            for customer in self.customers.values():
                print(customer)

# Class to manage rental-related operations
class RentalManagement:
    def __init__(self):
        self.rentals = {}

    def add_rental(self, transaction_id, customer_id, vehicle_id, rental_date, return_date=None):
        if transaction_id in self.rentals:
            print(f"Transaction with ID {transaction_id} already exists.")
        else:
            new_rental = RentalTransaction(transaction_id, customer_id, vehicle_id, rental_date, return_date)
            self.rentals[transaction_id] = new_rental
            print(f"Added rental: {new_rental}")

    def update_rental(self, transaction_id, customer_id=None, vehicle_id=None, rental_date=None, return_date=None):
        if transaction_id in self.rentals:
            rental = self.rentals[transaction_id]
            if customer_id is not None:
                rental.customer_id = customer_id
            if vehicle_id is not None:
                rental.vehicle_id = vehicle_id
            if rental_date is not None:
                rental.rental_date = rental_date
            if return_date is not None:
                rental.return_date = return_date
            print(f"Updated rental: {rental}")
        else:
            print(f"Transaction with ID {transaction_id} not found.")

    def return_rental(self, transaction_id, return_date):
        if transaction_id in self.rentals:
            rental = self.rentals[transaction_id]
            rental.return_date = return_date
            print(f"Rental returned: {rental}")
        else:
            print(f"Transaction with ID {transaction_id} not found.")

    def display_rentals(self):
        if not self.rentals:
            print("No rentals available.")
        else:
            for rental in self.rentals.values():
                print(rental)

# Main class to manage the entire Vehicle Rental Management System
class VehicleRentalManagementSystem:
    def __init__(self):
        self.vehicle_management = VehicleManagement()
        self.customer_management = CustomerManagement()
        self.rental_management = RentalManagement()

    def Main(self):
        while True:
            print("\n------------- Vehicle Rental Management System ---------------")
            print("1. Manage Vehicles")
            print("2. Manage Customers")
            print("3. Manage Rentals")
            print("4. Generate Rented Vehicles Report")
            print("5. Exit")
            choice = input("Enter your choice: ")

            match(choice):
                case '1':
                    self.manage_vehicles()
                case '2':
                    self.manage_customers()
                case '3':
                    self.manage_rentals()
                case '4':
                    self.vehicle_management.generate_rented_vehicles_report()
                case '5':
                    print("Exiting Vehicle Rental Management System.")
                    break
                case _:
                    print("Invalid choice. Please try again.")

    def manage_vehicles(self):
        while True:
            print("\n--- Manage Vehicles ---")
            print("1. Add Vehicle")
            print("2. Update Vehicle")
            print("3. Delete Vehicle")
            print("4. Display Vehicles")
            print("5. Back")
            choice = input("Enter your choice: ")
            match(choice):
                case '1':
                    try:
                        vehicle_id = int(input("Enter vehicle ID: "))
                        make = input("Enter vehicle make: ")
                        model = input("Enter vehicle model: ")
                        year = int(input("Enter vehicle year: "))
                        rental_price_per_day = float(input("Enter rental price per day: "))
                        available = input("Is the vehicle available? (yes/no): ").lower() == 'yes'
                        self.vehicle_management.add_vehicle(vehicle_id, make, model, year, rental_price_per_day, available)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '2':
                    try:
                        vehicle_id = int(input("Enter vehicle ID: "))
                        make = input("Enter new make (Press Enter to Skip): ")
                        model = input("Enter new model (Press Enter to Skip): ")
                        year = input("Enter new year (Press Enter to Skip): ")
                        rental_price_per_day = input("Enter new rental price per day (Press Enter to Skip): ")
                        available = input("Is the vehicle available? (yes/no, Press Enter to Skip): ").lower()
                        self.vehicle_management.update_vehicle(
                            vehicle_id, 
                            make if make else None, 
                            model if model else None, 
                            int(year) if year else None, 
                            float(rental_price_per_day) if rental_price_per_day else None, 
                            available == 'yes' if available else None
                        )
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '3':
                    try:
                        vehicle_id = int(input("Enter vehicle ID to delete: "))
                        self.vehicle_management.delete_vehicle(vehicle_id)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter a valid vehicle ID.")
                case '4':
                    self.vehicle_management.display_vehicles()
                case '5':
                    break
                case _:
                    print("Invalid choice. Please try again.")

    def manage_customers(self):
        while True:
            print("\n--- Manage Customers ---")
            print("1. Add Customer")
            print("2. Update Customer")
            print("3. Delete Customer")
            print("4. Display Customers")
            print("5. Back")
            choice = input("Enter your choice: ")
            match(choice):
                case '1':
                    try:
                        customer_id = int(input("Enter customer ID: "))
                        name = input("Enter customer name: ")
                        contact_number = input("Enter contact number: ")
                        email = input("Enter email: ")
                        self.customer_management.add_customer(customer_id, name, contact_number, email)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '2':
                    try:
                        customer_id = int(input("Enter customer ID: "))
                        name = input("Enter new name (Press Enter to Skip): ")
                        contact_number = input("Enter new contact number (Press Enter to Skip): ")
                        email = input("Enter new email (Press Enter to Skip): ")
                        self.customer_management.update_customer(
                            customer_id, 
                            name if name else None, 
                            contact_number if contact_number else None, 
                            email if email else None
                        )
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '3':
                    try:
                        customer_id = int(input("Enter customer ID to delete: "))
                        self.customer_management.delete_customer(customer_id)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter a valid customer ID.")
                case '4':
                    self.customer_management.display_customers()
                case '5':
                    break
                case _:
                    print("Invalid choice. Please try again.")

    def manage_rentals(self):
        while True:
            print("\n--- Manage Rentals ---")
            print("1. Add Rental")
            print("2. Update Rental")
            print("3. Return Rental")
            print("4. Display Rentals")
            print("5. Back")
            choice = input("Enter your choice: ")
            match(choice):
                case '1':
                    try:
                        transaction_id = int(input("Enter transaction ID: "))
                        customer_id = int(input("Enter customer ID: "))
                        vehicle_id = int(input("Enter vehicle ID: "))
                        rental_date = input("Enter rental date (YYYY-MM-DD): ")
                        self.rental_management.add_rental(transaction_id, customer_id, vehicle_id, datetime.date.fromisoformat(rental_date))
                        self.vehicle_management.update_vehicle(vehicle_id, available=False)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '2':
                    try:
                        transaction_id = int(input("Enter transaction ID: "))
                        customer_id = input("Enter new customer ID (Press Enter to Skip): ")
                        vehicle_id = input("Enter new vehicle ID (Press Enter to Skip): ")
                        rental_date = input("Enter new rental date (YYYY-MM-DD, Press Enter to Skip): ")
                        return_date = input("Enter new return date (YYYY-MM-DD, Press Enter to Skip): ")
                        self.rental_management.update_rental(
                            transaction_id, 
                            int(customer_id) if customer_id else None, 
                            int(vehicle_id) if vehicle_id else None, 
                            datetime.date.fromisoformat(rental_date) if rental_date else None, 
                            datetime.date.fromisoformat(return_date) if return_date else None
                        )
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '3':
                    try:
                        transaction_id = int(input("Enter transaction ID: "))
                        return_date = input("Enter return date (YYYY-MM-DD): ")
                        self.rental_management.return_rental(transaction_id, datetime.date.fromisoformat(return_date))
                        rental = self.rental_management.rentals[transaction_id]
                        self.vehicle_management.update_vehicle(rental.vehicle_id, available=True)
                    except ValueError as e:
                        print(f"Error: {e}. Please enter valid data.")
                case '4':
                    self.rental_management.display_rentals()
                case '5':
                    break
                case _:
                    print("Invalid choice. Please try again.")


# Initialize the Vehicle Rental Management System
vehicle_rental_management_system = VehicleRentalManagementSystem()
# Start the main menu loop
vehicle_rental_management_system.Main()
