CREATE DATABASE Vehicle_Rental_Management_System; -- Database Creation

USE Vehicle_Rental_Management_System; -- Database Usage

SHOW DATABASES; -- Display Databases

-- Create Vehicles table.
CREATE TABLE Vehicles (
    vehicle_id INT PRIMARY KEY,
    make VARCHAR(50),
    model VARCHAR(50),
    year INT,
    rental_rate DECIMAL(10, 2),
    available BOOLEAN
);

-- Create Customer Table.
CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_info VARCHAR(100)
);

-- Create Rentals Table.
CREATE TABLE Rentals (
    rental_id INT PRIMARY KEY,
    customer_id INT,
    vehicle_id INT,
    rental_start_date DATE,
    rental_end_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (vehicle_id) REFERENCES Vehicles(vehicle_id)
);

SHOW TABLES; -- Show Tables.

-- Write a query to find the total rental income for each vehicle

SELECT V.vehicle_id, V.make, V.model, SUM(R.rental_end_date - R.rental_start_date + 1) * V.rental_rate AS total_rental_income
FROM Vehicles V
JOIN Rentals R ON V.vehicle_id = R.vehicle_id
GROUP BY V.vehicle_id, V.make, V.model;

-- Write a query to find the names of customers and the vehicles they have rented.

SELECT C.name AS customer_name, V.make AS vehicle_make, V.model AS vehicle_model, R.rental_start_date, R.rental_end_date
FROM Customers C
JOIN Rentals R ON C.customer_id = R.customer_id
JOIN Vehicles V ON R.vehicle_id = V.vehicle_id;

-- Write a query to find the vehicles that have never been rented.

SELECT V.vehicle_id, V.make, V.model
FROM Vehicles V
LEFT JOIN Rentals R ON V.vehicle_id = R.vehicle_id
WHERE R.vehicle_id IS NULL;

-- Write a query to find the customers who have rented more than 3 different vehicles.

SELECT C.customer_id, C.name, COUNT(DISTINCT R.vehicle_id) AS vehicle_count
FROM Customers C
JOIN Rentals R ON C.customer_id = R.customer_id
GROUP BY C.customer_id, C.name
HAVING vehicle_count > 3;

-- Write a query to find the vehicle makes and models with less than 5 available units for rent.

SELECT V.make, V.model, COUNT(V.vehicle_id) AS available_units
FROM Vehicles V
WHERE V.available = TRUE
GROUP BY V.make, V.model
HAVING available_units < 5;





