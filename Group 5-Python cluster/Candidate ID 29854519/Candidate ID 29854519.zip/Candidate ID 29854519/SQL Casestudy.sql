-- Database created --
create database UniversityManagementSystem;
drop database universitymanagementsystem; 

-- Accessing it --
use UniversityManagementSystem;

-- 1. Student Table --
create table Students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    email VARCHAR(100) NOT NULL,
    major VARCHAR(50) NOT NULL);

-- 2. Courses Offered Table --
create table Courses(
    course_id INT PRIMARY KEY,
	course_name VARCHAR(100) NOT NULL,
    instructor VARCHAR(100) NOT NULL, 
    credits INT NOT NULL,
    max_students INT NOT NULL);

-- 3. Enrollment Table --
 create table Enrollments(
  enrollment_id INT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL ,
  enrollment_date DATE NOT NULL,
  FOREIGN KEY (student_id) REFERENCES Students(student_id),
  FOREIGN KEY (course_id) REFERENCES Courses(course_id));
  
-- 4. Inserting data into students table --
   insert into Students (name, age, email, major)
   values('Yash Desale', 20, 'yash14@gmail.com', 'Engineering'),
		 ('Rahul Wagh', 21, 'rahul07@gmail.com', 'Engineering'),
		 ('Raj Patil', 20, 'raj004@gmail.com', 'Engineering'),
		 ('Vikesh Dhawan', 21, 'vikesh@gmail.com', 'Engineering'),
		 ('Sarvesh Patil', 22, 'sarvesh@gmail.com', 'MBA'),
         ('Siddhesh Patil', 21, 'sid@gmail.com', 'Engineering'),
		 ('Nikita Sharma', 22, 'nikita@gmail.com', 'Engineering'),
		 ('Anya Kapoor', 19, 'anya@gmail.com', 'Engineering'),
		 ('Ishaan Singh', 23, 'ishaan@gmail.com', 'MBA'),
		 ('Priya Joshi', 20, 'priya@gmail.com', 'Engineering'),
		 ('Mihir Desai', 21, 'mihir@gmail.com', 'Engineering'),
		 ('Riya Mehta', 19, 'riya@gmail.com', 'Engineering'),
		 ('Rohan Patel', 22, 'rohan@gmail.com', 'Engineering'),
		 ('Aisha Khan', 20, 'aisha@gmail.com', 'Engineering'),
		 ('Vedant Kumar', 23, 'vedant@gmail.com', 'Engineering'),
	 	 ('Aditi Gupta', 19, 'aditi@gmail.com', 'Engineering'),
		 ('Karan Sharma', 22, 'karan@gmail.com', 'Engineering'),
		 ('Neha Verma', 20, 'neha@gmail.com', 'Engineering'),
		 ('Arjun Malhotra', 21, 'arjun@gmail.com', 'Engineering'),
		 ('Shreya Rao', 19, 'shreya@gmail.com', 'Engineering'),
         ('Vivaan Joshi', 23, 'vivaan@gmail.com', 'Engineering'),
		 ('Diya Shah', 20, 'diya@gmail.com', 'Engineering'),
         ('Yash Mehta', 21, 'yash@gmail.ccom', 'Engineering'),
         ('Kavya Patel', 19, 'kavya@gmail.com', 'Engineering'),
         ('Neil Kapoor', 22, 'neil.@gmail.com', 'MBA'),
         ('Vardhan Kumar',21,'vardhan@gmail.com','Engineering'), 
         ('Riya Desai', 20, 'riya@gmail.com', 'MBA');

         
 -- 5. Insert data into courses offered table -- 
   insert into Courses (course_name, course_id, instructor, credits, max_students)
   values('Computer Science',100, 'Dr.Patel', 8, 12),
          ('Basic Electronics',101, 'Prof.Hari', 6, 10),
          ('Data Science',102, 'Dr.Singh', 5, 10),
          ('Finance',103, 'Prof.Kulkarni', 4, 8),
          ('Cloud Computing',104, 'Dr.Patil', 5, 12),
          ('Machine Learning',105, 'Dr.Shah', 8, 11);
	
          
  -- 6. Insert data into enrollments table --
      insert into Enrollments(enrollment_id, student_id, course_id, enrollment_date)
      values( 1, 1, 100,'2024-03-10'),
			 ( 2, 3, 102,'2024-02-04'),
             ( 3, 2, 101,'2024-07-12'),
             ( 4, 4, 105,'2024-10-20'),
             ( 5, 6, 104,'2024-08-13'),
             ( 6, 9, 103,'2024-02-21'),
             ( 7, 12, 102,'2024-09-19'),
             ( 8, 5, 103,'2024-11-12'),
             ( 9, 14, 103,'2024-04-05'),
             ( 10, 21, 104,'2024-03-11'),
             ( 11, 15, 101,'2024-05-23'),
             ( 12, 13, 102,'2024-08-05'),
             ( 13, 10, 105,'2024-08-25'),
             ( 14, 19, 102,'2024-11-15'),
             ( 15, 16, 104,'2024-10-05'),
             ( 16, 23, 104,'2024-02-12'),
             ( 17, 27, 103,'2024-10-05'),
             ( 18, 8, 105,'2024-03-15'),
             ( 19, 20, 100,'2024-08-17'),
             ( 20, 7, 102,'2024-07-13'),       
             ( 21, 20, 100,'2024-08-22'),
             ( 22, 18, 100,'2024-02-15'),
             ( 23, 26, 105,'2024-09-21'),
             ( 24, 25, 103,'2024-09-25'),
             ( 25, 24, 101,'2024-11-22'),
             ( 26, 11, 103,'2024-01-23'),
             ( 27, 17, 103,'2024-08-19'),
             ( 28, 4, 101,'2024-10-20'),
             ( 29, 12, 104,'2024-09-20'),
             ( 30, 12, 101,'2024-08-22'),
             ( 31, 4, 103,'2024-10-16'),
             ( 32, 5, 105,'2024-11-05'),
             ( 33, 5, 100,'2024-11-01'),
             ( 34, 19, 104,'2024-10-11'),
             ( 35, 19, 105,'2024-11-05'),
             ( 36, 12, 101,'2024-07-04'),
             ( 37,  5, 102,'2024-10-22'),
             ( 38, 19, 100,'2024-10-17'),
             ( 39, 4, 101,'2024-05-18');
             
         
   -- Problem Statement and their Solutions --    
   -- Q1.Write a query to find the total number of students enrolled in each course.-- 
	  select Courses.course_name,count(*) As total_students
      from Enrollments, Courses
      where Enrollments.course_id = Courses.course_id
      group by courses.course_name;
      
   -- Q2.Write a query to find the names and emails of students who are enrolled in more than three courses.--
	  select s.name, s.email
	  from Students s
	  where s.student_id in (
	  select e.student_id
      from Enrollments e
      group by e.student_id
	  having count(e.course_id) > 3 );

   -- Q3.Write a query to find the courses that have not reached their maximum student capacity.--
      select course_id, course_name, max_students
      from Courses
      where course_id not in (
      select course_id
      from Enrollments
      group by course_id
      having count(student_id) >= max_students );

   -- Q4.Write a query to find the students who are enrolled in courses taught by a specific instructor.--
	    select s.student_id, s.name, s.email, s.major
        from Students s
        where s.student_id in( 
        select e.student_id
		from Enrollments e
        where e.course_id in(
        select c.course_id
        from Courses c
        where c.instructor = 'specified_instructor_name'));
	-- here the user can enter any instructor name which is present in the Courses table.-- 
   
   -- Q5.Write a query to find the details of enrollments made in the last semester.--
	   select enrollment_id, E.student_id as student_id , name as student_name, course_name, E.course_id, enrollment_date
       from Enrollments E, Students S, Courses C 
       where E.student_id = S.student_id
       and E.course_id = C.course_id
       and enrollment_date between '2024-01-01' and '2024-06-30';
	-- For the above query I have considered the semester duration from 2024-01-01 to 2024-06-30---