import datetime

# Exception Classes
class StudentNotFoundException(Exception):
    pass

class CourseNotFoundException(Exception):
    pass

class EnrollmentNotFoundException(Exception):
    pass

# Student Class
class Student:
    def __init__(self, student_id, name, age, email, major):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.email = email
        self.major = major

# Course Class
class Course:
    def __init__(self, course_id, course_name, instructor, credits, max_students):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.credits = credits
        self.max_students = max_students

# Enrollment Class
class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = datetime.datetime.now()

# University Management System
class UniversityManagementSystem:
    def __init__(self):
        self.students = {}
        self.courses = {}
        self.enrollments = {}
        self.enrollment_counter = 1

    # Student Management
    def add_student(self, student_id, name, age, email, major):
        self.students[student_id] = Student(student_id, name, age, email, major)

    def update_student(self, student_id, name=None, age=None, email=None, major=None):
        if student_id not in self.students:
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")
        student = self.students[student_id]
        if name:
            student.name = name
        if age:
            student.age = age
        if email:
            student.email = email
        if major:
            student.major = major

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")
        del self.students[student_id]

    # Course Management
    def add_course(self, course_id, course_name, instructor, credits, max_students):
        self.courses[course_id] = Course(course_id, course_name, instructor, credits, max_students)

    def update_course(self, course_id, course_name=None, instructor=None, credits=None, max_students=None):
        if course_id not in self.courses:
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")
        course = self.courses[course_id]
        if course_name:
            course.course_name = course_name
        if instructor:
            course.instructor = instructor
        if credits:
            course.credits = credits
        if max_students:
            course.max_students = max_students

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")
        del self.courses[course_id]

    # Enrollment Management
    def add_enrollment(self, student_id, course_id):
        if student_id not in self.students:
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")
        if course_id not in self.courses:
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")
        enrollment_id = self.enrollment_counter
        self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id)
        self.enrollment_counter += 1

    def update_enrollment(self, enrollment_id, student_id=None, course_id=None):
        if enrollment_id not in self.enrollments:
            raise EnrollmentNotFoundException(f"Enrollment with ID {enrollment_id} not found.")
        enrollment = self.enrollments[enrollment_id]
        if student_id:
            if student_id not in self.students:
                raise StudentNotFoundException(f"Student with ID {student_id} not found.")
            enrollment.student_id = student_id
        if course_id:
            if course_id not in self.courses:
                raise CourseNotFoundException(f"Course with ID {course_id} not found.")
            enrollment.course_id = course_id

    def delete_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise EnrollmentNotFoundException(f"Enrollment with ID {enrollment_id} not found.")
        del self.enrollments[enrollment_id]

# Main Console Application
def main():
    ums = UniversityManagementSystem()
    while True:
        print("\nUniversity Management System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Add Course")
        print("5. Update Course")
        print("6. Delete Course")
        print("7. Add Enrollment")
        print("8. Update Enrollment")
        print("9. Delete Enrollment")
        print("10. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                student_id = input("Enter student ID: ")
                name = input("Enter student name: ")
                age = int(input("Enter student age: "))
                email = input("Enter student email: ")
                major = input("Enter student major: ")
                ums.add_student(student_id, name, age, email, major)
                print("Student added successfully.")
            elif choice == '2':
                student_id = input("Enter student ID: ")
                name = input("Enter new name (or leave blank): ")
                age = input("Enter new age (or leave blank): ")
                email = input("Enter new email (or leave blank): ")
                major = input("Enter new major (or leave blank): ")
                ums.update_student(student_id, name=name or None, age=int(age) if age else None, email=email or None, major=major or None)
                print("Student updated successfully.")
            elif choice == '3':
                student_id = input("Enter student ID: ")
                ums.delete_student(student_id)
                print("Student deleted successfully.")
            elif choice == '4':
                course_id = input("Enter course ID: ")
                course_name = input("Enter course name: ")
                instructor = input("Enter course instructor: ")
                credits = int(input("Enter course credits: "))
                max_students = int(input("Enter maximum students: "))
                ums.add_course(course_id, course_name, instructor, credits, max_students)
                print("Course added successfully.")
            elif choice == '5':
                course_id = input("Enter course ID: ")
                course_name = input("Enter new course name (or leave blank): ")
                instructor = input("Enter new instructor (or leave blank): ")
                credits = input("Enter new credits (or leave blank): ")
                max_students = input("Enter new maximum students (or leave blank): ")
                ums.update_course(course_id, course_name=course_name or None, instructor=instructor or None, credits=int(credits) if credits else None, max_students=int(max_students) if max_students else None)
                print("Course updated successfully.")
            elif choice == '6':
                course_id = input("Enter course ID: ")
                ums.delete_course(course_id)
                print("Course deleted successfully.")
            elif choice == '7':
                student_id = input("Enter student ID: ")
                course_id = input("Enter course ID: ")
                ums.add_enrollment(student_id, course_id)
                print("Enrollment added successfully.")
            elif choice == '8':
                enrollment_id = int(input("Enter enrollment ID: "))
                student_id = input("Enter new student ID (or leave blank): ")
                course_id = input("Enter new course ID (or leave blank): ")
                ums.update_enrollment(enrollment_id, student_id=student_id or None, course_id=course_id or None)
                print("Enrollment updated successfully.")
            elif choice == '9':
                enrollment_id = int(input("Enter enrollment ID: "))
                ums.delete_enrollment(enrollment_id)
                print("Enrollment deleted successfully.")
            elif choice == '10':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
