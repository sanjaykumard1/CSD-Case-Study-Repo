import mysql.connector
import datetime

# Exception Classes
class StudentNotFoundException(Exception):
    pass

class CourseNotFoundException(Exception):
    pass

class EnrollmentNotFoundException(Exception):
    pass

# Database setup
def create_connection():
    conn = mysql.connector.connect(
        host='localhost',  # replace with your host
        user='root',  # replace with your MySQL username
        password='root',  # replace with your MySQL password
        database='UniversityManagementSystem'  # replace with your database name
    )
    return conn

def create_tables(conn):
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS students (
                        student_id VARCHAR(255) PRIMARY KEY,
                        name VARCHAR(255),
                        age INT,
                        email VARCHAR(255),
                        major VARCHAR(255)
                    )''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS courses (
                        course_id VARCHAR(255) PRIMARY KEY,
                        course_name VARCHAR(255),
                        instructor VARCHAR(255),
                        credits INT,
                        max_students INT
                    )''')
    cursor.execute('''CREATE TABLE IF NOT EXISTS enrollments (
                        enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
                        student_id VARCHAR(255),
                        course_id VARCHAR(255),
                        enrollment_date DATETIME,
                        FOREIGN KEY (student_id) REFERENCES students(student_id),
                        FOREIGN KEY (course_id) REFERENCES courses(course_id)
                    )''')
    conn.commit()

# University Management System
class UniversityManagementSystem:
    def __init__(self, conn):
        self.conn = conn

    # Student Management
    def add_student(self, student_id, name, age, email, major):
        cursor = self.conn.cursor()
        cursor.execute('INSERT INTO students (student_id, name, age, email, major) VALUES (%s, %s, %s, %s, %s)',
                       (student_id, name, age, email, major))
        self.conn.commit()

    def update_student(self, student_id, name=None, age=None, email=None, major=None):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM students WHERE student_id = %s', (student_id,))
        if not cursor.fetchone():
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")

        if name:
            cursor.execute('UPDATE students SET name = %s WHERE student_id = %s', (name, student_id))
        if age:
            cursor.execute('UPDATE students SET age = %s WHERE student_id = %s', (age, student_id))
        if email:
            cursor.execute('UPDATE students SET email = %s WHERE student_id = %s', (email, student_id))
        if major:
            cursor.execute('UPDATE students SET major = %s WHERE student_id = %s', (major, student_id))
        self.conn.commit()

    def delete_student(self, student_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM students WHERE student_id = %s', (student_id,))
        if not cursor.fetchone():
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")
        cursor.execute('DELETE FROM students WHERE student_id = %s', (student_id,))
        self.conn.commit()

    # Course Management
    def add_course(self, course_id, course_name, instructor, credits, max_students):
        cursor = self.conn.cursor()
        cursor.execute('INSERT INTO courses (course_id, course_name, instructor, credits, max_students) VALUES (%s, %s, %s, %s, %s)',
                       (course_id, course_name, instructor, credits, max_students))
        self.conn.commit()

    def update_course(self, course_id, course_name=None, instructor=None, credits=None, max_students=None):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM courses WHERE course_id = %s', (course_id,))
        if not cursor.fetchone():
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")

        if course_name:
            cursor.execute('UPDATE courses SET course_name = %s WHERE course_id = %s', (course_name, course_id))
        if instructor:
            cursor.execute('UPDATE courses SET instructor = %s WHERE course_id = %s', (instructor, course_id))
        if credits:
            cursor.execute('UPDATE courses SET credits = %s WHERE course_id = %s', (credits, course_id))
        if max_students:
            cursor.execute('UPDATE courses SET max_students = %s WHERE course_id = %s', (max_students, course_id))
        self.conn.commit()

    def delete_course(self, course_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM courses WHERE course_id = %s', (course_id,))
        if not cursor.fetchone():
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")
        cursor.execute('DELETE FROM courses WHERE course_id = %s', (course_id,))
        self.conn.commit()

    # Enrollment Management
    def add_enrollment(self, student_id, course_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM students WHERE student_id = %s', (student_id,))
        if not cursor.fetchone():
            raise StudentNotFoundException(f"Student with ID {student_id} not found.")
        cursor.execute('SELECT * FROM courses WHERE course_id = %s', (course_id,))
        if not cursor.fetchone():
            raise CourseNotFoundException(f"Course with ID {course_id} not found.")

        cursor.execute('INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (%s, %s, %s)',
                       (student_id, course_id, datetime.datetime.now()))
        self.conn.commit()

    def update_enrollment(self, enrollment_id, student_id=None, course_id=None):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM enrollments WHERE enrollment_id = %s', (enrollment_id,))
        if not cursor.fetchone():
            raise EnrollmentNotFoundException(f"Enrollment with ID {enrollment_id} not found.")

        if student_id:
            cursor.execute('SELECT * FROM students WHERE student_id = %s', (student_id,))
            if not cursor.fetchone():
                raise StudentNotFoundException(f"Student with ID {student_id} not found.")
            cursor.execute('UPDATE enrollments SET student_id = %s WHERE enrollment_id = %s', (student_id, enrollment_id))
        if course_id:
            cursor.execute('SELECT * FROM courses WHERE course_id = %s', (course_id,))
            if not cursor.fetchone():
                raise CourseNotFoundException(f"Course with ID {course_id} not found.")
            cursor.execute('UPDATE enrollments SET course_id = %s WHERE enrollment_id = %s', (course_id, enrollment_id))
        self.conn.commit()

    def delete_enrollment(self, enrollment_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM enrollments WHERE enrollment_id = %s', (enrollment_id,))
        if not cursor.fetchone():
            raise EnrollmentNotFoundException(f"Enrollment with ID {enrollment_id} not found.")
        cursor.execute('DELETE FROM enrollments WHERE enrollment_id = %s', (enrollment_id,))
        self.conn.commit()

# Main Console Application
def main():
    conn = create_connection()
    create_tables(conn)
    ums = UniversityManagementSystem(conn)
    while True:
        print("\nUniversity Management System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Add Course")
        print("5. Update Course")
        print("6. Delete Course")
        print("7. Add Enrollment")
        print("8. Update Enrollment")
        print("9. Delete Enrollment")
        print("0. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                student_id = input("Enter student ID: ")
                name = input("Enter student name: ")
                age = int(input("Enter student age: "))
                email = input("Enter student email: ")
                major = input("Enter student major: ")
                ums.add_student(student_id, name, age, email, major)
                print("Student added successfully.")
            elif choice == '2':
                student_id = input("Enter student ID: ")
                name = input("Enter new name (or leave blank): ")
                age = input("Enter new age (or leave blank): ")
                email = input("Enter new email (or leave blank): ")
                major = input("Enter new major (or leave blank): ")
                ums.update_student(student_id, name=name or None, age=int(age) if age else None, email=email or None, major=major or None)
                print("Student updated successfully.")
            elif choice == '3':
                student_id = input("Enter student ID: ")
                ums.delete_student(student_id)
                print("Student deleted successfully.")
            elif choice == '4':
                course_id = input("Enter course ID: ")
                course_name = input("Enter course name: ")
                instructor = input("Enter course instructor: ")
                credits = int(input("Enter course credits: "))
                max_students = int(input("Enter maximum students: "))
                ums.add_course(course_id, course_name, instructor, credits, max_students)
                print("Course added successfully.")
            elif choice == '5':
                course_id = input("Enter course ID: ")
                course_name = input("Enter new course name (or leave blank): ")
                instructor = input("Enter new instructor (or leave blank): ")
                credits = input("Enter new credits (or leave blank): ")
                max_students = input("Enter new maximum students (or leave blank): ")
                ums.update_course(course_id, course_name=course_name or None, instructor=instructor or None, credits=int(credits) if credits else None, max_students=int(max_students) if max_students else None)
                print("Course updated successfully.")
            elif choice == '6':
                course_id = input("Enter course ID: ")
                ums.delete_course(course_id)
                print("Course deleted successfully.")
            elif choice == '7':
                student_id = input("Enter student ID: ")
                course_id = input("Enter course ID: ")
                ums.add_enrollment(student_id, course_id)
                print("Enrollment added successfully.")
            elif choice == '8':
                enrollment_id = int(input("Enter enrollment ID: "))
                student_id = input("Enter new student ID (or leave blank): ")
                course_id = input("Enter new course ID (or leave blank): ")
                ums.update_enrollment(enrollment_id, student_id=student_id or None, course_id=course_id or None)
                print("Enrollment updated successfully.")
            elif choice == '9':
                enrollment_id = int(input("Enter enrollment ID: "))
                ums.delete_enrollment(enrollment_id)
                print("Enrollment deleted successfully.")
            elif choice == '0':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()