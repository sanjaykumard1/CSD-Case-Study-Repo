import datetime
from collections import defaultdict

class Flight:
    def __init__(self, flight_id, airline, destination, departure_time, available_seats):
        self.flight_id = flight_id
        self.airline = airline
        self.destination = destination
        self.departure_time = departure_time
        self.available_seats = available_seats

    def __str__(self):
        return f"Flight({self.flight_id}, {self.airline}, {self.destination}, {self.departure_time}, {self.available_seats})"

class Reservation:
    def __init__(self, reservation_id, passenger_name, flight_id, seat_number, reservation_date):
        self.reservation_id = reservation_id
        self.passenger_name = passenger_name
        self.flight_id = flight_id
        self.seat_number = seat_number
        self.reservation_date = reservation_date

    def __str__(self):
        return f"Reservation({self.reservation_id}, {self.passenger_name}, {self.flight_id}, {self.seat_number}, {self.reservation_date})"

class AirlineReservationSystem:
    def __init__(self):
        self.flights = {}
        self.reservations = defaultdict(list)

    def add_flight(self, flight):
        if flight.flight_id in self.flights:
            raise ValueError(f"Flight with id {flight.flight_id} already exists.")
        self.flights[flight.flight_id] = flight

    def update_flight(self, flight_id, **kwargs):
        if flight_id not in self.flights:
            raise ValueError(f"Flight with id {flight_id} does not exist.")
        for key, value in kwargs.items():
            setattr(self.flights[flight_id], key, value)

    def delete_flight(self, flight_id):
        if flight_id not in self.flights:
            raise ValueError(f"Flight with id {flight_id} does not exist.")
        del self.flights[flight_id]

    def add_reservation(self, reservation):
        if reservation.flight_id not in self.flights:
            raise ValueError(f"Flight with id {reservation.flight_id} does not exist.")
        if self.flights[reservation.flight_id].available_seats <= 0:
            raise ValueError(f"No available seats for flight id {reservation.flight_id}.")
        self.reservations[reservation.flight_id].append(reservation)
        self.flights[reservation.flight_id].available_seats -= 1

    def update_reservation(self, reservation_id, flight_id, **kwargs):
        for reservation in self.reservations[flight_id]:
            if reservation.reservation_id == reservation_id:
                for key, value in kwargs.items():
                    setattr(reservation, key, value)
                return
        raise ValueError(f"Reservation with id {reservation_id} does not exist for flight id {flight_id}.")

    def cancel_reservation(self, reservation_id, flight_id):
        for reservation in self.reservations[flight_id]:
            if reservation.reservation_id == reservation_id:
                self.reservations[flight_id].remove(reservation)
                self.flights[flight_id].available_seats += 1
                return
        raise ValueError(f"Reservation with id {reservation_id} does not exist for flight id {flight_id}.")

    def generate_passenger_report(self, flight_id):
        if flight_id not in self.reservations:
            raise ValueError(f"No reservations found for flight id {flight_id}.")
        return [str(reservation) for reservation in self.reservations[flight_id]]

# Example Usage
if __name__ == "__main__":
    system = AirlineReservationSystem()

    flight1 = Flight(1, "Airline A", "Destination A", datetime.datetime(2024, 7, 14, 15, 0), 10)
    system.add_flight(flight1)

    reservation1 = Reservation(1, "John Doe", 1, "1A", datetime.date(2024, 7, 13))
    system.add_reservation(reservation1)

    print(system.generate_passenger_report(1))
    system.update_flight(1, available_seats=20)
    system.update_reservation(1, 1, passenger_name="Jane Doe")
    system.cancel_reservation(1, 1)

    print(system.generate_passenger_report(1))