class Product:
    def __init__(self, product_id, name, description, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.stock_quantity = stock_quantity

class Collection:
    def __init__(self): 
        self.products_list = [] 
    
    #To add a product 
    def add_product(self, product): 
        self.products_list.append(product)
        print("\nProduct " + product.name + " added successfully")
    
    #To display a product
    def display_products(self):
        for product in self.products_list:
            print(f"\nID: {product.product_id}, Name: {product.name}, Price: {product.price}, Stock Quantity: {product.stock_quantity}")
    
    #To update a product
    def update_product(self, product_id, new_price, new_stock_quantity):
        for product in self.products_list:
            if product.product_id == product_id:
                product.price = new_price
                product.stock_quantity = new_stock_quantity
                print("\nProduct " + str(product_id) + " updated successfully")
                product_found = True
                break 

        if not product_found:
            print("Product id is not found") 
    
    #To delete a product 
    def delete_product(self, product_id):
        for product in self.products_list:
            if product.product_id == product_id:
                self.products_list.remove(product)
                print(f"\nProduct {product_id} removed succesfully") 
                product_found = True

        if not product_found:
            print("Product id not found")

#Sample Implementation
if __name__ == "__main__":
    collection = Collection()
    
    product1 = Product(1, "T shirt", "White color cotton t shirt", 299, 20)
    product2 = Product(2, "Jeans", "Levis blue jeans", 3400, 10) 
    product3 = Product(3, "Kurthi", "Avasa mix and match sleeveless kurthi", 599, 25)
    collection.add_product(product1)
    collection.add_product(product2) 
    collection.add_product(product3)

    print("\nProducts before update: ")
    collection.display_products()

    collection.update_product(2, 3500, 20)

    collection.delete_product(3)
    
    print("\nProducts after update: ")
    collection.display_products()
    
class Customer: 
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email 
        self.address = address 

class users:
    def __init__(self):
        self.customer_list = []
    
    #To add a customer 
    def add_customer(self, customer):
        self.customer_list.append(customer)
        print(f"\nCustomer {customer.name} added successfully") 
    
    #To update the details of customer
    def update_customer(self, customer_id, name=None, email=None, address=None):
        for customer in self.customer_list:
            if customer.customer_id == customer_id:
                if name:
                    customer.name = name
                if email:
                    customer.email = email
                if address:
                    customer.address = address
                print(f"\nCustomer {customer_id} updated successfully")
                return
        print(f"\nCustomer {customer_id} not found")

#Sample Implementation
if __name__ == "__main__":
    users = users()

    customer1 = Customer(101, "Gayathri", "gayathri123@gmail.com", "Hyderabad")
    users.add_customer(customer1) 

    users.update_customer(101, name="Gayathri Reddy")

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

class OrderManager:
    def __init__(self):
        self.orders_list = []

    #To add an order
    def add_order(self, order):
        self.orders_list.append(order)
        print(f"Order {order.order_id} added successfully")

    #To display orders
    def display_orders(self):
        for order in self.orders_list:
            print(f"\nOrder ID: {order.order_id}, Customer ID: {order.customer_id}, "
                  f"Product ID: {order.product_id}, Order Date: {order.order_date}, Quantity: {order.quantity}")

    #To update an order
    def update_order(self, order_id, new_customer_id, new_product_id, new_order_date, new_quantity):
        order_found = False
        for order in self.orders_list:
            if order.order_id == order_id:
                order.customer_id = new_customer_id
                order.product_id = new_product_id
                order.order_date = new_order_date
                order.quantity = new_quantity
                print(f"\nOrder {order_id} updated successfully")
                order_found = True
                break 

        if not order_found:
            print(f"Order ID {order_id} not found")

    #To delete an order
    def delete_order(self, order_id):
        order_found = False
        for order in self.orders_list:
            if order.order_id == order_id:
                self.orders_list.remove(order)
                print(f"\nOrder {order_id} removed successfully")
                order_found = True
                break

        if not order_found:
            print(f"Order ID {order_id} not found")

#Sample Implementation 
if __name__ == "__main__":
    order1 = Order(1, 101, 501, "2023-01-01", 2)
    order2 = Order(2, 102, 502, "2023-01-02", 5)

    manager = OrderManager()
    manager.add_order(order1)
    manager.add_order(order2)

    manager.display_orders()

    manager.update_order(1, 201, 601, "2023-02-01", 3)
    manager.display_orders()

    manager.delete_order(2)
    manager.display_orders()

    