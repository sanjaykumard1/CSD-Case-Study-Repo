
Employee Performance Tracking System - MySQL Database
This document serves as a guide for the Employee Performance Tracking System (EPTS) implemented using a MySQL database.

Database Schema:

The EPTS utilizes two tables:

Employees Table:

employee_id (INT, Primary Key): Unique identifier for each employee.
name (VARCHAR(100)): Employee's full name.
department (VARCHAR(50)): Department the employee belongs to.
designation (VARCHAR(50)): Employee's job title or designation.
performance_score (INT): Employee's current performance score.
PerformanceReviews Table:

review_id (INT, Primary Key): Unique identifier for each performance review.
employee_id (INT, Foreign Key): References the employee_id in the Employees table (establishes a one-to-many relationship between employees and reviews).
review_date (DATE): Date the performance review was conducted.
review_comments (TEXT): Textual comments from the performance review.
Foreign Key Relationship:

The PerformanceReviews table has a foreign key employee_id that references the primary key employee_id in the Employees table. This ensures data integrity and allows joining the tables for queries.

Sample Data (Mohan - Candidate ID 29854617):

Note: You'll need to replace the sample data with actual employee information and Mohan's details (including department, designation, and performance score) for the Employees table. You can also add performance reviews for Mohan (and other employees) in the PerformanceReviews table.

Problem Statements and Solutions:

The document also provides solutions to various problem statements using MySQL queries:

Average Performance Score per Department:

SQL
SELECT department, AVG(performance_score) AS average_score
FROM Employees
GROUP BY department;
Use code with caution.

Employee Details (Name, Performance Score, Department):

SQL
SELECT name, performance_score, department
FROM Employees;
Use code with caution.

Employees with No Performance Reviews:

SQL
SELECT e.name
FROM Employees e
LEFT JOIN PerformanceReviews pr ON e.employee_id = pr.employee_id
WHERE pr.review_id IS NULL;
Use code with caution.

Departments with More Than 5 Top Performers:

SQL
SELECT department
FROM Employees
WHERE performance_score > 85
GROUP BY department
HAVING COUNT(*) > 5;
Use code with caution.

Employees with More Than 3 Performance Reviews:

SQL
SELECT e.name, e.designation
FROM Employees e
JOIN (
    SELECT employee_id
    FROM PerformanceReviews
    GROUP BY employee_id
    HAVING COUNT(review_id) > 3
) pr ON e.employee_id = pr.employee_id;
Use code with caution.

Getting Started:

Ensure you have a MySQL database server running.
Import the provided table structures (or create them manually) into your database.
Replace the sample data with your actual employee information, including Mohan's details.
Use the provided queries to retrieve data based on your needs.



Example using MySQL Command Line Client:

Open your command prompt or terminal.

Assuming your username is root and password is mypassword (replace with your actual credentials), connect to the database named Employees using the following command:

Bash
mysql -u root -p Employees
Use code with caution.

When prompted, enter your password.
Now you're connected to the database. Paste one query at a time and press Enter to execute it.

Output Interpretation:

The output of each query will vary depending on your actual data. Here's how to interpret some of the sample queries:

1. Average Performance Score per Department:

SQL
SELECT department, AVG(performance_score) AS average_score
FROM Employees
GROUP BY department;
Use code with caution.

This query will display a table with two columns: department and average_score. Each row will represent a department and its average employee performance score based on the data in your Employees table.

Example Output:

department | average_score
-----------|---------------
Engineering | 88.5
Human Resources | 68
Marketing | 70.5
Sales | 85