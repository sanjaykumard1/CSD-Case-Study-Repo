class Employee:
  """
  Represents an employee with attributes and methods for performance tracking.
  """
  def __init__(self, employee_id, name, department, designation, performance_score):
    self.employee_id = employee_id
    self.name = name
    self.department = department
    self.designation = designation
    self.performance_score = performance_score

  def update_details(self, name=None, department=None, designation=None):
    """
    Updates employee details (name, department, designation) if provided.
    """
    if name:
      self.name = name
    if department:
      self.department = department
    if designation:
      self.designation = designation

class EmployeePerformanceTracker:
  """
  Manages employee records and performance tracking functionalities.
  """
  def __init__(self):
    self.employees = {}  # Dictionary to store employees (key: employee_id, value: Employee object)

  def add_employee(self, employee_id, name, department, designation, performance_score):
    """
    Adds a new employee to the system. Raises an exception if ID already exists.
    """
    if employee_id in self.employees:
      raise ValueError("Employee ID already exists")
    self.employees[employee_id] = Employee(employee_id, name, department, designation, performance_score)

  def update_employee(self, employee_id, **kwargs):
    """
    Updates existing employee details based on provided arguments. Raises an exception if ID not found.
    """
    if employee_id not in self.employees:
      raise ValueError("Employee not found")
    employee = self.employees[employee_id]
    employee.update_details(**kwargs)

  def delete_employee(self, employee_id):
    """
    Deletes an employee from the system. Raises an exception if ID not found.
    """
    if employee_id not in self.employees:
      raise ValueError("Employee not found")
    del self.employees[employee_id]

  def update_performance_score(self, employee_id, new_score):
    """
    Updates the performance score of an employee. Raises an exception if ID not found.
    """
    if employee_id not in self.employees:
      raise ValueError("Employee not found")
    self.employees[employee_id].performance_score = new_score

  def generate_performance_review(self, employee_id):
    """
    Generates a basic performance review string for a specific employee (not implemented here).
    This method can be extended to return a more detailed report based on the performance score.
    """
    if employee_id not in self.employees:
      raise ValueError("Employee not found")
    employee = self.employees[employee_id]
    review = f"Employee ID: {employee.employee_id}\nName: {employee.name}\nPerformance Score: {employee.performance_score}"
    # Add logic for detailed review based on score here
    return review

  def get_top_performers(self):
    """
    Returns a list of employee IDs with performance scores greater than 85.
    """
    top_performers = []
    for employee_id, employee in self.employees.items():
      if employee.performance_score > 85:
        top_performers.append(employee_id)
    return top_performers

def main():
  """
  Main function for user interaction and running the application functionalities.
  """
  tracker = EmployeePerformanceTracker()

  while True:
    print("\nEmployee Performance Tracking System")
    print("1. Add Employee")
    print("2. Update Employee Details")
    print("3. Delete Employee")
    print("4. Update Performance Score")
    print("5. Generate Performance Review")
    print("6. Top Performers Report")
    print("7. Exit")

    choice = input("Enter your choice: ")

    if choice == '1':
      try:
        employee_id = int(input("Enter Employee ID: "))
        name = input("Enter Name: ")
        department = input("Enter Department: ")
        designation = input("Enter Designation: ")
        performance_score = float(input("Enter Performance Score: "))
        tracker.add_employee(employee_id, name, department, designation, performance_score)
      except ValueError as e:
        print(f"Error: {e}")

    elif choice == '2':
      try:
        employee_id = int(input("Enter Employee ID to update: "))
        details_to_update = {}
        name_update = input("Update name? (y/n): ")
        if name_update.lower() == 'y':
          details_to_update["name"] = input("Enter new name: ")
        department_update = input("Update department? (y/n): ")
        if department_update.lower() == 'y':
          details_to_update["department"] = input("Enter new department: ")
        designation_update = input("Update designation? (y/n): ")
        if designation_update.lower() == 'y':
          details_to_update["designation"] = input("Enter new designation: ")
        tracker.update_employee(employee_id, **details_to_update)
        print("Employee details updated successfully!")
      except ValueError as e:
        print(f"Error: {e}")

    elif choice == '3':
      try:
        employee_id = int(input("Enter Employee ID to delete: "))
        tracker.delete_employee(employee_id)
        print("Employee deleted successfully!")
      except ValueError as e:
        print(f"Error: {e}")

    elif choice == '4':
      try:
        employee_id = int(input("Enter Employee ID to update score: "))
        new_score = float(input("Enter new performance score: "))
        tracker.update_performance_score(employee_id, new_score)
        print("Performance score updated successfully!")
      except ValueError as e:
        print(f"Error: {e}")

    elif choice == '5':
      try:
        employee_id = int(input("Enter Employee ID to generate review: "))
        review = tracker.generate_performance_review(employee_id)
        print(review)
      except ValueError as e:
        print(f"Error: {e}")

    elif choice == '6':
      top_performers = tracker.get_top_performers()
      if top_performers:
        print("Top Performers (Score > 85):")
        for performer in top_performers:
          print(f"- Employee ID: {performer}")
      else:
        print("No employees have a performance score above 85.")

    elif choice == '7':
      print("Exiting application...")
      break

    else:
      print("Invalid choice. Please try again.")

if __name__ == "__main__":
  main()

        
