 #MenuItem Class
 
class MenuItem:
    def __init__(self, item_id, name, category, price, availability):
        self.item_id = item_id
        self.name = name
        self.category = category
        self.price = price
        self.availability = availability

    def __str__(self):
        return f"ID: {self.item_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Availability: {'Yes' if self.availability else 'No'}"


#Menu Management

class MenuManagement:
    def __init__(self):
        self.menu_items = {}

    def add_menu_item(self, item):
        self.menu_items[item.item_id] = item

    def update_menu_item(self, item_id, name=None, category=None, price=None, availability=None):
        if item_id in self.menu_items:
            item = self.menu_items[item_id]
            if name:
                item.name = name
            if category:
                item.category = category
            if price is not None:
                item.price = price
            if availability is not None:
                item.availability = availability
        else:
            print("Menu item not found.")

    def delete_menu_item(self, item_id):
        if item_id in self.menu_items:
            del self.menu_items[item_id]
        else:
            print("Menu item not found.")

    def display_menu(self):
        for item in self.menu_items.values():
            print(item)

#Customer Class


class Customer:
    def __init__(self, customer_id, name, contact_number, email):
        self.customer_id = customer_id
        self.name = name
        self.contact_number = contact_number
        self.email = email

    def __str__(self):
        return f"ID: {self.customer_id}, Name: {self.name}, Contact: {self.contact_number}, Email: {self.email}"


#Customer MAnagement


class CustomerManagement:
    def __init__(self):
        self.customers = {}

    def add_customer(self, customer):
        self.customers[customer.customer_id] = customer

    def update_customer(self, customer_id, name=None, contact_number=None, email=None):
        if customer_id in self.customers:
            customer = self.customers[customer_id]
            if name:
                customer.name = name
            if contact_number:
                customer.contact_number = contact_number
            if email:
                customer.email = email
        else:
            print("Customer not found.")

    def delete_customer(self, customer_id):
        if customer_id in self.customers:
            del self.customers[customer_id]
        else:
            print("Customer not found.")

    def display_customers(self):
        for customer in self.customers.values():
            print(customer)


#Order Class


from datetime import date

class Order:
    def __init__(self, order_id, customer_id, item_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.item_id = item_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order ID: {self.order_id}, Customer ID: {self.customer_id}, Item ID: {self.item_id}, Date: {self.order_date}, Quantity: {self.quantity}"


#Order MAnagement


class OrderManagement:
    def __init__(self):
        self.orders = {}

    def add_order(self, order):
        self.orders[order.order_id] = order

    def update_order(self, order_id, customer_id=None, item_id=None, order_date=None, quantity=None):
        if order_id in self.orders:
            order = self.orders[order_id]
            if customer_id:
                order.customer_id = customer_id
            if item_id:
                order.item_id = item_id
            if order_date:
                order.order_date = order_date
            if quantity is not None:
                order.quantity = quantity
        else:
            print("Order not found.")

    def cancel_order(self, order_id):
        if order_id in self.orders:
            del self.orders[order_id]
        else:
            print("Order not found.")

    def display_orders(self):
        for order in self.orders.values():
            print(order)



#Main Application 


def main():
    menu_management = MenuManagement()
    customer_management = CustomerManagement()
    order_management = OrderManagement()

    while True:
        print("\nRestaurant Management System")
        print("1. Manage Menu Items")
        print("2. Manage Customers")
        print("3. Manage Orders")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            print("\nMenu Management")
            print("1. Add Menu Item")
            print("2. Update Menu Item")
            print("3. Delete Menu Item")
            print("4. Display Menu")

            menu_choice = input("Enter your choice: ")

            if menu_choice == '1':
                item_id = int(input("Enter item ID: "))
                name = input("Enter item name: ")
                category = input("Enter item category: ")
                price = float(input("Enter item price: "))
                availability = input("Is the item available (yes/no): ").lower() == 'yes'
                menu_item = MenuItem(item_id, name, category, price, availability)
                menu_management.add_menu_item(menu_item)
            elif menu_choice == '2':
                item_id = int(input("Enter item ID: "))
                name = input("Enter new item name (leave blank to keep current): ")
                category = input("Enter new item category (leave blank to keep current): ")
                price = input("Enter new item price (leave blank to keep current): ")
                availability = input("Is the item available (yes/no/leave blank to keep current): ").lower()
                price = float(price) if price else None
                availability = availability if availability in ['yes', 'no'] else None
                availability = True if availability == 'yes' else False if availability == 'no' else None
                menu_management.update_menu_item(item_id, name, category, price, availability)
            elif menu_choice == '3':
                item_id = int(input("Enter item ID to delete: "))
                menu_management.delete_menu_item(item_id)
            elif menu_choice == '4':
                menu_management.display_menu()

        elif choice == '2':
            print("\nCustomer Management")
            print("1. Add Customer")
            print("2. Update Customer")
            print("3. Delete Customer")
            print("4. Display Customers")

            customer_choice = input("Enter your choice: ")

            if customer_choice == '1':
                customer_id = int(input("Enter customer ID: "))
                name = input("Enter customer name: ")
                contact_number = input("Enter contact number: ")
                email = input("Enter email: ")
                customer = Customer(customer_id, name, contact_number, email)
                customer_management.add_customer(customer)
            elif customer_choice == '2':
                customer_id = int(input("Enter customer ID: "))
                name = input("Enter new customer name (leave blank to keep current): ")
                contact_number = input("Enter new contact number (leave blank to keep current): ")
                email = input("Enter new email (leave blank to keep current): ")
                customer_management.update_customer(customer_id, name, contact_number, email)
            elif customer_choice == '3':
                customer_id = int(input("Enter customer ID to delete: "))
                customer_management.delete_customer(customer_id)
            elif customer_choice == '4':
                customer_management.display_customers()

        elif choice == '3':
            print("\nOrder Management")
            print("1. Add Order")
            print("2. Update Order")
            print("3. Cancel Order")
            print("4. Display Orders")

            order_choice = input("Enter your choice: ")

            if order_choice == '1':
                order_id = int(input("Enter order ID: "))
                customer_id = int(input("Enter customer ID: "))
                item_id = int(input("Enter item ID: "))
                order_date = input("Enter order date (YYYY-MM-DD): ")
                quantity = int(input("Enter quantity: "))
                order = Order(order_id, customer_id, item_id, order_date, quantity)
                order_management.add_order(order)
            elif order_choice == '2':
                order_id = int(input("Enter order ID: "))
                customer_id = int(input("Enter new customer ID (leave blank to keep current): "))
                item_id = int(input("Enter new item ID (leave blank to keep current): "))
                order_date = input("Enter new order date (leave blank to keep current): ")
                quantity = input("Enter new quantity (leave blank to keep current): ")
                quantity = int(quantity) if quantity else None
                order_management.update_order(order_id, customer_id, item_id, order_date, quantity)
            elif order_choice == '3':
                order_id = int(input("Enter order ID to cancel: "))
                order_management.cancel_order(order_id)
            elif order_choice == '4':
                order_management.display_orders()

        elif choice == '4':
            break

        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()




