create database Online_Shopping_System;

use Online_Shopping_System;

create table Products(product_id INT Primary Key ,name VARCHAR(100),category VARCHAR(50),price DECIMAL(10, 2),stock_quantity INT);

create table Customers(
	customer_id  int primary key,
    name varchar(100),
    email varchar(100),
    address varchar(255)
);
CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    order_date DATE,
    quantity INT,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- 1.
SELECT SUM(o.quantity * p.price) AS total_sales_revenue
FROM Orders o
JOIN Products p ON o.product_id = p.product_id;

-- 2.
SELECT c.name, c.email
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name, c.email
HAVING COUNT(o.order_id) > 3;


-- 3.
SELECT category
FROM Products
WHERE stock_quantity = 0;

-- 4.
SELECT c.name, c.email
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN Products p ON o.product_id = p.product_id
GROUP BY c.customer_id, c.name, c.email
HAVING COUNT(DISTINCT p.category) > 2;
 
-- 5.
SELECT *
FROM Orders
WHERE order_date >= CURDATE() - INTERVAL 30 DAY;