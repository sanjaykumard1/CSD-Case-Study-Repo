import datetime

# Product Class
class Product:
    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Product[ID: {self.product_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Stock: {self.stock_quantity}]"

    def add(self, store):
        if self.product_id in store.products:
            raise Exception("Product with this ID already exists.")
        store.products[self.product_id] = self

    def update(self, store):
        if self.product_id not in store.products:
            raise Exception("Product not found.")
        store.products[self.product_id] = self

    def delete(self, store):
        if self.product_id not in store.products:
            raise Exception("Product not found.")
        del store.products[self.product_id]

# Customer Class
class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def __str__(self):
        return f"Customer[ID: {self.customer_id}, Name: {self.name}, Email: {self.email}, Address: {self.address}]"

    def add(self, store):
        if self.customer_id in store.customers:
            raise Exception("Customer with this ID already exists.")
        store.customers[self.customer_id] = self

    def update(self, store):
        if self.customer_id not in store.customers:
            raise Exception("Customer not found.")
        store.customers[self.customer_id] = self

    def delete(self, store):
        if self.customer_id not in store.customers:
            raise Exception("Customer not found.")
        del store.customers[self.customer_id]

# Order Class
class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order[ID: {self.order_id}, CustomerID: {self.customer_id}, ProductID: {self.product_id}, Date: {self.order_date}, Quantity: {self.quantity}]"

    def add(self, store):
        if self.order_id in store.orders:
            raise Exception("Order with this ID already exists.")
        if self.customer_id not in store.customers:
            raise Exception("Customer not found.")
        if self.product_id not in store.products:
            raise Exception("Product not found.")
        if store.products[self.product_id].stock_quantity < self.quantity:
            raise Exception("Insufficient stock.")
        store.products[self.product_id].stock_quantity -= self.quantity
        store.orders[self.order_id] = self

    def update(self, store):
        if self.order_id not in store.orders:
            raise Exception("Order not found.")
        old_order = store.orders[self.order_id]
        if self.product_id not in store.products:
            raise Exception("Product not found.")
        if self.customer_id not in store.customers:
            raise Exception("Customer not found.")
        if store.products[self.product_id].stock_quantity + old_order.quantity < self.quantity:
            raise Exception("Insufficient stock.")
        store.products[self.product_id].stock_quantity += old_order.quantity
        store.products[self.product_id].stock_quantity -= self.quantity
        store.orders[self.order_id] = self

    def delete(self, store):
        if self.order_id not in store.orders:
            raise Exception("Order not found.")
        old_order = store.orders[self.order_id]
        store.products[old_order.product_id].stock_quantity += old_order.quantity
        del store.orders[self.order_id]

# Store Class to manage products, customers, and orders
class Store:
    def __init__(self):
        self.products = {}
        self.customers = {}
        self.orders = {}

# Main Function to Run the Application
def OShopping():
    store = Store()

    while True:
        print("\n1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Add Customer")
        print("5. Update Customer")
        print("6. Delete Customer")
        print("7. Add Order")
        print("8. Update Order")
        print("9. Delete Order")
        print("10. Exit")
        choice = input("Enter your choice: ")

        try:
            match(choice):
                case '1':
                    product = Product(input("Product ID: "), input("Name: "), input("Category: "), float(input("Price: ")), int(input("Stock Quantity: ")))
                    product.add(store)
                    print("Product added successfully.")
                case  '2':
                    product = Product(input("Product ID: "), input("Name: "), input("Category: "), float(input("Price: ")), int(input("Stock Quantity: ")))
                    product.update(store)
                    print("Product updated successfully.")
                case'3':
                    product_id = input("Product ID: ")
                    product = store.products[product_id]
                    product.delete(store)
                    print("Product deleted successfully.")
                case'4':
                    customer = Customer(input("Customer ID: "), input("Name: "), input("Email: "), input("Address: "))
                    customer.add(store)
                    print("Customer added successfully.")
                case '5':
                    customer = Customer(input("Customer ID: "), input("Name: "), input("Email: "), input("Address: "))
                    customer.update(store)
                    print("Customer updated successfully.")
                case '6':
                    customer_id = input("Customer ID: ")
                    customer = store.customers[customer_id]
                    customer.delete(store)
                    print("Customer deleted successfully.")
                case '7':
                    order = Order(input("Order ID: "), input("Customer ID: "), input("Product ID: "), datetime.date.today(), int(input("Quantity: ")))
                    order.add(store)
                    print("Order added successfully.")
                case '8':
                    order = Order(input("Order ID: "), input("Customer ID: "), input("Product ID: "), datetime.date.today(), int(input("Quantity: ")))
                    order.update(store)
                    print("Order updated successfully.")
                case '9':
                    order_id = input("Order ID: ")
                    order = store.orders[order_id]
                    order.delete(store)
                    print("Order deleted successfully.")
                case '10':
                    break
                case _:
                    print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")
OShopping()
