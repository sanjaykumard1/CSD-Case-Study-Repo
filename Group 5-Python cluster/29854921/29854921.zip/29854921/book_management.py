import datetime

class Book:
    def __init__(self, book_id, title, author, genre, price, stock):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.price = price
        self.stock = stock

    def __str__(self):
        return f"{self.book_id}: {self.title} by {self.author} ({self.genre}) - ${self.price}, Stock: {self.stock}"

class Order:
    def __init__(self, order_id, customer_id, book_id, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.book_id = book_id
        self.quantity = quantity
        self.order_date = datetime.date.today()

class Bookstore:
    def __init__(self):
        self.books = {}
        self.orders = {}
        self.next_book_id = 1
        self.next_order_id = 1
        self.dummydata()

    def dummydata(self):
        dummy_books = [
            ("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 10.99, 3),
            ("1984", "George Orwell", "Dystopian", 8.99, 10),
            ("To Kill a Mockingbird", "Harper Lee", "Classic", 7.99, 2),
            ("The Catcher in the Rye", "J.D. Salinger", "Classic", 6.99, 4),
            ("Moby-Dick", "Herman Melville", "Adventure", 11.99, 7)
        ]
        for title, author, genre, price, stock in dummy_books:
            self.addbook(title, author, genre, price, stock, False)

    def addbook(self, title, author, genre, price, stock, display_message=True):
        book = Book(self.next_book_id, title, author, genre, price, stock)
        self.books[self.next_book_id] = book
        self.next_book_id += 1
        if display_message:
            print(f"Book added: {book}")

    def updatebook(self, book_id, title=None, author=None, genre=None, price=None, stock=None):
        book = self.books.get(book_id)
        if not book:
            print(f"No book found with ID {book_id}")
            return
        if title:
            book.title = title
        if author:
            book.author = author
        if genre:
            book.genre = genre
        if price is not None:
            book.price = price
        if stock is not None:
            book.stock = stock
        print(f"Book updated: {book}")

    def deletebook(self, book_id):
        if book_id in self.books:
            del self.books[book_id]
            print(f"Book with ID {book_id} has been deleted.")
        else:
            print(f"No book found with ID {book_id}")

    def processorder(self, customer_id, book_id, quantity):
        if book_id not in self.books:
            print(f"No book found with ID {book_id}")
            return
        book = self.books[book_id]
        if book.stock < quantity:
            print(f"Not enough stock for book ID {book_id}. Available stock: {book.stock}")
            return
        order = Order(self.next_order_id, customer_id, book_id, quantity)
        self.orders[self.next_order_id] = order
        book.stock -= quantity
        self.next_order_id += 1
        print(f"Order processed: {order}")

    def generate_low_stock_report(self):
        low_stock_books = [book for book in self.books.values() if book.stock < 5]
        if not low_stock_books:
            print("No books with low stock.")
        else:
            print("Books with low stock:")
            for book in low_stock_books:
                print(book)

def main():
    bookstore = Bookstore()
    while True:
        print("\nOnline Bookstore Management System")
        print("1. Add Book")
        print("2. Update Book")
        print("3. Delete Book")
        print("4. Process Order")
        print("5. Generate Low Stock Report")
        print("6. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            title = input("Enter title: ")
            author = input("Enter author: ")
            genre = input("Enter genre: ")
            price = float(input("Enter price: "))
            stock = int(input("Enter stock: "))
            bookstore.addbook(title, author, genre, price, stock)
        elif choice == "2":
            book_id = int(input("Enter book ID to update: "))
            title = input("Enter new title (leave blank to keep current): ")
            author = input("Enter new author (leave blank to keep current): ")
            genre = input("Enter new genre (leave blank to keep current): ")
            price = input("Enter new price (leave blank to keep current): ")
            stock = input("Enter new stock (leave blank to keep current): ")
            bookstore.updatebook(book_id, title or None, author or None, genre or None, float(price) if price else None, int(stock) if stock else None)
        elif choice == "3":
            book_id = int(input("Enter book ID to delete: "))
            bookstore.deletebook(book_id)
        elif choice == "4":
            customer_id = input("Enter customer ID: ")
            book_id = int(input("Enter book ID to order: "))
            quantity = int(input("Enter quantity: "))
            bookstore.processorder(customer_id, book_id, quantity)
        elif choice == "5":
            bookstore.generate_low_stock_report()
        elif choice == "6":
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
