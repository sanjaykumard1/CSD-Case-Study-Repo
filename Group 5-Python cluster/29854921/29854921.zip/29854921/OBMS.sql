Create database OBMS;
show databases;
use obms;

-- Created tables
CREATE TABLE books (
    bookId INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    author varchar(100),
    genre varchar(15),
    price decimal(10, 2),
    stock INT NOT NULL
);

Create Table Customers (
	customerId INT AUTO_INCREMENT PRIMARY KEY,
    name varchar(100) NOT NULL,
    email varchar(100) NOT NULL);
    
CREATE TABLE orders (
    orderId INT AUTO_INCREMENT PRIMARY KEY,
    customerId INT,
    bookId INT,
    orderDate DATE,
    quantity INT,
    FOREIGN KEY (customerId) REFERENCES customers(customerId),
    FOREIGN KEY (bookId) REFERENCES books(bookId)
);

-- Inserted Data for table
INSERT INTO customers (name, email) VALUES
('Aniket Doe', 'Ani.doe@example.com'),
('Anupam Smith', 'anup.smith@example.com'),
('Ashish Johnson', 'Ashish.johnson@example.com'),
('Harsh Brown', 'harsh.brown@example.com'),
('Carol White', 'carol.white@example.com');

select * from customers;
select * from books;
select * from orders;

INSERT INTO books (title, author, genre, price, stock) VALUES
('To Kill a Mockingbird', 'Harper Lee', 'Fiction', 10.99, 20),
('1984', 'George Orwell', 'Dystopian', 8.99, 15),
('Pride and Prejudice', 'Jane Austen', 'Romance', 12.99, 30),
('The Great Gatsby', 'F. Scott Fitzgerald', 'Fiction', 10.49, 25),
('Moby Dick', 'Herman Melville', 'Adventure', 9.99, 10),
('The Hobbit', 'J.R.R. Tolkien', 'Fantasy', 14.99, 40);


INSERT INTO orders (customerId, bookId, orderDate, quantity) VALUES
(1, 2, '2024-07-01', 3),
(2, 5, '2024-07-02', 1),
(3, 1, '2024-07-03', 2),
(1, 4, '2024-07-04', 1),
(4, 3, '2024-07-05', 4),
(5, 6, '2024-07-06', 1),
(2, 1, '2024-07-07', 2),
(3, 2, '2024-07-08', 1),
(4, 5, '2024-07-09', 3),
(5, 3, '2024-07-10', 2);

-- Query for the problem statement

SELECT b.title,SUM(o.quantity * b.price) AS total_sales_amount
FROM orders o JOIN books b ON o.bookId = b.bookId GROUP BY b.title;

SELECT c.name AS customer_name,SUM(o.quantity * b.price) AS total_order_amount
FROM orders o JOIN customers c ON o.customerId = c.customerId JOIN books b ON o.bookId = b.bookId
GROUP BY c.name;

SELECT b.title FROM books b LEFT JOIN orders o ON b.bookId = o.bookId
WHERE o.orderId IS NULL;

SELECT c.name AS customer_name, COUNT(o.orderId) AS order_count
FROM orders o JOIN customers c ON o.customerId = c.customerId
GROUP BY c.customerId, c.name HAVING COUNT(o.orderId) > 5;

SELECT title, stock FROM books WHERE stock < 5;

