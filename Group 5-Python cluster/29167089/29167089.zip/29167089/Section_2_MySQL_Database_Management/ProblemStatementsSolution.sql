-- 1. Write a query to find the total rental income for each vehicle
SELECT V.vehicle_id, V.make, V.model, SUM(DATEDIFF(R.rental_end_date, R.rental_start_date) * V.rental_rate) AS total_rental_income FROM Rentals R JOIN Vehicles V ON R.vehicle_id = V.vehicle_id GROUP BY V.vehicle_id, V.make, V.model;

-- 2. Write a query to find the names of customers and the vehicles they have rented
SELECT C.name AS customer_name, V.make, V.model FROM Rentals R JOIN Customers C ON R.customer_id = C.customer_id JOIN Vehicles V ON R.vehicle_id = V.vehicle_id;

-- 3. Write a query to find the vehicles that have never been rented
SELECT V.vehicle_id, V.make, V.model FROM Vehicles V LEFT JOIN Rentals R ON V.vehicle_id = R.vehicle_id WHERE R.rental_id IS NULL;

-- 4. Write a query to find the customers who have rented more than 3 different vehicles
SELECT C.customer_id, C.name AS customer_name, COUNT(DISTINCT R.vehicle_id) AS vehicles_rented FROM Rentals R JOIN Customers C ON R.customer_id = C.customer_id GROUP BY C.customer_id, C.name HAVING COUNT(DISTINCT R.vehicle_id) > 3;

-- 5. Write a query to find the vehicle makes and models with less than 5 available units for rent
SELECT V.make, V.model, COUNT(V.vehicle_id) AS available_units FROM Vehicles V WHERE V.available = TRUE GROUP BY V.make, V.model HAVING COUNT(V.vehicle_id) < 5;
