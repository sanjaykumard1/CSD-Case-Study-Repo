import mysql.connector
from mysql.connector import Error
from datetime import date

class Vehicle:
    def __init__(self, vehicle_id, make, model, year, rental_rate, available=True):
        self.vehicle_id = vehicle_id
        self.make = make
        self.model = model
        self.year = year
        self.rental_rate = rental_rate
        self.available = available

    @staticmethod
    def connect():
        try:
            connection = mysql.connector.connect(
                host='localhost',
                database='VehicleRentalDB',
                user='root',
                password='1234'  # Replace with your MySQL root password
            )
            return connection
        except Error as e:
            print(f"Error: {e}")
            return None

    def add_vehicle(self):
        connection = self.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                sql = "INSERT INTO Vehicles (vehicle_id, make, model, year, rental_rate, available) VALUES (%s, %s, %s, %s, %s, %s)"
                val = (self.vehicle_id, self.make, self.model, self.year, self.rental_rate, self.available)
                cursor.execute(sql, val)
                connection.commit()
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

    def update_vehicle(self, **kwargs):
        connection = self.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                set_clause = ", ".join(f"{key} = %s" for key in kwargs.keys())
                sql = f"UPDATE Vehicles SET {set_clause} WHERE vehicle_id = %s"
                values = tuple(kwargs.values()) + (self.vehicle_id,)
                cursor.execute(sql, values)
                connection.commit()
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

    def delete_vehicle(self):
        connection = self.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                sql = "DELETE FROM Vehicles WHERE vehicle_id = %s"
                val = (self.vehicle_id,)
                cursor.execute(sql, val)
                connection.commit()
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

class Rental:
    def __init__(self, rental_id, customer_name, vehicle_id, rental_start_date, rental_end_date):
        self.rental_id = rental_id
        self.customer_name = customer_name
        self.vehicle_id = vehicle_id
        self.rental_start_date = rental_start_date
        self.rental_end_date = rental_end_date

    @staticmethod
    def connect():
        try:
            connection = mysql.connector.connect(
                host='localhost',
                database='VehicleRentalDB',
                user='root',
                password='1234' 
            )
            return connection
        except Error as e:
            print(f"Error: {e}")
            return None

    def process_rental(self):
        connection = self.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                customer_id = self.get_customer_id()
                sql = "INSERT INTO Rentals (customer_id, vehicle_id, rental_start_date, rental_end_date) VALUES (%s, %s, %s, %s)"
                val = (customer_id, self.vehicle_id, self.rental_start_date, self.rental_end_date)
                cursor.execute(sql, val)

                sql = "UPDATE Vehicles SET available = %s WHERE vehicle_id = %s"
                cursor.execute(sql, (False, self.vehicle_id))
                connection.commit()
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

    def get_customer_id(self):
        connection = self.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                sql = "SELECT customer_id FROM Customers WHERE name = %s"
                cursor.execute(sql, (self.customer_name,))
                result = cursor.fetchone()
                if result:
                    customer_id = result[0]
                else:
                    # If customer does not exist then we are adding to it
                    sql = "INSERT INTO Customers (name, contact_info) VALUES (%s, %s)"
                    cursor.execute(sql, (self.customer_name, ''))
                    connection.commit()
                    customer_id = cursor.lastrowid
                return customer_id
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

class RentalReport:
    @staticmethod
    def connect():
        try:
            connection = mysql.connector.connect(
                host='localhost',
                database='VehicleRentalDB',
                user='root',
                password='1234'
            )
            return connection
        except Error as e:
            print(f"Error: {e}")
            return None

    @staticmethod
    def generate_report():
        connection = RentalReport.connect()
        if connection and connection.is_connected():
            try:
                cursor = connection.cursor()
                sql = "SELECT vehicle_id, make, model FROM Vehicles WHERE available = FALSE"
                cursor.execute(sql)
                result = cursor.fetchall()
                for row in result:
                    print(f"Vehicle ID: {row[0]}, Make: {row[1]}, Model: {row[2]}")
            except Error as e:
                print(f"Error: {e}")
            finally:
                cursor.close()
                connection.close()

def insert_sample_data():
    connection = Vehicle.connect()
    if connection and connection.is_connected():
        try:
            cursor = connection.cursor()

            # Samples below
            vehicles = [
                (1, 'Toyota', 'Camry', 2020, 50.0, True),
                (2, 'Honda', 'Civic', 2019, 45.0, True),
                (3, 'Ford', 'Mustang', 2021, 70.0, True)
            ]
            cursor.executemany("INSERT INTO Vehicles (vehicle_id, make, model, year, rental_rate, available) VALUES (%s, %s, %s, %s, %s, %s)", vehicles)

            customers = [
                ('John Doe', 'john@example.com'),
                ('Jane Smith', 'jane@example.com'),
                ('Alice Johnson', 'alice@example.com')
            ]
            cursor.executemany("INSERT INTO Customers (name, contact_info) VALUES (%s, %s)", customers)

            connection.commit()
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
            connection.close()


# now here we are inserting deleting and updating then generating report 

insert_sample_data() #just for inserting few sample data

vehicle = Vehicle(4, 'Chevrolet', 'Impala', 2018, 60.0)
vehicle.add_vehicle()

vehicle.update_vehicle(model='Malibu', rental_rate=55.0)
vehicle.update_vehicle(model='Creta', rental_rate=65.0)


rental = Rental(1, 'John Doe', 1, date(2023, 7, 1), date(2023, 7, 10))
rental.process_rental()
rental2 = Rental(2, 'vicky Doe', 2, date(2023, 7, 1), date(2023, 7, 10))
rental2.process_rental()

RentalReport.generate_report()
