import datetime

# Define MenuItem class
class MenuItem:
    def __init__(self, item_id, name, category, price, availability):
        self.item_id = item_id
        self.name = name
        self.category = category
        self.price = price
        self.availability = availability
    
    def __repr__(self):
        return f"MenuItem({self.item_id}, {self.name}, {self.category}, {self.price}, {self.availability})"

# Define Customer class
class Customer:
    def __init__(self, customer_id, name, contact_number, email):
        self.customer_id = customer_id
        self.name = name
        self.contact_number = contact_number
        self.email = email
        self.reviews = []  # To store customer reviews
    
    def __repr__(self):
        return f"Customer({self.customer_id}, {self.name}, {self.contact_number}, {self.email})"

    def add_review(self, review):
        self.reviews.append(review)

# Define Order class
class Order:
    def __init__(self, order_id, customer_id, item_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.item_id = item_id
        self.order_date = order_date
        self.quantity = quantity
    
    def __repr__(self):
        return f"Order({self.order_id}, {self.customer_id}, {self.item_id}, {self.order_date}, {self.quantity})"

# Define RestaurantManagementSystem class
class RestaurantManagementSystem:
    def __init__(self):
        self.menu_items = {}
        self.customers = {}
        self.orders = {}
        self.current_order_id = 1
        
        # Initialize with predefined menu items
        self.initialize_menu()
    
    def initialize_menu(self):
        # Biryani Category
        self.menu_items[1] = MenuItem(1, "Veg Biryani", "Biryani", 100, True)
        self.menu_items[2] = MenuItem(2, "Chicken Biryani", "Biryani", 250, True)
        self.menu_items[3] = MenuItem(3, "Paneer Biryani", "Biryani", 200, True)
        self.menu_items[4] = MenuItem(4, "Egg Biryani", "Biryani", 190, True)
        
        # Roti Category
        self.menu_items[5] = MenuItem(5, "Butter Naan", "Roti", 20, True)
        self.menu_items[6] = MenuItem(6, "Tandoori Roti", "Roti", 50, False)
        self.menu_items[7] = MenuItem(7, "Chapathi", "Roti", 25, True)
        
        # Curries Category
        self.menu_items[8] = MenuItem(8, "Veg Curry", "Curries", 150, True)
        self.menu_items[9] = MenuItem(9, "Chicken Curry", "Curries", 200, True)
        self.menu_items[10] = MenuItem(10, "Paneer Curry", "Curries", 190, True)

    # Menu Management
    def add_menu_item(self):
        item_id = int(input("Enter Item ID: "))
        if item_id in self.menu_items:
            print("Item with this ID already exists.")
            return
        name = input("Enter Item Name: ")
        category = input("Enter Item Category (Biryani, Roti, Curries): ")
        price = float(input("Enter Item Price: "))
        availability = input("Is the item available? (yes/no): ").strip().lower() == 'yes'
        self.menu_items[item_id] = MenuItem(item_id, name, category, price, availability)
        print(f"Menu Item '{name}' added successfully.")
    
    def update_menu_item(self):
        item_id = int(input("Enter the Item ID to update: "))
        if item_id not in self.menu_items:
            print("Item with this ID does not exist.")
            return
        item = self.menu_items[item_id]
        print(f"Updating item: {item.name}")
        name = input(f"Enter new name (or press Enter to keep '{item.name}'): ")
        if name:
            item.name = name
        category = input(f"Enter new category (or press Enter to keep '{item.category}'): ")
        if category:
            item.category = category
        price = input(f"Enter new price (or press Enter to keep '{item.price}'): ")
        if price:
            item.price = float(price)
        availability = input(f"Is the item available? (yes/no, or press Enter to keep '{item.availability}'): ").strip().lower()
        if availability:
            item.availability = availability == 'yes'
        print(f"Menu Item '{item_id}' updated successfully.")
    
    def delete_menu_item(self):
        item_id = int(input("Enter the Item ID to delete: "))
        if item_id not in self.menu_items:
            print("Item with this ID does not exist.")
            return
        del self.menu_items[item_id]
        print(f"Menu Item '{item_id}' deleted successfully.")
    
    def show_menu(self):
        if not self.menu_items:
            print("No menu items available.")
            return

        # Group menu items by category
        categories = {'Biryani': [], 'Roti': [], 'Curries': []}
        for item in self.menu_items.values():
            categories[item.category].append(item)
        
        print("\n--- Menu ---")
        for category, items in categories.items():
            print(f"\nCategory: {category}")
            print(f"{'Item ID':<7} {'Item Name':<20} {'Price':<10} {'Available':<10}")
            print("-" * 50)
            for item in items:
                availability = 'Yes' if item.availability else 'No'
                print(f"{item.item_id:<7} {item.name:<20} ${item.price:<10.2f} {availability:<10}")

    # Customer Management
    def add_customer(self):
        customer_id = int(input("Enter Customer ID: "))
        if customer_id in self.customers:
            print("Customer with this ID already exists.")
            return
        name = input("Enter Customer Name: ")
        contact_number = input("Enter Customer Contact Number: ")
        email = input("Enter Customer Email: ")
        self.customers[customer_id] = Customer(customer_id, name, contact_number, email)
        print(f"Customer '{name}' added successfully.")
    
    def update_customer(self):
        customer_id = int(input("Enter the Customer ID to update: "))
        if customer_id not in self.customers:
            print("Customer with this ID does not exist.")
            return
        customer = self.customers[customer_id]
        print(f"Updating customer: {customer.name}")
        name = input(f"Enter new name (or press Enter to keep '{customer.name}'): ")
        if name:
            customer.name = name
        contact_number = input(f"Enter new contact number (or press Enter to keep '{customer.contact_number}'): ")
        if contact_number:
            customer.contact_number = contact_number
        email = input(f"Enter new email (or press Enter to keep '{customer.email}'): ")
        if email:
            customer.email = email
        print(f"Customer '{customer_id}' updated successfully.")
    
    def delete_customer(self):
        customer_id = int(input("Enter the Customer ID to delete: "))
        if customer_id not in self.customers:
            print("Customer with this ID does not exist.")
            return
        del self.customers[customer_id]
        print(f"Customer '{customer_id}' deleted successfully.")
    
    def show_customers(self):
        if not self.customers:
            print("No customers available.")
            return
        print("\n--- Customers ---")
        for customer in self.customers.values():
            print(f"ID: {customer.customer_id}, Name: {customer.name}, Contact: {customer.contact_number}, Email: {customer.email}")

    # Order Management
    def place_order(self):
        self.show_menu()
        customer_id = int(input("Enter Customer ID for the order: "))
        if customer_id not in self.customers:
            print("Customer with this ID does not exist.")
            return

        total_order_cost = 0
        while True:
            item_id = int(input("Enter Menu Item ID to order: "))
            if item_id not in self.menu_items or not self.menu_items[item_id].availability:
                print("Menu Item is either unavailable or does not exist.")
                continue
            quantity = int(input("Enter Quantity: "))
            item = self.menu_items[item_id]
            total_cost = item.price * quantity
            total_order_cost += total_cost
            order_date = datetime.date.today()
            order = Order(self.current_order_id, customer_id, item_id, order_date, quantity)
            self.orders[self.current_order_id] = order
            self.current_order_id += 1
            print(f"Added to your order: {item.name}, Quantity: {quantity}, Cost: ${total_cost:.2f}")

            # Ask if the user wants to add more items
            more_items = input("Do you want to add more items to this order? (yes/no): ").strip().lower()
            if more_items != 'yes':
                break

        print(f"Total Cost for the order: ${total_order_cost:.2f}")

        # Collecting Customer Review
        review_text = input("Please provide your review for the item(s): ")
        self.customers[customer_id].add_review(review_text)
        print("Thank you for your review!")

    def show_orders(self):
        if not self.orders:
            print("No orders placed yet.")
            return
        print("\n--- Orders ---")
        for order in self.orders.values():
            item_name = self.menu_items[order.item_id].name
            customer_name = self.customers[order.customer_id].name
            print(f"Order ID: {order.order_id}, Customer: {customer_name}, Item: {item_name}, Date: {order.order_date}, Quantity: {order.quantity}")

    # Main menu for user interaction
    def main_menu(self):
        while True:
            print("\n--- Restaurant Management System ---")
            print("1. Show Menu items")
            print("2. Add Menu item")
            print("3. Update Menu Item")
            print("4. Delete Menu Item")
            print("5. Add Customers")
            print("6. Update Customers")
            print("7. Delete Customer")
            print("8. Show Customers")
            print("9. Place Order")
            print("10. Show Orders")
            print("11. Exit")
            choice = input("Enter your choice: ")
            if choice == '1':
                self.show_menu()
            elif choice == '2':
                self.add_menu_item()
            elif choice == '3':
                self.update_menu_item()
            elif choice == '4':
                self.delete_menu_item()
            elif choice == '5':
                self.add_customer()
            elif choice == '6':
                self.update_customer()
            elif choice == '7':
                self.delete_customer()
            elif choice == '8':
                self.show_customers()
            elif choice == '9':
                self.place_order()
            elif choice == '10':
                self.show_orders()
            elif choice == '11':
                print("Exiting the system. Goodbye!")
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 11.")

# Instantiate and run the restaurant management system
if __name__ == "__main__":
    system = RestaurantManagementSystem()
    system.main_menu()
