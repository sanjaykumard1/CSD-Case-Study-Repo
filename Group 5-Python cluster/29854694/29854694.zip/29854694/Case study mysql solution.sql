-- Create Memberships Table
CREATE TABLE Memberships (
    membership_id INT PRIMARY KEY AUTO_INCREMENT,
    member_name VARCHAR(255),
    member_contact VARCHAR(20),
    membership_type VARCHAR(50),
    membership_expiry DATE
);

-- Create Trainers Table
CREATE TABLE Trainers (
    trainer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255),
    specialty VARCHAR(50),
    contact_info VARCHAR(255),
    availability TEXT
);

-- Create Classes Table
CREATE TABLE Classes (
    class_id INT PRIMARY KEY AUTO_INCREMENT,
    class_name VARCHAR(100),
    trainer_id INT,
    schedule DATETIME,
    capacity INT,
    FOREIGN KEY (trainer_id) REFERENCES Trainers(trainer_id)
);

-- Create Attendance Table
CREATE TABLE Attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT,
    class_id INT,
    attendance_date DATE,
    FOREIGN KEY (member_id) REFERENCES Memberships(membership_id),
    FOREIGN KEY (class_id) REFERENCES Classes(class_id)
);

-- Query to find the total number of members whose memberships expire in the next month
SELECT COUNT(*) AS total_members_expiring_next_month
FROM Memberships
WHERE membership_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH);

-- Query to find the trainers who are available for a specific specialty
SELECT * 
FROM Trainers
WHERE specialty = 'Yoga';  -- Replace 'Yoga' with the specific specialty you are looking for

-- Query to find the classes that are fully booked
SELECT c.class_id, c.class_name, c.trainer_id, c.schedule, c.capacity
FROM Classes c
JOIN (
    SELECT class_id, COUNT(*) AS attendees
    FROM Attendance
    GROUP BY class_id
) a ON c.class_id = a.class_id
WHERE a.attendees >= c.capacity;

-- Query to find the members who have attended the most classes in the past month
SELECT m.member_name, COUNT(a.attendance_id) AS classes_attended
FROM Attendance a
JOIN Memberships m ON a.member_id = m.membership_id
WHERE a.attendance_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()
GROUP BY m.member_name
ORDER BY classes_attended DESC
LIMIT 1;

-- Query to find the schedule and details of classes conducted by a specific trainer
SELECT c.class_id, c.class_name, c.schedule, c.capacity
FROM Classes c
JOIN Trainers t ON c.trainer_id = t.trainer_id
WHERE t.name = 'Alice';  -- Replace 'Alice' with the specific trainer's name you are looking for
