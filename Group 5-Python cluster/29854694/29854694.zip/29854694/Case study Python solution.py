import datetime

# Exception Classes
class MemberNotFoundException(Exception):
    pass

class TrainerNotFoundException(Exception):
    pass

class ClassNotFoundException(Exception):
    pass

class AttendanceNotFoundException(Exception):
    pass

# Data Classes
class Membership:
    def __init__(self, membership_id, member_name, member_contact, membership_type, membership_expiry):
        self.membership_id = membership_id
        self.member_name = member_name
        self.member_contact = member_contact
        self.membership_type = membership_type
        self.membership_expiry = membership_expiry

    def __str__(self):
        return f"Membership(ID: {self.membership_id}, Name: {self.member_name}, Contact: {self.member_contact}, Type: {self.membership_type}, Expiry: {self.membership_expiry})"

class Trainer:
    def __init__(self, trainer_id, name, specialty, contact_info, availability):
        self.trainer_id = trainer_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.availability = availability

    def __str__(self):
        return f"Trainer(ID: {self.trainer_id}, Name: {self.name}, Specialty: {self.specialty}, Contact: {self.contact_info}, Availability: {self.availability})"

class FitnessClass:
    def __init__(self, class_id, class_name, trainer_id, schedule, capacity):
        self.class_id = class_id
        self.class_name = class_name
        self.trainer_id = trainer_id
        self.schedule = schedule
        self.capacity = capacity

    def __str__(self):
        return f"Class(ID: {self.class_id}, Name: {self.class_name}, Trainer ID: {self.trainer_id}, Schedule: {self.schedule}, Capacity: {self.capacity})"

class Attendance:
    def __init__(self, attendance_id, member_id, class_id, attendance_date):
        self.attendance_id = attendance_id
        self.member_id = member_id
        self.class_id = class_id
        self.attendance_date = attendance_date

    def __str__(self):
        return f"Attendance(ID: {self.attendance_id}, Member ID: {self.member_id}, Class ID: {self.class_id}, Date: {self.attendance_date})"

# Management System Class
class FitnessCenterManagementSystem:
    def __init__(self):
        self.memberships = {}
        self.trainers = {}
        self.classes = {}
        self.attendances = {}

    # Membership Management
    def add_membership(self, membership):
        self.memberships[membership.membership_id] = membership

    def update_membership(self, membership_id, **kwargs):
        if membership_id not in self.memberships:
            raise MemberNotFoundException("Membership not found.")
        for key, value in kwargs.items():
            setattr(self.memberships[membership_id], key, value)

    def delete_membership(self, membership_id):
        if membership_id not in self.memberships:
            raise MemberNotFoundException("Membership not found.")
        del self.memberships[membership_id]

    def view_memberships(self):
        for membership in self.memberships.values():
            print(membership)

    # Trainer Management
    def add_trainer(self, trainer):
        self.trainers[trainer.trainer_id] = trainer

    def update_trainer(self, trainer_id, **kwargs):
        if trainer_id not in self.trainers:
            raise TrainerNotFoundException("Trainer not found.")
        for key, value in kwargs.items():
            setattr(self.trainers[trainer_id], key, value)

    def delete_trainer(self, trainer_id):
        if trainer_id not in self.trainers:
            raise TrainerNotFoundException("Trainer not found.")
        del self.trainers[trainer_id]

    def view_trainers(self):
        for trainer in self.trainers.values():
            print(trainer)

    # Class Management
    def add_class(self, fitness_class):
        self.classes[fitness_class.class_id] = fitness_class

    def update_class(self, class_id, **kwargs):
        if class_id not in self.classes:
            raise ClassNotFoundException("Class not found.")
        for key, value in kwargs.items():
            setattr(self.classes[class_id], key, value)

    def delete_class(self, class_id):
        if class_id not in self.classes:
            raise ClassNotFoundException("Class not found.")
        del self.classes[class_id]

    def view_classes(self):
        for fitness_class in self.classes.values():
            print(fitness_class)

    # Attendance Management
    def record_attendance(self, attendance):
        self.attendances[attendance.attendance_id] = attendance

    def update_attendance(self, attendance_id, **kwargs):
        if attendance_id not in self.attendances:
            raise AttendanceNotFoundException("Attendance not found.")
        for key, value in kwargs.items():
            setattr(self.attendances[attendance_id], key, value)

    def delete_attendance(self, attendance_id):
        if attendance_id not in self.attendances:
            raise AttendanceNotFoundException("Attendance not found.")
        del self.attendances[attendance_id]

    def view_attendances(self):
        for attendance in self.attendances.values():
            print(attendance)

# Main Function to Demonstrate the System
def main():
    system = FitnessCenterManagementSystem()

    while True:
        print("\nFitness Center Management System")
        print("1. Add Membership")
        print("2. Update Membership")
        print("3. Delete Membership")
        print("4. View Memberships")
        print("5. Add Trainer")
        print("6. Update Trainer")
        print("7. Delete Trainer")
        print("8. View Trainers")
        print("9. Add Class")
        print("10. Update Class")
        print("11. Delete Class")
        print("12. View Classes")
        print("13. Record Attendance")
        print("14. Update Attendance")
        print("15. Delete Attendance")
        print("16. View Attendances")
        print("17. Exit")
        
        choice = input("Enter your choice: ")

        if choice == "1":
            membership_id = int(input("Enter Membership ID: "))
            member_name = input("Enter Member Name: ")
            member_contact = input("Enter Member Contact: ")
            membership_type = input("Enter Membership Type: ")
            membership_expiry = input("Enter Membership Expiry (YYYY-MM-DD): ")
            membership_expiry = datetime.datetime.strptime(membership_expiry, "%Y-%m-%d").date()
            membership = Membership(membership_id, member_name, member_contact, membership_type, membership_expiry)
            system.add_membership(membership)
        elif choice == "2":
            membership_id = int(input("Enter Membership ID: "))
            updates = {}
            updates['member_name'] = input("Enter new Member Name (leave blank to keep current): ") or None
            updates['member_contact'] = input("Enter new Member Contact (leave blank to keep current): ") or None
            updates['membership_type'] = input("Enter new Membership Type (leave blank to keep current): ") or None
            updates['membership_expiry'] = input("Enter new Membership Expiry (YYYY-MM-DD, leave blank to keep current): ") or None
            updates = {k: v for k, v in updates.items() if v is not None}
            if 'membership_expiry' in updates:
                updates['membership_expiry'] = datetime.datetime.strptime(updates['membership_expiry'], "%Y-%m-%d").date()
            system.update_membership(membership_id, **updates)
        elif choice == "3":
            membership_id = int(input("Enter Membership ID: "))
            system.delete_membership(membership_id)
        elif choice == "4":
            system.view_memberships()
        elif choice == "5":
            trainer_id = int(input("Enter Trainer ID: "))
            name = input("Enter Trainer Name: ")
            specialty = input("Enter Specialty: ")
            contact_info = input("Enter Contact Info: ")
            availability = input("Enter Availability: ")
            trainer = Trainer(trainer_id, name, specialty, contact_info, availability)
            system.add_trainer(trainer)
        elif choice == "6":
            trainer_id = int(input("Enter Trainer ID: "))
            updates = {}
            updates['name'] = input("Enter new Name (leave blank to keep current): ") or None
            updates['specialty'] = input("Enter new Specialty (leave blank to keep current): ") or None
            updates['contact_info'] = input("Enter new Contact Info (leave blank to keep current): ") or None
            updates['availability'] = input("Enter new Availability (leave blank to keep current): ") or None
            updates = {k: v for k, v in updates.items() if v is not None}
            system.update_trainer(trainer_id, **updates)
        elif choice == "7":
            trainer_id = int(input("Enter Trainer ID: "))
            system.delete_trainer(trainer_id)
        elif choice == "8":
            system.view_trainers()
        elif choice == "9":
            class_id = int(input("Enter Class ID: "))
            class_name = input("Enter Class Name: ")
            trainer_id = int(input("Enter Trainer ID: "))
            schedule = input("Enter Schedule: ")
            capacity = int(input("Enter Capacity: "))
            fitness_class = FitnessClass(class_id, class_name, trainer_id, schedule, capacity)
            system.add_class(fitness_class)
        elif choice == "10":
            class_id = int(input("Enter Class ID: "))
            updates = {}
            updates['class_name'] = input("Enter new Class Name (leave blank to keep current): ") or None
            updates['trainer_id'] = input("Enter new Trainer ID (leave blank to keep current): ") or None
            updates['schedule'] = input("Enter new Schedule (leave blank to keep current): ") or None
            updates['capacity'] = input("Enter new Capacity (leave blank to keep current): ") or None
            updates = {k: v for k, v in updates.items() if v is not None}
            system.update_class(class_id, **updates)
        elif choice == "11":
            class_id = int(input("Enter Class ID: "))
            system.delete_class(class_id)
        elif choice == "12":
            system.view_classes()
        elif choice == "13":
            attendance_id = int(input("Enter Attendance ID: "))
            member_id = int(input("Enter Member ID: "))
            class_id = int(input("Enter Class ID: "))
            attendance_date = input("Enter Attendance Date (YYYY-MM-DD): ")
            attendance_date = datetime.datetime.strptime(attendance_date, "%Y-%m-%d").date()
            attendance = Attendance(attendance_id, member_id, class_id, attendance_date)
            system.record_attendance(attendance)
        elif choice == "14":
            attendance_id = int(input("Enter Attendance ID: "))
            updates = {}
            updates['member_id'] = input("Enter new Member ID (leave blank to keep current): ") or None
            updates['class_id'] = input("Enter new Class ID (leave blank to keep current): ") or None
            updates['attendance_date'] = input("Enter new Attendance Date (YYYY-MM-DD, leave blank to keep current): ") or None
            updates = {k: v for k, v in updates.items() if v is not None}
            if 'attendance_date' in updates:
                updates['attendance_date'] = datetime.datetime.strptime(updates['attendance_date'], "%Y-%m-%d").date()
            system.update_attendance(attendance_id, **updates)
        elif choice == "15":
            attendance_id = int(input("Enter Attendance ID: "))
            system.delete_attendance(attendance_id)
        elif choice == "16":
            system.view_attendances()
        elif choice == "17":
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
