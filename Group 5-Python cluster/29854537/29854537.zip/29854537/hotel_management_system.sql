-- Creating Rooms table
CREATE TABLE Rooms (
    room_id INT PRIMARY KEY, 
    room_type VARCHAR(50),
    price_per_night DECIMAL(10, 2), 
    is_available BOOLEAN 
);

-- Creating Guests table
CREATE TABLE Guests (
    guest_id INT PRIMARY KEY, 
    name VARCHAR(100), 
    contact_number VARCHAR(15), 
    address VARCHAR(255) 
);

-- Creating Bookings table
CREATE TABLE Bookings (
    booking_id INT PRIMARY KEY, 
    guest_id INT, 
    room_id INT,  
    check_in_date DATE, 
    check_out_date DATE, 
    FOREIGN KEY (guest_id) REFERENCES Guests(guest_id),
    FOREIGN KEY (room_id) REFERENCES Rooms(room_id)
);

-- Inserting sample data into Rooms table
INSERT INTO Rooms (room_id, room_type, price_per_night, is_available)
VALUES (301, 'Double', 200.00, TRUE),
    (302, 'Single', 150.00, TRUE),
    (303, 'Suite', 300.00, TRUE),
    (304, 'Single', 150.00, FALSE),
    (305, 'Double', 200.00, FALSE);

-- Inserting sample data into Guests table
INSERT INTO Guests (guest_id, name, contact_number, address)
VALUES (1, 'Tommy', '1234567890', 'Siruseri'),
    (2, 'Jhon', '0987654321', 'Sholiganallur'),
    (3, 'Jerry', '1234123412', 'Kancheepuram'),
    (4, 'Bob', '9876987698', 'Tambaram');

-- Inserting sample data into Bookings table
INSERT INTO Bookings (booking_id, guest_id, room_id, check_in_date, check_out_date)
VALUES (1, 1, 301, '2024-07-01', '2024-07-05'), 
    (2, 1, 302, '2024-07-06', '2024-07-10'), 
    (3, 2, 303, '2024-06-20', '2024-07-01'),
    (4, 2, 304, '2024-07-02', '2024-07-07'), 
    (5, 3, 305, '2024-07-01', '2024-07-10'), 
    (6, 4, 301, '2024-07-08', '2024-07-15'), 
    (7, 3, 302, '2024-07-10', '2024-07-15'); 

-- Query to find the total revenue generated from all room bookings
SELECT SUM(DATEDIFF(check_out_date, check_in_date) * price_per_night) AS total_revenue
FROM Bookings AS b
JOIN Rooms AS r ON b.room_id = r.room_id;

-- Query to find the names and contact numbers of guests who have booked more than one room
SELECT g.name, g.contact_number
FROM Guests AS g
JOIN Bookings AS b ON g.guest_id = b.guest_id
GROUP BY g.guest_id, g.name, g.contact_number
HAVING COUNT(DISTINCT b.room_id) > 1;

-- Query to find the room types that are currently available
SELECT DISTINCT room_type
FROM Rooms
WHERE is_available = TRUE;

-- Query to find the guests who have stayed for more than 5 nights
SELECT g.name, g.contact_number
FROM Guests AS g
JOIN Bookings AS b ON g.guest_id = b.guest_id
WHERE DATEDIFF(check_out_date, check_in_date) > 5;

-- Query to find the details of bookings made in the last month
SELECT *
FROM Bookings
WHERE check_in_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH);
