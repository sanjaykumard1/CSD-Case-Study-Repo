class Room:
    def __init__(self, room_id, room_type, price_per_night, is_available=True):
        """Initialize the Room object with room_id, room_type, price_per_night, and availability status"""
        self.room_id = room_id
        self.room_type = room_type
        self.price_per_night = price_per_night
        self.is_available = is_available

    def __str__(self):
        """Return string representation of the Room object"""
        return f'Room ID: {self.room_id}, Type: {self.room_type}, Price: {self.price_per_night}, Available: {self.is_available}'


class RoomManager:
    def __init__(self):
        """Initialize the RoomManager with an empty dictionary to store rooms"""
        self.rooms = {}

    def add_room(self, room):
        """Adding a new room to the system"""
        if room.room_id in self.rooms:
            raise Exception("Room ID already exists")
        self.rooms[room.room_id] = room

    def update_room(self, room_id, room_type=None, price_per_night=None, is_available=None):
        """Updating the details of an existing room"""
        if room_id not in self.rooms:
            raise Exception("Room ID does not exist")
        room = self.rooms[room_id]
        if room_type is not None:
            room.room_type = room_type
        if price_per_night is not None:
            room.price_per_night = price_per_night
        if is_available is not None:
            room.is_available = is_available

    def delete_room(self, room_id):
        """Deleting a room from the system"""
        if room_id not in self.rooms:
            raise Exception("Room ID does not exist")
        del self.rooms[room_id]

    def list_rooms(self):
        """List all rooms in the system"""
        for room in self.rooms.values():
            print(room)


class Guest:
    def __init__(self, guest_id, name, contact_number, address):
        """Initialize the Guest object with guest_id, name, contact_number, and address"""
        self.guest_id = guest_id
        self.name = name
        self.contact_number = contact_number
        self.address = address

    def __str__(self):
        """Return the string representation of Guest object"""
        return f'Guest ID: {self.guest_id}, Name: {self.name}, Contact: {self.contact_number}, Address: {self.address}'


class GuestManager:
    def __init__(self):
        """Initialize the GuestManager with an empty dictionary to store guests"""
        self.guests = {}

    def add_guest(self, guest):
        """Adding a new guest to the system"""
        if guest.guest_id in self.guests:
            raise Exception("Guest ID already exists")
        self.guests[guest.guest_id] = guest

    def update_guest(self, guest_id, name=None, contact_number=None, address=None):
        """Updating the details of an existing guest"""
        if guest_id not in self.guests:
            raise Exception("Guest ID does not exist")
        guest = self.guests[guest_id]
        if name is not None:
            guest.name = name
        if contact_number is not None:
            guest.contact_number = contact_number
        if address is not None:
            guest.address = address

    def delete_guest(self, guest_id):
        """Deleting a guest from the system"""
        if guest_id not in self.guests:
            raise Exception("Guest ID does not exist")
        del self.guests[guest_id]

    def list_guests(self):
        """List all guests in the system"""
        for guest in self.guests.values():
            print(guest)


class Booking:
    def __init__(self, booking_id, guest_id, room_id, check_in_date, check_out_date):
        """Initialize the Booking object with booking_id, guest_id, room_id, check_in_date, and check_out_date"""
        self.booking_id = booking_id
        self.guest_id = guest_id
        self.room_id = room_id
        self.check_in_date = check_in_date
        self.check_out_date = check_out_date

    def __str__(self):
        """Return the string representation of Booking object"""
        return (f'Booking ID: {self.booking_id}, Guest ID: {self.guest_id}, Room ID: {self.room_id}, '
                f'Check-in: {self.check_in_date}, Check-out: {self.check_out_date}')


class BookingManager:
    def __init__(self, room_manager, guest_manager):
        """Initialize the BookingManager with an empty dictionary to store bookings"""
        self.bookings = {}
        self.room_manager = room_manager
        self.guest_manager = guest_manager

    def add_booking(self, booking):
        """Adding a new booking to the system"""
        if booking.booking_id in self.bookings:
            raise Exception("Booking ID already exists")
        if booking.room_id not in self.room_manager.rooms:
            raise Exception("Room ID does not exist")
        if not self.room_manager.rooms[booking.room_id].is_available:
            raise Exception("Room is not available")
        if booking.guest_id not in self.guest_manager.guests:
            raise Exception("Guest ID does not exist")
        self.bookings[booking.booking_id] = booking
        self.room_manager.update_room(booking.room_id, is_available=False)

    def update_booking(self, booking_id, check_in_date=None, check_out_date=None):
        """Updating the details of an existing booking"""
        if booking_id not in self.bookings:
            raise Exception("Booking ID does not exist")
        booking = self.bookings[booking_id]
        if check_in_date is not None:
            booking.check_in_date = check_in_date
        if check_out_date is not None:
            booking.check_out_date = check_out_date

    def cancel_booking(self, booking_id):
        """Canceling an existing booking"""
        if booking_id not in self.bookings:
            raise Exception("Booking ID does not exist")
        booking = self.bookings[booking_id]
        self.room_manager.update_room(booking.room_id, is_available=True)
        del self.bookings[booking_id]

    def list_bookings(self):
        """List all bookings in the system"""
        for booking in self.bookings.values():
            print(booking)


def main():
    """Main function to demonstrate the functionality of the Hotel Management System"""
    room_manager = RoomManager()
    guest_manager = GuestManager()
    booking_manager = BookingManager(room_manager, guest_manager)

    room_manager.add_room(Room(301, "Double", 200.0))
    room_manager.add_room(Room(302, "Single", 150.0))
    guest_manager.add_guest(Guest(1, "Tommy", "6789054321", "Siruseri"))
    guest_manager.add_guest(Guest(2, "Jhon", "0987654321", "Sholingnallur"))

    booking_manager.add_booking(Booking(1, 1, 301, "2024-07-15", "2024-07-20"))
    
    print("Rooms:")
    room_manager.list_rooms()

    print("\nGuests:")
    guest_manager.list_guests()

    print("\nBookings:")
    booking_manager.list_bookings()


if __name__ == "__main__":
    main()
