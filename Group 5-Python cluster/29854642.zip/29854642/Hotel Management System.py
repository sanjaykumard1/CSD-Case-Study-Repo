class Room:
    def __init__(self, room_id, room_type, price_per_night, is_available=True):
        self.room_id = room_id
        self.room_type = room_type
        self.price_per_night = price_per_night
        self.is_available = is_available

    def update_room(self, room_type=None, price_per_night=None, is_available=None):
        if room_type is not None:
            self.room_type = room_type
        if price_per_night is not None:
            self.price_per_night = price_per_night
        if is_available is not None:
            self.is_available = is_available

    def __str__(self):
        return f"Room ID: {self.room_id}, Type: {self.room_type}, Price: {self.price_per_night}, Available: {self.is_available}"

    def __repr__(self):
        return self.__str__()

class Guest:
    def __init__(self, guest_id, name, contact_number, address):
        self.guest_id = guest_id
        self.name = name
        self.contact_number = contact_number
        self.address = address

    def update_guest(self, name=None, contact_number=None, address=None):
        if name is not None:
            self.name = name
        if contact_number is not None:
            self.contact_number = contact_number
        if address is not None:
            self.address = address

    def __str__(self):
        return f"Guest ID: {self.guest_id}, Name: {self.name}, Contact: {self.contact_number}, Address: {self.address}"

    def __repr__(self):
        return self.__str__()

class Booking:
    def __init__(self, booking_id, guest_id, room_id, check_in_date, check_out_date):
        self.booking_id = booking_id
        self.guest_id = guest_id
        self.room_id = room_id
        self.check_in_date = check_in_date
        self.check_out_date = check_out_date

    def update_booking(self, guest_id=None, room_id=None, check_in_date=None, check_out_date=None):
        if guest_id is not None:
            self.guest_id = guest_id
        if room_id is not None:
            self.room_id = room_id
        if check_in_date is not None:
            self.check_in_date = check_in_date
        if check_out_date is not None:
            self.check_out_date = check_out_date

    def __str__(self):
        return f"Booking ID: {self.booking_id}, Guest ID: {self.guest_id}, Room ID: {self.room_id}, Check-in: {self.check_in_date}, Check-out: {self.check_out_date}"

    def __repr__(self):
        return self.__str__()

class HotelManagementSystem:
    def __init__(self):
        self.rooms = {}
        self.guests = {}
        self.bookings = {}

    def add_room(self, room):
        if room.room_id in self.rooms:
            raise ValueError("Room ID already exists.")
        self.rooms[room.room_id] = room

    def update_room(self, room_id, **kwargs):
        if room_id not in self.rooms:
            raise ValueError("Room ID does not exist.")
        self.rooms[room_id].update_room(**kwargs)

    def delete_room(self, room_id):
        if room_id not in self.rooms:
            raise ValueError("Room ID does not exist.")
        del self.rooms[room_id]

    def add_guest(self, guest):
        if guest.guest_id in self.guests:
            raise ValueError("Guest ID already exists.")
        self.guests[guest.guest_id] = guest

    def update_guest(self, guest_id, **kwargs):
        if guest_id not in self.guests:
            raise ValueError("Guest ID does not exist.")
        self.guests[guest_id].update_guest(**kwargs)

    def delete_guest(self, guest_id):
        if guest_id not in self.guests:
            raise ValueError("Guest ID does not exist.")
        del self.guests[guest_id]

    def add_booking(self, booking):
        if booking.booking_id in self.bookings:
            raise ValueError("Booking ID already exists.")
        if booking.room_id not in self.rooms:
            raise ValueError("Room ID does not exist.")
        if booking.guest_id not in self.guests:
            raise ValueError("Guest ID does not exist.")
        if not self.rooms[booking.room_id].is_available:
            raise ValueError("Room is not available.")
        self.bookings[booking.booking_id] = booking
        self.rooms[booking.room_id].is_available = False

    def update_booking(self, booking_id, **kwargs):
        if booking_id not in self.bookings:
            raise ValueError("Booking ID does not exist.")
        self.bookings[booking_id].update_booking(**kwargs)

    def delete_booking(self, booking_id):
        if booking_id not in self.bookings:
            raise ValueError("Booking ID does not exist.")
        room_id = self.bookings[booking_id].room_id
        del self.bookings[booking_id]
        self.rooms[room_id].is_available = True

    def __str__(self):
        return f"Rooms: {list(self.rooms.values())}\nGuests: {list(self.guests.values())}\nBookings: {list(self.bookings.values())}"

if __name__ == "__main__":
    system = HotelManagementSystem()

    while True:
        print("\nHotel Management System")
        print("1. Add Room")
        print("2. Update Room")
        print("3. Delete Room")
        print("4. Add Guest")
        print("5. Update Guest")
        print("6. Delete Guest")
        print("7. Add Booking")
        print("8. Update Booking")
        print("9. Cancel Booking")
        print("10. View All")
        print("11. Exit")

        choice = int(input("Enter choice: "))

        if choice == 1:
            room_id = input("Enter room ID: ")
            room_type = input("Enter room type: ")
            price_per_night = float(input("Enter price per night: "))
            room = Room(room_id, room_type, price_per_night)
            system.add_room(room)
        elif choice == 2:
            room_id = input("Enter room ID: ")
            room_type = input("Enter room type: ")
            price_per_night = float(input("Enter price per night: "))
            is_available = input("Is room available? (yes/no): ").lower() == "yes"
            system.update_room(room_id, room_type=room_type, price_per_night=price_per_night, is_available=is_available)
        elif choice == 3:
            room_id = input("Enter room ID: ")
            system.delete_room(room_id)
        elif choice == 4:
            guest_id = input("Enter guest ID: ")
            name = input("Enter name: ")
            contact_number = input("Enter contact number: ")
            address = input("Enter address: ")
            guest = Guest(guest_id, name, contact_number, address)
            system.add_guest(guest)
        elif choice == 5:
            guest_id = input("Enter guest ID: ")
            name = input("Enter name: ")
            contact_number = input("Enter contact number: ")
            address = input("Enter address: ")
            system.update_guest(guest_id, name=name, contact_number=contact_number, address=address)
        elif choice == 6:
            guest_id = input("Enter guest ID: ")
            system.delete_guest(guest_id)
        elif choice == 7:
            booking_id = input("Enter booking ID: ")
            guest_id = input("Enter guest ID: ")
            room_id = input("Enter room ID: ")
            check_in_date = input("Enter check-in date: ")
            check_out_date = input("Enter check-out date: ")
            booking = Booking(booking_id, guest_id, room_id, check_in_date, check_out_date)
            system.add_booking(booking)
        elif choice == 8:
            booking_id = input("Enter booking ID: ")
            guest_id = input("Enter guest ID: ")
            room_id = input("Enter room ID: ")
            check_in_date = input("Enter check-in date: ")
            check_out_date = input("Enter check-out date: ")
            system.update_booking(booking_id, guest_id=guest_id, room_id=room_id, check_in_date=check_in_date, check_out_date=check_out_date)
        elif choice == 9:
            booking_id = input("Enter booking ID: ")
            system.delete_booking(booking_id)
        elif choice == 10:
            print(system)
        elif choice == 11:
            break
        else:
            print("Invalid choice. Please try again.")
