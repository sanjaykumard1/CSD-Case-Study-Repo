SELECT SUM(price_per_night * DATEDIFF(check_out_date, check_in_date)) AS total_revenue
FROM Bookings
JOIN Rooms ON Bookings.room_id = Rooms.room_id;

SELECT Guests.name, Guests.contact_number
FROM Guests
JOIN Bookings ON Guests.guest_id = Bookings.guest_id
GROUP BY Guests.guest_id
HAVING COUNT(DISTINCT Bookings.room_id) > 1;

SELECT DISTINCT room_type
FROM Rooms
WHERE is_available = TRUE;

SELECT DISTINCT Guests.*
FROM Guests
JOIN Bookings ON Guests.guest_id = Bookings.guest_id
WHERE DATEDIFF(Bookings.check_out_date, Bookings.check_in_date) > 5;

SELECT *
FROM Bookings
WHERE check_in_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH);
