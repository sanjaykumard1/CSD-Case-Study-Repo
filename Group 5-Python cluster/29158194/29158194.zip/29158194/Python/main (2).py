class Employee:
    def __init__(self, employee_id, name, department, designation, performance_score):
        self.employee_id = employee_id
        self.name = name
        self.department = department
        self.designation = designation
        self.performance_score = performance_score

class EmployeePerformanceTrackingSystem:
    def __init__(self):
        self.employees = {}

    def add_employee(self, employee):
        if employee.employee_id in self.employees:
            raise ValueError(f"Employee with ID {employee.employee_id} already exists.")
        self.employees[employee.employee_id] = employee

    def update_employee(self, employee_id, name=None, department=None, designation=None):
        if employee_id not in self.employees:
            raise KeyError(f"Employee with ID {employee_id} not found.")
        if name:
            self.employees[employee_id].name = name
        if department:
            self.employees[employee_id].department = department
        if designation:
            self.employees[employee_id].designation = designation

    def delete_employee(self, employee_id):
        if employee_id not in self.employees:
            raise KeyError(f"Employee with ID {employee_id} not found.")
        del self.employees[employee_id]

    def update_performance_score(self, employee_id, score):
        if employee_id not in self.employees:
            raise KeyError(f"Employee with ID {employee_id} not found.")
        self.employees[employee_id].performance_score=score

    def generate_performance_review(self, employee_id):
        if employee_id not in self.employees:
            raise KeyError(f"Employee with ID {employee_id} not found.")
        employee = self.employees[employee_id]
        score = employee.performance_score
        if score > 85:
            review = "Excellent performance. Keep up the great work!"
        elif score > 70:
            review = "Good performance. There is room for improvement."
        elif score > 50:
            review = "Average performance. Needs improvement."
        else:
            review = "Poor performance. Significant improvement required."
        return review

    def top_performers(self):
        return [employee for employee in self.employees.values() if employee.performance_score > 85]

    def display_employee(self, employee_id):
        if employee_id not in self.employees:
            raise KeyError(f"Employee with ID {employee_id} not found.")
        employee = self.employees[employee_id]
        print(f"ID: {employee.employee_id}, Name: {employee.name}, "
              f"Department: {employee.department}, Designation: {employee.designation}, "
              f"Performance Score: {employee.performance_score}")

    def display_all_employees(self):
        if not self.employees:
            print("No employees found.")
        for employee in self.employees.values():
            self.display_employee(employee.employee_id)


def main():
    system = EmployeePerformanceTrackingSystem()

    while True:
        print("\nEmployee Performance Tracking System")
        print("1. Add Employee")
        print("2. Update Employee")
        print("3. Delete Employee")
        print("4. Update Performance Score")
        print("5. Show Top Performers")
        print("6. Display Employee")
        print("7. Display All Employees")
        print("8. Generate Performance Review")
        print("9. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                employee_id = int(input("Enter employee ID: "))
                name = input("Enter name: ")
                department = input("Enter department: ")
                designation = input("Enter designation: ")
                performance_score=int(input("Enter the performance score: "))
                employee = Employee(employee_id, name, department, designation, performance_score)
                system.add_employee(employee)
                print("Employee added successfully.")
            elif choice == '2':
                employee_id = int(input("Enter employee ID to update: "))
                name = input("Enter new name (leave blank to skip): ")
                department = input("Enter new department (leave blank to skip): ")
                designation = input("Enter new designation (leave blank to skip): ")
                system.update_employee(employee_id, name, department, designation)
                print("Employee updated successfully.")
            elif choice == '3':
                employee_id = input("Enter employee ID to delete: ")
                system.delete_employee(employee_id)
                print("Employee deleted successfully.")
            elif choice == '4':
                employee_id = int(input("Enter employee ID to update performance score: "))
                score = int(input("Enter new performance score: "))
                system.update_performance_score(employee_id, score)
                print("Performance score updated successfully.")
            elif choice == '5':
                top_performers = system.top_performers()
                if not top_performers:
                    print("No top performers found.")
                for employee in top_performers:
                    system.display_employee(employee.employee_id)
            elif choice == '6':
                employee_id = int(input("Enter employee ID to display: "))
                system.display_employee(employee_id)
            elif choice == '7':
                system.display_all_employees()
            elif choice == '8':
                employee_id = int(input("Enter employee ID to generate performance review: "))
                review = system.generate_performance_review(employee_id)
                print(f"Performance Review for Employee {employee_id}: {review}")
            elif choice == '9':
                print("Exiting the system.")
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
