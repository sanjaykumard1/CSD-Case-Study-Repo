CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(100),
    department VARCHAR(50),
    designation VARCHAR(50),
    performance_score INT
);

CREATE TABLE PerformanceReviews (
    review_id INT PRIMARY KEY,
    employee_id INT,
    review_date DATE,
    review_comments TEXT,
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);


INSERT INTO Employees (employee_id, name, department, designation, performance_score) VALUES
(1, 'John Doe', 'Sales', 'Manager', 90),
(2, 'Jane Smith', 'Sales', 'Executive', 90),
(3, 'Emily Johnson', 'Sales', 'Developer', 90),
(4, 'Michael Brown', 'Sales', 'Analyst', 90),
(5, 'Linda Davis', 'Sales', 'Executive', 90),
(6, 'William Wilson', 'IT', 'Developer', 55),
(7, 'Elizabeth Martinez', 'Marketing', 'Manager', 95),
(8, 'James Anderson', 'Finance', 'Executive', 85),
(9, 'Patricia Thomas', 'HR', 'Manager', 80),
(10, 'Robert Jackson', 'Sales', 'Developer', 92);

INSERT INTO PerformanceReviews (review_id, employee_id, review_date, review_comments) VALUES
(1, 1, '2023-01-10', 'Excellent performance'),
(2, 2, '2023-02-15', 'Good performance'),
(3, 1, '2023-03-20', 'Consistent top performer'),
(4, 3, '2023-04-10', 'Improvement noted'),
(5, 1, '2023-05-05', 'Outstanding achievements'),
(6, 4, '2023-06-12', 'Good technical skills'),
(7, 5, '2023-07-18', 'Excellent management skills');

SELECT department, AVG(performance_score) AS average_score
FROM Employees
GROUP BY department;

SELECT name, performance_score, department
FROM Employees;

SELECT E.name
FROM Employees E
LEFT JOIN PerformanceReviews PR ON E.employee_id = PR.employee_id
WHERE PR.review_id = NULL;

SELECT department
FROM Employees
WHERE performance_score > 85
GROUP BY department
HAVING COUNT(employee_id) > 5;

SELECT e.name, e.designation
FROM Employees e
JOIN PerformanceReviews p ON e.employee_id = p.employee_id
GROUP BY e.employee_id
HAVING COUNT(p.review_id) > 3;





