from database import connect_to_db

class Appointment:
    def __init__(self, appointment_id, patient_id, doctor_id, appointment_date, reason):
        self.appointment_id = appointment_id
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.appointment_date = appointment_date
        self.reason = reason

    def schedule_appointment(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "INSERT INTO Appointments (appointment_id, patient_id, doctor_id, appointment_date, reason) VALUES (%s, %s, %s, %s, %s)"
        values = (self.appointment_id, self.patient_id, self.doctor_id, self.appointment_date, self.reason)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Appointment scheduled successfully!")

    def update_appointment(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "UPDATE Appointments SET patient_id = %s, doctor_id = %s, appointment_date = %s, reason = %s WHERE appointment_id = %s"
        values = (self.patient_id, self.doctor_id, self.appointment_date, self.reason, self.appointment_id)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Appointment updated successfully!")

    def cancel_appointment(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "DELETE FROM Appointments WHERE appointment_id = %s"
        values = (self.appointment_id,)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Appointment canceled successfully!")
