# Health Clinic Management System

This project is a simple console-based Health Clinic Management System implemented in Python. It allows you to manage patients, doctors, and appointments using a MySQL database.

## Features

- **Manage Patients:** Add, update, delete patient records.
- **Manage Doctors:** Add, update, delete doctor records.
- **Manage Appointments:** Schedule, update, cancel appointments.
- **SQL Queries:**
  - Find the number of appointments scheduled for each doctor.
  - Find the patients who have appointments in the next week.
  - Find the doctors who specialize in a specific field.
  - Find the available dates for a particular doctor.
  - Find the appointment history of a specific patient.

## Project Structure

health_clinic_management/
│
├── main.py
├── patient.py
├── doctor.py
├── appointment.py
├── database.py
└── requirements.txt


- `appointment.py`: Contains the `Appointment` class with methods for scheduling, updating, and canceling appointments.
- `database.py`: Contains the `connect_to_db` function to connect to the MySQL database.
- `doctor.py`: Contains the `Doctor` class with methods for adding, updating, and deleting doctor records.
- `main.py`: The main script to run the console application.
- `patient.py`: Contains the `Patient` class with methods for adding, updating, and deleting patient records.
- `README.md`: This file, providing an overview of the project.
- `requirements.txt`: Lists the required Python packages.


## Initialize the Database

```sql
CREATE DATABASE clinic_db;
```
```bash
python initialize_db.py
```