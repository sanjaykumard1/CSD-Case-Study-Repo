from database import connect_to_db

class Patient:
    def __init__(self, patient_id, name, date_of_birth, gender, contact_info):
        self.patient_id = patient_id
        self.name = name
        self.date_of_birth = date_of_birth
        self.gender = gender
        self.contact_info = contact_info

    def add_patient(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "INSERT INTO Patients (patient_id, name, date_of_birth, gender, contact_info) VALUES (%s, %s, %s, %s, %s)"
        values = (self.patient_id, self.name, self.date_of_birth, self.gender, self.contact_info)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Patient added successfully!")

    def update_patient(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "UPDATE Patients SET name = %s, date_of_birth = %s, gender = %s, contact_info = %s WHERE patient_id = %s"
        values = (self.name, self.date_of_birth, self.gender, self.contact_info, self.patient_id)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Patient updated successfully!")

    def delete_patient(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "DELETE FROM Patients WHERE patient_id = %s"
        values = (self.patient_id,)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Patient deleted successfully!")
