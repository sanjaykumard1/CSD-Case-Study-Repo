from patient import Patient
from doctor import Doctor
from appointment import Appointment

def main():
    while True:
        print("Health Clinic Management System")
        print("1. Manage Patients")
        print("2. Manage Doctors")
        print("3. Manage Appointments")
        print("4. Exit")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            manage_patients()
        elif choice == '2':
            manage_doctors()
        elif choice == '3':
            manage_appointments()
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_patients():
    while True:
        print("\nPatient Management")
        print("1. Add Patient")
        print("2. Update Patient")
        print("3. Delete Patient")
        print("4. Back")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            patient_id = input("Enter patient ID: ")
            name = input("Enter name: ")
            date_of_birth = input("Enter date of birth (YYYY-MM-DD): ")
            gender = input("Enter gender: ")
            contact_info = input("Enter contact info: ")
            patient = Patient(patient_id, name, date_of_birth, gender, contact_info)
            patient.add_patient()
        elif choice == '2':
            patient_id = input("Enter patient ID to update: ")
            name = input("Enter new name: ")
            date_of_birth = input("Enter new date of birth (YYYY-MM-DD): ")
            gender = input("Enter new gender: ")
            contact_info = input("Enter new contact info: ")
            patient = Patient(patient_id, name, date_of_birth, gender, contact_info)
            patient.update_patient()
        elif choice == '3':
            patient_id = input("Enter patient ID to delete: ")
            patient = Patient(patient_id, None, None, None, None)
            patient.delete_patient()
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_doctors():
    while True:
        print("\nDoctor Management")
        print("1. Add Doctor")
        print("2. Update Doctor")
        print("3. Delete Doctor")
        print("4. Back")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            doctor_id = input("Enter doctor ID: ")
            name = input("Enter name: ")
            specialty = input("Enter specialty: ")
            contact_info = input("Enter contact info: ")
            available_dates = input("Enter available dates (comma separated): ")
            doctor = Doctor(doctor_id, name, specialty, contact_info, available_dates)
            doctor.add_doctor()
        elif choice == '2':
            doctor_id = input("Enter doctor ID to update: ")
            name = input("Enter new name: ")
            specialty = input("Enter new specialty: ")
            contact_info = input("Enter new contact info: ")
            available_dates = input("Enter new available dates (comma separated): ")
            doctor = Doctor(doctor_id, name, specialty, contact_info, available_dates)
            doctor.update_doctor()
        elif choice == '3':
            doctor_id = input("Enter doctor ID to delete: ")
            doctor = Doctor(doctor_id, None, None, None, None)
            doctor.delete_doctor()
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_appointments():
    while True:
        print("\nAppointment Management")
        print("1. Schedule Appointment")
        print("2. Update Appointment")
        print("3. Cancel Appointment")
        print("4. Back")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            appointment_id = input("Enter appointment ID: ")
            patient_id = input("Enter patient ID: ")
            doctor_id = input("Enter doctor ID: ")
            appointment_date = input("Enter appointment date (YYYY-MM-DD): ")
            reason = input("Enter reason: ")
            appointment = Appointment(appointment_id, patient_id, doctor_id, appointment_date, reason)
            appointment.schedule_appointment()
        elif choice == '2':
            appointment_id = input("Enter appointment ID to update: ")
            patient_id = input("Enter new patient ID: ")
            doctor_id = input("Enter new doctor ID: ")
            appointment_date = input("Enter new appointment date (YYYY-MM-DD): ")
            reason = input("Enter new reason: ")
            appointment = Appointment(appointment_id, patient_id, doctor_id, appointment_date, reason)
            appointment.update_appointment()
        elif choice == '3':
            appointment_id = input("Enter appointment ID to cancel: ")
            appointment = Appointment(appointment_id, None, None, None, None)
            appointment.cancel_appointment()
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
