import mysql.connector

def connect_to_db():
    connection = mysql.connector.connect(
        host='localhost',
        user='user',
        password='password',
        database='clinic_db'
    )
    return connection