SELECT doctor_id, COUNT(*) AS number_of_appointments
FROM Appointments
GROUP BY doctor_id;

SELECT Patients.patient_id, Patients.name, Appointments.appointment_date
FROM Patients
JOIN Appointments ON Patients.patient_id = Appointments.patient_id
WHERE Appointments.appointment_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY);

SELECT doctor_id, name, contact_info
FROM Doctors
WHERE specialty = 'oncologist';

SELECT available_dates
FROM Doctors
WHERE doctor_id = 'particular_doctor_id';

SELECT Appointments.appointment_id, Appointments.doctor_id, Appointments.appointment_date, Appointments.reason
FROM Appointments
WHERE patient_id = 'specific_patient_id'
ORDER BY appointment_date DESC;

