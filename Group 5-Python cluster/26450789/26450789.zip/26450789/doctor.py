from database import connect_to_db

class Doctor:
    def __init__(self, doctor_id, name, specialty, contact_info, available_dates):
        self.doctor_id = doctor_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.available_dates = available_dates

    def add_doctor(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "INSERT INTO Doctors (doctor_id, name, specialty, contact_info, available_dates) VALUES (%s, %s, %s, %s, %s)"
        values = (self.doctor_id, self.name, self.specialty, self.contact_info, self.available_dates)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Doctor added successfully!")

    def update_doctor(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "UPDATE Doctors SET name = %s, specialty = %s, contact_info = %s, available_dates = %s WHERE doctor_id = %s"
        values = (self.name, self.specialty, self.contact_info, self.available_dates, self.doctor_id)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Doctor updated successfully!")

    def delete_doctor(self):
        conn = connect_to_db()
        cursor = conn.cursor()
        sql = "DELETE FROM Doctors WHERE doctor_id = %s"
        values = (self.doctor_id,)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        conn.close()
        print("Doctor deleted successfully!")
