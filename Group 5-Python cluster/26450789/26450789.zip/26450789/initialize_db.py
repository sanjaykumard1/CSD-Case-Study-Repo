import mysql.connector
from mysql.connector import Error

def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host='your_host',        # e.g., 'localhost' or '127.0.0.1'
            user='your_username',    # e.g., 'root' or 'user'
            password='your_password' # e.g., 'password for the user'
        )

        if connection.is_connected():
            db_info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_info)
            return connection

    except Error as e:
        print("Error while connecting to MySQL", e)
        return None

def initialize_db():
    connection = connect_to_db()
    if connection is None:
        return

    try:
        cursor = connection.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS clinic_db;")
        cursor.execute("USE clinic_db;")
        
        create_patients_table = """
        CREATE TABLE IF NOT EXISTS Patients (
            patient_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            date_of_birth DATE NOT NULL,
            gender VARCHAR(10) NOT NULL,
            contact_info VARCHAR(255) NOT NULL
        );
        """
        cursor.execute(create_patients_table)

        create_doctors_table = """
        CREATE TABLE IF NOT EXISTS Doctors (
            doctor_id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            specialty VARCHAR(255) NOT NULL,
            contact_info VARCHAR(255) NOT NULL,
            available_dates TEXT NOT NULL
        );
        """
        cursor.execute(create_doctors_table)

        create_appointments_table = """
        CREATE TABLE IF NOT EXISTS Appointments (
            appointment_id INT AUTO_INCREMENT PRIMARY KEY,
            patient_id INT NOT NULL,
            doctor_id INT NOT NULL,
            appointment_date DATE NOT NULL,
            reason VARCHAR(255) NOT NULL,
            FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
            FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
        );
        """
        cursor.execute(create_appointments_table)

        print("Database and tables created successfully!")
    
    except Error as e:
        print(f"Error: '{e}'")
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

if __name__ == "__main__":
    initialize_db()
