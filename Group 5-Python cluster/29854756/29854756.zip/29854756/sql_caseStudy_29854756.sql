create database OnlineLearningPlatform;
use OnlineLearningPlatform;

CREATE TABLE Courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    instructor_id INT,
    capacity INT,
    FOREIGN KEY (instructor_id) REFERENCES Instructors(instructor_id)
);

INSERT INTO Courses (course_id, title, description, instructor_id, capacity) VALUES
(1, 'Introduction to Python', 'Learn the basics of Python programming.', 1, 50),
(2, 'Data Structures', 'Introduction to Data Structures using Python.', 2, 40);



CREATE TABLE Students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    address VARCHAR(255)
);

INSERT INTO Students (student_id, name, email, address) VALUES
(1, 'Ajay', 'ajay@example.com', '123 Main St, Springfield'),
(2, 'Sinha', 'sinha@example.com', '456 Elm St, Springfield');


CREATE TABLE Instructors (
    instructor_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    expertise TEXT
);

INSERT INTO Instructors (instructor_id, name, email, expertise) VALUES
(1, 'Thirmal', 'thirmal@example.com', 'Python, Machine Learning'),
(2, 'Jyotsna', 'jyotsna@example.com', 'Data Structures, Algorithms');



CREATE TABLE Enrollments (
    enrollment_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date) VALUES
(1, 1, 1, '2024-07-15'),
(2, 2, 2, '2024-07-15');



#Query 1
#Query to find the total number of students enrolled in each course:
SELECT course_id, COUNT(student_id) AS total_students
FROM Enrollments
GROUP BY course_id;



#Query 2
#Query to find the courses with the highest enrollment:
SELECT course_id, COUNT(student_id) AS total_students
FROM Enrollments
GROUP BY course_id
ORDER BY total_students DESC
LIMIT 1;


#Query 3
#Query to find the instructors who are teaching the most courses:
SELECT instructor_id, COUNT(course_id) AS total_courses
FROM Courses
GROUP BY instructor_id
ORDER BY total_courses DESC
LIMIT 1;


#Query 4
#Query to find the courses a specific student is enrolled in:

SELECT c.course_id, c.title, c.description
FROM Courses c
JOIN Enrollments e ON c.course_id = e.course_id
WHERE e.student_id = 1;


#Query 5
#Query to find the students enrolled in a specific course:
SELECT s.student_id, s.name, s.email, s.address
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
WHERE e.course_id = 1;

