import datetime

class Course:
    def __init__(self, course_id, title, description, instructor_id, capacity):
        self.course_id = course_id
        self.title = title
        self.description = description
        self.instructor_id = instructor_id
        self.capacity = capacity

class Student:
    def __init__(self, student_id, name, email, address):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.address = address

class Instructor:
    def __init__(self, instructor_id, name, email, expertise):
        self.instructor_id = instructor_id
        self.name = name
        self.email = email
        self.expertise = expertise

class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date


class CourseManagement:
    def __init__(self):
        self.courses = {}

    def add_course(self, course):
        if course.course_id in self.courses:
            raise ValueError("Course ID already exists")
        self.courses[course.course_id] = course

    def update_course(self, course_id, **kwargs):
        if course_id not in self.courses:
            raise ValueError("Course not found")
        for key, value in kwargs.items():
            if hasattr(self.courses[course_id], key):
                setattr(self.courses[course_id], key, value)

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise ValueError("Course not found")
        del self.courses[course_id]

class StudentManagement:
    def __init__(self):
        self.students = {}

    def add_student(self, student):
        if student.student_id in self.students:
            raise ValueError("Student ID already exists")
        self.students[student.student_id] = student

    def update_student(self, student_id, **kwargs):
        if student_id not in self.students:
            raise ValueError("Student not found")
        for key, value in kwargs.items():
            if hasattr(self.students[student_id], key):
                setattr(self.students[student_id], key, value)

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise ValueError("Student not found")
        del self.students[student_id]

class InstructorManagement:
    def __init__(self):
        self.instructors = {}

    def add_instructor(self, instructor):
        if instructor.instructor_id in self.instructors:
            raise ValueError("Instructor ID already exists")
        self.instructors[instructor.instructor_id] = instructor

    def update_instructor(self, instructor_id, **kwargs):
        if instructor_id not in self.instructors:
            raise ValueError("Instructor not found")
        for key, value in kwargs.items():
            if hasattr(self.instructors[instructor_id], key):
                setattr(self.instructors[instructor_id], key, value)

    def delete_instructor(self, instructor_id):
        if instructor_id not in self.instructors:
            raise ValueError("Instructor not found")
        del self.instructors[instructor_id]

class EnrollmentManagement:
    def __init__(self):
        self.enrollments = {}
        self.enrollment_id_counter = 1

    def enroll_student(self, student_id, course_id):
        enrollment = Enrollment(
            enrollment_id=self.enrollment_id_counter,
            student_id=student_id,
            course_id=course_id,
            enrollment_date=datetime.date.today()
        )
        self.enrollments[self.enrollment_id_counter] = enrollment
        self.enrollment_id_counter += 1

    def update_enrollment(self, enrollment_id, **kwargs):
        if enrollment_id not in self.enrollments:
            raise ValueError("Enrollment not found")
        for key, value in kwargs.items():
            if hasattr(self.enrollments[enrollment_id], key):
                setattr(self.enrollments[enrollment_id], key, value)

    def cancel_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise ValueError("Enrollment not found")
        del self.enrollments[enrollment_id]


def main():
    course_management = CourseManagement()
    student_management = StudentManagement()
    instructor_management = InstructorManagement()
    enrollment_management = EnrollmentManagement()

    while True:
        print("\nOnline Learning Platform Management System")
        print("1. Manage Courses")
        print("2. Manage Students")
        print("3. Manage Instructors")
        print("4. Manage Enrollments")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            print("\nCourse Management")
            print("1. Add Course")
            print("2. Update Course")
            print("3. Delete Course")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                course_id = int(input("Enter course ID: "))
                title = input("Enter title: ")
                description = input("Enter description: ")
                instructor_id = int(input("Enter instructor ID: "))
                capacity = int(input("Enter capacity: "))
                course = Course(course_id, title, description, instructor_id, capacity)
                try:
                    course_management.add_course(course)
                    print("Course added successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '2':
                course_id = int(input("Enter course ID: "))
                updates = {}
                title = input("Enter new title : ")
                if title:
                    updates['title'] = title
                description = input("Enter new description : ")
                if description:
                    updates['description'] = description
                instructor_id = input("Enter new instructor ID : ")
                if instructor_id:
                    updates['instructor_id'] = int(instructor_id)
                capacity = input("Enter new capacity : ")
                if capacity:
                    updates['capacity'] = int(capacity)
                try:
                    course_management.update_course(course_id, **updates)
                    print("Course updated successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '3':
                course_id = int(input("Enter course ID: "))
                try:
                    course_management.delete_course(course_id)
                    print("Course deleted successfully")
                except ValueError as e:
                    print(e)

        elif choice == '2':
            print("\nStudent Management")
            print("1. Add Student")
            print("2. Update Student")
            print("3. Delete Student")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                student_id = int(input("Enter student ID: "))
                name = input("Enter name: ")
                email = input("Enter email: ")
                address = input("Enter address: ")
                student = Student(student_id, name, email, address)
                try:
                    student_management.add_student(student)
                    print("Student added successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '2':
                student_id = int(input("Enter student ID: "))
                updates = {}
                name = input("Enter new name : ")
                if name:
                    updates['name'] = name
                email = input("Enter new email : ")
                if email:
                    updates['email'] = email
                address = input("Enter new address : ")
                if address:
                    updates['address'] = address
                try:
                    student_management.update_student(student_id, **updates)
                    print("Student updated successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '3':
                student_id = int(input("Enter student ID: "))
                try:
                    student_management.delete_student(student_id)
                    print("Student deleted successfully.")
                except ValueError as e:
                    print(e)

        elif choice == '3':
            print("\nInstructor Management")
            print("1. Add Instructor")
            print("2. Update Instructor")
            print("3. Delete Instructor")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                instructor_id = int(input("Enter instructor ID: "))
                name = input("Enter name: ")
                email = input("Enter email: ")
                expertise = input("Enter expertise: ")
                instructor = Instructor(instructor_id, name, email, expertise)
                try:
                    instructor_management.add_instructor(instructor)
                    print("Instructor added successfully.")
                except ValueError as e:
                    print(e)

            elif sub_choice == '2':
                instructor_id = int(input("Enter instructor ID: "))
                updates = {}
                name = input("Enter new name : ")
                if name:
                    updates['name'] = name
                email = input("Enter new email : ")
                if email:
                    updates['email'] = email
                expertise = input("Enter new expertise : ")
                if expertise:
                    updates['expertise'] = expertise
                try:
                    instructor_management.update_instructor(instructor_id, **updates)
                    print("Instructor updated successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '3':
                instructor_id = int(input("Enter instructor ID: "))
                try:
                    instructor_management.delete_instructor(instructor_id)
                    print("Instructor deleted successfully")
                except ValueError as e:
                    print(e)

        elif choice == '4':
            print("\nEnrollment Management")
            print("1. Enroll Student")
            print("2. Update Enrollment")
            print("3. Cancel Enrollment")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                student_id = int(input("Enter student ID: "))
                course_id = int(input("Enter course ID: "))
                try:
                    enrollment_management.enroll_student(student_id, course_id)
                    print("Student enrolled successfully.")
                except ValueError as e:
                    print(e)

            elif sub_choice == '2':
                enrollment_id = int(input("Enter enrollment ID: "))
                updates = {}
                student_id = input("Enter new student ID : ")
                if student_id:
                    updates['student_id'] = int(student_id)
                course_id = input("Enter new course ID : ")
                if course_id:
                    updates['course_id'] = int(course_id)
                enrollment_date = input("Enter new enrollment date (YYYY-MM-DD): ")
                if enrollment_date:
                    updates['enrollment_date'] = datetime.date.fromisoformat(enrollment_date)
                try:
                    enrollment_management.update_enrollment(enrollment_id, **updates)
                    print("Enrollment updated successfully")
                except ValueError as e:
                    print(e)

            elif sub_choice == '3':
                enrollment_id = int(input("Enter enrollment ID: "))
                try:
                    enrollment_management.cancel_enrollment(enrollment_id)
                    print("Enrollment cancelled successfully")
                except ValueError as e:
                    print(e)

        elif choice == '5':
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again")

if __name__ == "__main__":
    main()
