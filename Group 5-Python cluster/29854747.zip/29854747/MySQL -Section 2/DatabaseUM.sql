Create database new_schema;
show databases;
use new_schema;


-- creation of Tables --
CREATE TABLE Students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    email VARCHAR(100),
    major VARCHAR(100)
);

CREATE TABLE Courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100),
    instructor VARCHAR(100),
    credits INT,
    max_students INT
);

CREATE TABLE Enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);
-- ADDING  Data in Tables--
INSERT INTO Students (name, age, email, major) VALUES
('Alice Johnson', 20, 'alice.johnson@example.com', 'Computer Science'),
('Bob Smith', 21, 'bob.smith@example.com', 'Mathematics'),
('Carol White', 22, 'carol.white@example.com', 'Physics'),
('David Brown', 20, 'david.brown@example.com', 'Chemistry'),
('Eve Davis', 23, 'eve.davis@example.com', 'Biology');


INSERT INTO Courses ( course_name, instructor, credits, max_students) VALUES
( 'Introduction to Computer Science', 'Dr. S. Radhakrishnan', 4, 30),
( 'Calculus I', 'Dr. Aryabhata', 3, 25),
( 'General Physics', 'Dr. C.V. Raman', 4, 20),
( 'Organic Chemistry', 'Dr. Prafulla Chandra Ray', 4, 30),
( 'Genetics', 'Dr. M.S. Swaminathan', 3, 25);

INSERT INTO Enrollments ( student_id, course_id, enrollment_date) VALUES
( 1, 1, '2024-01-15'),
( 1, 2, '2024-01-20'),
( 1, 3, '2024-02-01'),
( 2, 1, '2024-01-16'),
( 2, 4, '2024-02-10'),
( 3, 2, '2024-01-25'),
( 3, 3, '2024-01-30'),
( 3, 5, '2024-02-05'),
( 4, 4, '2024-01-17'),
( 4, 5, '2024-01-18'),
(5, 1, '2024-01-19'),
( 5, 2, '2024-01-22'),
( 5, 3, '2024-02-03'),
( 5, 4, '2024-02-07');

select * from students;
select * from Courses ;
select * from Enrollments;

/*1.	Write a query to find the total number of students enrolled in each course.--*/
SELECT 
    c.course_id, 
    c.course_name, 
    COUNT(e.student_id) AS total_students
FROM 
    Courses c
LEFT JOIN 
    Enrollments e ON c.course_id = e.course_id
GROUP BY 
    c.course_id, c.course_name;
    
    
    
/*2.	Write a query to find the names and emails of students who are enrolled in more than three courses.*/
SELECT 
    s.name, 
    s.email
FROM 
    Students s
JOIN (
    SELECT 
        student_id
    FROM 
        Enrollments
    GROUP BY 
        student_id
    HAVING 
        COUNT(course_id) > 3
) AS e ON s.student_id = e.student_id;



/*3.	Write a query to find the courses that have not reached their maximum student capacity.*/
SELECT 
    c.course_id, 
    c.course_name, 
    c.max_students, 
    COUNT(e.student_id) AS enrolled_students
FROM 
    Courses c
LEFT JOIN 
    Enrollments e ON c.course_id = e.course_id
GROUP BY 
    c.course_id, c.course_name, c.max_students
HAVING 
    COUNT(e.student_id) < c.max_students;
    
    
    
/*4.	Write a query to find the students who are enrolled in courses taught by a specific instructor.*/
SELECT 
    s.name, 
    s.email, 
    c.course_name
FROM 
    Students s
JOIN 
    Enrollments e ON s.student_id = e.student_id
JOIN 
    Courses c ON e.course_id = c.course_id
WHERE 
    c.instructor = 'Dr. Aryabhata';
/*5.	Write a query to find the details of enrollments made in the last semester.*/
SELECT 
    e.enrollment_id, 
    s.name AS student_name, 
    c.course_name, 
    e.enrollment_date
FROM 
    Enrollments e
JOIN 
    Students s ON e.student_id = s.student_id
JOIN 
    Courses c ON e.course_id = c.course_id
WHERE 
    e.enrollment_date BETWEEN '2024-01-01' AND '2024-06-30';

