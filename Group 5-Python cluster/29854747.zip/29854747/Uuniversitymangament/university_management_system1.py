import mysql.connector
from mysql.connector import Error
from config import db_config
from models import Student, Course, Enrollment

class UniversityManagementSystem:
    def __init__(self):
        self.connection = mysql.connector.connect(**db_config)

    def add_student(self, student):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Students ( name, age, email, major) VALUES ( %s, %s, %s, %s)"
            cursor.execute(query, ( student.name, student.age, student.email, student.major))
            self.connection.commit()
            print("Student added successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def update_student(self, student_id, **kwargs):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Students SET name=%s, age=%s, email=%s, major=%s WHERE student_id=%s"
            cursor.execute(query, (kwargs.get('name'), kwargs.get('age'), kwargs.get('email'), kwargs.get('major'), student_id))
            self.connection.commit()
            print("Student updated successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def delete_student(self, student_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Students WHERE student_id=%s"
            cursor.execute(query, (student_id,))
            self.connection.commit()
            print("Student deleted successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def get_all_students(self):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Students"
            cursor.execute(query)
            students = cursor.fetchall()
            return students
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def add_course(self, course):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Courses (course_name, instructor, credits, max_students) VALUES ( %s, %s, %s, %s)"
            cursor.execute(query, (course.course_name, course.instructor, course.credits, course.max_students))
            self.connection.commit()
            print("Course added successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def update_course(self, course_id, **kwargs):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Courses SET course_name=%s, instructor=%s, credits=%s, max_students=%s WHERE course_id=%s"
            cursor.execute(query, (kwargs.get('course_name'), kwargs.get('instructor'), kwargs.get('credits'), kwargs.get('max_students'), course_id))
            self.connection.commit()
            print("Course updated successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def delete_course(self, course_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Courses WHERE course_id=%s"
            cursor.execute(query, (course_id,))
            self.connection.commit()
            print("Course deleted successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def get_all_courses(self):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Courses"
            cursor.execute(query)
            courses = cursor.fetchall()
            return courses
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def add_enrollment(self, enrollment):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Enrollments ( student_id, course_id, enrollment_date) VALUES ( %s, %s, %s)"
            cursor.execute(query, (enrollment.student_id, enrollment.course_id, enrollment.enrollment_date))
            self.connection.commit()
            print("Enrollment added successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def update_enrollment(self, enrollment_id, **kwargs):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Enrollments SET student_id=%s, course_id=%s, enrollment_date=%s WHERE enrollment_id=%s"
            cursor.execute(query, (kwargs.get('student_id'), kwargs.get('course_id'), kwargs.get('enrollment_date'), enrollment_id))
            self.connection.commit()
            print("Enrollment updated successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def cancel_enrollment(self, enrollment_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Enrollments WHERE enrollment_id=%s"
            cursor.execute(query, (enrollment_id,))
            self.connection.commit()
            print("Enrollment canceled successfully!")
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()

    def get_all_enrollments(self):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Enrollments"
            cursor.execute(query)
            enrollments = cursor.fetchall()
            return enrollments
        except Error as e:
            print(f"Error: {e}")
        finally:
            cursor.close()
