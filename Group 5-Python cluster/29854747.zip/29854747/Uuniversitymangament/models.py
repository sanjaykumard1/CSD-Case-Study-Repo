from datetime import date

class Student:
    def __init__(self, name, age, email, major, student_id=None):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.email = email
        self.major = major


class Course:
    def __init__(self,  course_name, instructor, credits, max_students,course_id=None):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.credits = credits
        self.max_students = max_students

class Enrollment:
    def __init__(self,  student_id, course_id, enrollment_date=None,enrollment_id=None):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date if enrollment_date else date.today()
