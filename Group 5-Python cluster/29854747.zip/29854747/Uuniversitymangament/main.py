from university_management_system1 import UniversityManagementSystem
from models import Student, Course, Enrollment

def main():
    ums = UniversityManagementSystem()

    while True:
        print("\nUniversity Management System")
        print("1. Manage Students")
        print("2. Manage Courses")
        print("3. Manage Enrollments")
        print("4. View All Students")
        print("5. View All Courses")
        print("6. View All Enrollments")
        print("7. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            print("\n1. Add Student")
            print("2. Update Student")
            print("3. Delete Student")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                #student_id = int(input("Enter Student ID: "))
                name = input("Enter Name: ")
                age = int(input("Enter Age: "))
                email = input("Enter Email: ")
                major = input("Enter Major: ")
                student = Student(name, age, email, major)
                ums.add_student(student)
            elif sub_choice == '2':
                student_id = int(input("Enter Student ID: "))
                name = input("Enter Name (leave blank to skip): ")
                age = input("Enter Age (leave blank to skip): ")
                email = input("Enter Email (leave blank to skip): ")
                major = input("Enter Major (leave blank to skip): ")
                ums.update_student(student_id, name=name or None, age=int(age) if age else None, email=email or None, major=major or None)
            elif sub_choice == '3':
                student_id = int(input("Enter Student ID: "))
                ums.delete_student(student_id)

        elif choice == '2':
            print("\n1. Add Course")
            print("2. Update Course")
            print("3. Delete Course")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                #course_id = int(input("Enter Course ID: "))
                course_name = input("Enter Course Name: ")
                instructor = input("Enter Instructor: ")
                credits = int(input("Enter Credits: "))
                max_students = int(input("Enter Max Students: "))
                course = Course(course_name, instructor, credits, max_students)
                ums.add_course(course)
            elif sub_choice == '2':
                course_id = int(input("Enter Course ID: "))
                course_name = input("Enter Course Name (leave blank to skip): ")
                instructor = input("Enter Instructor (leave blank to skip): ")
                credits = input("Enter Credits (leave blank to skip): ")
                max_students = input("Enter Max Students (leave blank to skip): ")
                ums.update_course(course_id, course_name=course_name or None, instructor=instructor or None, credits=int(credits) if credits else None, max_students=int(max_students) if max_students else None)
            elif sub_choice == '3':
                course_id = int(input("Enter Course ID: "))
                ums.delete_course(course_id)

        elif choice == '3':
            print("\n1. Add Enrollment")
            print("2. Update Enrollment")
            print("3. Cancel Enrollment")
            sub_choice = input("Enter your choice: ")

            if sub_choice == '1':
                #enrollment_id = int(input("Enter Enrollment ID: "))
                student_id = int(input("Enter Student ID: "))
                course_id = int(input("Enter Course ID: "))
                enrollment_date = input("Enter Enrollment Date (YYYY-MM-DD, leave blank for today): ")
                enrollment = Enrollment(student_id, course_id, enrollment_date or None)
                ums.add_enrollment(enrollment)
            elif sub_choice == '2':
                enrollment_id = int(input("Enter Enrollment ID: "))
                student_id = input("Enter Student ID (leave blank to skip): ")
                course_id = input("Enter Course ID (leave blank to skip): ")
                enrollment_date = input("Enter Enrollment Date (leave blank to skip): ")
                ums.update_enrollment(enrollment_id, student_id=int(student_id) if student_id else None, course_id=int(course_id) if course_id else None, enrollment_date=enrollment_date or None)
            elif sub_choice == '3':
                enrollment_id = int(input("Enter Enrollment ID: "))
                ums.cancel_enrollment(enrollment_id)

        elif choice == '4':
            students = ums.get_all_students()
            if students:
                for student in students:
                    print(student)
            else:
                print("No students found.")

        elif choice == '5':
            courses = ums.get_all_courses()
            if courses:
                for course in courses:
                    print(course)
            else:
                print("No courses found.")

        elif choice == '6':
            enrollments = ums.get_all_enrollments()
            if enrollments:
                for enrollment in enrollments:
                    print(enrollment)
            else:
                print("No enrollments found .")

        elif choice == '7':
            print("Exit")
            break

        else:
            print("choose from 1-7.")

if __name__ == "__main__":
    main()
