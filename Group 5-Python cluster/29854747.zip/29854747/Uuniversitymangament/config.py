# config.py
db_config = {
    'user': 'root',  # Your MySQL username
    'password': 'root',  # Your MySQL password
    'host': '127.0.0.1',
    'database': 'new_schema',
    'raise_on_warnings': True
}
