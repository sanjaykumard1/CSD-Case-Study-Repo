class Participant:
    def __init__(self, participant_id, name, email, phone_number):
        # Initialize participant details
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.phone_number = phone_number

    def add_participant(self, participants):
        # Add participant to the participants dictionary if it doesn't already exist
        if self.participant_id in participants:
            print(f"Participant ID {self.participant_id} already exists.")
        else:
            participants[self.participant_id] = self
            print(f"Participant '{self.name}' added with ID: {self.participant_id}")

    def update_participant(self, name=None, email=None, phone_number=None):
        # Update participant details if provided
        if name: self.name = name
        if email: self.email = email
        if phone_number: self.phone_number = phone_number
        print(f"Participant '{self.participant_id}' updated.")

    def delete_participant(self, participants):
        # Delete participant from the participants dictionary if it exists
        if self.participant_id in participants:
            del participants[self.participant_id]
            print(f"Participant '{self.participant_id}' deleted.")
        else:
            print("Participant not found.")

    @staticmethod
    def show_participants(participants):
        # Display all participants
        if not participants:
            print("No participants available.")
        for participant in participants.values():
            print(f"ID: {participant.participant_id}, Name: {participant.name}, Email: {participant.email}, Phone: {participant.phone_number}")
