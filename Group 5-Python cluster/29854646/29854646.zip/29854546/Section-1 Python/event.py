class Event:
    def __init__(self, event_id, event_name, event_date, location, max_participants):
        # Initialize event details
        self.event_id = event_id
        self.event_name = event_name
        self.event_date = event_date
        self.location = location
        self.max_participants = max_participants

    def add_event(self, events):
        # Add event to the events dictionary if it doesn't already exist
        if self.event_id in events:
            print(f"Event ID {self.event_id} already exists.")
        else:
            events[self.event_id] = self
            print(f"Event '{self.event_name}' added with ID: {self.event_id}")

    def update_event(self, event_name=None, event_date=None, location=None, max_participants=None):
        # Update event details if provided
        if event_name: self.event_name = event_name
        if event_date: self.event_date = event_date
        if location: self.location = location
        if max_participants: self.max_participants = max_participants
        print(f"Event '{self.event_id}' updated.")

    def delete_event(self, events):
        # Delete event from the events dictionary if it exists
        if self.event_id in events:
            del events[self.event_id]
            print(f"Event '{self.event_id}' deleted.")
        else:
            print("Event not found.")

    @staticmethod
    def show_events(events):
        # Display all events
        if not events:
            print("No events available.")
        for event in events.values():
            print(f"ID: {event.event_id}, Name: {event.event_name}, Date: {event.event_date}, Location: {event.location}, Max Participants: {event.max_participants}")
