from event import Event
from participant import Participant
from registration import Registration

events = {}
participants = {}
registrations = {}

def manage_events():
    # Manage event operations (add, update, delete, show)
    while True:
        print("\nManage Events")
        print("1. Add Event")
        print("2. Update Event")
        print("3. Delete Event")
        print("4. Show Events")
        print("0. Back to Main Menu")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            event_id = int(input("Event ID: "))
            name = input("Event Name: ")
            date = input("Event Date (YYYY-MM-DD): ")
            location = input("Location: ")
            max_participants = int(input("Max Participants: "))
            event = Event(event_id, name, date, location, max_participants)
            event.add_event(events)
        elif choice == '2':
            event_id = int(input("Event ID: "))
            event = events.get(event_id)
            if event:
                name = input("New Event Name (leave blank to skip): ")
                date = input("New Event Date (leave blank to skip): ")
                location = input("New Location (leave blank to skip): ")
                max_participants = input("New Max Participants (leave blank to skip): ")
                event.update_event(name or None, date or None, location or None, int(max_participants) if max_participants else None)
            else:
                print("Event not found.")
        elif choice == '3':
            event_id = int(input("Event ID: "))
            event = events.get(event_id)
            if event:
                event.delete_event(events)
            else:
                print("Event not found.")
        elif choice == '4':
            Event.show_events(events)
        elif choice == '0':
            break
        else:
            print("Invalid choice! Please try again.")

def manage_participants():
    # Manage participant operations (add, update, delete, show)
    while True:
        print("\nManage Participants")
        print("1. Add Participant")
        print("2. Update Participant")
        print("3. Delete Participant")
        print("4. Show Participants")
        print("0. Back to Main Menu")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            participant_id = int(input("Participant ID: "))
            name = input("Participant Name: ")
            email = input("Email: ")
            phone_number = input("Phone Number: ")
            participant = Participant(participant_id, name, email, phone_number)
            participant.add_participant(participants)
        elif choice == '2':
            participant_id = int(input("Participant ID: "))
            participant = participants.get(participant_id)
            if participant:
                name = input("New Name (leave blank to skip): ")
                email = input("New Email (leave blank to skip): ")
                phone_number = input("New Phone Number (leave blank to skip): ")
                participant.update_participant(name or None, email or None, phone_number or None)
            else:
                print("Participant not found.")
        elif choice == '3':
            participant_id = int(input("Participant ID: "))
            participant = participants.get(participant_id)
            if participant:
                participant.delete_participant(participants)
            else:
                print("Participant not found.")
        elif choice == '4':
            Participant.show_participants(participants)
        elif choice == '0':
            break
        else:
            print("Invalid choice! Please try again.")

def manage_registrations():
    # Manage registration operations (add, update, cancel, show)
    while True:
        print("\nManage Registrations")
        print("1. Add Registration")
        print("2. Update Registration")
        print("3. Cancel Registration")
        print("4. Show Registrations")
        print("0. Back to Main Menu")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            registration_id = int(input("Registration ID: "))
            event_id = int(input("Event ID: "))
            if event_id not in events:
                print("Error: Event ID does not exist.")
                continue
            participant_id = int(input("Participant ID: "))
            if participant_id not in participants:
                print("Error: Participant ID does not exist.")
                continue
            registration_date = input("Registration Date (YYYY-MM-DD): ")

            registration = Registration(registration_id, event_id, participant_id, registration_date)
            registration.add_registration(registrations)

        elif choice == '2':
            registration_id = int(input("Registration ID: "))
            registration = registrations.get(registration_id)
            if registration:
                event_id = input("New Event ID (leave blank to skip): ")
                participant_id = input("New Participant ID (leave blank to skip): ")
                registration_date = input("New Registration Date (leave blank to skip): ")
                registration.update_registration(int(event_id) if event_id else None,
                                                 int(participant_id) if participant_id else None,
                                                 registration_date or None)
            else:
                print("Registration not found.")
        elif choice == '3':
            registration_id = int(input("Registration ID: "))
            registration = registrations.get(registration_id)
            if registration:
                registration.cancel_registration(registrations)
            else:
                print("Registration not found.")
        elif choice == '4':
            Registration.show_registrations(registrations)
        elif choice == '0':
            break
        else:
            print("Invalid choice! Please try again.")

def main():
    # Main menu to navigate between event, participant, and registration management
    while True:
        print("\nEvent Management System")
        print("1. Manage Events")
        print("2. Manage Participants")
        print("3. Manage Registrations")
        print("0. Exit")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            manage_events()
        elif choice == '2':
            manage_participants()
        elif choice == '3':
            manage_registrations()
        elif choice == '0':
            print("Exiting...")
            break
        else:
            print("Invalid choice! Please try again.")

if __name__ == "__main__":
    # Entry point of the application
    main()
