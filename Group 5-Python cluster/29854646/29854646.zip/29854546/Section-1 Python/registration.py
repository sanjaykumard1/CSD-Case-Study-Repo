class Registration:
    def __init__(self, registration_id, event_id, participant_id, registration_date):
        # Initialize registration details
        self.registration_id = registration_id
        self.event_id = event_id
        self.participant_id = participant_id
        self.registration_date = registration_date

    def add_registration(self, registrations):
        # Add registration to the registrations dictionary if it doesn't already exist
        if self.registration_id in registrations:
            print(f"Registration ID {self.registration_id} already exists.")
        else:
            registrations[self.registration_id] = self
            print(f"Registration added with ID: {self.registration_id}")

    def update_registration(self, event_id=None, participant_id=None, registration_date=None):
        # Update registration details if provided
        if event_id: self.event_id = event_id
        if participant_id: self.participant_id = participant_id
        if registration_date: self.registration_date = registration_date
        print(f"Registration '{self.registration_id}' updated.")

    def cancel_registration(self, registrations):
        # Cancel (delete) registration from the registrations dictionary if it exists
        if self.registration_id in registrations:
            del registrations[self.registration_id]
            print(f"Registration '{self.registration_id}' canceled.")
        else:
            print("Registration not found.")

    @staticmethod
    def show_registrations(registrations):
        # Display all registrations
        if not registrations:
            print("No registrations available.")
        for registration in registrations.values():
            print(f"ID: {registration.registration_id}, Event ID: {registration.event_id}, Participant ID: {registration.participant_id}, Date: {registration.registration_date}")
