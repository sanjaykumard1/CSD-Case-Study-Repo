CREATE DATABASE event_management;
USE event_management;

CREATE TABLE events (
    event_id INT PRIMARY KEY,
    event_name VARCHAR(255),
    event_date DATE,
    location VARCHAR(255),
    max_participants INT
);

CREATE TABLE participants (
    participant_id INT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone_number VARCHAR(20)
);

CREATE TABLE registrations (
    registration_id INT PRIMARY KEY,
    event_id INT,
    participant_id INT,
    registration_date DATE,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (participant_id) REFERENCES participants(participant_id)
);
