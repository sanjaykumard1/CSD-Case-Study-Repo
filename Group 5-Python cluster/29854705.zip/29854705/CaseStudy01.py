class Student:
    def __init__(self, student_id, name, age, major, year):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.major = major
        self.year = year

class EnrollmentSystem:
    def __init__(self):
        self.students = {}
        self.courses = {}

    def add_student(self, student_id, name, age, major, year):
        if student_id in self.students:
            raise ValueError("Student ID already exists.")
        student = Student(student_id, name, age, major, year)
        self.students[student_id] = student

    def update_student(self, student_id, name=None, age=None, major=None, year=None):
        if student_id not in self.students:
            raise ValueError("Student ID not found.")
        student = self.students[student_id]
        if name is not None:
            student.name = name
        if age is not None:
            student.age = age
        if major is not None:
            student.major = major
        if year is not None:
            student.year = year

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise ValueError("Student ID not found.")
        del self.students[student_id]

    def enroll_student(self, student_id, course_id):
        if student_id not in self.students:
            raise ValueError("Student ID not found.")
        if course_id not in self.courses:
            self.courses[course_id] = []
        if student_id not in self.courses[course_id]:
            self.courses[course_id].append(student_id)

    def drop_student(self, student_id, course_id):
        if course_id in self.courses and student_id in self.courses[course_id]:
            self.courses[course_id].remove(student_id)

    def generate_report(self, course_id):
        if course_id not in self.courses:
            return []
        enrolled_students = self.courses[course_id]
        return [self.students[student_id] for student_id in enrolled_students]

# Console Application
def main():
    system = EnrollmentSystem()

    while True:
        print("\nStudent Enrollment System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Enroll Student in Course")
        print("5. Drop Student from Course")
        print("6. Generate Course Report")
        print("7. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            student_id = input("Enter student ID: ")
            name = input("Enter student name: ")
            age = int(input("Enter student age: "))
            major = input("Enter student major: ")
            year = int(input("Enter student year: "))
            try:
                system.add_student(student_id, name, age, major, year)
                print("Student added successfully.")
            except ValueError as e:
                print(e)

        elif choice == '2':
            student_id = input("Enter student ID: ")
            name = input("Enter new student name (leave blank to keep unchanged): ")
            age = input("Enter new student age (leave blank to keep unchanged): ")
            major = input("Enter new student major (leave blank to keep unchanged): ")
            year = input("Enter new student year (leave blank to keep unchanged): ")
            try:
                system.update_student(student_id, name or None, int(age) if age else None, major or None, int(year) if year else None)
                print("Student updated successfully.")
            except ValueError as e:
                print(e)

        elif choice == '3':
            student_id = input("Enter student ID: ")
            try:
                system.delete_student(student_id)
                print("Student deleted successfully.")
            except ValueError as e:
                print(e)

        elif choice == '4':
            student_id = input("Enter student ID: ")
            course_id = input("Enter course ID: ")
            try:
                system.enroll_student(student_id, course_id)
                print("Student enrolled in course successfully.")
            except ValueError as e:
                print(e)

        elif choice == '5':
            student_id = input("Enter student ID: ")
            course_id = input("Enter course ID: ")
            try:
                system.drop_student(student_id, course_id)
                print("Student dropped from course successfully.")
            except ValueError as e:
                print(e)

        elif choice == '6':
            course_id = input("Enter course ID: ")
            report = system.generate_report(course_id)
            if not report:
                print("No students enrolled in this course.")
            else:
                for student in report:
                    print(f"ID: {student.student_id}, Name: {student.name}, Age: {student.age}, Major: {student.major}, Year: {student.year}")

        elif choice == '7':
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
