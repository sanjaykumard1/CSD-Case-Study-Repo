class Room:
    def __init__(self, room_id, room_type, price_per_night, is_available=True):
        self.room_id = room_id
        self.room_type = room_type
        self.price_per_night = price_per_night
        self.is_available = is_available

    def __repr__(self):
        return f"Room({self.room_id}, {self.room_type}, {self.price_per_night}, {self.is_available})"

class RoomManager:
    def __init__(self):
        self.rooms = {}

    def add_room(self, room):
        if room.room_id in self.rooms:
            raise ValueError("Room with this ID already exists.")
        self.rooms[room.room_id] = room

    def update_room(self, room_id, **kwargs):
        if room_id not in self.rooms:
            raise ValueError("Room not found.")
        for key, value in kwargs.items():
            if hasattr(self.rooms[room_id], key):
                setattr(self.rooms[room_id], key, value)

    def delete_room(self, room_id):
        if room_id not in self.rooms:
            raise ValueError("Room not found.")
        del self.rooms[room_id]

    def list_rooms(self):
        return list(self.rooms.values())
