-- Rooms Table
CREATE TABLE Rooms (
    room_id INT PRIMARY KEY,
    room_type VARCHAR(50),
    price_per_night DECIMAL(10, 2),
    is_available BOOLEAN
);
-- Guests Table
CREATE TABLE Guests (
    guest_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_number VARCHAR(15),
    address VARCHAR(255)
);
--Bookings Table
CREATE TABLE Bookings (
    booking_id INT PRIMARY KEY,
    guest_id INT,
    room_id INT,
    check_in_date DATE,
    check_out_date DATE,
    FOREIGN KEY (guest_id) REFERENCES Guests(guest_id),
    FOREIGN KEY (room_id) REFERENCES Rooms(room_id)
);

-- Inserted data into Rooms table
INSERT INTO Rooms (room_id, room_type, price_per_night, is_available)
VALUES 
(1, 'Single', 50.00, TRUE),
(2, 'Double', 75.00, FALSE),
(3, 'Suite', 150.00, TRUE),
(4, 'Single', 50.00, FALSE),
(5, 'Double', 75.00, TRUE);

-- Inserted data into Guests table
INSERT INTO Guests (guest_id, name, contact_number, address)
VALUES 
(1, 'John Doe', '1234567890', '123 Main St'),
(2, 'Jane Smith', '0987654321', '456 Oak St'),
(3, 'Alice Johnson', '5555555555', '789 Pine St');

-- Inserted data into Bookings table
INSERT INTO Bookings (booking_id, guest_id, room_id, check_in_date, check_out_date)
VALUES 
(1, 1, 1, '2024-06-01', '2024-06-05'),
(2, 2, 2, '2024-06-10', '2024-06-12'),
(3, 3, 3, '2024-06-15', '2024-06-23'),
(4, 1, 4, '2024-07-01', '2024-07-03'),
(5, 2, 5, '2024-07-05', '2024-07-12'),
(6, 3, 1, '2024-07-15', '2024-07-18');

-- Query 1: Total Revenue Generated from All Room Bookings
SELECT SUM((DATEDIFF(check_out_date, check_in_date) + 1) * price_per_night) AS total_revenue
FROM Bookings
JOIN Rooms ON Bookings.room_id = Rooms.room_id;

-- Query 2: Names and Contact Numbers of Guests Who Have Booked More Than One Room
SELECT Guests.name, Guests.contact_number
FROM Bookings
JOIN Guests ON Bookings.guest_id = Guests.guest_id
GROUP BY Guests.guest_id
HAVING COUNT(DISTINCT room_id) > 1;

-- Query 3: Room Types That Are Currently Available
SELECT room_type
FROM Rooms
WHERE is_available = TRUE;

-- Query 4: Guests Who Have Stayed for More Than 5 Nights
SELECT Guests.name, Guests.contact_number
FROM Bookings
JOIN Guests ON Bookings.guest_id = Guests.guest_id
WHERE DATEDIFF(check_out_date, check_in_date) + 1 > 5;

-- Query 5: Details of Bookings Made in the Last Month
SELECT *
FROM Bookings
WHERE check_in_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH);