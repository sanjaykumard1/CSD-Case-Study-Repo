class Guest:
    def __init__(self, guest_id, name, contact_number, address):
        self.guest_id = guest_id
        self.name = name
        self.contact_number = contact_number
        self.address = address

    def __repr__(self):
        return f"Guest({self.guest_id}, {self.name}, {self.contact_number}, {self.address})"

class GuestManager:
    def __init__(self):
        self.guests = {}

    def add_guest(self, guest):
        if guest.guest_id in self.guests:
            raise ValueError("Guest with this ID already exists.")
        self.guests[guest.guest_id] = guest

    def update_guest(self, guest_id, **kwargs):
        if guest_id not in self.guests:
            raise ValueError("Guest not found.")
        for key, value in kwargs.items():
            if hasattr(self.guests[guest_id], key):
                setattr(self.guests[guest_id], key, value)

    def delete_guest(self, guest_id):
        if guest_id not in self.guests:
            raise ValueError("Guest not found.")
        del self.guests[guest_id]

    def list_guests(self):
        return list(self.guests.values())
