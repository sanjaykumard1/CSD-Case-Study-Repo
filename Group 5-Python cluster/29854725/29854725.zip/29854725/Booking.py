class Booking:
    def __init__(self, booking_id, guest_id, room_id, check_in_date, check_out_date):
        self.booking_id = booking_id
        self.guest_id = guest_id
        self.room_id = room_id
        self.check_in_date = check_in_date
        self.check_out_date = check_out_date

    def __repr__(self):
        return f"Booking({self.booking_id}, {self.guest_id}, {self.room_id}, {self.check_in_date}, {self.check_out_date})"

class BookingManager:
    def __init__(self):
        self.bookings = {}

    def add_booking(self, booking):
        if booking.booking_id in self.bookings:
            raise ValueError("Booking with this ID already exists.")
        self.bookings[booking.booking_id] = booking

    def update_booking(self, booking_id, **kwargs):
        if booking_id not in self.bookings:
            raise ValueError("Booking not found.")
        for key, value in kwargs.items():
            if hasattr(self.bookings[booking_id], key):
                setattr(self.bookings[booking_id], key, value)

    def delete_booking(self, booking_id):
        if booking_id not in self.bookings:
            raise ValueError("Booking not found.")
        del self.bookings[booking_id]

    def list_bookings(self):
        return list(self.bookings.values())
