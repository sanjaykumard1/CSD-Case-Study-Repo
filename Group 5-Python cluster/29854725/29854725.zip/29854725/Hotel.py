from Room import Room, RoomManager
from Booking import Booking, BookingManager
from Guest import Guest, GuestManager

if __name__ == "__main__":
    room_manager = RoomManager()
    guest_manager = GuestManager()
    booking_manager = BookingManager()

    # Add Rooms
    try:
        room1 = Room(101, "Single", 100.00)
        room2 = Room(102, "Double", 150.00)
        room_manager.add_room(room1)
        room_manager.add_room(room2)
    except ValueError as e:
        print(e)

    # Update Room
    try:
        room_manager.update_room(101, price_per_night=120.00)
    except ValueError as e:
        print(e)

    # List Rooms
    print("Rooms:")
    for room in room_manager.list_rooms():
        print(room)

    # Add Guests
    try:
        guest1 = Guest(1, "Farhan Attar", "9876543210", "123 Street")
        guest2 = Guest(2, "Cristiano Ronaldo", "9087654321", "456 Street")
        guest_manager.add_guest(guest1)
        guest_manager.add_guest(guest2)
    except ValueError as e:
        print(e)

    # Update Guest
    try:
        guest_manager.update_guest(1, address="789 Boulevard")
    except ValueError as e:
        print(e)

    # List Guests
    print("Guests:")
    for guest in guest_manager.list_guests():
        print(guest)

    # Add Booking
    try:
        booking1 = Booking(1, 1, 101, "2024-07-01", "2024-07-05")
        booking2 = Booking(2, 2, 102, "2024-07-10", "2024-07-13")
        booking_manager.add_booking(booking1)
        booking_manager.add_booking(booking2)
    except ValueError as e:
        print(e)

    # Update Booking
    try:
        booking_manager.update_booking(1, check_out_date="2024-07-06")
    except ValueError as e:
        print(e)

    # List Bookings
    print("Bookings:")
    for booking in booking_manager.list_bookings():
        print(booking)
