class Employee:
    def __init__(self,employee_id, name, department, designation, performance_score=0):
        self.employee_id = employee_id
        self.name = name
        self.department = department
        self.designation = designation
        self.performance_score = performance_score

    def __str__(self):
        return (f"ID: {self.employee_id}, Name: {self.name}, Department: {self.department}, "
                f"Designation: {self.designation}, Performance Score: {self.performance_score}")