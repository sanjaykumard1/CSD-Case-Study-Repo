HOST = "localhost"
DATABASE = "EmployeePerformanceDB"
USER = "root"
PASSWORD = "root"
