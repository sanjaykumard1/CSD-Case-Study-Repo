from EmployeeClass import Employee
from EmployeeManagementSystemClass import EmployeeManagementSystem
from configs import HOST, DATABASE, USER, PASSWORD

def main():
    ems = EmployeeManagementSystem(
        host=HOST, database=DATABASE, user=USER, password=PASSWORD)
    input("\nPress any key to continue to the Application...")
    while True:
        print("\n")
        print("Employee Performance Tracking System".center(50, '-'))
        print("1. Add Employee")
        print("2. Update Employee")
        print("3. Delete Employee")
        print("4. Update Performance Score")
        print("5. Generate Top Performers Report")
        print("6. Performance Review")
        print("7. View Employee")
        print("8. Exit")
        print("-" * 50)

        choice = input("Enter your choice: ")

        if choice == '1':
            employee_id = input("Enter Employee ID: ")
            if ems.employee_exists(employee_id):
                print("\nEmployee {} already exists.".format(employee_id))
                input("Press any key to continue...")
                continue
            name = input("Enter Name: ")
            department = input("Enter Department: ")
            designation = input("Enter Designation: ")
            try:
                ems.add_employee(
                    Employee(employee_id, name, department, designation))
            except ValueError as e:
                print(e)

        elif choice == '2':
            employee_id = input("Enter Employee ID: ")
            if not ems.employee_exists(employee_id):
                print("\nEmployee not found.")
                input("Press any key to continue...")
                continue
            name = input("Enter Name (press enter to skip): ")
            department = input("Enter Department (press enter to skip): ")
            designation = input("Enter Designation (press enter to skip): ")
            performance_score = input(
                "Enter Performance Score (press enter to skip): ")
            try:
                if performance_score:
                    performance_score = int(performance_score)
            except ValueError:
                print("Performance Score should be an integer.")
                input("Press any key to continue...")
                continue
            try:
                if name or department or designation or performance_score:
                    if int(performance_score) < 0 or int(performance_score) > 100:
                        raise ValueError("Performance Score should be between 0 and 100.")
                    else:
                        ems.update_employee(employee_id, name if name else None, department if department else None,
                                            designation if designation else None,
                                            int(performance_score) if performance_score else None)
                else:
                    print("Nothing to update.")
            except ValueError as e:
                print(e)

        elif choice == '3':
            employee_id = input("Enter Employee ID: ")
            if not ems.employee_exists(employee_id):
                print("\nEmployee not found.")
                input("Press any key to continue...")
                continue
            try:
                ems.delete_employee(employee_id)
            except ValueError as e:
                print(e)

        elif choice == '4':
            employee_id = input("Enter Employee ID: ")
            if not ems.employee_exists(employee_id):
                print("\nEmployee not found.")
                input("Press any key to continue...")
                continue
            performance_score = int(input("Enter Performance Score: "))
            review_comments = input(
                "Enter Review Comments (press enter to skip): ")
            try:
                ems.update_performance_score(
                    employee_id, performance_score, review_comments)
            except ValueError as e:
                print(e)

        elif choice == '5':
            ems.generate_report()

        elif choice == '6':
            employee_id = input("Enter Employee ID: ")
            if not ems.employee_exists(employee_id):
                print("\nEmployee not found.")
                input("Press any key to continue...")
                continue
            try:
                review = ems.performance_review(employee_id)
                print("\n")
                print("Performance Review for Employee ID: {}".format(
                    employee_id).center(30, '-'))
                print("Name: {}".format(review[0][1]))
                print("Department: {}".format(review[0][2]))
                print("Designation: {}".format(review[0][3]))
                if len(review) == 0:
                    print("No reviews found.")
                    continue
                if len(review) == 1:
                    print("Performance Score: {}".format(review[0][4]))
                    print("Review Date: {}".format(review[0][5]))
                    print("Review Comments: {}".format(review[0][6]))
                    print("\n")
                else:
                    rev_count = 1
                    print("Performance Score: {}".format(review[0][4]))
                    for r in review:
                        print("Review {}".format(rev_count).center(30, '-'))
                        print("Review Date: {}".format(r[5]))
                        print("Review Comments: {}".format(r[6]))
                        rev_count += 1
                    print("-" * 30)
            except ValueError as e:
                print(e)

        elif choice == '7':
            employee_id = input("Enter Employee ID: ")
            if not ems.employee_exists(employee_id):
                print("\nEmployee not found.")
                input("Press any key to continue...")
                continue
            try:
                print("\n")
                print("Employee Details".center(30, '-'))
                ems.view_employee(employee_id)
                print("-" * 30)
            except ValueError as e:
                print(e)

        elif choice == '8':
            break

        else:
            print("\nInvalid choice. Please try again.")

        input("Press any key to continue...")

    ems.close_connection()


if __name__ == "__main__":
    main()
