import mysql.connector
from mysql.connector import Error
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

class EmployeeManagementSystem:
    def __init__(self, host, database, user, password):
        try:
            self.connection = mysql.connector.connect(
                host=host,
                database=database,
                user=user,
                password=password
            )
            if self.connection.is_connected():
                db_info = self.connection.get_server_info()
                print("\nConnected to MySQL Server version", db_info)
                cursor = self.connection.cursor()
                cursor.execute("select database();")
                record = cursor.fetchone()
                print("You're connected to database:", record[0])
        except Error as e:
            print("Error while connecting to MySQL", e)

    def add_employee(self, employee):
        try:
            cursor = self.connection.cursor()
            query = """INSERT INTO Employees (employee_id,name, department, designation, performance_score) 
                       VALUES (%s, %s, %s, %s,%s)"""
            cursor.execute(query, (employee.employee_id, employee.name,
                           employee.department, employee.designation, employee.performance_score))
            self.connection.commit()
            print("\nEmployee added successfully. (employee_id: {})".format(
                employee.employee_id))
        except Error as e:
            print("\nFailed to insert into MySQL table", e)

    def employee_exists(self, employee_id):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Employees WHERE employee_id = %s"
            cursor.execute(query, (employee_id,))
            result = cursor.fetchall()
            return len(result) > 0
        except Error as e:
            print("\nFailed to fetch employee from MySQL table", e)
            return False
        
    def perfomance_score_exists(self, employee_id):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM PERFORMANCEREVIEWS WHERE employee_id = %s"
            cursor.execute(query, (employee_id,))
            result = cursor.fetchall()
            return len(result) > 0
        except Error as e:
            print("\nFailed to fetch employee from MySQL table", e)
            return False
        
    def update_employee(self, employee_id, name=None, department=None, designation=None, performance_score=None):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Employees SET "
            params = []
            if name:
                query += "name = %s, "
                params.append(name)
            if department:
                query += "department = %s, "
                params.append(department)
            if designation:
                query += "designation = %s, "
                params.append(designation)
            if performance_score is not None:
                query += "performance_score = %s, "
                params.append(performance_score)
            query = query.rstrip(', ')
            query += " WHERE employee_id = %s"
            params.append(employee_id)
            cursor.execute(query, tuple(params))
            self.connection.commit()
            print("\nEmployee updated successfully. (employee_id: {})".format(employee_id))
        except Error as e:
            print("\nFailed to update MySQL table", e)

    def delete_employee(self, employee_id):
        try:
            if self.perfomance_score_exists(employee_id):
                cursor = self.connection.cursor()
                query = "DELETE FROM PerformanceReviews WHERE employee_id = %s"
                cursor.execute(query, (employee_id,))
                self.connection.commit()
            cursor = self.connection.cursor()
            query = "DELETE FROM Employees WHERE employee_id = %s"
            cursor.execute(query, (employee_id,))
            self.connection.commit()
            print("\nEmployee deleted successfully. (employee_id: {})".format(employee_id))
        except Error as e:
            print("\nFailed to delete from MySQL table", e)

    def fetch_previous_performance_score(self, employee_id):
        try:
            cursor = self.connection.cursor()
            query = "SELECT performance_score FROM Employees WHERE employee_id = %s"
            cursor.execute(query, (employee_id,))
            result = cursor.fetchall()
            return result[0][0]
        except Error as e:
            print("\nFailed to fetch performance score from MySQL table", e)

    def update_performance_score(self, employee_id, performance_score, review_comments):
        try:
            cursor = self.connection.cursor()
            previous_performance_score = self.fetch_previous_performance_score(employee_id)
            query = "UPDATE Employees SET performance_score = %s WHERE employee_id = %s"
            cursor.execute(query, (performance_score, employee_id))

            if review_comments == "":
                review_comments = "No comments"
            review_comments += f"\nPrevious Performance Score: {previous_performance_score}"
            performance_diff = performance_score - previous_performance_score
            if performance_diff > 0:
                review_comments += f"\nPerformance increased by {performance_diff}"
            elif performance_diff < 0:
                review_comments += f"\nPerformance decreased by {abs(performance_diff)}"
            query = """INSERT INTO PerformanceReviews (employee_id, review_date, review_comments) 
                       VALUES (%s, CURDATE(), %s)"""
            cursor.execute(query, (employee_id, review_comments))

            self.connection.commit()
            print("\nPerformance score updated successfully. (employee_id: {})".format(
                employee_id))
        except Error as e:
            print("\nFailed to update performance score in MySQL table", e)

    def top_performers(self):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Employees WHERE performance_score > 85"
            cursor.execute(query)
            result = cursor.fetchall()
            return result
        except Error as e:
            print("\nFailed to fetch top performers from MySQL table", e)

    def generate_report(self, file_name='Top_Performers_Report.xlsx'):
        top_performers = self.top_performers()

        if not top_performers:
            print("\n--No top performers found--")
            return

        data = []
        employee_list = []
        for performer in top_performers:
            data.append([performer[0], performer[1],
                        performer[2], performer[3], performer[4]])
            employee_list.append(performer[0])

        df = pd.DataFrame(data, columns=[
                          'Employee ID', 'Name', 'Department', 'Designation', 'Performance Score'])
        df.to_excel(file_name, index=False)
        print("\nEmployee ID's who scored top performace are: ", end="")
        print(*employee_list, sep=", ")
        print(f"\nView the full data in excel format: {file_name}")

    def performance_review(self, employee_id):
        try:
            cursor = self.connection.cursor()
            query = """SELECT E.employee_id, E.name, E.department, E.designation, E.performance_score, P.review_date, P.review_comments
                       FROM Employees E
                       LEFT JOIN PerformanceReviews P ON E.employee_id = P.employee_id
                       WHERE E.employee_id = %s"""
            cursor.execute(query, (employee_id,))
            result = cursor.fetchall()
            return result
        except Error as e:
            print("\nFailed to fetch performance review from MySQL table", e)

    def view_employee(self, employee_id):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Employees WHERE employee_id = %s"
            cursor.execute(query, (employee_id,))
            result = cursor.fetchall()
            print("\nEmployee ID: {}\nName: {}\nDepartment: {}\nDesignation: {}\nPerformance Score: {}".format(
                result[0][0], result[0][1], result[0][2], result[0][3], result[0][4]))
        except Error as e:
            print("\nFailed to fetch employee from MySQL table", e)

    def close_connection(self):
        if self.connection.is_connected():
            self.connection.close()
            print("\nMySQL connection is closed")
