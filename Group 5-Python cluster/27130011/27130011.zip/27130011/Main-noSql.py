class Employee:
    def __init__(self, employee_id, name, department, designation, performance_score=0):
        self.employee_id = employee_id
        self.name = name
        self.department = department
        self.designation = designation
        self.performance_score = performance_score

    def __str__(self):
        return (f"ID: {self.employee_id}, Name: {self.name}, Department: {self.department}, "
                f"Designation: {self.designation}, Performance Score: {self.performance_score}")


class EmployeeManagementSystem:
    def __init__(self):
        self.employees = {}

    def add_employee(self, employee):
        if employee.employee_id in self.employees:
            raise ValueError("\nEmployee ID already exists.")
        self.employees[employee.employee_id] = employee

    def update_employee(self, employee_id, name=None, department=None, designation=None, performance_score=None):
        if employee_id not in self.employees:
            raise ValueError("\nEmployee ID not found.")
        if name:
            self.employees[employee_id].name = name
        if department:
            self.employees[employee_id].department = department
        if designation:
            self.employees[employee_id].designation = designation
        if performance_score is not None:
            self.employees[employee_id].performance_score = performance_score

    def delete_employee(self, employee_id):
        if employee_id not in self.employees:
            raise ValueError("\nEmployee ID not found.")
        del self.employees[employee_id]

    def update_performance_score(self, employee_id, performance_score):
        if employee_id not in self.employees:
            raise ValueError("\nEmployee ID not found.")
        self.employees[employee_id].performance_score = performance_score

    def top_performers(self):
        return [employee for employee in self.employees.values() if employee.performance_score > 85]

    def view_employee(self, employee_id):
        if employee_id not in self.employees:
            raise ValueError("\nEmployee ID not found.")
        print(self.employees[employee_id])

    def generate_report(self):
        top_performers = self.top_performers()
        if not top_performers:
            print("\nNo top performers found.")
        tcount = 1
        for employee in top_performers:
            print("\nTop Performing Employees:")
            print(f"{tcount}. {employee}")
            tcount += 1


def main():
    ems = EmployeeManagementSystem()

    while True:
        print("Employee Performance Tracking System".center(50, '-'))
        print("1. Add Employee")
        print("2. Update Employee")
        print("3. Delete Employee")
        print("4. Update Performance Score")
        print("5. Generate Top Performers Report")
        print("6. View Employee")
        print("7. Exit")
        print("-" * 50)
        choice = input("Enter your choice: ")

        if choice == '1':
            employee_id = input("Enter Employee ID: ")
            name = input("Enter Name: ")
            department = input("Enter Department: ")
            designation = input("Enter Designation: ")
            try:
                ems.add_employee(
                    Employee(employee_id, name, department, designation))
                print("Employee added successfully.")
            except ValueError as e:
                print(e)

        elif choice == '2':
            employee_id = input("Enter Employee ID: ")
            name = input("Enter Name (press enter to skip): ")
            department = input("Enter Department (press enter to skip): ")
            designation = input("Enter Designation (press enter to skip): ")
            performance_score = input(
                "Enter Performance Score (press enter to skip): ")
            try:
                if performance_score:
                    performance_score = int(performance_score)
            except ValueError:
                print("Performance Score should be an integer.")
                input("Press any key to continue...")
                continue
            try:
                if name or department or designation or performance_score:
                    if int(performance_score) < 0 or int(performance_score) > 100:
                        raise ValueError(
                            "Performance Score should be between 0 and 100.")
                    else:
                        ems.update_employee(employee_id, name if name else None, department if department else None,
                                            designation if designation else None,
                                            int(performance_score) if performance_score else None)
                        print("Employee updated successfully.")
                else:
                    print("Nothing to update.")
            except ValueError as e:
                print(e)

        elif choice == '3':
            employee_id = input("Enter Employee ID: ")
            try:
                ems.delete_employee(employee_id)
                print("Employee deleted successfully.")
            except ValueError as e:
                print(e)

        elif choice == '4':
            employee_id = input("Enter Employee ID: ")
            performance_score = int(input("Enter Performance Score: "))
            try:
                ems.update_performance_score(employee_id, performance_score)
                print("Performance score updated successfully.")
            except ValueError as e:
                print(e)

        elif choice == '5':
            ems.generate_report()

        elif choice == '6':
            employee_id = input("Enter Employee ID: ")
            print("\n")
            print("Employee Details".center(30, '-'))
            ems.view_employee(employee_id)
            print("-" * 30)

        elif choice == '7':
            break

        else:
            print("Invalid choice. Please try again.")

        input("\nPress any key to continue...")


if __name__ == "__main__":
    main()
