use khaja;
create table employee(employee_id int primary key, Name varchar(100), designation varchar(100), salary decimal(10, 2));
select * from employee;
create table department(department_id int primary key, Name varchar(255), location varchar(255));
create table salary1(salary_id int not null primary key, amount decimal(10, 2), date DATE, employee_id int, Foreign key(employee_id) references employee(employee_id));
INSERT INTO employee (employee_id, Name, designation, salary) VALUES
( 1, 'John Doe', 'Software Engineer', 50000),
( 2, 'Jane Smith', 'Marketing Manager', 60000),
( 3, 'Bob Johnson', 'Sales Representative', 40000),
( 4, 'Maria Rodriguez', 'HR Manager', 55000),
( 5, 'David Lee', 'IT Support Specialist', 45000);
INSERT INTO department (department_id, Name, location) VALUES
( 1, 'IT' , 'New York' ),
( 2 , 'Marketing', 'Los Angeles' ),
( 3 , 'Sales', 'Chicago' );

INSERT INTO salary1 (salary_id, amount, date, employee_id) VALUES
( 1, 50000 , 2022-01-01 , 1),
( 2, 60000 , 2022-01-01 , 2),
( 3, 40000 , 2022-01-01 , 3),
( 4, 55000 , 2022-01-01 , 4),
( 5, 45000 , 2022-01-01 , 5),
( 6, 52000 , 2022-02-01 , 1),
( 7, 62000 , 2022-02-01 , 2),
( 8, 42000 , 2022-02-01 , 3),
( 9, 57000 , 2022-02-01 , 4),
( 10, 47000 , 2022-02-01 , 5);
select * from department;
select * from employee;