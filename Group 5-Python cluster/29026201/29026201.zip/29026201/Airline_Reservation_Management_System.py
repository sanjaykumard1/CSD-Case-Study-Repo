import datetime

class Flight:
    # Represents a flight in the airline system
    all_flights = {}  # Store all flights

    def __init__(self, flight_id, airline, destination, departure_time, available_seats):
        # Initialize a new flight
        self.flight_id = flight_id
        self.airline = airline
        self.destination = destination
        self.departure_time = departure_time
        self.available_seats = available_seats

    def add_flight(flight_id, airline, destination, departure_time, available_seats):
        # Add a new flight to the system
        if flight_id not in Flight.all_flights:
            new_flight = Flight(flight_id, airline, destination, departure_time, available_seats)
            Flight.all_flights[flight_id] = new_flight
            message = "Flight {} added successfully.".format(flight_id)
            print(message)
        else:
            message = "Flight {} already exists.".format(flight_id)
            print(message)

    def update_flight(self, airline=None, destination=None, departure_time=None, available_seats=None):
        # Update existing flight details
        if airline:
            self.airline = airline
        if destination:
            self.destination = destination
        if departure_time:
            self.departure_time = departure_time
        if available_seats is not None:
            self.available_seats = available_seats
        message = "Flight {} updated successfully.".format(self.flight_id)
        print(message)

    def delete_flight(flight_id):
        # Delete a flight from the system
        if flight_id in Flight.all_flights:
            del Flight.all_flights[flight_id]
            message = "Flight {} deleted successfully.".format(flight_id)
            print(message)
        else:
            message = "Flight {} not found.".format(flight_id)
            print(message)

    def __str__(self):
        return "Flight {}: {} to {} at {}, Available seats: {}".format(self.flight_id, self.airline, self.destination, self.departure_time, self.available_seats)

class Reservation:
    # Represents a reservation in the airline system
    all_reservations = {}  # Store all reservations
    reservation_counter = 1  # Counter for generating reservation IDs

    def __init__(self, passenger_name, flight_id, seat_number):
        # Initialize a new reservation
        self.reservation_id = str(Reservation.reservation_counter).zfill(8)
        Reservation.reservation_counter += 1
        self.passenger_name = passenger_name
        self.flight_id = flight_id
        self.seat_number = seat_number
        self.reservation_date = datetime.datetime.now()

    def add_reservation(passenger_name, flight_id, seat_number):
        # Add a new reservation to the system
        if flight_id in Flight.all_flights:
            flight = Flight.all_flights[flight_id]
            if flight.available_seats > 0:
                new_reservation = Reservation(passenger_name, flight_id, seat_number)
                Reservation.all_reservations[new_reservation.reservation_id] = new_reservation
                flight.available_seats -= 1
                message = "Reservation added successfully. Reservation ID: {}".format(new_reservation.reservation_id)
                print(message)
            else:
                message = "No available seats on this flight."
                print(message)
        else:
            message = "Flight {} not found.".format(flight_id)
            print(message)

    def update_reservation(self, passenger_name=None, seat_number=None):
        # Update reservation details
        if passenger_name:
            self.passenger_name = passenger_name
        if seat_number:
            self.seat_number = seat_number
        message = "Reservation {} updated successfully.".format(self.reservation_id)
        print(message)

    def cancel_reservation(reservation_id):
        # Cancel a reservation
        if reservation_id in Reservation.all_reservations:
            reservation = Reservation.all_reservations[reservation_id]
            flight = Flight.all_flights.get(reservation.flight_id)
            if flight:
                flight.available_seats += 1
            del Reservation.all_reservations[reservation_id]
            message = "Reservation {} cancelled successfully.".format(reservation_id)
            print(message)
        else:
            message = "Reservation {} not found.".format(reservation_id)
            print(message)

    def __str__(self):
        return "Reservation {}: {} on Flight {}, Seat {}, Reserved on {}".format(self.reservation_id, self.passenger_name, self.flight_id, self.seat_number, self.reservation_date)

class AirlineManagement:
    # Class to manage the airline reservation system

    def display_menu(self):
        # Display the main menu options
        print("\nAirline Reservation Management System")
        print("1. Add Flight")
        print("2. Update Flight")
        print("3. Delete Flight")
        print("4. Display All Flights")
        print("5. Add Reservation")
        print("6. Update Reservation")
        print("7. Cancel Reservation")
        print("8. Display All Reservations")
        print("9. Generate Flight Report")
        print("10. Exit")

    def generate_flight_report(self, flight_id):
        # Generate a report of all passengers booked on a specific flight
        if flight_id in Flight.all_flights:
            passengers = [res for res in Reservation.all_reservations.values() if res.flight_id == flight_id]
            print("\nPassengers on Flight {}:".format(flight_id))
            for passenger in passengers:
                print("- {}, Seat: {}".format(passenger.passenger_name, passenger.seat_number))
        else:
            message = "Flight {} not found.".format(flight_id)
            print(message)

    def implement(self):
        # Run the airline management system
        while True:
            self.display_menu()
            choice = input("Enter your choice (1-10): ")

            try:
                if choice == "1":
                    flight_id = input("Enter flight ID: ")
                    airline = input("Enter airline: ")
                    destination = input("Enter destination: ")
                    departure_time = input("Enter departure time (YYYY-MM-DD HH:MM): ")
                    available_seats = int(input("Enter available seats: "))
                    Flight.add_flight(flight_id, airline, destination, departure_time, available_seats)

                elif choice == "2":
                    flight_id = input("Enter flight ID to update: ")
                    if flight_id in Flight.all_flights:
                        flight = Flight.all_flights[flight_id]
                        print("Enter new details (press enter to skip):")
                        airline = input("New airline: ")
                        destination = input("New destination: ")
                        departure_time = input("New departure time (YYYY-MM-DD HH:MM): ")
                        available_seats = input("New available seats: ")
                        if airline:
                            flight.airline = airline
                        if destination:
                            flight.destination = destination
                        if departure_time:
                            flight.departure_time = departure_time
                        if available_seats:
                            flight.available_seats = int(available_seats)
                        flight.update_flight()
                    else:
                        message = "Flight {} not found.".format(flight_id)
                        print(message)

                elif choice == "3":
                    flight_id = input("Enter flight ID to delete: ")
                    Flight.delete_flight(flight_id)

                elif choice == "4":
                    for flight in Flight.all_flights.values():
                        print(flight)

                elif choice == "5":
                    passenger_name = input("Enter passenger name: ")
                    flight_id = input("Enter flight ID: ")
                    seat_number = input("Enter seat number: ")
                    Reservation.add_reservation(passenger_name, flight_id, seat_number)

                elif choice == "6":
                    reservation_id = input("Enter reservation ID to update: ")
                    if reservation_id in Reservation.all_reservations:
                        reservation = Reservation.all_reservations[reservation_id]
                        print("Enter new details (press enter to skip):")
                        passenger_name = input("New passenger name: ")
                        seat_number = input("New seat number: ")
                        if passenger_name:
                            reservation.passenger_name = passenger_name
                        if seat_number:
                            reservation.seat_number = seat_number
                        reservation.update_reservation()
                    else:
                        message = "Reservation {} not found.".format(reservation_id)
                        print(message)

                elif choice == "7":
                    reservation_id = input("Enter reservation ID to cancel: ")
                    Reservation.cancel_reservation(reservation_id)

                elif choice == "8":
                    for reservation in Reservation.all_reservations.values():
                        print(reservation)

                elif choice == "9":
                    flight_id = input("Enter flight ID for report: ")
                    self.generate_flight_report(flight_id)

                elif choice == "10":
                    print("Thank you for using the Airline Reservation Management System. Goodbye!")
                    break

                else:
                    print("Invalid choice. Please try again.")

            except Exception as e:
                message = "An error occurred: {}".format(str(e))
                print(message)

# Run the system
management_system = AirlineManagement()
management_system.implement()
