-- Create a new database named Airline_Reservation_Database
CREATE DATABASE Airline_Reservation_Database;

-- Use the newly created database
use Airline_Reservation_Database;

-- Create the Flights table with specified columns and primary key
CREATE TABLE Flights ( flight_id INT PRIMARY KEY,
airline VARCHAR(100),
destination VARCHAR(100),
departure_time DATETIME,
available_seats INT);
    
-- Insert sample data into the Flights table
INSERT INTO Flights (flight_id, airline, destination, departure_time, available_seats)
VALUES (1, 'Air India', 'Mumbai', '2024-07-15 08:00:00', 150),
 (2, 'IndiGo', 'Delhi', '2024-07-15 09:30:00', 200),
 (3, 'SpiceJet', 'Bangalore', '2024-07-15 11:15:00', 180);

-- Create the Passengers table with specified columns and primary key

CREATE TABLE Passengers (passenger_id INT PRIMARY KEY,
name VARCHAR(100),
contact_info VARCHAR(100));

-- Insert sample data into the Passengers table

INSERT INTO Passengers (passenger_id, name, contact_info)
VALUES (1, 'Amit Kumar', 'amit.kumar@example.com'),
 (2, 'Priya Singh', 'priya.singh@example.com'),
 (3, 'Rahul Sharma', 'rahul.sharma@example.com'),
 (4, 'Neha Patel', 'neha.patel@example.com');

-- Create the Reservations table with specified columns, primary key, and foreign key constraints

CREATE TABLE Reservations (reservation_id INT PRIMARY KEY,
passenger_id INT,
flight_id INT,
seat_number VARCHAR(10),
reservation_date DATE,
FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id),
FOREIGN KEY (flight_id) REFERENCES Flights(flight_id));


-- Insert sample data into the Reservations table

INSERT INTO Reservations (reservation_id, passenger_id, flight_id, seat_number, reservation_date)
VALUES (1, 1, 1, 'A1', '2024-07-10'),
 (2, 2, 2, 'B2', '2024-07-12'),
 (3, 3, 1, 'C3', '2024-07-13'),
 (4, 4, 3, 'D4', '2024-07-14'),
 (5, 1, 2, 'E5', '2024-07-15'),
 (6, 2, 3, 'F6', '2024-07-15'),
 (7, 3, 2, 'G7', '2024-07-15');

-- Query to find the total number of seats booked on each flight

SELECT f.flight_id, f.airline, f.destination, COUNT(r.reservation_id) AS booked_seat_count
FROM Flights f
LEFT JOIN Reservations r ON f.flight_id = r.flight_id
GROUP BY f.flight_id;

-- Query to find the names of passengers and the flights they are booked on

SELECT p.name, f.airline, f.destination
FROM Passengers p
JOIN Reservations r ON p.passenger_id = r.passenger_id
JOIN Flights f ON r.flight_id = f.flight_id;

-- Query to find the flights that have never been booked by any passenger


SELECT f.flight_id, f.airline, f.destination
FROM Flights f
LEFT JOIN Reservations r ON f.flight_id = r.flight_id
WHERE r.reservation_id IS NULL;


-- Query to find the passengers who have made reservations for more than 3 flights


SELECT p.passenger_id, p.name, COUNT(r.reservation_id) AS num_reservations
FROM Passengers p
JOIN Reservations r ON p.passenger_id = r.passenger_id
GROUP BY p.passenger_id
HAVING COUNT(r.reservation_id) > 3;


-- Query to find the details of flights with less than 5 available seats


SELECT *
FROM Flights
WHERE available_seats < 5;

