import datetime

# Exception classes
class MembershipError(Exception):
    pass

class TrainerError(Exception):
    pass

class ClassError(Exception):
    pass

class AttendanceError(Exception):
    pass

# Membership class
class Membership:
    def __init__(self, membership_id, member_name, member_contact, membership_type, membership_expiry):
        self.membership_id = membership_id
        self.member_name = member_name
        self.member_contact = member_contact
        self.membership_type = membership_type
        self.membership_expiry = membership_expiry

# Trainer class
class Trainer:
    def __init__(self, trainer_id, name, specialty, contact_info, availability):
        self.trainer_id = trainer_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.availability = availability

# FitnessClass class
class FitnessClass:
    def __init__(self, class_id, class_name, trainer_id, schedule, capacity):
        self.class_id = class_id
        self.class_name = class_name
        self.trainer_id = trainer_id
        self.schedule = schedule
        self.capacity = capacity

# Attendance class
class Attendance:
    def __init__(self, attendance_id, member_id, class_id, attendance_date):
        self.attendance_id = attendance_id
        self.member_id = member_id
        self.class_id = class_id
        self.attendance_date = attendance_date

# Fitness Center Management System
class FitnessCenterManagementSystem:
    def __init__(self):
        self.memberships = {}
        self.trainers = {}
        self.classes = {}
        self.attendances = {}

    # Membership management
    def add_membership(self, membership):
        if membership.membership_id in self.memberships:
            raise MembershipError(f"Membership ID {membership.membership_id} already exists.")
        self.memberships[membership.membership_id] = membership

    def update_membership(self, membership_id, **kwargs):
        if membership_id not in self.memberships:
            raise MembershipError(f"Membership ID {membership_id} does not exist.")
        for key, value in kwargs.items():
            setattr(self.memberships[membership_id], key, value)

    def delete_membership(self, membership_id):
        if membership_id not in self.memberships:
            raise MembershipError(f"Membership ID {membership_id} does not exist.")
        del self.memberships[membership_id]

    # Trainer management
    def add_trainer(self, trainer):
        if trainer.trainer_id in self.trainers:
            raise TrainerError(f"Trainer ID {trainer.trainer_id} already exists.")
        self.trainers[trainer.trainer_id] = trainer

    def update_trainer(self, trainer_id, **kwargs):
        if trainer_id not in self.trainers:
            raise TrainerError(f"Trainer ID {trainer_id} does not exist.")
        for key, value in kwargs.items():
            setattr(self.trainers[trainer_id], key, value)

    def delete_trainer(self, trainer_id):
        if trainer_id not in self.trainers:
            raise TrainerError(f"Trainer ID {trainer_id} does not exist.")
        del self.trainers[trainer_id]

    # Class management
    def add_class(self, fitness_class):
        if fitness_class.class_id in self.classes:
            raise ClassError(f"Class ID {fitness_class.class_id} already exists.")
        self.classes[fitness_class.class_id] = fitness_class

    def update_class(self, class_id, **kwargs):
        if class_id not in self.classes:
            raise ClassError(f"Class ID {class_id} does not exist.")
        for key, value in kwargs.items():
            setattr(self.classes[class_id], key, value)

    def delete_class(self, class_id):
        if class_id not in self.classes:
            raise ClassError(f"Class ID {class_id} does not exist.")
        del self.classes[class_id]

    # Attendance management
    def record_attendance(self, attendance):
        if attendance.attendance_id in self.attendances:
            raise AttendanceError(f"Attendance ID {attendance.attendance_id} already exists.")
        self.attendances[attendance.attendance_id] = attendance

    def update_attendance(self, attendance_id, **kwargs):
        if attendance_id not in self.attendances:
            raise AttendanceError(f"Attendance ID {attendance_id} does not exist.")
        for key, value in kwargs.items():
            setattr(self.attendances[attendance_id], key, value)

    def delete_attendance(self, attendance_id):
        if attendance_id not in self.attendances:
            raise AttendanceError(f"Attendance ID {attendance_id} does not exist.")
        del self.attendances[attendance_id]

# Test the system
if __name__ == "__main__":
    system = FitnessCenterManagementSystem()

    # Add memberships
    m1 = Membership(1, "Abeed", "1234567890", "Gold", datetime.date(2023, 12, 31))
    m2 = Membership(2, "Divisha", "0987654321", "Silver", datetime.date(2023, 11, 30))
    system.add_membership(m1)
    system.add_membership(m2)

    # Add trainers
    t1 = Trainer(1, "Sooraj", "Yoga", "Sooraj@example.com", "MWF")
    t2 = Trainer(2, "Devesh", "Cardio", "Devesh@example.com", "TTh")
    system.add_trainer(t1)
    system.add_trainer(t2)

    # Add classes
    c1 = FitnessClass(1, "Morning Yoga", 1, "08:00 AM", 20)
    c2 = FitnessClass(2, "Evening Cardio", 2, "06:00 PM", 15)
    system.add_class(c1)
    system.add_class(c2)

    # Record attendance
    a1 = Attendance(1, 1, 1, datetime.date(2023, 7, 10))
    a2 = Attendance(2, 2, 2, datetime.date(2023, 7, 11))
    system.record_attendance(a1)
    system.record_attendance(a2)

    # Display current records
    print("Memberships:")
    for membership in system.memberships.values():
        print(vars(membership))

    print("\nTrainers:")
    for trainer in system.trainers.values():
        print(vars(trainer))

    print("\nClasses:")
    for fitness_class in system.classes.values():
        print(vars(fitness_class))

    print("\nAttendance records:")
    for attendance in system.attendances.values():
        print(vars(attendance))

    # Update and delete examples
    system.update_membership(1, member_contact="1112223333")
    system.delete_trainer(2)

    print("\nUpdated Memberships:")
    for membership in system.memberships.values():
        print(vars(membership))

    print("\nUpdated Trainers:")
    for trainer in system.trainers.values():
        print(vars(trainer))
