### Database Schema
import mysql.connector as a 
con = a.connect(host="localhost"
                user="root",
                passwd="12345678")

#### 1. Memberships Table
sql
CREATE TABLE Memberships (
    membership_id INT PRIMARY KEY AUTO_INCREMENT,
    member_name VARCHAR(255) NOT NULL,
    member_contact VARCHAR(20) NOT NULL,
    membership_type VARCHAR(50) NOT NULL,
    membership_expiry DATE NOT NULL
);


#### 2. Trainers Table
sql
CREATE TABLE Trainers (
    trainer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    specialty VARCHAR(50) NOT NULL,
    contact_info VARCHAR(255) NOT NULL,
    availability TEXT NOT NULL
);


#### 3. Classes Table
sql
CREATE TABLE Classes (
    class_id INT PRIMARY KEY AUTO_INCREMENT,
    class_name VARCHAR(100) NOT NULL,
    trainer_id INT,
    schedule DATETIME NOT NULL,
    capacity INT NOT NULL,
    FOREIGN KEY (trainer_id) REFERENCES Trainers(trainer_id)
);


#### 4. Attendance Table
sql
CREATE TABLE Attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT,
    class_id INT,
    attendance_date DATE NOT NULL,
    FOREIGN KEY (member_id) REFERENCES Memberships(membership_id),
    FOREIGN KEY (class_id) REFERENCES Classes(class_id)
);


-- # ### Problem Statements

-- # #### 1. Query to find the total number of members whose memberships expire in the next month
-- # sql
-- # SELECT COUNT(*) AS total_members
-- # FROM Memberships
-- # WHERE membership_expiry BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH);


-- # #### 2. Query to find the trainers who are available for a specific specialty
-- # sql
-- # SELECT *
-- # FROM Trainers
-- # WHERE specialty = 'specific_specialty';

-- # #Replace 'specific_specialty' with the actual specialty you're searching for.

-- # #### 3. Query to find the classes that are fully booked
-- # sql
-- # SELECT c.class_id, c.class_name, c.trainer_id, c.schedule, c.capacity, COUNT(a.attendance_id) AS attendance_count
-- # FROM Classes c
-- # JOIN Attendance a ON c.class_id = a.class_id
-- # GROUP BY c.class_id
-- # HAVING attendance_count >= c.capacity;


-- # #### 4. Query to find the members who have attended the most classes in the past month
-- # sql
-- # SELECT m.member_name, COUNT(a.attendance_id) AS classes_attended
-- # FROM Attendance a
-- # JOIN Memberships m ON a.member_id = m.membership_id
-- # WHERE a.attendance_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE()
-- # GROUP BY a.member_id
-- # ORDER BY classes_attended DESC
-- # LIMIT 1;


-- # #### 5. Query to find the schedule and details of classes conducted by a specific trainer
-- # sql
-- # SELECT c.class_id, c.class_name, c.schedule, c.capacity, t.name AS trainer_name
-- # FROM Classes c
-- # JOIN Trainers t ON c.trainer_id = t.trainer_id
-- # WHERE t.trainer_id = specific_trainer_id;

-- # #Replace specific_trainer_id with the actual trainer ID you are searching for.

-- # ### Example Data Insertions

-- # #### Insert Sample Data into Memberships
-- # sql
-- # INSERT INTO Memberships (member_name, member_contact, membership_type, membership_expiry) VALUES
-- # ('Abeed', '1234567890', 'Gold', '2023-12-31'),
-- # ('Divisha', '0987654321', 'Silver', '2023-11-30');


-- # #### Insert Sample Data into Trainers
-- # sql
-- # INSERT INTO Trainers (name, specialty, contact_info, availability) VALUES
-- # ('Sooraj', 'Yoga', 'Sooraj@example.com', 'MWF'),
-- # ('Devesh', 'Cardio', 'Devesh@example.com', 'TTh');


-- # #### Insert Sample Data into Classes
-- # sql
-- # INSERT INTO Classes (class_name, trainer_id, schedule, capacity) VALUES
-- # ('Morning Yoga', 1, '2023-07-12 08:00:00', 20),
-- # ('Evening Cardio', 2, '2023-07-12 18:00:00', 15);


-- # #### Insert Sample Data into Attendance
-- # sql
-- # INSERT INTO Attendance (member_id, class_id, attendance_date) VALUES
-- # (1, 1, '2023-07-10'),
-- # (2, 2, '2023-07-11');
