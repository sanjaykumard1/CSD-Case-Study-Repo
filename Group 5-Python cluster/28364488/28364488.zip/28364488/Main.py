import datetime

# Class representing a menu item
class MenuItem:
    def __init__(self, item_id, name, category, price, availability=True):
        self.item_id = item_id
        self.name = name
        self.category = category
        self.price = price
        self.availability = availability

    def __str__(self):
        return f"item_id : {self.item_id}, Name : {self.name}, Category : {self.category}, Price : ₹{self.price}, Availability : {'Available' if self.availability else 'Not Available'}"

# Class representing a customer
class Customer:
    def __init__(self, customer_id, name, contact_number, email):
        self.customer_id = customer_id
        self.name = name
        self.contact_number = contact_number
        self.email = email

    def __str__(self):
        return f"Customer ID: {self.customer_id}, Name: {self.name}, Contact Number: {self.contact_number}, Email: {self.email}"

# Class representing an order
class Order:
    def __init__(self, order_id, customer_id, item_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.item_id = item_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order ID: {self.order_id}, Customer ID: {self.customer_id}, Item ID: {self.item_id}, Order Date: {self.order_date}, Quantity: {self.quantity}"

# Class for managing menu items
class MenuManagement:
    def __init__(self):
        self.menu_items = {}

    # Add a new menu item
    def add_menu_item(self, item_id, name, category, price, availability=True):
        if item_id in self.menu_items:
            raise ValueError(f"Menu item with ID {item_id} already exists.")
        new_item = MenuItem(item_id, name, category, price, availability)
        self.menu_items[item_id] = new_item
        print(f"Added menu item: {new_item}")

    # Update an existing menu item
    def update_menu_item(self, item_id, name=None, category=None, price=None, availability=None):
        if item_id not in self.menu_items:
            raise ValueError(f"Menu item with ID {item_id} not found.")
        item = self.menu_items[item_id]
        if name is not None:
            item.name = name
        if category is not None:
            item.category = category
        if price is not None:
            item.price = price
        if availability is not None:
            item.availability = availability
        print(f"Updated menu item: {item}")
        
    # Delete a menu item
    def delete_menu_item(self, item_id):
        if item_id not in self.menu_items:
            raise ValueError(f"Menu item with ID {item_id} not found.")
        deleted_item = self.menu_items.pop(item_id)
        print(f"Deleted menu item: {deleted_item}")

    # Display all menu items
    def display_menu(self):
        if not self.menu_items:
            print("No menu items available.")
        else:
            for item in self.menu_items.values():
                print(item)

# Class for managing customers
class CustomerManagement:
    def __init__(self):
        self.customers = {}

    # Add new Customer
    def add_customer(self, customer_id, name, contact_number, email):
        if customer_id in self.customers:
            raise ValueError(f"Customer with ID {customer_id} already exists.")
        new_customer = Customer(customer_id, name, contact_number, email)
        self.customers[customer_id] = new_customer
        print(f"Added customer: {new_customer}")
        
    # Update an existing customer
    def update_customer(self, customer_id, name=None, contact_number=None, email=None):
        if customer_id not in self.customers:
            raise ValueError(f"Customer with ID {customer_id} not found.")
        customer = self.customers[customer_id]
        if name is not None:
            customer.name = name
        if contact_number is not None:
            customer.contact_number = contact_number
        if email is not None:
            customer.email = email
        print(f"Updated customer: {customer}")
        
    # Delete a customer
    def delete_customer(self, customer_id):
        if customer_id not in self.customers:
            raise ValueError(f"Customer with ID {customer_id} not found.")
        deleted_customer = self.customers.pop(customer_id)
        print(f"Deleted customer: {deleted_customer}")

    # Display all customers
    def display_customers(self):
        if not self.customers:
            print("No customers available.")
        else:
            for customer in self.customers.values():
                print(customer)

# Class for managing orders
class OrderManagement:
    def __init__(self):
        self.orders = {}

    # Add a new order
    def add_order(self, order_id, customer_id, item_id, order_date, quantity):
        if order_id in self.orders:
            raise ValueError(f"Order with ID {order_id} already exists.")
        new_order = Order(order_id, customer_id, item_id, order_date, quantity)
        self.orders[order_id] = new_order
        print(f"Added order: {new_order}")

    # Update an existing order
    def update_order(self, order_id, customer_id=None, item_id=None, order_date=None, quantity=None):
        if order_id not in self.orders:
            raise ValueError(f"Order with ID {order_id} not found.")
        order = self.orders[order_id]
        if customer_id is not None:
            order.customer_id = customer_id
        if item_id is not None:
            order.item_id = item_id
        if order_date is not None:
            order.order_date = order_date
        if quantity is not None:
            order.quantity = quantity
        print(f"Updated order: {order}")

    # Cancel an order
    def cancel_order(self, order_id):
        if order_id not in self.orders:
            raise ValueError(f"Order with ID {order_id} not found.")
        canceled_order = self.orders.pop(order_id)
        print(f"Canceled order: {canceled_order}")

    # Display all orders
    def display_orders(self):
        if not self.orders:
            print("No orders available.")
        else:
            for order in self.orders.values():
                print(order)

# Main class for the restaurant management system
class RestaurantManagementSystem:
    def __init__(self):
        self.menu_management = MenuManagement()
        self.customer_management = CustomerManagement()
        self.order_management = OrderManagement()

    #Main function to display to handle user choices
    def Main(self):
        while True:
            print(f"\n{'-'*10} Restaurant Management System {'-'*10}\n1. Manage Menu\n2. Manage Customers\n3. Manage Orders\n4. Exit")
            choice = input("Enter your choice: ")

            match(choice):
                case'1':
                    self.manage_menu()
                case '2':
                    self.manage_customers()
                case '3':
                    self.manage_orders()
                case '4':
                    print("Exiting the Reataurant Managemrnt System.")
                    break
                case _:
                    print("Invalid choice. Please try again.")

    # Function to manage menu items
    def manage_menu(self):
        while True:
            print("\n{'-'*10} Manage Menu {'-'*10}\n1. Add Menu Item\n2. Update Menu Item\n3. Delete Menu Item\n4. Display Menu\n5. Back")
            choice = input("Enter your choice: ")

            try:
                match(choice):
                    case '1':
                        item_id = int(input("Enter item ID: "))
                        name = input("Enter item name: ")
                        category = input("Enter item category: ")
                        price = float(input("Enter item price: "))
                        availability = input("Is the item available? (yes/no): ").lower() == 'yes'
                        self.menu_management.add_menu_item(item_id, name, category, price, availability)
                    case'2':
                        item_id = int(input("Enter item ID: "))
                        name = input("Enter new name (Press Enter to Skip) : ")
                        category = input("Enter new category (Press Enter to Skip) : ")
                        price = input("Enter new price (Press Enter to Skip) : ")
                        availability = input("Is the item available? (yes/no) (Press Enter to Skip) : ").lower()
                        self.menu_management.update_menu_item(
                            item_id, 
                            name if name else None, 
                            category if category else None, 
                            float(price) if price else None, 
                            availability == 'yes' if availability else None
                        )
                    case'3':
                        item_id = int(input("Enter item ID to delete: "))
                        self.menu_management.delete_menu_item(item_id)
                    case'4':
                        self.menu_management.display_menu()
                    case'5':
                        break
                    case _:
                        print("Invalid choice. Please try again.")
            except ValueError as e:
                print(f"Error: {e}. Please enter valid data.")

    # Function to manage customers
    def manage_customers(self):
        while True:
            print(f"\n{'-'*10} Manage Customers{'-'*10}\n1. Add Customer\n2. Update Customer\n3. Delete Customer\n4. Display Customers\n5. Back""")
            choice = input("Enter your choice: ")

            try:
                match(choice):
                    case'1':
                        customer_id = int(input("Enter customer ID: "))
                        name = input("Enter customer name: ")
                        contact_number = input("Enter contact number: ")
                        email = input("Enter email: ")
                        self.customer_management.add_customer(customer_id, name, contact_number, email)
                        
                    case '2':
                        customer_id = int(input("Enter customer ID: "))
                        name = input("Enter new name (Press Enter to Skip) : ")
                        contact_number = input("Enter new contact number (Press Enter to Skip) : ")
                        email = input("Enter new email (Press Enter to Skip) : ")
                        self.customer_management.update_customer(
                            customer_id, 
                            name if name else None, 
                            contact_number if contact_number else None, 
                            email if email else None
                        )
                    case '3':
                        customer_id = int(input("Enter customer ID to delete: "))
                        self.customer_management.delete_customer(customer_id)
                    case '4':
                        self.customer_management.display_customers()
                    case '5':
                        break
                    case _:
                        print("Invalid choice. Please try again.")
            except ValueError as e:
                print(f"Error: {e}. Please enter valid data.")

    # Function to manage orders
    def manage_orders(self):
        while True:
            print("\n{'-'*10} Manage Orders {'-'*10}\n1. Add Order\n2. Update Order\n3. Cancel Order\n4. Display Orders\n5. Back")
            choice = input("Enter your choice: ")

            try:
                match(choice):
                    case '1':
                        order_id = int(input("Enter order ID: "))
                        customer_id = int(input("Enter customer ID: "))
                        item_id = int(input("Enter item ID: "))
                        order_date = input("Enter order date (YYYY-MM-DD): ")
                        quantity = int(input("Enter quantity: "))
                        self.order_management.add_order(order_id, customer_id, item_id, datetime.date.fromisoformat(order_date), quantity)
                    case'2':
                        order_id = int(input("Enter order ID: "))
                        customer_id = input("Enter new customer ID (Press Enter to Skip) : ")
                        item_id = input("Enter new item ID (Press Enter to Skip) : ")
                        order_date = input("Enter new order date (YYYY-MM-DD) (Press Enter to Skip) : ")
                        quantity = input("Enter new quantity (Press Enter to Skip) : ")
                        self.order_management.update_order(
                            order_id, 
                            int(customer_id) if customer_id else None, 
                            int(item_id) if item_id else None, 
                            datetime.date.fromisoformat(order_date) if order_date else None, 
                            int(quantity) if quantity else None
                        )
                    case'3':
                        order_id = int(input("Enter order ID to cancel: "))
                        self.order_management.cancel_order(order_id)
                    case'4':
                        self.order_management.display_orders()
                    case'5':
                        break
                    case _:
                        print("Invalid choice. Please try again.")
            except ValueError as e:
                print(f"Error: {e}. Please enter valid data.")

# Create an instance of the restaurant management system and start the main function
restaurant_management_system = RestaurantManagementSystem()
restaurant_management_system.Main()
