 -- Creating DataBase
CREATE DATABASE RestaurantManagementStudy;

-- Using the DataBase
USE RestaurantManagementStudy; 

-- Creating the MenuItems Table
CREATE TABLE MenuItems(
	item_id INT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2),
    availability BOOLEAN
    );

-- Creating the Customers Table
CREATE TABLE Customers(
	customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_number VARCHAR(15),
    email VARCHAR(100)
    );

-- creating the Orders Table
CREATE TABLE Orders(
	order_id INT PRIMARY KEY,
    customer_id INT,
    item_id INT,
    order_date DATE,
    quantity INT,
    FOREIGN KEY(customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY(item_id) REFERENCES MenuItems(item_id)
    );
    
-- Query to find the Total revenue generated from all Orders
SELECT SUM(O.quantity * M.price) AS total_revenue FROM Orders O 
JOIN MenuItems M ON O.item_id = M.item_id;

-- Query to find the Names and Contact numbers of Customers who have placed more than five orders
SELECT C.name ,C.contact_number FROM Customers C 
JOIN Orders O ON C.customer_id = O.customer_id
GROUP BY C.customer_id,C.name,C.contact_number Having COUNT(O.order_id)>5;

-- Query to find MenuItems that are currently Unavailable
SELECT name,category,price FROM MenuItems WHERE availability = FALSE;

-- Query to find customers who have ordered items from more than three different categories
SELECT C.name,C.contact_number FROM Customers C JOIN Orders O on C.customer_id = O.customer_id 
JOIN MenuItems M ON O.item_id = M.item-id 
GROUP BY C.customer_id,C.name,C.contact_number HAVING COUNT(DISTINCT M.category) >3;

-- Query to find Details of Orders Placed in the Last 7 Days
SELECT O.order_id ,C.name as customer_name, M.name AS item_name,
O.order_date, O.quantity FROM Orders O 
JOIN Customers C ON O>customer_id = C.customer_id 
JOIN MenuItems M ON O.item_id = M.item_id WHERE O.order_date >= CURDATE() - INTERVAL 7 DAY;
    
    