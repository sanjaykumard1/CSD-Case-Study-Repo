from src.db_config import db_config
from src.patient_management import PatientManagement
from src.doctor_management import DoctorsManagement
from src.appointment_management import AppointmentManagement

def main_menu():
    P = PatientManagement()
    D = DoctorsManagement()
    A = AppointmentManagement()

    while True:
        print("\n----- Health Clinic   ------")
        print("1. Manage Patients")
        print("2. Manage Doctors")
        print("3. Manage Appointments")
        print("4. Exit")
        print("-----------------------------")
        choice = input("Select an option: ")
        

        if choice == "1":
            manage_patients(P)
        elif choice == "2":
            manage_doctors(D)
        elif choice == "3":
            manage_appointments(A)
        elif choice == "4":
            P.close_connection()
            D.close_connection()
            A.close_connection()
            break
        else:
            print("Invalid option, please try again.")
            

def manage_patients(P):
    while True:
        print("\n=== Patient Management ===")
        print("1. Add Patient")
        print("2. Update Patient")
        print("3. Delete Patient")
        print("4. View Patient")
        print("5. Back to Main Menu")
        print("-----------------------------")
        choice = input("Select an option: ")

        if choice == "1":
            new_patient = P.input_patient()
            P.add_patient(new_patient)
            print("ADDED PATIENT: ", P.get_patient(new_patient.patient_id))
        elif choice == "2":
            patient_id = input("Enter patient ID to update: ")
            if P.get_patient(patient_id) != "Patient not found":
                updates = {}
                print("Leave fields empty to keep current value.")
                name = input("Enter new name: ")
                if name: updates['name'] = name
                dob = input("Enter new date of birth (DD-MM-YYYY): ")
                if dob: updates['date_of_birth'] = dob
                gender = input("Enter new gender: ")
                if gender: updates['gender'] = gender
                contact_info = input("Enter new contact info: ")
                if contact_info: updates['contact_info'] = contact_info
                P.update_patient(patient_id, **updates)
                print("UPDATED PATIENT: ", P.get_patient(patient_id))
            else:
                print("Patient not found")
        elif choice == "3":
            patient_id = input("Enter patient ID to delete: ")
            if P.get_patient(patient_id) != "Patient not found":
                P.delete_patient(patient_id)
                print(f"Patient {patient_id} deleted successfully.")
            else:
                print("Patient not found")
        elif choice == "4":
            patient_id = input("Enter patient ID to view: ")
            print(P.get_patient(patient_id))
        elif choice == "5":
            break
        else:
            print("Invalid option, please try again.")

def manage_doctors(D):
    while True:
        print("\n=== Doctor Management ===")
        print("1. Add Doctor")
        print("2. Update Doctor")
        print("3. Delete Doctor")
        print("4. View Doctor")
        print("5. Back to Main Menu")
        print("-----------------------------")
        choice = input("Select an option: ")

        if choice == "1":
            new_doctor = D.input_doctors()
            D.add_doctors(new_doctor)
            print("ADDED DOCTOR: ", D.get_doctors(new_doctor.doctor_id))
        elif choice == "2":
            doctor_id = input("Enter doctor ID to update: ")
            if D.get_doctors(doctor_id) != "Doctor not found":
                updates = {}
                print("Leave fields empty to keep current value.")
                name = input("Enter new name: ")
                if name: updates['name'] = name
                specialty = input("Enter new specialty: ")
                if specialty: updates['specialty'] = specialty
                contact_info = input("Enter new contact info: ")
                if contact_info: updates['contact_info'] = contact_info
                available_dates = input("Enter new available dates (comma-separated, e.g., 01-01-2022,02-02-2022): ")
                if available_dates: updates['available_dates'] = available_dates.split(',')
                D.update_doctors(doctor_id, **updates)
                print("UPDATED DOCTOR: ", D.get_doctors(doctor_id))
            else:
                print("Doctor not found")
        elif choice == "3":
            doctor_id = input("Enter doctor ID to delete: ")
            if D.get_doctors(doctor_id) != "Doctor not found":
                D.delete_doctors(doctor_id)
                print(f"Doctor {doctor_id} deleted successfully.")
            else:
                print("Doctor not found")
        elif choice == "4":
            doctor_id = input("Enter doctor ID to view: ")
            print(D.get_doctors(doctor_id))
        elif choice == "5":
            break
        else:
            print("Invalid option, please try again.")

def manage_appointments(A):
    while True:
        print("\n=== Appointment Management ===")
        print("1. Schedule Appointment")
        print("2. Update Appointment")
        print("3. Cancel Appointment")
        print("4. View Appointment")
        print("5. Back to Main Menu")
        print("-----------------------------")
        choice = input("Select an option: ")

        if choice == "1":
            new_appointment = A.input_appointment()
            A.schedule_appointment(new_appointment)
            print("SCHEDULED APPOINTMENT: ", A.get_appointment(new_appointment.appointment_id))
        elif choice == "2":
            appointment_id = input("Enter appointment ID to update: ")
            if A.get_appointment(appointment_id) != "Appointment not found":
                updates = {}
                print("Leave fields empty to keep current value.")
                patient_id = input("Enter new patient ID: ")
                if patient_id: updates['patient_id'] = patient_id
                doctor_id = input("Enter new doctor ID: ")
                if doctor_id: updates['doctor_id'] = doctor_id
                appointment_date = input("Enter new appointment date (DD-MM-YYYY): ")
                if appointment_date: updates['appointment_date'] = appointment_date
                reason = input("Enter new reason for appointment: ")
                if reason: updates['reason'] = reason
                A.update_appointment(appointment_id, **updates)
                print("UPDATED APPOINTMENT: ", A.get_appointment(appointment_id))
            else:
                print("Appointment not found")
        elif choice == "3":
            appointment_id = input("Enter appointment ID to cancel: ")
            if A.get_appointment(appointment_id) != "Appointment not found":
                A.cancel_appointment(appointment_id)
                print(f"Appointment {appointment_id} canceled successfully.")
            else:
                print("Appointment not found")
        elif choice == "4":
            appointment_id = input("Enter appointment ID to view: ")
            print(A.get_appointment(appointment_id))
        elif choice == "5":
            break
        else:
            print("Invalid option, please try again.")

if __name__ == "__main__":
    main_menu()
