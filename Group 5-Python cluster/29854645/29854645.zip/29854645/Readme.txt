#Health Clinic Management System
Software Used:
Python 3.12 
MySQL 3.9
MySQL workbench 8.0 CE

Steps to run the Python File

Step 1: Create 3 Individual Table in the MySQL Database  such as follows:


CREATE TABLE Patients (
    patient_id INT PRIMARY KEY ,
    name VARCHAR(255) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) NOT NULL,
    contact_info VARCHAR(255) NOT NULL
);
CREATE TABLE Doctors (
    doctor_id INT PRIMARY KEY ,
    name VARCHAR(255) NOT NULL,
    specialty VARCHAR(255) NOT NULL,
    contact_info VARCHAR(255) NOT NULL,
    available_dates TEXT
);
CREATE TABLE Appointments (
    appointment_id INT PRIMARY KEY ,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE,
    reason VARCHAR(255),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
);

Step 2: After created table in the database change the db_config file according to MySQL server or client CMD such as host, user, password, database.

Step 3(optional): after change the db_config check the connection if it is working using MySQL workbench if it positive or not.

Step 4: if the table is created successfully you directly go to python IDLE and run the app.py

Step 5: Using Console in you give input use the application.

Step 6: The Change that you make in console also affect the database file.
