import mysql.connector

class Doctors:
    def __init__(self, doctor_id, name, specialty, contact_info, available_dates):
        self.doctor_id = doctor_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.available_dates = available_dates

    def __str__(self):
        return (f"Doctors[ID={self.doctor_id}, NAME={self.name}, SPECIALITY={self.specialty}, "
                f"CONTACT.NO-={self.contact_info}, AVAILABLE DATES ={self.available_dates}]")

class DoctorsManagement:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost", user="root", passwd="Sabari@123", database="health_clinic",auth_plugin='mysql_native_password')
        self.cursor = self.conn.cursor()

    def add_doctors(self, doctors):
        sql = "INSERT INTO doctors (doctor_id, name, specialty, contact_info, available_dates) VALUES (%s, %s, %s, %s, %s)"
        available_dates_str = ','.join(doctors.available_dates)
        vals = (doctors.doctor_id, doctors.name, doctors.specialty, doctors.contact_info, available_dates_str)
        self.cursor.execute(sql, vals)
        self.conn.commit()

    def update_doctors(self, doctor_id, **kwargs):
        updates = []
        values = []
        
        for key, value in kwargs.items():
            if key == 'available_dates' and isinstance(value, list):
                value = ','.join(value)  # Convert list to a comma-separated string
            updates.append(f"{key} = %s")
            values.append(value)
        
        updates_str = ", ".join(updates)
        sql = f"UPDATE doctors SET {updates_str} WHERE doctor_id = %s"
        values.append(doctor_id)
        
        self.cursor.execute(sql, values)
        self.conn.commit()

    def delete_doctors(self, doctor_id):
        sql = "DELETE FROM doctors WHERE doctor_id = %s"
        self.cursor.execute(sql, (doctor_id,))
        self.conn.commit()

    def get_doctors(self, doctor_id):
        sql = "SELECT * FROM doctors WHERE doctor_id = %s"
        self.cursor.execute(sql, (doctor_id,))
        result = self.cursor.fetchone()
        if result:
            doctor_id, name, specialty, contact_info, available_dates = result
            available_dates_list = available_dates.split(',')  # Convert string back to list
            return Doctors(doctor_id, name, specialty, contact_info, available_dates_list)
        else:
            return "Doctor not found"

    def close_connection(self):
        self.cursor.close()
        self.conn.close()

    def input_doctors(self):
        doctor_id = int(input("Enter doctor ID: "))
        name = str(input("Enter doctor name: "))
        specialty = input("Enter specialty: ")
        contact_info = int(input("Enter contact info: "))
        available_dates = input("Enter available dates (comma-separated, e.g., 01-01-2022,02-02-2022): ").split(",")
        return Doctors(doctor_id, name, specialty, contact_info, available_dates)
