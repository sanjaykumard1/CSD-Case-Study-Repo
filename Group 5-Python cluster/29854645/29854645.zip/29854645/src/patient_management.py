import mysql.connector

class Patient:
    def __init__(self, patient_id, name, date_of_birth, gender, contact_info):
        self.patient_id = patient_id
        self.name = name
        self.date_of_birth = date_of_birth
        self.gender = gender
        self.contact_info = contact_info

    def __str__(self):
        return (f"Patient [ID={self.patient_id}, NAME={self.name}, DATE OF BIRTH={self.date_of_birth}, "
                f"GENDER={self.gender}, CONTACT_INFO={self.contact_info}]")

class PatientManagement:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost", user="root", passwd="Sabari@123", database="health_clinic",auth_plugin='mysql_native_password')
        self.cursor = self.conn.cursor()

    def add_patient(self, patient):
        sql = "INSERT INTO patients (patient_id, name, date_of_birth, gender, contact_info) VALUES (%s, %s, %s, %s, %s)"
        vals = (patient.patient_id, patient.name, patient.date_of_birth, patient.gender, patient.contact_info)
        self.cursor.execute(sql, vals)
        self.conn.commit()

    def update_patient(self, patient_id, **kwargs):
        updates = ", ".join([f"{key} = %s" for key in kwargs.keys()])
        values = list(kwargs.values())
        values.append(patient_id)
        sql = f"UPDATE patients SET {updates} WHERE patient_id = %s"
        self.cursor.execute(sql, values)
        self.conn.commit()

    def delete_patient(self, patient_id):
        sql = "DELETE FROM patients WHERE patient_id = %s"
        self.cursor.execute(sql, (patient_id,))
        self.conn.commit()

    def get_patient(self, patient_id):
        sql = "SELECT * FROM patients WHERE patient_id = %s"
        self.cursor.execute(sql, (patient_id,))
        result = self.cursor.fetchone()
        if result:
            return Patient(*result)
        else:
            return "Patient not found"

    def close_connection(self):
        self.cursor.close()
        self.conn.close()

    def input_patient(self):
        patient_id = int(input("Enter your patient ID: "))
        name = str(input("Enter your patient name: "))
        date_of_birth = input("Enter your date of birth (DD-MM-YYYY): ")
        gender = str(input("Enter your gender: "))
        contact_info = int(input("Enter your contact info: "))
        return Patient(patient_id, name, date_of_birth, gender, contact_info)
