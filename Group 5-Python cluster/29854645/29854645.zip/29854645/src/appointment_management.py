import mysql.connector

class Appointment:
    def __init__(self, appointment_id, patient_id, doctor_id, appointment_date, reason):
        self.appointment_id = appointment_id
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.appointment_date = appointment_date
        self.reason = reason

    def __str__(self):
        return (f"Appointment[ID={self.appointment_id}, PATIENT ID={self.patient_id}, "
                f"DOCTOR ID={self.doctor_id}, APPOINTMENT DATE={self.appointment_date}, REASON ={self.reason}]")

class AppointmentManagement:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost", user="root", passwd="Sabari@123", database="health_clinic",auth_plugin='mysql_native_password')
        self.cursor = self.conn.cursor()

    def schedule_appointment(self, appointment):
        if not self._patient_exists(appointment.patient_id):
            print(f"Patient ID {appointment.patient_id} does not exist.")
            return
        if not self._doctor_exists(appointment.doctor_id):
            print(f"Doctor ID {appointment.doctor_id} does not exist.")
            return
        sql = "INSERT INTO Appointments (appointment_id, patient_id, doctor_id, appointment_date, reason) VALUES (%s, %s, %s, %s, %s)"
        vals = (appointment.appointment_id, appointment.patient_id, appointment.doctor_id, appointment.appointment_date, appointment.reason)
        try:
            self.cursor.execute(sql, vals)
            self.conn.commit()
            print("Appointment scheduled successfully.")
        except mysql.connector.Error as err:
            print(f"Error: {err}")

    def update_appointment(self, appointment_id, **kwargs):
        updates = ", ".join([f"{key} = '{value}'" for key, value in kwargs.items()])
        sql = f"UPDATE Appointments SET {updates} WHERE appointment_id = {appointment_id}"
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            print("Appointment updated successfully.")
        except mysql.connector.Error as err:
            print(f"Error: {err}")

    def cancel_appointment(self, appointment_id):
        sql = "DELETE FROM Appointments WHERE appointment_id = %s"
        try:
            self.cursor.execute(sql, (appointment_id,))
            self.conn.commit()
            print("Appointment canceled successfully.")
        except mysql.connector.Error as err:
            print(f"Error: {err}")

    def get_appointment(self, appointment_id):
        sql = "SELECT * FROM Appointments WHERE appointment_id = %s"
        self.cursor.execute(sql, (appointment_id,))
        result = self.cursor.fetchone()
        if result:
            return Appointment(*result)
        else:
            return "Appointment not found"

    def input_appointment(self):
        appointment_id = input("Enter your appointment ID: ")
        patient_id = input("Enter your patient ID: ")
        doctor_id = input("Enter your doctor ID: ")
        appointment_date = input("Enter your appointment date: ")
        reason = input("Enter the reason for the appointment: ")
        return Appointment(appointment_id, patient_id, doctor_id, appointment_date, reason)

    def close_connection(self):
        self.cursor.close()
        self.conn.close()

    def _patient_exists(self, patient_id):
        sql = "SELECT 1 FROM patients WHERE patient_id = %s"
        self.cursor.execute(sql, (patient_id,))
        return self.cursor.fetchone() is not None


    def _doctor_exists(self, doctor_id):
        sql = "SELECT 1 FROM doctors WHERE doctor_id = %s"
        self.cursor.execute(sql, (doctor_id,))
        return self.cursor.fetchone() is not None
0
