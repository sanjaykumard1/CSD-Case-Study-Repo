# Employee Management System

This case study is an Employee Management System developed using Python and MySQL. The system allows you to manage employees, departments, and salaries with functionalities to add, update, delete, and display records.

# Prerequisites

Ensure the following are installed:
1. Python 3.x
2. MySQL Server
3. MySQL Connector for Python

# After installing create a directory
1. Create a directory name as "Canditate ID"
2. Redirect to that directory install the commamd "pip install mysql-connector-python"
3. Write queries to create_database, insert values and queries for the problem_statement given in the case study in VS Code
4. Using python, write code to implement the functionalities of employee , department and salaries


# Database_Setup
1. Start your MySQL server and log in to the MySQL prompt.
2. use command "mysql -u root -p -h localhost -P 3305" 
3. Enter the correct password and make connection
4. Execute the SQL queries successfully

# Integrate
1. After successfully executing the queries. Make connection between MySQL and python by importing mysql.connector
2. Run the project folder in cmd by giving the command "python main.py"
3. The application will present you a menu of options: 
   Employee Management System
   1. Add Employee
   2. Update Employee
   3. Delete Employee
   4. Display Employees
   5. Add Department
   6. Update Department
   7. Delete Department
   8. Display Departments
   9. Add Salary
   10. Update Salary
   11. Delete Salary
   12. Display Salaries
   13. Exit
   Enter your choice:

4. Enter the corresponding number to perform the desired operation. Follow the prompts to enter necessary details.  

# File description
1. console_app/main.py: Main script to run the application.
2. console_app/management_system.py: Contains the EmployeeManagementSystem class with methods to manage employees, departments, and salaries.
3. console_app/employee.py: Contains the Employee class.
4. console_app/department.py: Contains the Department class.
5. console_app/salary.py: Contains the Salary class.
6. sql/create_database.sql: SQL script to set up the database and tables.
7. sql/problem_statements.sql :Contains Queries for the problem statement 
7. README.md: This file.


