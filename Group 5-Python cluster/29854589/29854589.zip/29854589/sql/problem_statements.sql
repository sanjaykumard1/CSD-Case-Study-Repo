SELECT sum(EMPLOYEES.salary) TOTAL_SALARY, DATE_FORMAT(SALARIES.date, '%M') MONTH from EMPLOYEES
Inner join SALARIES
on SALARIES.employee_id = EMPLOYEES.employee_id
Group by DATE_FORMAT(SALARIES.date, '%M');


SELECT DISTINCT EMPLOYEES.name  from EMPLOYEES
INNER JOIN SALARIES
ON SALARIES.employee_id = EMPLOYEES.employee_id
WHERE EXTRACT(YEAR FROM SALARIES.date) >= YEAR(current_date) -5 ;



SELECT d.name AS department_name, AVG(e.salary) AS average_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
GROUP BY d.name;


SELECT e.name AS employee_name, d.name AS department_name, e.salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
WHERE e.salary = (
    SELECT MAX(e2.salary)
    FROM Employees e2
    WHERE e2.department_id = e.department_id
);



SELECT e.name, e.salary, d.name AS department_name
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
WHERE e.salary > (
    SELECT AVG(e2.salary)
    FROM Employees e2
    WHERE e2.department_id = e.department_id
);
