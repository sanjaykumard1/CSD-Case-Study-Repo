DROP DATABASE IF EXISTS EmployeeManagement;
CREATE DATABASE EmployeeManagement;

USE EmployeeManagement;

CREATE TABLE Departments (
    department_id INT PRIMARY KEY,
    name VARCHAR(255),
    location VARCHAR(255)
);

CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(255),
    designation VARCHAR(255),
    salary DECIMAL(10, 2),
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

CREATE TABLE Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    amount DECIMAL(10, 2),
    date DATE,
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);



INSERT INTO Departments (department_id, name, location) VALUES
(100, 'ACCOUNTING', 'NEW YORK'),
(200, 'SALES', 'CHICAGO'),
(300, 'OPERATIONS', 'TEXAS');


INSERT INTO Employees (employee_id, name, designation, salary, department_id) VALUES
(10, 'Adam', 'Clerk', 500, 100),
(20, 'Stuart', 'Clerk', 500, 100),
(30, 'Clark', 'Senior Clerk', 750, 200),
(40, 'Ross', 'Accountant', 750, 200),
(50, 'Taylor', 'Manager', 1000, 300);


INSERT INTO Salaries (salary_id, employee_id, amount, date) VALUES
(1, 10, 500, '2024-01-01'),
(2, 10, 500, '2024-02-01'),
(3, 10, 500, '2024-03-01'),
(4, 10, 500, '2024-04-01'),
(5, 10, 500, '2024-05-01'),
(6, 10, 500, '2024-06-01'),
(7, 10, 500, '2024-07-01'),
(8, 20, 500, '2024-01-01'),
(9, 20, 500, '2024-02-01'),
(10, 20, 500, '2024-03-01'),
(11, 20, 500, '2024-04-01'),
(12, 20, 500, '2024-05-01'),
(13, 20, 500, '2024-06-01'),
(14, 20, 500, '2024-07-01'),
(15, 30, 750, '2024-01-01'),
(16, 30, 750, '2024-02-01'),
(17, 30, 750, '2024-03-01'),
(18, 30, 750, '2024-04-01'),
(19, 30, 750, '2024-05-01'),
(20, 30, 750, '2024-06-01'),
(21, 30, 750, '2024-07-01'),
(22, 40, 750, '2024-01-01'),
(23, 40, 750, '2024-02-01'),
(24, 40, 750, '2024-03-01'),
(25, 40, 750, '2024-04-01'),
(26, 40, 750, '2024-05-01'),
(27, 40, 750, '2024-06-01'),
(28, 40, 750, '2024-07-01'),
(29, 50, 1000, '2024-01-01'),
(30, 50, 1000, '2024-02-01'),
(31, 50, 1000, '2024-03-01'),
(32, 50, 1000, '2024-04-01'),
(33, 50, 1000, '2024-05-01'),
(34, 50, 1000, '2024-06-01'),
(35, 50, 1000, '2024-07-01');