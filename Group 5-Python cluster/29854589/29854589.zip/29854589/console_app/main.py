
import mysql.connector
from management_system import EmployeeManagementSystem
from employee import Employee
from department import Department
from salary import Salary


def get_mysql_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",  
            port="3305",       
            user="root",
            password="Cognizant@2024",
            database="EmployeeManagement"  # Your database name
        )
        return connection
    except mysql.connector.Error as error:
        print("Error connecting to MySQL database:", error)
        return None

def main():
    # Connect to MySQL database
    connection = get_mysql_connection()
    if not connection:
        return

    # Initialize EmployeeManagementSystem with the MySQL connection
    system = EmployeeManagementSystem(connection)

    while True:
        print("Employee Management System")
        print("1. Add Employee")
        print("2. Update Employee")
        print("3. Delete Employee")
        print("4. Display Employees")
        print("5. Add Department")
        print("6. Update Department")
        print("7. Delete Department")
        print("8. Display Departments")
        print("9. Add Salary")
        print("10. Update Salary")
        print("11. Delete Salary")
        print("12. Display Salaries")
        print("13. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            employee_id = int(input("Enter employee ID: "))
            name = input("Enter name: ")
            designation = input("Enter designation: ")
            salary = float(input("Enter salary: "))
            department_id = int(input("Enter department ID: "))
            system.add_emp(Employee(employee_id, name, designation, salary, department_id))

        elif choice == '2':
            employee_id = int(input("Enter employee ID to update: "))
            name = input("Enter new name (leave blank to skip): ")
            designation = input("Enter new designation (leave blank to skip): ")
            salary = input("Enter new salary (leave blank to skip): ")
            salary = float(salary) if salary else None
            department_id = input("Enter new department ID (leave blank to skip): ")
            department_id = int(department_id) if department_id else None
            system.update_emp(employee_id, name, designation, salary, department_id)

        elif choice == '3':
            employee_id = int(input("Enter employee ID to delete: "))
            system.del_emp(employee_id)

        elif choice == '4':
            system.display_emp()

        elif choice == '5':
            department_id = int(input("Enter department ID: "))
            name = input("Enter name: ")
            location = input("Enter location: ")
            system.add_dept(Department(department_id, name, location))

        elif choice == '6':
            department_id = int(input("Enter department ID to update: "))
            name = input("Enter new name (leave blank to skip): ")
            location = input("Enter new location (leave blank to skip): ")
            system.update_dept(department_id, name, location)

        elif choice == '7':
            department_id = int(input("Enter department ID to delete: "))
            system.del_dept(department_id)

        elif choice == '8':
            system.display_dept()

        elif choice == '9':
            salary_id = int(input("Enter salary ID: "))
            employee_id = int(input("Enter employee ID: "))
            amount = float(input("Enter amount: "))
            date = input("Enter date (YYYY-MM-DD): ")
            system.add_salary(Salary(salary_id, employee_id, amount, date))

        elif choice == '10':
            salary_id = int(input("Enter salary ID to update: "))
            employee_id = input("Enter new employee ID (leave blank to skip): ")
            employee_id = int(employee_id) if employee_id else None
            amount = input("Enter new amount (leave blank to skip): ")
            amount = float(amount) if amount else None
            date = input("Enter new date (leave blank to skip): ")
            system.update_salary(salary_id, employee_id, amount, date)

        elif choice == '11':
            salary_id = int(input("Enter salary ID to delete: "))
            system.del_salary(salary_id)

        elif choice == '12':
            system.display_salaries()

        elif choice == '13':
            break

        else:
            print("Invalid choice! Please try again.")

    # Close MySQL connection when done
    connection.close()

if __name__ == "__main__":
    main()
