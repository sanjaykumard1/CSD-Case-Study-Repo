class Department:
    def __init__(self, department_id, name, location):
        self.department_id = department_id
        self.name = name
        self.location = location

    def __str__(self):
        return f"Department[{self.department_id}] - {self.name}, Location: {self.location}"

    def to_dict(self):
        """
        Converts the Department object to a dictionary for database operations.
        """
        return {
            'department_id': self.department_id,
            'name': self.name,
            'location': self.location
        }

    @staticmethod
    def from_dict(data):
        """
        Creates a Department object from a dictionary (typically retrieved from the database).
        """
        return Department(data['department_id'], data['name'], data['location'])
