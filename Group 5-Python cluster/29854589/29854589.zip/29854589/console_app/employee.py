class Employee:
    def __init__(self, employee_id, name, designation, salary, department_id):
        self.employee_id = employee_id
        self.name = name
        self.designation = designation
        self.salary = salary
        self.department_id = department_id

    def __str__(self):
        return f"Employee[{self.employee_id}] - {self.name}, {self.designation}, Salary: {self.salary}, Department ID: {self.department_id}"

    def to_dict(self):
        """
        Converts the Employee object to a dictionary for database operations.
        """
        return {
            'employee_id': self.employee_id,
            'name': self.name,
            'designation': self.designation,
            'salary': self.salary,
            'department_id': self.department_id
        }

    @staticmethod
    def from_dict(data):
        """
        Creates an Employee object from a dictionary (typically retrieved from the database).
        """
        return Employee(data['employee_id'], data['name'], data['designation'], data['salary'], data['department_id'])
