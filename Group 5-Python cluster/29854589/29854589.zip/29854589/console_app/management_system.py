import mysql.connector
class EmployeeManagementSystem:
    def __init__(self, connection):
        self.connection = connection
        self.cursor = connection.cursor()

    # Employee Management
    def add_emp(self, employee):
        query = "INSERT INTO Employees (employee_id, name, designation, salary, department_id) VALUES (%s, %s, %s, %s, %s)"
        values = (employee.employee_id, employee.name, employee.designation, employee.salary, employee.department_id)
        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            print("Employee added successfully.")
        except mysql.connector.Error as error:
            print(f"Failed to add employee: {error}")

    def update_emp(self, employee_id, name=None, designation=None, salary=None, department_id=None):
        query = "UPDATE Employees SET "
        fields = []
        values = []

        if name:
            fields.append("name = %s")
            values.append(name)
        if designation:
            fields.append("designation = %s")
            values.append(designation)
        if salary:
            fields.append("salary = %s")
            values.append(salary)
        if department_id:
            fields.append("department_id = %s")
            values.append(department_id)

        query += ", ".join(fields)
        query += " WHERE employee_id = %s"
        values.append(employee_id)

        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Employee updated successfully.")
            else:
                print("No employee found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to update employee: {error}")

    def del_emp(self, employee_id):
        query = "DELETE FROM Employees WHERE employee_id = %s"
        try:
            self.cursor.execute(query, (employee_id,))
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Employee deleted successfully.")
            else:
                print("No employee found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to delete employee: {error}")

    # Department Management
    def add_dept(self, department):
        query = "INSERT INTO Departments (department_id, name, location) VALUES (%s, %s, %s)"
        values = (department.department_id, department.name, department.location)
        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            print("Department added successfully.")
        except mysql.connector.Error as error:
            print(f"Failed to add department: {error}")

    def update_dept(self, department_id, name=None, location=None):
        if not name and not location:
            print("No fields to update. Please provide at least one field to update.")
            return

        query = "UPDATE Departments SET "
        fields = []
        values = []

        if name:
            fields.append("name = %s")
            values.append(name)
        if location:
            fields.append("location = %s")
            values.append(location)

        query += ", ".join(fields)
        query += " WHERE department_id = %s"
        values.append(department_id)

        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Department updated successfully.")
            else:
                print("No department found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to update department: {error}")

    def del_dept(self, department_id):
        query = "DELETE FROM Departments WHERE department_id = %s"
        try:
            self.cursor.execute(query, (department_id,))
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Department deleted successfully.")
            else:
                print("No department found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to delete department: {error}")

    # Salary Management
    def add_salary(self, salary):
        query = "INSERT INTO Salaries (salary_id, employee_id, amount, date) VALUES (%s, %s, %s, %s)"
        values = (salary.salary_id, salary.employee_id, salary.amount, salary.date)
        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            print("Salary added successfully.")
        except mysql.connector.Error as error:
            print(f"Failed to add salary: {error}")

    def update_salary(self, salary_id, employee_id=None, amount=None, date=None):
        query = "UPDATE Salaries SET "
        fields = []
        values = []

        if employee_id:
            fields.append("employee_id = %s")
            values.append(employee_id)
        if amount:
            fields.append("amount = %s")
            values.append(amount)
        if date:
            fields.append("date = %s")
            values.append(date)

        query += ", ".join(fields)
        query += " WHERE salary_id = %s"
        values.append(salary_id)

        try:
            self.cursor.execute(query, values)
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Salary updated successfully.")
            else:
                print("No salary found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to update salary: {error}")

    def del_salary(self, salary_id):
        query = "DELETE FROM Salaries WHERE salary_id = %s"
        try:
            self.cursor.execute(query, (salary_id,))
            self.connection.commit()
            if self.cursor.rowcount > 0:
                print("Salary deleted successfully.")
            else:
                print("No salary found with the given ID.")
        except mysql.connector.Error as error:
            print(f"Failed to delete salary: {error}")

    # Display
    def display_emp(self):
        query = "SELECT * FROM Employees"
        self.cursor.execute(query)
        employees = self.cursor.fetchall()
        for emp in employees:
            print(emp)

    def display_dept(self):
        query = "SELECT * FROM Departments"
        self.cursor.execute(query)
        departments = self.cursor.fetchall()
        for dept in departments:
            print(dept)

    def display_salaries(self):
        query = "SELECT * FROM Salaries"
        self.cursor.execute(query)
        salaries = self.cursor.fetchall()
        for sal in salaries:
            print(sal)
