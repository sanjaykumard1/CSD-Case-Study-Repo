class Salary:
    def __init__(self, salary_id, employee_id, amount, date):
        self.salary_id = salary_id
        self.employee_id = employee_id
        self.amount = amount
        self.date = date

    def __str__(self):
        return f"Salary[{self.salary_id}] - Employee ID: {self.employee_id}, Amount: {self.amount}, Date: {self.date}"

    def to_dict(self):
        """
        Converts the Salary object to a dictionary for database operations.
        """
        return {
            'salary_id': self.salary_id,
            'employee_id': self.employee_id,
            'amount': self.amount,
            'date': self.date
        }

    @staticmethod
    def from_dict(data):
        """
        Creates a Salary object from a dictionary (typically retrieved from the database).
        """
        return Salary(data['salary_id'], data['employee_id'], data['amount'], data['date'])
