CREATE DATABASE VehicleRental;
 USE VehicleRental;
CREATE TABLE Vehicles (
    vehicle_id INT PRIMARY KEY,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    rental_rate DECIMAL(10, 2) NOT NULL,
    available BOOLEAN NOT NULL
);

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_info VARCHAR(100) NOT NULL
);

CREATE TABLE Rentals (
    rental_id INT PRIMARY KEY,
    customer_id INT,
    vehicle_id INT,
    rental_start_date DATE NOT NULL,
    rental_end_date DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (vehicle_id) REFERENCES Vehicles(vehicle_id)
);

/*1. Write a query to find the total rental income for each vehicle*/
SELECT V.model,sum(V.rental_rate)
FROM Rentals R 
inner join Vehicles V ON v.vehicle_id=R.vehicle_id
group by R.vehicle_id;

/*2. Write a query to find the names of customers and the vehicles they have rented.*/
SELECT C.name,V.model from Customers C inner join Rentals R 
ON R.customer_id=C.customer_id
INNER JOIN Vehicles V ON R.vehicle_id=V.vehicle_id ;

/*3. Write a query to find the vehicles that have never been rented.*/
SELECT *
FROM Vehicles V
LEFT JOIN Rentals R ON V.vehicle_id = R.vehicle_id
WHERE R.vehicle_id IS NULL;

/*4. Write a query to find the customers who have rented more than 3 different vehicles.*/
SELECT * from Customers C inner join Rentals R 
ON R.customer_id=C.customer_id
INNER JOIN Vehicles V ON R.vehicle_id=V.vehicle_id GROUP BY C.name, V.model
HAVING COUNT(V.vehicle_id) > 3;

/*5. Write a query to find the vehicle makes and models with less than 5 available units for rent.*/
SELECT V.make, V.model
FROM Vehicles V
GROUP BY V.make, V.model
HAVING COUNT(V.vehicle_id) < 5;



