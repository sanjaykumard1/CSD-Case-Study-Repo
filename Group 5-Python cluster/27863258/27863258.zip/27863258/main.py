class Vehicle:
    n=1  
    vehicles={}

    def __init__(self,make,model,year,rental_rate):
        self.vehicle_id=Vehicle.n
        Vehicle.n+=1
        self.make=make
        self.model=model
        self.year=year
        self.rental_rate=rental_rate
        self.available=True
        Vehicle.vehicles[self.vehicle_id]=self 

    def update_make(self,make):
        self.make=make

    def update_model(self,model):
        self.model=model

    def update_year(self,year):
        self.year=year

    def update_rental_rate(self,rental_rate):
        self.rental_rate=rental_rate

    def update_available(self,available):
        self.available=available

    def __str__(self):
        return f"ID: {self.vehicle_id}, Make: {self.make}, Model: {self.model}, Year: {self.year}, Rate: {self.rental_rate}, Available: {self.available}"


class Rental:
    r = 1  
    def __init__(self,customer_name,vehicle_id,rental_start_date,rental_end_date):
        self.rental_id=Rental.r
        Rental.r+=1
        self.customer_name=customer_name
        self.vehicle_id=vehicle_id
        self.rental_start_date=rental_start_date
        self.rental_end_date=rental_end_date

    def update_rental_transaction(self):
        if self.vehicle_id in Vehicle.vehicles:
            Vehicle.vehicles[self.vehicle_id].update_available(False)


class VehicleRentalManagementSystem:
    def __init__(self):
        self.rentals={}

    def add_vehicle(self,make,model,year,rental_rate):
        vehicle=Vehicle(make,model,year,rental_rate)
        print("Vehicle added successfully.")
        

    def update_vehicle(self,vehicle_id,make=None,model=None,year=None,rental_rate=None,available=None):
        try:
            if vehicle_id in Vehicle.vehicles:
                vehicle=Vehicle.vehicles[vehicle_id]
                if make is not None:
                    vehicle.update_make(make)
                if model is not None:
                    vehicle.update_model(model)
                if year is not None:
                    vehicle.update_year(year)
                if rental_rate is not None:
                    vehicle.update_rental_rate(rental_rate)
                if available is not None:
                    vehicle.update_available(available)
                print("Vehicle updated successfully.")
            else:
                print("Vehicle not found.")
        except ValueError  as e:
            print("enter correct id")

    def delete_vehicle(self,vehicle_id):
        try:
            if vehicle_id in Vehicle.vehicles:
                del Vehicle.vehicles[vehicle_id]
                print("Vehicle deleted successfully.")
            else:
                print("Vehicle not found.")
        except Exception as e:
            print("id not found")

    def process_rental(self,customer_name,vehicle_id,rental_start_date,rental_end_date):
        try:
            if vehicle_id in Vehicle.vehicles and Vehicle.vehicles[vehicle_id].available:
                rental=Rental(customer_name,vehicle_id,rental_start_date,rental_end_date)
                self.rentals[rental.rental_id]=rental
                Vehicle.vehicles[vehicle_id].update_available(False)
                print("Rental processed successfully.")
            else:
                print("Vehicle not available for rental.")
        except Exception as e:
            print("Vehicle not found")

    def rented_vehicles_report(self):
        rented_vehicles=[vehicle for vehicle in Vehicle.vehicles.values() if not vehicle.available]
        if rented_vehicles:
            print("Currently Rented Vehicles:")
            for vehicle in rented_vehicles:
                print(vehicle)
        else:
            print("No vehicles currently rented out.")
    def available_vehicles_report(self):
        available_vehicles=[vehicle for vehicle in Vehicle.vehicles.values() if vehicle.available]
        if available_vehicles:
            print("Currently Available Vehicles:")
            for vehicle in available_vehicles:
                print(vehicle)
        else:
            print("No vehicles currently available for rent.")

    def display_menu(self):
        print("\nVehicle Rental Management System")
        print("1. Add Vehicle")
        print("2. Update Vehicle")
        print("3. Delete Vehicle")
        print("4. Process Rental")
        print("5. Rented Vehicles Report")
        print("6. Available Vehicles Report")
        print("7. Exit")

    def run(self):
        while True:
            self.display_menu()
            choice=input("Enter your choice: ")
            
            if choice=='1':
                try:
                    make=input("Enter make: ")
                    model=input("Enter model: ")
                    year=int(input("Enter year: "))
                    rental_rate=float(input("Enter rental rate: "))
                    self.add_vehicle(make, model, year, rental_rate)
                except ValueError as e:
                    print("Enter correct year and rate")
            elif choice=='2':
                try:
                    vehicle_id=int(input("Enter vehicle ID to update: "))
                    make=input("Enter new make (or leave blank): ")
                    model=input("Enter new model (or leave blank): ")
                    year=input("Enter new year (or leave blank): ")
                    rental_rate=input("Enter new rental rate (or leave blank): ")
                    available=input("Is the vehicle available (yes/no): ").lower()
                    self.update_vehicle(vehicle_id,make if make else None,
                    model if model else None,
                    int(year) if year else None,
                    float(rental_rate) if rental_rate else None,
                    True if available == 'yes' else False if available == 'no' else None
                    )
                except:
                    print("Enter correct id")
            elif choice=='3':
                vehicle_id=int(input("Enter vehicle ID to delete: "))
                self.delete_vehicle(vehicle_id)
            elif choice=='4':
                customer_name=input("Enter customer name: ")
                vehicle_id=int(input("Enter vehicle ID to rent: "))
                rental_start_date=input("Enter rental start date (date-month-year): ")
                rental_end_date=input("Enter rental end date (date-month-year): ")
                self.process_rental(customer_name, vehicle_id, rental_start_date, rental_end_date)
            elif choice=='5':
                self.rented_vehicles_report()
            elif choice=='6':
                self.available_vehicles_report()
            elif choice=='7':
                print("Exit")
                break
            else:
                print("Invalid choice.Please try again.")
            
vrs = VehicleRentalManagementSystem()
vrs.run()
