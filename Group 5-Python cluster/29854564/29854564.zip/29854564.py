# keerthi.py

class Product:
    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Product ID: {self.product_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Stock Quantity: {self.stock_quantity}"

class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def __str__(self):
        return f"Customer ID: {self.customer_id}, Name: {self.name}, Email: {self.email}, Address: {self.address}"

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order ID: {self.order_id}, Customer ID: {self.customer_id}, Product ID: {self.product_id}, Order Date: {self.order_date}, Quantity: {self.quantity}"

class OnlineShoppingSystem:
    def __init__(self):
        self.products = []
        self.customers = []
        self.orders = []

    # Product Management
    def add_product(self, product):
        self.products.append(product)

    def update_product(self, product_id, updated_product):
        for i, product in enumerate(self.products):
            if product.product_id == product_id:
                self.products[i] = updated_product
                break
        else:
            raise ValueError(f"Product with ID {product_id} not found.")

    def delete_product(self, product_id):
        self.products = [product for product in self.products if product.product_id != product_id]

    # Customer Management
    def add_customer(self, customer):
        self.customers.append(customer)

    def update_customer(self, customer_id, updated_customer):
        for i, customer in enumerate(self.customers):
            if customer.customer_id == customer_id:
                self.customers[i] = updated_customer
                break
        else:
            raise ValueError(f"Customer with ID {customer_id} not found.")

    def delete_customer(self, customer_id):
        self.customers = [customer for customer in self.customers if customer.customer_id != customer_id]

    # Order Management
    def add_order(self, order):
        self.orders.append(order)

    def update_order(self, order_id, updated_order):
        for i, order in enumerate(self.orders):
            if order.order_id == order_id:
                self.orders[i] = updated_order
                break
        else:
            raise ValueError(f"Order with ID {order_id} not found.")

    def cancel_order(self, order_id):
        self.orders = [order for order in self.orders if order.order_id != order_id]

    # Display methods
    def display_products(self):
        for product in self.products:
            print(product)

    def display_customers(self):
        for customer in self.customers:
            print(customer)

    def display_orders(self):
        for order in self.orders:
            print(order)

# Function to display menu and handle user input
def main_menu(system):
    while True:
        print("\n=== Online Shopping System ===")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Add Customer")
        print("5. Update Customer")
        print("6. Delete Customer")
        print("7. Add Order")
        print("8. Update Order")
        print("9. Cancel Order")
        print("10. Display Products")
        print("11. Display Customers")
        print("12. Display Orders")
        print("0. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_product_menu(system)
        elif choice == "2":
            update_product_menu(system)
        elif choice == "3":
            delete_product_menu(system)
        elif choice == "4":
            add_customer_menu(system)
        elif choice == "5":
            update_customer_menu(system)
        elif choice == "6":
            delete_customer_menu(system)
        elif choice == "7":
            add_order_menu(system)
        elif choice == "8":
            update_order_menu(system)
        elif choice == "9":
            cancel_order_menu(system)
        elif choice == "10":
            system.display_products()
        elif choice == "11":
            system.display_customers()
        elif choice == "12":
            system.display_orders()
        elif choice == "0":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

def add_product_menu(system):
    print("\n=== Add Product ===")
    product_id = input("Enter Product ID: ")
    name = input("Enter Product Name: ")
    category = input("Enter Product Category: ")
    price = float(input("Enter Product Price: "))
    stock_quantity = int(input("Enter Stock Quantity: "))

    new_product = Product(product_id, name, category, price, stock_quantity)
    system.add_product(new_product)
    print("Product added successfully.")

def update_product_menu(system):
    print("\n=== Update Product ===")
    product_id = input("Enter Product ID to update: ")

    # Check if product exists
    for product in system.products:
        if product.product_id == product_id:
            name = input("Enter New Product Name: ")
            category = input("Enter New Product Category: ")
            price = float(input("Enter New Product Price: "))
            stock_quantity = int(input("Enter New Stock Quantity: "))

            updated_product = Product(product_id, name, category, price, stock_quantity)
            system.update_product(product_id, updated_product)
            print("Product updated successfully.")
            return

    print(f"Product with ID {product_id} not found.")

def delete_product_menu(system):
    print("\n=== Delete Product ===")
    product_id = input("Enter Product ID to delete: ")

    try:
        system.delete_product(product_id)
        print("Product deleted successfully.")
    except ValueError as e:
        print(e)

def add_customer_menu(system):
    print("\n=== Add Customer ===")
    customer_id = input("Enter Customer ID: ")
    name = input("Enter Customer Name: ")
    email = input("Enter Customer Email: ")
    address = input("Enter Customer Address: ")

    new_customer = Customer(customer_id, name, email, address)
    system.add_customer(new_customer)
    print("Customer added successfully.")

def update_customer_menu(system):
    print("\n=== Update Customer ===")
    customer_id = input("Enter Customer ID to update: ")

    # Check if customer exists
    for customer in system.customers:
        if customer.customer_id == customer_id:
            name = input("Enter New Customer Name: ")
            email = input("Enter New Customer Email: ")
            address = input("Enter New Customer Address: ")

            updated_customer = Customer(customer_id, name, email, address)
            system.update_customer(customer_id, updated_customer)
            print("Customer updated successfully.")
            return

    print(f"Customer with ID {customer_id} not found.")

def delete_customer_menu(system):
    print("\n=== Delete Customer ===")
    customer_id = input("Enter Customer ID to delete: ")

    try:
        system.delete_customer(customer_id)
        print("Customer deleted successfully.")
    except ValueError as e:
        print(e)

def add_order_menu(system):
    print("\n=== Add Order ===")
    order_id = input("Enter Order ID: ")
    customer_id = input("Enter Customer ID: ")
    product_id = input("Enter Product ID: ")
    order_date = input("Enter Order Date (YYYY-MM-DD): ")
    quantity = int(input("Enter Quantity: "))

    new_order = Order(order_id, customer_id, product_id, order_date, quantity)
    system.add_order(new_order)
    print("Order added successfully.")

def update_order_menu(system):
    print("\n=== Update Order ===")
    order_id = input("Enter Order ID to update: ")

    # Check if order exists
    for order in system.orders:
        if order.order_id == order_id:
            customer_id = input("Enter New Customer ID: ")
            product_id = input("Enter New Product ID: ")
            order_date = input("Enter New Order Date (YYYY-MM-DD): ")
            quantity = int(input("Enter New Quantity: "))

            updated_order = Order(order_id, customer_id, product_id, order_date, quantity)
            system.update_order(order_id, updated_order)
            print("Order updated successfully.")
            return

    print(f"Order with ID {order_id} not found.")

def cancel_order_menu(system):
    print("\n=== Cancel Order ===")
    order_id = input("Enter Order ID to cancel: ")

    try:
        system.cancel_order(order_id)
        print("Order canceled successfully.")
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    # Example usage
    system = OnlineShoppingSystem()
    main_menu(system)
