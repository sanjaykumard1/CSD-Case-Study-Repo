class Employee:
    def __init__(self, employee_id, name, designation, salary):
        self.employee_id = employee_id
        self.name = name
        self.designation = designation
        self.salary = salary

    def __str__(self):
        return f'ID: {self.employee_id}, Name: {self.name}, Designation: {self.designation}, Salary: {self.salary}'


class EmployeeManagement:
    def __init__(self):
        self.employees = {}

    def add_employee(self, employee):
        self.employees[employee.employee_id] = employee

    def update_employee(self, employee_id, **kwargs):
        if employee_id in self.employees:
            for key, value in kwargs.items():
                setattr(self.employees[employee_id], key, value)
        else:
            print("Employee not found")

    def delete_employee(self, employee_id):
        if employee_id in self.employees:
            del self.employees[employee_id]
        else:
            print("Employee not found")

    def list_employees(self):
        for employee in self.employees.values():
            print(employee)


class Department:
    def __init__(self, department_id, name, location):
        self.department_id = department_id
        self.name = name
        self.location = location

    def __str__(self):
        return f'ID: {self.department_id}, Name: {self.name}, Location: {self.location}'


class DepartmentManagement:
    def __init__(self):
        self.departments = {}

    def add_department(self, department):
        self.departments[department.department_id] = department

    def update_department(self, department_id, **kwargs):
        if department_id in self.departments:
            for key, value in kwargs.items():
                setattr(self.departments[department_id], key, value)
        else:
            print("Department not found")

    def delete_department(self, department_id):
        if department_id in self.departments:
            del self.departments[department_id]
        else:
            print("Department not found")

    def list_departments(self):
        for department in self.departments.values():
            print(department)


class Salary:
    def __init__(self, salary_id, employee_id, amount, date):
        self.salary_id = salary_id
        self.employee_id = employee_id
        self.amount = amount
        self.date = date

    def __str__(self):
        return f'ID: {self.salary_id}, Employee ID: {self.employee_id}, Amount: {self.amount}, Date: {self.date}'


class SalaryManagement:
    def __init__(self):
        self.salaries = {}

    def add_salary(self, salary):
        self.salaries[salary.salary_id] = salary

    def update_salary(self, salary_id, **kwargs):
        if salary_id in self.salaries:
            for key, value in kwargs.items():
                setattr(self.salaries[salary_id], key, value)
        else:
            print("Salary record not found")

    def delete_salary(self, salary_id):
        if salary_id in self.salaries:
            del self.salaries[salary_id]
        else:
            print("Salary record not found")

    def list_salaries(self):
        for salary in self.salaries.values():
            print(salary)


def main():
    emp_mgmt = EmployeeManagement()
    dept_mgmt = DepartmentManagement()
    sal_mgmt = SalaryManagement()

    while True:
        print("\n1. Manage Employees\n2. Manage Departments\n3. Manage Salaries\n4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            print("\n1. Add Employee\n2. Update Employee\n3. Delete Employee\n4. List Employees")
            emp_choice = input("Enter your choice: ")

            if emp_choice == '1':
                emp_id = input("Enter Employee ID: ")
                name = input("Enter Name: ")
                designation = input("Enter Designation: ")
                salary = float(input("Enter Salary: "))
                emp_mgmt.add_employee(Employee(emp_id, name, designation, salary))
            elif emp_choice == '2':
                emp_id = input("Enter Employee ID: ")
                name = input("Enter Name: ")
                designation = input("Enter Designation: ")
                salary = float(input("Enter Salary: "))
                emp_mgmt.update_employee(emp_id, name=name, designation=designation, salary=salary)
            elif emp_choice == '3':
                emp_id = input("Enter Employee ID: ")
                emp_mgmt.delete_employee(emp_id)
            elif emp_choice == '4':
                emp_mgmt.list_employees()

        elif choice == '2':
            print("\n1. Add Department\n2. Update Department\n3. Delete Department\n4. List Departments")
            dept_choice = input("Enter your choice: ")

            if dept_choice == '1':
                dept_id = input("Enter Department ID: ")
                name = input("Enter Name: ")
                location = input("Enter Location: ")
                dept_mgmt.add_department(Department(dept_id, name, location))
            elif dept_choice == '2':
                dept_id = input("Enter Department ID: ")
                name = input("Enter Name: ")
                location = input("Enter Location: ")
                dept_mgmt.update_department(dept_id, name=name, location=location)
            elif dept_choice == '3':
                dept_id = input("Enter Department ID: ")
                dept_mgmt.delete_department(dept_id)
            elif dept_choice == '4':
                dept_mgmt.list_departments()

        elif choice == '3':
            print("\n1. Add Salary\n2. Update Salary\n3. Delete Salary\n4. List Salaries")
            sal_choice = input("Enter your choice: ")

            if sal_choice == '1':
                sal_id = input("Enter Salary ID: ")
                emp_id = input("Enter Employee ID: ")
                amount = float(input("Enter Amount: "))
                date = input("Enter Date (YYYY-MM-DD): ")
                sal_mgmt.add_salary(Salary(sal_id, emp_id, amount, date))
            elif sal_choice == '2':
                sal_id = input("Enter Salary ID: ")
                emp_id = input("Enter Employee ID: ")
                amount = float(input("Enter Amount: "))
                date = input("Enter Date (YYYY-MM-DD): ")
                sal_mgmt.update_salary(sal_id, employee_id=emp_id, amount=amount, date=date)
            elif sal_choice == '3':
                sal_id = input("Enter Salary ID: ")
                sal_mgmt.delete_salary(sal_id)
            elif sal_choice == '4':
                sal_mgmt.list_salaries()

        elif choice == '4':
            break

if __name__ == "__main__":
    main()

