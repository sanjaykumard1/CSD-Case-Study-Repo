
-- Query 1: Total Salary Amount Paid in a Specific Month
SELECT SUM(amount) AS total_salary
FROM Salaries
WHERE DATE_FORMAT(date, '%Y-%m') = '2024-07';


-- Query 2: Employees with More than Five Years in the Company
SELECT *
FROM Employees
WHERE DATEDIFF(CURDATE(), hire_date) > 5 * 365;


-- Query 3: Average Salary for Each Department
SELECT d.name AS department_name, AVG(e.salary) AS average_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
GROUP BY d.name;

-- Query 4: Highest Paid Employee in Each Department
SELECT d.name AS department_name, e.name AS employee_name, e.salary AS highest_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
JOIN (
    SELECT department_id, MAX(salary) AS highest_salary
    FROM Employees
    GROUP BY department_id
) dept_max ON e.department_id = dept_max.department_id AND e.salary = dept_max.highest_salary;

-- Query 5: Employees Whose Salary is Above the Average Salary of Their Department
SELECT e.*
FROM Employees e
JOIN (
    SELECT department_id, AVG(salary) AS average_salary
    FROM Employees
    GROUP BY department_id
) dept_avg ON e.department_id = dept_avg.department_id
WHERE e.salary > dept_avg.average_salary;
