-- Create the Departments table
CREATE TABLE IF NOT EXISTS Departments (
    department_id INT PRIMARY KEY,
    name VARCHAR(255),
    location VARCHAR(255)
);

-- Insert data into Departments table
INSERT INTO Departments (department_id, name, location) VALUES
(1, 'HR', 'New York'),
(2, 'Engineering', 'San Francisco'),
(3, 'Marketing', 'Chicago');

-- Create the Employees table
CREATE TABLE IF NOT EXISTS Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(255),
    designation VARCHAR(255),
    salary DECIMAL(10, 2),
    hire_date DATE,
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

-- Insert data into Employees table
INSERT INTO Employees (employee_id, name, designation, salary, hire_date, department_id) VALUES
(1, 'Yeswanth', 'Manager', 75000.00, '2015-06-01', 1),
(2, 'Mukund', 'Engineer', 90000.00, '2018-03-15', 2),
(3, 'Vatsan', 'Marketing Specialist', 60000.00, '2020-09-30', 3),
(4, 'Rajan', 'HR Specialist', 65000.00, '2012-11-20', 1),
(5, 'Venkat', 'Senior Engineer', 120000.00, '2010-01-05', 2),
(6, 'Venki', 'Engineer', 95000.00, '2017-08-25', 2);

-- Create the Salaries table
CREATE TABLE IF NOT EXISTS Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    amount DECIMAL(10, 2),
    date DATE,
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Insert data into Salaries table
INSERT INTO Salaries (salary_id, employee_id, amount, date) VALUES
(1, 1, 7500.00, '2024-07-01'),
(2, 2, 9000.00, '2024-07-01'),
(3, 3, 6000.00, '2024-07-01'),
(4, 4, 6500.00, '2024-07-01'),
(5, 5, 12000.00, '2024-07-01'),
(6, 6, 9500.00, '2024-07-01'),
(7, 1, 7500.00, '2024-06-01'),
(8, 2, 9000.00, '2024-06-01'),
(9, 3, 6000.00, '2024-06-01'),
(10, 4, 6500.00, '2024-06-01'),
(11, 5, 12000.00, '2024-06-01'),
(12, 6, 9500.00, '2024-06-01');

-- Query 1: Total Salary Amount Paid in a Specific Month
SELECT SUM(amount) AS total_salary
FROM Salaries
WHERE DATE_FORMAT(date, '%Y-%m') = '2024-07';

-- Query 2: Employees with More than Five Years in the Company
SELECT *
FROM Employees
WHERE DATEDIFF(CURDATE(), hire_date) > 5 * 365;

-- Query 3: Average Salary for Each Department
SELECT d.name AS department_name, AVG(e.salary) AS average_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
GROUP BY d.name;

-- Query 4: Highest Paid Employee in Each Department
SELECT d.name AS department_name, e.name AS employee_name, e.salary AS highest_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
JOIN (
    SELECT department_id, MAX(salary) AS highest_salary
    FROM Employees
    GROUP BY department_id
) dept_max ON e.department_id = dept_max.department_id AND e.salary = dept_max.highest_salary;

-- Query 5: Employees Whose Salary is Above the Average Salary of Their Department
SELECT e.*
FROM Employees e
JOIN (
    SELECT department_id, AVG(salary) AS average_salary
    FROM Employees
    GROUP BY department_id
) dept_avg ON e.department_id = dept_avg.department_id
WHERE e.salary > dept_avg.average_salary;
