import datetime
import re

# Define the Student class
class Student:
    def __init__(self, student_id, name, age, email, major):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.email = email
        self.major = major

    def __str__(self):
        return f"ID: {self.student_id}, Name: {self.name}, Age: {self.age}, Email: {self.email}, Major: {self.major}"

# Define the Course class
class Course:
    def __init__(self, course_id, course_name, instructor, credits, max_students):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.credits = credits
        self.max_students = max_students

    def __str__(self):
        return f"ID: {self.course_id}, Name: {self.course_name}, Instructor: {self.instructor}, Credits: {self.credits}, Max Students: {self.max_students}"

# Define the Enrollment class
class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date

    def __str__(self):
        return f"Enrollment ID: {self.enrollment_id}, Student ID: {self.student_id}, Course ID: {self.course_id}, Date: {self.enrollment_date}"

# Define the UniversityManagementSystem class
class UniversityManagementSystem:
    def __init__(self):
        self.students = {}
        self.courses = {}
        self.enrollments = {}

    # Email validation
    def validate_email(self, email):
        return re.match(r"^[a-zA-Z0-9._%+-]+@gmail\.com$", email) is not None

    # Add a new student
    def add_student(self):
        while True:
            try:
                # Prompt for student details
                student_id = int(input("\nEnter student ID : "))
                name = input("Enter name : ")
                age = int(input("Enter age : "))
                email = input("Enter email : ")

                # Validate email format
                while not self.validate_email(email):
                    print("Invalid email format. Please enter a valid email ending with @gmail.com.")
                    email = input("Enter email: ")

                major = input("Enter major : ")
                self.students[student_id] = Student(student_id, name, age, email, major)
                print(f"\n  **** Student with ID {student_id} added successfully ****")
                break  # Exit the loop if successful
            except ValueError:
                print("Invalid input. Please ensure it.")

    # Update an existing student
    def update_student(self, student_id):
        if student_id not in self.students:
            raise ValueError(f"\n  **** Error: Student with ID {student_id} not found ****")
        student = self.students[student_id]

        # Prompt for updated details
        name = input("Enter name (leave blank to skip): ")
        age = input("Enter age (leave blank to skip): ")
        email = input("Enter email (leave blank to skip): ")
        major = input("Enter major (leave blank to skip): ")

        # Update details if provided
        if name:
            student.name = name
        if age:
            student.age = int(age)
        if email:
            if self.validate_email(email):
                student.email = email
            else:
                print("Invalid email format. Email not updated.")
        if major:
            student.major = major

        print(f"\n  **** Student with ID {student_id} updated successfully ****")

    # Delete an existing student
    def delete_student(self, student_id):
        if student_id not in self.students:
            raise ValueError(f"\n  **** Error: Student with ID {student_id} not found ****")
        del self.students[student_id]
        print(f"\n  **** Student with ID {student_id} deleted successfully ****")

    # Add a new course
    def add_course(self):
        while True:
            try:
                # Prompt for course details
                course_id = int(input("\nEnter course ID : "))
                course_name = input("Enter course name : ")
                instructor = input("Enter instructor : ")
                credits = int(input("Enter credits : "))
                max_students = int(input("Enter maximum students : "))
                self.courses[course_id] = Course(course_id, course_name, instructor, credits, max_students)
                print(f"\n  **** Course with ID {course_id} added successfully ****")
                break  # Exit the loop if successful
            except ValueError:
                print("Invalid input. Please ensure the given details in a correct type.")

    # Update an existing course
    def update_course(self, course_id):
        if course_id not in self.courses:
            raise ValueError(f"\n  **** Error: Course with ID {course_id} not found ****")
        course = self.courses[course_id]

        # Prompt for updated details
        course_name = input("Enter course name (leave blank to skip): ")
        instructor = input("Enter instructor (leave blank to skip): ")
        credits = input("Enter credits (leave blank to skip): ")
        max_students = input("Enter maximum students (leave blank to skip): ")

        # Update details if provided
        if course_name:
            course.course_name = course_name
        if instructor:
            course.instructor = instructor
        if credits:
            course.credits = int(credits)
        if max_students:
            course.max_students = int(max_students)

        print(f"\n  **** Course with ID {course_id} updated successfully ****")

    # Delete an existing course
    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise ValueError(f"\n  **** Error: Course with ID {course_id} not found ****")
        del self.courses[course_id]
        print(f"\n  **** Course with ID {course_id} deleted successfully ****")

    # Add a new enrollment
    def add_enrollment(self):
        while True:
            try:
                # Prompt for enrollment details
                enrollment_id = int(input("\nEnter enrollment ID : "))
                student_id = int(input("Enter student ID : "))
                course_id = int(input("Enter course ID : "))

                # Validate student and course existence
                if student_id not in self.students:
                    raise ValueError(f"\n  **** Error: Student with ID {student_id} not found ****")
                if course_id not in self.courses:
                    raise ValueError(f"\n  **** Error: Course with ID {course_id} not found ****")

                self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id, datetime.datetime.now().date())
                print(f"\n  **** Enrollment with ID {enrollment_id} added successfully ****")
                break  # Exit the loop if successful
            except ValueError:
                print("Invalid input. Please ensure the details are correct.")

    # Update an existing enrollment
    def update_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise ValueError(f"\n  **** Error: Enrollment with ID {enrollment_id} not found ****")
        enrollment = self.enrollments[enrollment_id]

        # Prompt for updated details
        student_id = input("Enter student ID (leave blank to skip): ")
        course_id = input("Enter course ID (leave blank to skip): ")

        # Update details if provided
        if student_id:
            enrollment.student_id = int(student_id)
        if course_id:
            enrollment.course_id = int(course_id)

        print("\n  **** Enrollment updated successfully ****")

    # Delete an existing enrollment
    def delete_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise ValueError(f"\n  **** Error: Enrollment with ID {enrollment_id} not found ****")
        del self.enrollments[enrollment_id]
        print(f"\n  **** Enrollment with ID {enrollment_id} deleted successfully ****")

    # List all students
    def list_students(self):
        if not self.students:
            print("\n **** There are currently no students enrolled ****")
        for student in self.students.values():
            print(f"\nID: {student.student_id}\nName: {student.name}\nAge: {student.age}\nEmail: {student.email}\nMajor: {student.major}\n")

    # List all courses
    def list_courses(self):
        if not self.courses:
            print("\n **** There are currently no courses available ****")
        for course in self.courses.values():
            print(f"\nID: {course.course_id}\nName: {course.course_name}\nInstructor: {course.instructor}\nCredits: {course.credits}\nMax Students: {course.max_students}\n")

    # List all enrollments
    def list_enrollments(self):
        if not self.enrollments:
            print("\n **** There are currently no enrollments ****")
        for enrollment in self.enrollments.values():
            print(f"\nEnrollment ID: {enrollment.enrollment_id}\nStudent ID: {enrollment.student_id}\nCourse ID: {enrollment.course_id}\nEnrollment Date: {enrollment.enrollment_date}\n")

# Main program loop

if __name__ == "__main__":
    # Create an instance of UniversityManagementSystem
    ums = UniversityManagementSystem()

    # Start an infinite loop to display the menu and process user input
    while True:
        # Display the menu options
        print("\nUniversity Management System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Add Course")
        print("5. Update Course")
        print("6. Delete Course")
        print("7. Add Enrollment")
        print("8. Update Enrollment")
        print("9. Delete Enrollment")
        print("10. List Students")
        print("11. List Courses")
        print("12. List Enrollments")
        print("13. Exit")

        # Prompt the user to enter their choice
        choice = input("\nEnter your choice: ")

        try:
            # Process the user's choice
            if choice == '1':
                ums.add_student()  # Add a new student
            elif choice == '2':
                student_id = int(input("\nEnter student ID: "))
                ums.update_student(student_id)  # Update an existing student
            elif choice == '3':
                student_id = int(input("\nEnter student ID: "))
                ums.delete_student(student_id)  # Delete an existing student
            elif choice == '4':
                ums.add_course()  # Add a new course
            elif choice == '5':
                course_id = int(input("\nEnter course ID: "))
                ums.update_course(course_id)  # Update an existing course
            elif choice == '6':
                course_id = int(input("\nEnter course ID: "))
                ums.delete_course(course_id)  # Delete an existing course
            elif choice == '7':
                ums.add_enrollment()  # Add a new enrollment
            elif choice == '8':
                enrollment_id = int(input("\nEnter enrollment ID: "))
                ums.update_enrollment(enrollment_id)  # Update an existing enrollment
            elif choice == '9':
                enrollment_id = int(input("\nEnter enrollment ID: "))
                ums.delete_enrollment(enrollment_id)  # Delete an existing enrollment
            elif choice == '10':
                ums.list_students()  # List all students
            elif choice == '11':
                ums.list_courses()  # List all courses
            elif choice == '12':
                ums.list_enrollments()  # List all enrollments
            elif choice == '13':
                # Prompt for exit confirmation
                confirm = input("\nAre you sure you want to exit? (yes/no): ").strip().lower()
                if confirm == 'yes':
                    print("\nExiting the University Management System. Goodbye!")
                    break  # Exit the loop and terminate the program
                else:
                    print("\nContinuing in the system...")  # Continue the loop
            else:
                print("\n **** Please enter a valid choice from the menu ****")
        except ValueError as e:
            # Handle value errors (e.g., invalid integer input)
            print(e)
        except Exception as e:
            # Handle any other exceptions
            print(f"An error occurred: {e}")
