-- 1. Total Salary Amount Paid in a Specific Month
SELECT SUM(amount) AS total_salary
FROM Salaries
WHERE MONTH(date) = 'specific_month' AND YEAR(date) = 'specific_year';

-- 2. Employees Who Have Been with the Company for More Than Five Years
SELECT e.*
FROM Employees e
JOIN Salaries s ON e.employee_id = s.employee_id
GROUP BY e.employee_id
HAVING MIN(YEAR(s.date)) <= YEAR(CURDATE()) - 5;

-- 3. Average Salary for Each Department
SELECT d.name AS department_name, AVG(e.salary) AS average_salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
GROUP BY d.department_id;

-- 4. Highest-Paid Employee in Each Department
SELECT e.name AS employee_name, d.name AS department_name, e.salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
WHERE e.salary = (
    SELECT MAX(salary)
    FROM Employees
    WHERE department_id = d.department_id
);

-- 5. Employees Whose Salary is Above the Average Salary of Their Department
SELECT e.*
FROM Employees e
JOIN (
    SELECT department_id, AVG(salary) AS avg_salary
    FROM Employees
    GROUP BY department_id
) avg_salaries ON e.department_id = avg_salaries.department_id
WHERE e.salary > avg_salaries.avg_salary;
