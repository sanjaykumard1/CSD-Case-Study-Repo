class Employee:
    def __init__(self, employee_id, name, designation, salary):
        self.employee_id = employee_id
        self.name = name
        self.designation = designation
        self.salary = salary

    def __str__(self):
        return f"Employee ID: {self.employee_id}, Name: {self.name}, Designation: {self.designation}, Salary: {self.salary}"