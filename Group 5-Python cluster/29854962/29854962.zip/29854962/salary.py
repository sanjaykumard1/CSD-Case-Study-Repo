class Salary:
    def __init__(self, salary_id, employee_id, amount, date):
        self.salary_id = salary_id
        self.employee_id = employee_id
        self.amount = amount
        self.date = date

    def __str__(self):
        return f"Salary ID: {self.salary_id}, Employee ID: {self.employee_id}, Amount: {self.amount}, Date: {self.date}"


