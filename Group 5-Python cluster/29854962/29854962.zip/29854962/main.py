# main.py

from employee import Employee
from department import Department
from salary import Salary
from manager.employee_manager import EmployeeManager
from manager.department_manager import DepartmentManager
from manager.salary_manager import SalaryManager

if __name__ == "__main__":
    # Create managers
    emp_manager = EmployeeManager()
    dept_manager = DepartmentManager()
    sal_manager = SalaryManager()

    # Add employees
    emp1 = Employee(1, "John Doe", "Developer", 50000)
    emp2 = Employee(2, "Jane Smith", "Designer", 45000)

    emp_manager.add_employee(emp1)
    emp_manager.add_employee(emp2)

    # Update an employee
    emp_manager.update_employee(1, name="John Doe Jr.", salary=55000)

    # Delete an employee
    emp_manager.delete_employee(2)

    # Display all employees
    print("All Employees:")
    for employee in emp_manager.get_all_employees():
        print(employee)

    # Add departments
    dept1 = Department(1, "IT", "New York")
    dept2 = Department(2, "HR", "London")

    dept_manager.add_department(dept1)
    dept_manager.add_department(dept2)

    # Update a department
    dept_manager.update_department(1, location="San Francisco")

    # Delete a department
    dept_manager.delete_department(2)

    # Display all departments
    print("\nAll Departments:")
    for department in dept_manager.get_all_departments():
        print(department)

    # Add salaries
    sal1 = Salary(1, 1, 5000, "2024-07-01")
    sal2 = Salary(2, 2, 6000, "2024-07-01")

    sal_manager.add_salary(sal1)
    sal_manager.add_salary(sal2)

    # Update a salary
    sal_manager.update_salary(1, amount=5500)

    # Delete a salary
    sal_manager.delete_salary(2)

    # Display all salaries
    print("\nAll Salaries:")
    for salary in sal_manager.get_all_salaries():
        print(salary)

