class Department:
    def __init__(self, department_id, name, location):
        self.department_id = department_id
        self.name = name
        self.location = location

    def __str__(self):
        return f"Department ID: {self.department_id}, Name: {self.name}, Location: {self.location}"


