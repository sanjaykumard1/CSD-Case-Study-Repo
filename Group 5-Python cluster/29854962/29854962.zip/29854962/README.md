# Employee Management System

This is a standalone console application for managing employee records, departments, and salaries using Python. The application utilizes object-oriented programming, collections, and exception handling.

## Features

- Add, update, and delete employee records.
- Manage departments with attributes like department_id, name, and location.
- Handle employee salaries with attributes like salary_id, employee_id, amount, and date.

## Structure

- `employee.py`: Contains the `Employee` class.
- `department.py`: Contains the `Department` class.
- `salary.py`: Contains the `Salary` class.
- `manager/`: Contains management classes for employees, departments, and salaries.
  - `employee_manager.py`: Contains the `EmployeeManager` class.
  - `department_manager.py`: Contains the `DepartmentManager` class.
  - `salary_manager.py`: Contains the `SalaryManager` class.
- `main.py`: The entry point of the application.

## How to Run

1. Clone the repository.
2. Navigate to the project directory.
3. Run `python main.py` to start the application.

## Example Usage

```bash
python main.py
