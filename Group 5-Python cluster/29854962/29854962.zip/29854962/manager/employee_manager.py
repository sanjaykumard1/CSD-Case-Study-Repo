class EmployeeManager:
    def __init__(self):
        self.employees = []

    def add_employee(self, employee):
        self.employees.append(employee)

    def update_employee(self, employee_id, **kwargs):
        for employee in self.employees:
            if employee.employee_id == employee_id:
                for key, value in kwargs.items():
                    setattr(employee, key, value)
                break

    def delete_employee(self, employee_id):
        self.employees = [emp for emp in self.employees if emp.employee_id != employee_id]

    def get_all_employees(self):
        return self.employees
