class SalaryManager:
    def __init__(self):
        self.salaries = []

    def add_salary(self, salary):
        self.salaries.append(salary)

    def update_salary(self, salary_id, **kwargs):
        for salary in self.salaries:
            if salary.salary_id == salary_id:
                for key, value in kwargs.items():
                    setattr(salary, key, value)
                break

    def delete_salary(self, salary_id):
        self.salaries = [sal for sal in self.salaries if sal.salary_id != salary_id]

    def get_all_salaries(self):
        return self.salaries