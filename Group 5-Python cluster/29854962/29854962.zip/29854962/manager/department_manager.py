class DepartmentManager:
    def __init__(self):
        self.departments = []

    def add_department(self, department):
        self.departments.append(department)

    def update_department(self, department_id, **kwargs):
        for department in self.departments:
            if department.department_id == department_id:
                for key, value in kwargs.items():
                    setattr(department, key, value)
                break

    def delete_department(self, department_id):
        self.departments = [dept for dept in self.departments if dept.department_id != department_id]

    def get_all_departments(self):
        return self.departments