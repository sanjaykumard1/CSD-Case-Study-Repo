# student_enrollment_system.py

class Student:
    def __init__(self, student_id, name, age, major, year):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.major = major
        self.year = year

    def __str__(self):
        return f"ID: {self.student_id}, Name: {self.name}, Age: {self.age}, Major: {self.major}, Year: {self.year}"

class EnrollmentSystem:
    def __init__(self):
        self.students = {}
        self.course_enrollments = {}

    def add_student(self, student):
        if student.student_id in self.students:
            print(f"Student with ID {student.student_id} already exists.")
        else:
            self.students[student.student_id] = student
            print(f"Student {student.name} added successfully.")

    def update_student(self, student_id, **kwargs):
        if student_id in self.students:
            student = self.students[student_id]
            for key, value in kwargs.items():
                if hasattr(student, key):
                    setattr(student, key, value)
            print(f"Student {student_id} updated successfully.")
        else:
            print(f"Student with ID {student_id} not found.")

    def delete_student(self, student_id):
        if student_id in self.students:
            del self.students[student_id]
            print(f"Student {student_id} deleted successfully.")
        else:
            print(f"Student with ID {student_id} not found.")

    def enroll_course(self, student_id, course_id):
        if student_id in self.students:
            if course_id not in self.course_enrollments:
                self.course_enrollments[course_id] = []
            if student_id not in self.course_enrollments[course_id]:
                self.course_enrollments[course_id].append(student_id)
                print(f"Student {student_id} enrolled in course {course_id} successfully.")
            else:
                print(f"Student {student_id} is already enrolled in course {course_id}.")
        else:
            print(f"Student with ID {student_id} not found.")

    def drop_course(self, student_id, course_id):
        if course_id in self.course_enrollments and student_id in self.course_enrollments[course_id]:
            self.course_enrollments[course_id].remove(student_id)
            print(f"Student {student_id} dropped from course {course_id} successfully.")
        else:
            print(f"Student {student_id} is not enrolled in course {course_id}.")

    def report_students_in_course(self, course_id):
        if course_id in self.course_enrollments:
            print(f"Students enrolled in course {course_id}:")
            for student_id in self.course_enrollments[course_id]:
                print(self.students[student_id])
        else:
            print(f"No students enrolled in course {course_id}.")

def main():
    system = EnrollmentSystem()

    while True:
        print("\nStudent Enrollment System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Enroll Course")
        print("5. Drop Course")
        print("6. Report Students in Course")
        print("7. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            student_id = input("Enter student ID: ")
            name = input("Enter name: ")
            age = input("Enter age: ")
            major = input("Enter major: ")
            year = input("Enter year: ")
            student = Student(student_id, name, age, major, year)
            system.add_student(student)
        elif choice == '2':
            student_id = input("Enter student ID to update: ")
            print("Enter new values (leave blank to keep current value):")
            name = input("Enter new name: ")
            age = input("Enter new age: ")
            major = input("Enter new major: ")
            year = input("Enter new year: ")
            updates = {}
            if name: updates['name'] = name
            if age: updates['age'] = age
            if major: updates['major'] = major
            if year: updates['year'] = year
            system.update_student(student_id, **updates)
        elif choice == '3':
            student_id = input("Enter student ID to delete: ")
            system.delete_student(student_id)
        elif choice == '4':
            student_id = input("Enter student ID to enroll: ")
            course_id = input("Enter course ID: ")
            system.enroll_course(student_id, course_id)
        elif choice == '5':
            student_id = input("Enter student ID to drop: ")
            course_id = input("Enter course ID: ")
            system.drop_course(student_id, course_id)
        elif choice == '6':
            course_id = input("Enter course ID to report: ")
            system.report_students_in_course(course_id)
        elif choice == '7':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
