import mysql.connector

# Function to establish connection to MySQL
def connect_to_mysql():
    try:
        # Connect to MySQL
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Navaneeth@143",
            database="student_enrollment_system"  # Specify the database name here
        )
        return mydb
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

# Function to create the database and tables
def create_database_and_tables():
    try:
        # Connect to MySQL without specifying the database
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Navaneeth@143"
        )
        cursor = mydb.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS student_enrollment_system")
        cursor.close()
        mydb.close()
        
        # Connect to the newly created database
        mydb = connect_to_mysql()
        if mydb:
            cursor = mydb.cursor()

            # Create Students table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Students (
                    student_id INT PRIMARY KEY,
                    name VARCHAR(100),
                    age INT,
                    major VARCHAR(50),
                    year VARCHAR(10)
                )
            """)

            # Create Courses table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Courses (
                    course_id INT PRIMARY KEY,
                    course_name VARCHAR(100),
                    credits INT
                )
            """)

            # Create Enrollments table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS Enrollments (
                    enrollment_id INT PRIMARY KEY,
                    student_id INT,
                    course_id INT,
                    enrollment_date DATE,
                    FOREIGN KEY (student_id) REFERENCES Students(student_id),
                    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
                )
            """)
            mydb.commit()
            cursor.close()
            print("Database and tables created successfully.")
            mydb.close()
    except mysql.connector.Error as err:
        print(f"Error: {err}")

# Function to insert sample data into tables
def insert_sample_data():
    mydb = connect_to_mysql()
    if mydb:
        try:
            cursor = mydb.cursor()

            # Insert sample data into Students table
            students = [
                (1, 'Alice', 20, 'Computer Science', 'Sophomore'),
                (2, 'Bob', 21, 'Engineering', 'Junior'),
                (3, 'Charlie', 19, 'Mathematics', 'Freshman'),
                (4, 'David', 22, 'Physics', 'Senior')  # New student not enrolled in any course
            ]
            for student in students:
                cursor.execute("""
                    INSERT IGNORE INTO Students (student_id, name, age, major, year)
                    VALUES (%s, %s, %s, %s, %s)
                """, student)

            # Insert sample data into Courses table
            courses = [
                (101, 'Database Management', 3),
                (102, 'Python Programming', 4),
                (103, 'Web Development', 3),
                (104, 'Machine Learning', 4)  # New course for additional enrollment
            ]
            for course in courses:
                cursor.execute("""
                    INSERT IGNORE INTO Courses (course_id, course_name, credits)
                    VALUES (%s, %s, %s)
                """, course)

            # Insert sample data into Enrollments table
            enrollments = [
                (1, 1, 101, '2024-07-01'),
                (2, 1, 102, '2024-07-02'),
                (3, 2, 101, '2024-07-03'),
                (4, 3, 103, '2024-07-04'),
                (5, 1, 103, '2024-07-05'),
                (6, 2, 102, '2024-07-06'),
                (7, 3, 101, '2024-07-07'),
                (8, 3, 102, '2024-07-08'),
                (9, 1, 104, '2024-07-09'),  # Additional enrollment to test query 5
                (10, 2, 103, '2024-07-10'),  # Additional enrollment to test query 5
                (11, 3, 104, '2024-07-11')  # Additional enrollment to test query 5
            ]
            for enrollment in enrollments:
                cursor.execute("""
                    INSERT IGNORE INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date)
                    VALUES (%s, %s, %s, %s)
                """, enrollment)

            mydb.commit()
            cursor.close()
            print("Sample data inserted successfully.")
        except mysql.connector.Error as err:
            print(f"Error: {err}")
        finally:
            mydb.close()

# Function to execute problem statement queries
def execute_queries():
    mydb = connect_to_mysql()
    if mydb:
        try:
            cursor = mydb.cursor()

            # Query 1: Total number of students enrolled in each course
            cursor.execute("""
                SELECT c.course_id, c.course_name, COUNT(e.student_id) AS num_students_enrolled
                FROM Courses c
                LEFT JOIN Enrollments e ON c.course_id = e.course_id
                GROUP BY c.course_id, c.course_name
            """)
            print("\nQuery 1 Results:")
            for row in cursor.fetchall():
                print(row)

            # Query 2: Names of students and the courses they are enrolled in
            cursor.execute("""
                SELECT s.name AS student_name, c.course_name
                FROM Students s
                JOIN Enrollments e ON s.student_id = e.student_id
                JOIN Courses c ON e.course_id = c.course_id
            """)
            print("\nQuery 2 Results:")
            for row in cursor.fetchall():
                print(row)

            # Query 3: Names of students who are not enrolled in any courses
            cursor.execute("""
                SELECT name
                FROM Students
                WHERE student_id NOT IN (SELECT DISTINCT student_id FROM Enrollments)
            """)
            print("\nQuery 3 Results:")
            for row in cursor.fetchall():
                print(row)

            # Query 4: Courses that have more than 30 students enrolled
            cursor.execute("""
                SELECT c.course_id, c.course_name, COUNT(e.student_id) AS num_students_enrolled
                FROM Courses c
                JOIN Enrollments e ON c.course_id = e.course_id
                GROUP BY c.course_id, c.course_name
                HAVING COUNT(e.student_id) > 30
            """)
            
            print("\nQuery 4 Results:")
            for row in cursor.fetchall():
                print(row)

            # Query 5: Student names and their corresponding majors who are enrolled in more than 3 courses
            cursor.execute("""
                SELECT s.name AS student_name, s.major
                FROM Students s
                JOIN (
                    SELECT student_id
                    FROM Enrollments
                    GROUP BY student_id
                    HAVING COUNT(course_id) > 3
                ) AS enrolled_students ON s.student_id = enrolled_students.student_id
            """)
            print("\nQuery 5 Results:")
            for row in cursor.fetchall():
                print(row)

            cursor.close()
        except mysql.connector.Error as err:
            print(f"Error: {err}")
        finally:
            mydb.close()

# Main function to run the script
if __name__ == "__main__":
    create_database_and_tables()
    insert_sample_data()
    execute_queries()
