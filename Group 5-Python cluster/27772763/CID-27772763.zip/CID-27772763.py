import datetime

# Exception classes
class NotFoundError(Exception):
    pass

# Utility function
def generate_id(prefix):
    return f"{prefix}{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"

# Data classes
class Course:
    def __init__(self, course_id, title, description, instructor_id, capacity):
        self.course_id = course_id
        self.title = title
        self.description = description
        self.instructor_id = instructor_id
        self.capacity = capacity

class Student:
    def __init__(self, student_id, name, email, address):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.address = address

class Instructor:
    def __init__(self, instructor_id, name, email, expertise):
        self.instructor_id = instructor_id
        self.name = name
        self.email = email
        self.expertise = expertise

class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date

# Main Application class
class OnlineLearningPlatform:
    def __init__(self):
        self.courses = {}
        self.students = {}
        self.instructors = {}
        self.enrollments = {}

    # Course Management
    def add_course(self, title, description, instructor_id, capacity):
        course_id = generate_id("C")
        self.courses[course_id] = Course(course_id, title, description, instructor_id, capacity)
        print(f"Course {course_id} added successfully.")

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise NotFoundError(f"Course {course_id} not found.")
        del self.courses[course_id]
        print(f"Course {course_id} deleted successfully.")

    # Student Management
    def add_student(self, name, email, address):
        student_id = generate_id("S")
        self.students[student_id] = Student(student_id, name, email, address)
        print(f"Student {student_id} added successfully.")

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise NotFoundError(f"Student {student_id} not found.")
        del self.students[student_id]
        print(f"Student {student_id} deleted successfully.")

    # Instructor Management
    def add_instructor(self, name, email, expertise):
        instructor_id = generate_id("I")
        self.instructors[instructor_id] = Instructor(instructor_id, name, email, expertise)
        print(f"Instructor {instructor_id} added successfully.")

    def delete_instructor(self, instructor_id):
        if instructor_id not in self.instructors:
            raise NotFoundError(f"Instructor {instructor_id} not found.")
        del self.instructors[instructor_id]
        print(f"Instructor {instructor_id} deleted successfully.")

    # Enrollment Management
    def add_enrollment(self, student_id, course_id):
        if student_id not in self.students:
            raise NotFoundError(f"Student {student_id} not found.")
        if course_id not in self.courses:
            raise NotFoundError(f"Course {course_id} not found.")
        enrollment_id = generate_id("E")
        enrollment_date = datetime.datetime.now().strftime("%Y-%m-%d")
        self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id, enrollment_date)
        print(f"Enrollment {enrollment_id} added successfully.")

    def delete_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise NotFoundError(f"Enrollment {enrollment_id} not found.")
        del self.enrollments[enrollment_id]
        print(f"Enrollment {enrollment_id} deleted successfully.")

    def run(self):
        while True:
            print("\nOnline Learning Platform")
            print("1 Add Course")
            print("2 Delete Course")
            print("3 Add Student")
            print("4 Delete Student")
            print("5 Add Instructor")
            print("6 Delete Instructor")
            print("7 Add Enrollment")
            print("8 Delete Enrollment")
            print("9 Close")
            choice = input("Enter choice:")

            try:
                if choice == '1':
                    title = input("Enter course title: ")
                    description = input("Enter course description: ")
                    instructor_id = input("Enter instructor ID: ")
                    capacity = int(input("Enter course capacity: "))
                    self.add_course(title, description, instructor_id, capacity)
                elif choice == '2':
                    course_id = input("Enter course ID to delete: ")
                    self.delete_course(course_id)
                elif choice == '3':
                    name = input("Enter student name: ")
                    email = input("Enter student email: ")
                    address = input("Enter student address: ")
                    self.add_student(name, email, address)
                elif choice == '4':
                    student_id = input("Enter student ID to delete: ")
                    self.delete_student(student_id)
                elif choice == '5':
                    name = input("Enter instructor name: ")
                    email = input("Enter instructor email: ")
                    expertise = input("Enter instructor expertise: ")
                    self.add_instructor(name, email, expertise)
                elif choice == '6':
                    instructor_id = input("Enter instructor ID to delete: ")
                    self.delete_instructor(instructor_id)
                elif choice == '7':
                    student_id = input("Enter student ID: ")
                    course_id = input("Enter course ID: ")
                    self.add_enrollment(student_id, course_id)
                elif choice == '8':
                    enrollment_id = input("Enter enrollment ID to delete: ")
                    self.delete_enrollment(enrollment_id)
                elif choice == '9':
                    print("Exiting...")
                    break
                else:
                    print("Invalid choice. Please try again.")
            except NotFoundError as e:
                print(e)
            except Exception as e:
                print(f"An error occurred: {e}")

# Run the application
if __name__ == "__main__":
    app = OnlineLearningPlatform()
    app.run()