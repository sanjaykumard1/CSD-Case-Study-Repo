-- Query 1: Find the total salary amount paid in a specific month
SELECT SUM(amount) AS total_salary
FROM Salaries
WHERE DATE_FORMAT(date, '%Y-%m') = '2023-01';

-- Query 2: Find the employees who have been with the company for more than five years
SELECT employee_id, name, designation, salary
FROM Employees
WHERE DATEDIFF(CURDATE(), (SELECT MIN(date) FROM Salaries WHERE employee_id = Employees.employee_id)) > 5 * 365;

-- Query 3: Find the average salary for each department
SELECT Departments.department_id, Departments.name, AVG(Employees.salary) AS average_salary
FROM Employees
JOIN Departments ON Employees.department_id = Departments.department_id
GROUP BY Departments.department_id, Departments.name;

-- Query 4: Find the highest-paid employee in each department
SELECT e.department_id, d.name, e.employee_id, e.name AS employee_name, e.salary
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
WHERE e.salary = (
    SELECT MAX(salary)
    FROM Employees
    WHERE department_id = e.department_id
);

-- Query 5: Find the employees whose salary is above the average salary of their department
SELECT e.employee_id, e.name, e.designation, e.salary, d.name AS department_name
FROM Employees e
JOIN Departments d ON e.department_id = d.department_id
WHERE e.salary > (
    SELECT AVG(salary)
    FROM Employees
    WHERE department_id = e.department_id
);
