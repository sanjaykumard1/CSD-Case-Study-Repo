-- Created Departments table
CREATE TABLE Departments (
    department_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL
);

-- Created Employees table
CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    designation VARCHAR(255) NOT NULL,
    salary DECIMAL(10, 2) NOT NULL,
    department_id INT,
    FOREIGN KEY (department_id) REFERENCES Departments(department_id)
);

-- Created Salaries table
CREATE TABLE Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    date DATE NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
);

-- Insert sample data into Departments table
INSERT INTO Departments (department_id, name, location) VALUES
(1, 'Human Resources', 'New York'),
(2, 'Engineering', 'San Francisco'),
(3, 'Marketing', 'Chicago');

-- Insert sample data into Employees table
INSERT INTO Employees (employee_id, name, designation, salary, department_id) VALUES
(1, 'Alice Johnson', 'HR Manager', 80000.00, 1),
(2, 'Bob Smith', 'Software Engineer', 120000.00, 2),
(3, 'Carol Davis', 'Marketing Specialist', 90000.00, 3),
(4, 'David Brown', 'Software Engineer', 110000.00, 2),
(5, 'Eva Green', 'HR Assistant', 60000.00, 1);

-- Insert sample data into Salaries table
INSERT INTO Salaries (salary_id, employee_id, amount, date) VALUES
(1, 1, 80000.00, '2023-01-15'),
(2, 2, 120000.00, '2023-01-15'),
(3, 3, 90000.00, '2023-01-15'),
(4, 4, 110000.00, '2023-01-15'),
(5, 5, 60000.00, '2023-01-15'),
(6, 1, 81000.00, '2023-02-15'),
(7, 2, 121000.00, '2023-02-15'),
(8, 3, 91000.00, '2023-02-15'),
(9, 4, 111000.00, '2023-02-15'),
(10, 5, 61000.00, '2023-02-15');
