import datetime

class Employee:
    def __init__(self, employee_id, name, designation, salary):
        self.employee_id = employee_id
        self.name = name
        self.designation = designation
        self.salary = salary

    def __str__(self):
        return f"ID: {self.employee_id}, Name: {self.name}, Designation: {self.designation}, Salary: {self.salary}"

class Department:
    def __init__(self, department_id, name, location):
        self.department_id = department_id
        self.name = name
        self.location = location

    def __str__(self):
        return f"ID: {self.department_id}, Name: {self.name}, Location: {self.location}"

class Salary:
    def __init__(self, salary_id, employee_id, amount, date):
        self.salary_id = salary_id
        self.employee_id = employee_id
        self.amount = amount
        self.date = date

    def __str__(self):
        return f"ID: {self.salary_id}, Employee ID: {self.employee_id}, Amount: {self.amount}, Date: {self.date}"

class EmployeeManagementSystem:
    def __init__(self):
        self.employees = {}
        self.departments = {}
        self.salaries = {}

    # Employee Management
    def add_employee(self, employee_id, name, designation, salary):
        if employee_id in self.employees:
            raise Exception("Employee with this ID already exists.")
        self.employees[employee_id] = Employee(employee_id, name, designation, salary)
        print(f"Employee {name} added successfully.")

    def update_employee(self, employee_id, name=None, designation=None, salary=None):
        if employee_id not in self.employees:
            raise Exception("Employee not found.")
        employee = self.employees[employee_id]
        if name:
            employee.name = name
        if designation:
            employee.designation = designation
        if salary:
            employee.salary = salary
        print(f"Employee {employee_id} updated successfully.")

    def delete_employee(self, employee_id):
        if employee_id not in self.employees:
            raise Exception("Employee not found.")
        del self.employees[employee_id]
        print(f"Employee {employee_id} deleted successfully.")

    # Department Management
    def add_department(self, department_id, name, location):
        if department_id in self.departments:
            raise Exception("Department with this ID already exists.")
        self.departments[department_id] = Department(department_id, name, location)
        print(f"Department {name} added successfully.")

    def update_department(self, department_id, name=None, location=None):
        if department_id not in self.departments:
            raise Exception("Department not found.")
        department = self.departments[department_id]
        if name:
            department.name = name
        if location:
            department.location = location
        print(f"Department {department_id} updated successfully.")

    def delete_department(self, department_id):
        if department_id not in self.departments:
            raise Exception("Department not found.")
        del self.departments[department_id]
        print(f"Department {department_id} deleted successfully.")

    # Salary Management
    def add_salary(self, salary_id, employee_id, amount, date):
        if salary_id in self.salaries:
            raise Exception("Salary record with this ID already exists.")
        if employee_id not in self.employees:
            raise Exception("Employee not found.")
        self.salaries[salary_id] = Salary(salary_id, employee_id, amount, date)
        print(f"Salary record added successfully.")

    def update_salary(self, salary_id, amount=None, date=None):
        if salary_id not in self.salaries:
            raise Exception("Salary record not found.")
        salary = self.salaries[salary_id]
        if amount:
            salary.amount = amount
        if date:
            salary.date = date
        print(f"Salary record {salary_id} updated successfully.")

    def delete_salary(self, salary_id):
        if salary_id not in self.salaries:
            raise Exception("Salary record not found.")
        del self.salaries[salary_id]
        print(f"Salary record {salary_id} deleted successfully.")

    def show_employees(self):
        for employee in self.employees.values():
            print(employee)

    def show_departments(self):
        for department in self.departments.values():
            print(department)

    def show_salaries(self):
        for salary in self.salaries.values():
            print(salary)

def main():
    ems = EmployeeManagementSystem()

    while True:
        print("\n1. Add Employee")
        print("\n2. Update Employee")
        print("\n3. Delete Employee")
        print("\n4. Add Department")
        print("\n5. Update Department")
        print("\n6. Delete Department")
        print("\n7. Add Salary")
        print("\n8. Update Salary")
        print("\n9. Delete Salary")
        print("\n10. Show Employees")
        print("\n11. Show Departments")
        print("\n12. Show Salaries")
        print("\n13. Exit")

        choice = int(input("Enter choice: "))

        if choice == 1:
            employee_id = input("Enter Employee ID: ")
            name = input("Enter Name: ")
            designation = input("Enter Designation: ")
            salary = float(input("Enter Salary: "))
            ems.add_employee(employee_id, name, designation, salary)
        elif choice == 2:
            employee_id = input("Enter Employee ID: ")
            name = input("Enter Name (leave blank if no change): ") or None
            designation = input("Enter Designation (leave blank if no change): ") or None
            salary = input("Enter Salary (leave blank if no change): ")
            salary = float(salary) if salary else None
            ems.update_employee(employee_id, name, designation, salary)
        elif choice == 3:
            employee_id = input("Enter Employee ID: ")
            ems.delete_employee(employee_id)
        elif choice == 4:
            department_id = input("Enter Department ID: ")
            name = input("Enter Name: ")
            location = input("Enter Location: ")
            ems.add_department(department_id, name, location)
        elif choice == 5:
            department_id = input("Enter Department ID: ")
            name = input("Enter Name (leave blank if no change): ") or None
            location = input("Enter Location (leave blank if no change): ") or None
            ems.update_department(department_id, name, location)
        elif choice == 6:
            department_id = input("Enter Department ID: ")
            ems.delete_department(department_id)
        elif choice == 7:
            salary_id = input("Enter Salary ID: ")
            employee_id = input("Enter Employee ID: ")
            amount = float(input("Enter Amount: "))
            date = input("Enter Date (YYYY-MM-DD): ")
            date = datetime.datetime.strptime(date, '%Y-%m-%d')
            ems.add_salary(salary_id, employee_id, amount, date)
        elif choice == 8:
            salary_id = input("Enter Salary ID: ")
            amount = input("Enter Amount (leave blank if no change): ")
            amount = float(amount) if amount else None
            date = input("Enter Date (YYYY-MM-DD, leave blank if no change): ")
            date = datetime.datetime.strptime(date, '%Y-%m-%d') if date else None
            ems.update_salary(salary_id, amount, date)
        elif choice == 9:
            salary_id = input("Enter Salary ID: ")
            ems.delete_salary(salary_id)
        elif choice == 10:
            ems.show_employees()
        elif choice == 11:
            ems.show_departments()
        elif choice == 12:
            ems.show_salaries()
        elif choice == 13:
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
