CREATE DATABASE AirlineReservation;

USE AirlineReservation;

CREATE TABLE Flights (
    flight_id INT PRIMARY KEY,
    airline VARCHAR(100),
    destination VARCHAR(100),
    departure_time DATETIME,
    available_seats INT
);

CREATE TABLE Passengers (
    passenger_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    contact_info VARCHAR(100)
);

CREATE TABLE Reservations (
    reservation_id INT PRIMARY KEY AUTO_INCREMENT,
    passenger_id INT,
    flight_id INT,
    seat_number VARCHAR(10),
    reservation_date DATE,
    FOREIGN KEY (passenger_id) REFERENCES Passengers(passenger_id),
    FOREIGN KEY (flight_id) REFERENCES Flights(flight_id)
);

-- Write a query to find the total number of seats booked on each flight.
SELECT flight_id, COUNT(*) AS total_seats_booked
FROM Reservations
GROUP BY flight_id;


-- Write a query to find the names of passengers and the flights they are booked on.
SELECT p.name, r.flight_id
FROM Passengers p
JOIN Reservations r ON p.passenger_id = r.passenger_id;

-- Write a query to find the flights that have never been booked by any passenger
SELECT f.flight_id
FROM Flights f
LEFT JOIN Reservations r ON f.flight_id = r.flight_id
WHERE r.reservation_id IS NULL;


-- Write a query to find the passengers who have made reservations for more than 3 flights.
SELECT p.name, COUNT(r.reservation_id) AS total_reservations
FROM Passengers p
JOIN Reservations r ON p.passenger_id = r.passenger_id
GROUP BY p.name
HAVING COUNT(r.reservation_id) > 3;

-- Write a query to find the details of flights with less than 5 available seats.
select * from flights
where available_seats<5;