class Reservation:
    def __init__(self, reservation_id, passenger_name, flight_id, seat_number, reservation_date):
        self.reservation_id = reservation_id
        self.passenger_name = passenger_name
        self.flight_id = flight_id
        self.seat_number = seat_number
        self.reservation_date = reservation_date

    def __str__(self):
        return (f"Reservation ID: {self.reservation_id}, Passenger: {self.passenger_name}, "
                f"Flight ID: {self.flight_id}, Seat: {self.seat_number}, Date: {self.reservation_date}")


class ReservationManagement:
    def __init__(self):
        self.reservations = {}

    def add_reservation(self, reservation):
        if reservation.reservation_id in self.reservations:
            raise ValueError("SORRY Entered Reservation ID already exists.")
        self.reservations[reservation.reservation_id] = reservation

    def update_reservation(self, reservation_id, **updates):
        if reservation_id not in self.reservations:
            raise ValueError("SORRY Entered Reservation ID does not exist.")
        for key, value in updates.items():
            if hasattr(self.reservations[reservation_id], key):
                setattr(self.reservations[reservation_id], key, value)
            else:
                raise Exception(f"Invalid attribute: {key}")

    def cancel_reservation(self, reservation_id):
        if reservation_id not in self.reservations:
            raise ValueError("SORRY Entered Reservation ID does not exist.")
        del self.reservations[reservation_id]

    def get_reservations_by_flight(self, flight_id):
        return [reservation for reservation in self.reservations.values() if reservation.flight_id == flight_id]

    def passengers_on_flight(self, flight_id):
        reservations = self.get_reservations_by_flight(flight_id)
        if not reservations:
            print(f"No reservations for flight ID: {flight_id}")
        else:
            for res in reservations:
                print(f"{res.reservation_id}: {res.passenger_name}, Seat: {res.seat_number}")

    def display_reservation(self):
        for reservation in self.reservations.values():
            print(reservation)
