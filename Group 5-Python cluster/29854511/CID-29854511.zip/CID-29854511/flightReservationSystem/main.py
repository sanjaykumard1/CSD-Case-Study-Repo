from flights import *
from reservation import *

def main():
    flight_manager = FlightManagement()
    reservation_manager = ReservationManagement()

    while True:
        print("\t")
        heading = "Airline Reservation Management System"
        print(heading.center(50, "*"))
        print("\t")
        print("1. Add Flight")
        print("2. Update Flight")
        print("3. Delete Flight")
        print("4. View All Flights")
        print("5. Add Reservation")
        print("6. Update Reservation")
        print("7. Cancel Reservation")
        print("8. View All Reservations")
        print("9. View Passengers on a Flight")
        print("10. Exit")
        print("\t")

        choice = input("Enter your choice: ")

        try:
            match choice:
                case '1':
                    flight_id = int(input("Enter Flight ID: "))
                    airline = input("Enter Airline: ")
                    destination = str(input("Enter Destination: "))
                    departure_time = input("Enter Departure Time (YYYY-MM-DD HH:MM:SS): ")
                    available_seats = int(input("Enter Available Seats: "))
                    flight = Flight(flight_id, airline, destination, departure_time, available_seats)
                    flight_manager.add_flight(flight)
                    print("Flight added successfully.")

                case '2':
                    flight_id = int(input("Enter Flight ID you want to update: "))
                    airline = input("Enter new Airline (leave blank if no change): ")
                    destination = input("Enter new Destination (leave blank if no change): ")
                    departure_time = input("Enter new Departure Time (YYYY-MM-DD HH:MM:SS) (leave blank if no change): ")
                    available_seats = input("Enter new Available Seats (leave blank if no change): ")

                    new = {}
                    if airline:
                        new['airline'] = airline
                    if destination:
                        new['destination'] = str(destination)
                    if departure_time:
                        new['departure_time'] = departure_time
                    if available_seats:
                        new['available_seats'] = int(available_seats)

                    flight_manager.update_flight(flight_id, **new)
                    print("Flight updated successfully.")

                case '3':
                    flight_id = int(input("Enter Flight ID to delete: "))
                    flight_manager.delete_flight(flight_id)
                    print("Flight deleted successfully.")

                case'4':
                    print("\nAll Flights :")
                    flight_manager.display_flights()

                case '5':
                    reservation_id = int(input("Enter Reservation ID: "))
                    passenger_name = input("Enter Passenger Name: ")
                    flight_id = int(input("Enter Flight ID: "))
                    seat_number = int(input("Enter Seat Number: "))
                    reservation_date = input("Enter Reservation Date (YYYY-MM-DD): ")
                    reservation = Reservation(reservation_id, passenger_name, flight_id, seat_number, reservation_date)
                    reservation_manager.add_reservation(reservation)
                    print("Reservation added successfully!!!!")

                case '6':
                    reservation_id = int(input("Enter Reservation ID you want to update: "))
                    passenger_name = input("Enter new Passenger Name (leave blank if no change): ")
                    flight_id = input("Enter new Flight ID (leave blank if no change): ")
                    seat_number = input("Enter new Seat Number (leave blank if no change): ")
                    reservation_date = input("Enter new Reservation Date (YYYY-MM-DD) (leave blank if no change): ")

                    new = {}
                    if passenger_name:
                        new['passenger_name'] = passenger_name
                    if flight_id:
                        new['flight_id'] = int(flight_id)
                    if seat_number:
                        new['seat_number'] = int(seat_number)
                    if reservation_date:
                        new['reservation_date'] = reservation_date

                    reservation_manager.update_reservation(reservation_id, **new)
                    print("Reservation updated successfully.")

                case '7':
                    reservation_id = int(input("Enter Reservation ID you want to cancel: "))
                    reservation_manager.cancel_reservation(reservation_id)
                    print("Reservation cancelled successfully!!!!")

                case '8':
                    print("\nAll Reservations:")
                    reservation_manager.display_reservation()

                case '9':
                    flight_id = int(input("Please enter Flight ID to view passengers: "))
                    print("\nPassengers on Flight:")
                    print(reservation_manager.passengers_on_flight(flight_id))

                case '10':
                    print("Exiting...")
                    break

                case _:
                    print("Invalid choice. Please try again.")

        except (Exception, ValueError) as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
