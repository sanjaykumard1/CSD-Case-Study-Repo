class Flight:
    def __init__(self, flight_id, airline, destination, departure_time, available_seats):
        self.flight_id = flight_id
        self.airline = airline
        self.destination = destination
        self.departure_time = departure_time
        self.available_seats = available_seats

    def __str__(self):
        return (f"Flight ID: {self.flight_id}, Airline: {self.airline}, "
                f"Destination: {self.destination}, Departure: {self.departure_time}, "
                f"Available Seats: {self.available_seats}")


class FlightManagement:
    def __init__(self):
        self.flights = {}

    def add_flight(self, flight):
        if flight.flight_id in self.flights:
            raise ValueError("SORRY Entered Flight ID already exists.")
        self.flights[flight.flight_id] = flight

    def update_flight(self, flight_id, **updates):
        if flight_id not in self.flights:
            raise ValueError("SORRY Entered Flight ID does not exist.")
        for key, value in updates.items():
            if hasattr(self.flights[flight_id], key):
                setattr(self.flights[flight_id], key, value)
            else:
                raise Exception(f"Invalid attribute: {key}")

    def delete_flight(self, flight_id):
        if flight_id not in self.flights:
            raise Exception("SORRY Entered Flight ID does not exist.")
        del self.flights[flight_id]

    def display_flights(self):
        for flight in self.flights.values():
            print(flight)
