import sqlite3 as sq

import datetime

#establishing SQLite connection
def db_connect():
    try:
        conn = sq.connect('fcm_database.db')
        return conn
    except sq.Error as e:
        print(e)
    return  None

# creating tables in SQLite 
def create_tables(conn):
    try:
        c = conn.cursor()

        # Creating Memberships table
        c.execute('''CREATE TABLE IF NOT EXISTS Memberships (
                        membership_id INTEGER PRIMARY KEY,
                        member_name TEXT NOT NULL,
                        member_contact TEXT,
                        membership_type TEXT,
                        membership_expiry DATE
                     )''')

        # Creating Trainers table
        c.execute('''CREATE TABLE IF NOT EXISTS Trainers (
                        trainer_id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        specialty TEXT,
                        contact_info TEXT,
                        availability TEXT
                     )''')

        # Create Classes table
        c.execute('''CREATE TABLE IF NOT EXISTS Classes (
                        class_id INTEGER PRIMARY KEY,
                        class_name TEXT NOT NULL,
                        trainer_id INTEGER,
                        schedule DATETIME,
                        capacity INTEGER,
                        FOREIGN KEY (trainer_id) REFERENCES Trainers(trainer_id)
                     )''')

        # Creating Attendance table
        c.execute('''CREATE TABLE IF NOT EXISTS Attendance (
                        attendance_id INTEGER PRIMARY KEY,
                        member_id INTEGER,
                        class_id INTEGER,
                        attendance_date DATE,
                        FOREIGN KEY (member_id) REFERENCES Memberships(membership_id),
                        FOREIGN KEY (class_id) REFERENCES Classes(class_id)
                     )''')

        conn.commit()
        print("Tables created successfully.")

    except sq.Error as e:
        print(e)

# Class Definitions
class Membership:
    def __init__(self, membership_id, member_name, member_contact, membership_type, membership_expiry):
        self.membership_id = membership_id
        self.member_name = member_name
        self.member_contact = member_contact
        self.membership_type = membership_type
        self.membership_expiry = membership_expiry

    def __str__(self):
        return f"Membership ID: {self.membership_id}, Name: {self.member_name}, Type: {self.membership_type}, Expiry: {self.membership_expiry}"

class Trainer:
    def __init__(self, trainer_id, name, specialty, contact_info, availability):
        self.trainer_id = trainer_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.availability = availability

    def __str__(self):
        return f"Trainer ID: {self.trainer_id}, Name: {self.name}, Specialty: {self.specialty}, Availability: {self.availability}"

class FitnessClass:
    def __init__(self, class_id, class_name, trainer_id, schedule, capacity):
        self.class_id = class_id
        self.class_name = class_name
        self.trainer_id = trainer_id
        self.schedule = schedule
        self.capacity = capacity

    def __str__(self):
        return f"Class ID: {self.class_id}, Name: {self.class_name}, Schedule: {self.schedule}, Capacity: {self.capacity}"

class Attendance:
    def __init__(self, attendance_id, member_id, class_id, attendance_date):
        self.attendance_id = attendance_id
        self.member_id = member_id
        self.class_id = class_id
        self.attendance_date = attendance_date

    def __str__(self):
        return f"Attendance ID: {self.attendance_id}, Member ID: {self.member_id}, Class ID: {self.class_id}, Date: {self.attendance_date}"

class FitnessCenterManagement:
    def __init__(self):
        self.conn = db_connect()
        if self.conn:
            create_tables(self.conn)

    # Membership Management
    def add_membership(self, member):
        try:
            c = self.conn.cursor()
            c.execute('''INSERT INTO Memberships (member_name, member_contact, membership_type, membership_expiry)
                         VALUES (?, ?, ?, ?)''', (member.member_name, member.member_contact, member.membership_type, member.membership_expiry))
            self.conn.commit()
            print("Membership added successfully.")
        except sq.Error as e:
            print(e)

    def update_membership(self, membership_id, new_membership):
        try:
            c = self.conn.cursor()
            c.execute('''UPDATE Memberships
                         SET member_name=?, member_contact=?, membership_type=?, membership_expiry=?
                         WHERE membership_id=?''',
                      (new_membership.member_name, new_membership.member_contact, new_membership.membership_type,
                       new_membership.membership_expiry, membership_id))
            self.conn.commit()
            print("Membership updated successfully.")
        except sq.Error as e:
            print(e)

    def delete_membership(self, membership_id):
        try:
            c = self.conn.cursor()
            c.execute('''DELETE FROM Memberships WHERE membership_id=?''', (membership_id,))
            self.conn.commit()
            print("Membership deleted successfully.")
        except sq.Error as e:
            print(e)

    # Trainer Management
    def add_trainer(self, trainer):
        try:
            c = self.conn.cursor()
            c.execute('''INSERT INTO Trainers (name, specialty, contact_info, availability)
                         VALUES (?, ?, ?, ?)''', (trainer.name, trainer.specialty, trainer.contact_info, trainer.availability))
            self.conn.commit()
            print("Trainer added successfully.")
        except sq.Error as e:
            print(e)

    def update_trainer(self, trainer_id, new_trainer):
        try:
            c = self.conn.cursor()
            c.execute('''UPDATE Trainers
                         SET name=?, specialty=?, contact_info=?, availability=?
                         WHERE trainer_id=?''',
                      (new_trainer.name, new_trainer.specialty, new_trainer.contact_info,
                       new_trainer.availability, trainer_id))
            self.conn.commit()
            print("Trainer updated successfully.")
        except sq.Error as e:
            print(e)

    def delete_trainer(self, trainer_id):
        try:
            c = self.conn.cursor()
            c.execute('''DELETE FROM Trainers WHERE trainer_id=?''', (trainer_id,))
            self.conn.commit()
            print("Trainer deleted successfully.")
        except sq.Error as e:
            print(e)

    # Class Management
    def add_class(self, fitness_class):
        try:
            c = self.conn.cursor()
            c.execute('''INSERT INTO Classes (class_name, trainer_id, schedule, capacity)
                         VALUES (?, ?, ?, ?)''', (fitness_class.class_name, fitness_class.trainer_id,
                                                  fitness_class.schedule, fitness_class.capacity))
            self.conn.commit()
            print("Class added successfully.")
        except sq.Error as e:
            print(e)

    def update_class(self, class_id, new_class):
        try:
            c = self.conn.cursor()
            c.execute('''UPDATE Classes
                         SET class_name=?, trainer_id=?, schedule=?, capacity=?
                         WHERE class_id=?''',
                      (new_class.class_name, new_class.trainer_id, new_class.schedule,
                       new_class.capacity, class_id))
            self.conn.commit()
            print("Class updated successfully.")
        except sq.Error as e:
            print(e)

    def delete_class(self, class_id):
        try:
            c = self.conn.cursor()
            c.execute('''DELETE FROM Classes WHERE class_id=?''', (class_id,))
            self.conn.commit()
            print("Class deleted successfully.")
        except sq.Error as e:
            print(e)

    # Attendance Management
    def record_attendance(self, attendance):
        try:
            c = self.conn.cursor()
            c.execute('''INSERT INTO Attendance (member_id, class_id, attendance_date)
                         VALUES (?, ?, ?)''', (attendance.member_id, attendance.class_id, attendance.attendance_date))
            self.conn.commit()
            print("Attendance recorded")
        except sq.Error as e:
            print(e)

    def update_attendance(self, attendance_id, new_attendance):
        try:
            c = self.conn.cursor()
            c.execute('''UPDATE Attendance
                         SET member_id=?, class_id=?, attendance_date=?
                         WHERE attendance_id=?''',
                      (new_attendance.member_id, new_attendance.class_id, new_attendance.attendance_date, attendance_id))
            self.conn.commit()
            print("Attendance updated")
        except sq.Error as e:
            print(e)

    def delete_attendance(self, attendance_id):
        try:
            c = self.conn.cursor()
            c.execute('''DELETE FROM Attendance WHERE attendance_id=?''', (attendance_id,))
            self.conn.commit()
            print("Attendance deleted")
        except sq.Error as e:
            print(e)

    # Display methods
    def display_memberships(self):
        try:
            c = self.conn.cursor()
            c.execute('''SELECT * FROM Memberships''')
            rows = c.fetchall()
            print("\nMemberships:")
            for row in rows:
                print("Membership ID: " + str(row[0]) + ", Name: " + row[1] + ", Type: " + row[3] + ", Expiry: " + row[4])

        except sq.Error as e:
            print(e)

    def display_trainers(self):
        try:
            c = self.conn.cursor()
            c.execute('''SELECT * FROM Trainers''')
            rows = c.fetchall()
            print("\nTrainers:")
            for row in rows:
                print("Trainer ID: " + str(row[0]) + ", Name: " + row[1] + ", Specialty: " + row[2] + ", Availability: " + row[4])

        except sq.Error as e:
            print(e)

    def display_classes(self):
        try:
            c = self.conn.cursor()
            c.execute('''SELECT * FROM Classes''')
            rows = c.fetchall()
            print("\nClasses:")
            for row in rows:
                print("Class ID: " + str(row[0]) + ", Name: " +str( row[1]) + ", Schedule: " + str(row[3]) + ", Capacity: " + str(row[4]) ) 
        except sq.Error as e:
            print(e)

    def display_attendance(self):
        try:
            c = self.conn.cursor()
            c.execute('''SELECT * FROM Attendance''')
            rows = c.fetchall()
            print("\nAttendance Records:")
            for row in rows:
                print("Attendance ID: " + str(row[0]) + ", Member ID: " + str(row[1]) + ", Class ID: " + str(row[2]) + ", Date: " + str(row[3]))
        except sq.Error as e:
            print(e)

    # Query 1: Find the total number of members whose memberships expire in the next month
    def get_expiring_members(self):
        cursor = self.conn.cursor()
        next_month = (datetime.now() + datetime.timedelta(days=30)).date()
        cursor.execute('''
        SELECT COUNT(*) AS total_members_expiring_next_month
        FROM Memberships
        WHERE membership_expiry BETWEEN DATE('now') AND ?
        ''', (next_month,))
        result = cursor.fetchone()
        return result[0]

    # Query 2: Find the trainers who are available for a specific specialty
    def get_trainers_by_specialty(self,specialty):
        cursor = self.conn.cursor()
        cursor.execute('''
        SELECT trainer_id, name, contact_info, availability
        FROM Trainers
        WHERE specialty = ?
        ''', (specialty,))
        results = cursor.fetchall()
        return results

    # Query 3: Find the classes that are fully booked
    def get_fully_booked_classes(self):
        cursor = self.conn.cursor()
        cursor.execute('''
        SELECT c.class_id, c.class_name, c.trainer_id, c.schedule, c.capacity
        FROM Classes c
        JOIN (SELECT class_id, COUNT(*) AS attendance_count
            FROM Attendance
            GROUP BY class_id) a ON c.class_id = a.class_id
        WHERE a.attendance_count >= c.capacity
        ''')
        results = cursor.fetchall()
        return results

    # Query 4: Find the members who have attended the most classes in the past month
    def get_top_attending_members(self):
        cursor = self.conn.cursor()
        last_month = (datetime.now() - datetime.timedelta(days=30)).date()
        cursor.execute('''
        SELECT m.member_name, m.member_contact, COUNT(a.attendance_id) AS total_classes_attended
        FROM Attendance a
        JOIN Memberships m ON a.member_id = m.membership_id
        WHERE a.attendance_date BETWEEN ? AND DATE('now')
        GROUP BY m.member_name, m.member_contact
        ORDER BY total_classes_attended DESC
        LIMIT 1
        ''', (last_month,))
        result = cursor.fetchone()
        return result

    # Query 5: Find the schedule and details of classes conducted by a specific trainer
    def get_classes_by_trainer(self,trainer_id):
        cursor = self.conn.cursor()
        cursor.execute('''
        SELECT c.class_id, c.class_name, c.schedule, c.capacity
        FROM Classes c
        JOIN Trainers t ON c.trainer_id = t.trainer_id
        WHERE t.trainer_id = ?
        ''', (trainer_id,))
        results = cursor.fetchall()
        return results
def main():
    fcm = FitnessCenterManagement()

    while True:
        print("\n1. Add Membership")
        print("2. Add Trainer")
        print("3. Add Class")
        print("4. Record Attendance")
        print("5. Update Membership")
        print("6. Delete Class")
        print("7. Display Memberships,Trainers,Classes")
        print("8. Execute queries" )
        print("0. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            id = int(input("Enter Membership ID: "))
            name = input("Enter Name: ")
            contact = input("Enter Contact Number: ")
            type = input("Enter Membership Type: ")
            expiry_year = int(input("Enter Expiry Year (YYYY): "))
            expiry_month = int(input("Enter Expiry Month (MM): "))
            expiry_day = int(input("Enter Expiry Day (DD): "))
            expiry = datetime.date(expiry_year, expiry_month, expiry_day)
            membership = Membership(id, name, contact, type, expiry)
            fcm.add_membership(membership)

        elif choice == '2':
            id = int(input("Enter Trainer ID: "))
            name = input("Enter Name: ")
            specialty = input("Enter Specialty: ")
            email = input("Enter Email: ")
            availability = input("Enter Availability: ")
            trainer = Trainer(id, name, specialty, email, availability)
            fcm.add_trainer(trainer)

        elif choice == '3':
            id = int(input("Enter Class ID: "))
            name = input("Enter Class Name: ")
            trainer_id = int(input("Enter Trainer ID: "))
            schedule = input("Enter Schedule (YYYY-MM-DD HH:MM:SS): ")
            capacity = int(input("Enter Capacity: "))
            fitness_class = FitnessClass(id, name, trainer_id, schedule, capacity)
            fcm.add_class(fitness_class)

        elif choice == '4':
            id = int(input("Enter Attendance ID: "))
            member_id = int(input("Enter Member ID: "))
            class_id = int(input("Enter Class ID: "))
            date_year = int(input("Enter Date Year (YYYY): "))
            date_month = int(input("Enter Date Month (MM): "))
            date_day = int(input("Enter Date Day (DD): "))
            date = datetime.date(date_year, date_month, date_day)
            attendance = Attendance(id, member_id, class_id, date)
            fcm.record_attendance(attendance)

        elif choice == '5':
            id = int(input("Enter Membership ID to update: "))
            name = input("Enter Name: ")
            contact = input("Enter Contact Number: ")
            type = input("Enter Membership Type: ")
            expiry_year = int(input("Enter Expiry Year (YYYY): "))
            expiry_month = int(input("Enter Expiry Month (MM): "))
            expiry_day = int(input("Enter Expiry Day (DD): "))
            expiry = datetime.date(expiry_year, expiry_month, expiry_day)
            updated_membership = Membership(id, name, contact, type, expiry)
            fcm.update_membership(id, updated_membership)

        elif choice == '6':
            id = int(input("Enter Class ID to delete: "))
            fcm.delete_class(id)

        elif choice == '7':
            fcm.display_memberships()
            fcm.display_trainers()
            fcm.display_classes()
            fcm.display_attendance()

        elif choice == '8':
            print("\n select query to be execute")
            while True:
                print("\n1. find the total number of members whose memberships expire in the next month.")
                print("2. find the trainers who are available for a specific specialty")
                print("3. find the classes that are fully booked")
                print("4. find the members who have attended the most classes in the past month")
                print("5. find the schedule and details of classes conducted by a specific trainer")
                print("0. To exit")
                opt = input("Enter your choice: ")
                if opt =="1":
                    print("Total members expiring next month:", fcm.get_expiring_members())
                elif opt=="2":
                    specialty=input("enter speciality :")
                    print(f"Trainers available for {specialty}:")
                    for trainer in fcm.get_trainers_by_specialty(specialty):
                        print(trainer)
                elif opt=="3":
                        print("Fully booked classes:")
                        for class_info in fcm.get_fully_booked_classes():
                            print(class_info)
                elif opt=="4":
                    print("Top attending member in the past month:", fcm.get_top_attending_members())
                elif opt=="5":
                    trainer_id = int(input("Enter trainer id"))  
                    print(f"Classes conducted by trainer {trainer_id}:")
                    for class_info in fcm.get_classes_by_trainer(trainer_id):
                        print(class_info)
                elif opt =="0":
                    break
                else:
                    print("wrong key")         

        elif choice == '0':
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
