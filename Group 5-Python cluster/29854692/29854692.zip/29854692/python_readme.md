For the given python question we can solve by -->

We Create a class of Products where we will initialize the variables(attributes) and we will return the string otherwise the form will be in object class.

Then we create the Inventory class where we initialize the products list and create various functions to perform various tasks:

    add_new_product()--> function to add new product object to list.

    update_product() --> Helps in updating the exsisting object in a list.

    delete_product() --> Removes the product object from products list.

    check_stock_level() --> returns the quantity of product.

    update_stock_level() --> updates the quantity of product. 

    generate_low_stock_report() --> we will return the list of products with less stock.

main() function to include all other console based activites such as taking input values from the users and printing the desired results.


Usage:
    Run -> python3 inventory.py
    Results ->
    Inventory Management System
    1. Add new Product
    2. Update the product
    3. Delete the Product
    4. Check Stock Level
    5. Update the Stock Level
    6. Generate the low stock report
    7. Exit

    Enter your choice: 1
    Enter the Product_id: 1
    Enter the name of product: Lays
    Enter the category of the product: Food
    Enter the price of the product: 10
    Enter the Quantity: 5
    Product add success

    Enter your choice: 2
    Enter the product_id to update: 1
    Enter the new name: Chips
    Enter the new category of the product: Food
    Enter the new price: 15
    Enter the new quantity: 6
    Product update success

    Enter your choice: 4
    Enter the product_id: 1
    The current stock is 6

    Enter your choice: 5
    Enter the product id: 1
    Enter the value to change stock: 3
    Stock level update success

    Enter your choice: 6
    Low stock products:
    Id: 1, Name: Chips, Category: Food, Price: 15.0, Quantity: 9

    Enter your choice: 3
    Enter the product_id to delete: 1
    Delete success

    Enter your choice: 7
    Goodbye.
















