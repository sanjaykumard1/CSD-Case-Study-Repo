class Products:
    def __init__(self, product_id, name, category, price, quantity_in_stock):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def __str__(self):
        return f"Id: {self.product_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Quantity: {self.quantity_in_stock}"

class Inventory:
    def __init__(self):
        self.products = []  #[Products(p_id1,name1,cat1,price1,quantity1,
                            # Products(p_id2,name2,cat2,price2,quantity2)...]
    
    def add_new_product(self, product):
        for exist_product in self.products:
            if exist_product.product_id == product.product_id:
                raise ValueError("Oops! The Value already Exists")
        self.products.append(product)
    def update_product(self, product_id, name, category, price, quantity_in_stock):
        flag = False
        for product in self.products:
            if product.product_id == product_id:
                product.name = name
                product.category = category
                product.price = price
                product.quantity_in_stock = quantity_in_stock
                flag = True      # Once we find the specified id we break to avoid looping again
                break
        if not flag:
            raise ValueError("The Product does not exist")
    def delete_product(self, product_id):
        flag = False
        for i, product in enumerate(self.products):
            if product.product_id == product_id:
                del self.products[i]
                flag = True     # Once we find the specified id we break to avoid looping again
                break
        if not flag:
            raise ValueError("The product does not exist to delete!")
    def check_stock_level(self, product_id):
        for product in self.products:
            if product.product_id == product_id:
                return product.quantity_in_stock
        raise ValueError("Oops! The Product does not exist")
    
    def update_stock_level(self, product_id, quantity_change):
        flag = False
        for product in self.products:
            if product.product_id == product_id:
                product.quantity_in_stock += quantity_change
                flag = True
                break
        if not flag:
            raise ValueError("Sorry! The Product Does not Exist to update the stock")
    def generate_low_stock_report(self):
        low_stock = []
        for product in self.products:
            if product.quantity_in_stock < 10:
                low_stock.append(product)
        return low_stock

def main():
    inven = Inventory()

    while True:
        print()
        print("Inventory Management System")
        print("1. Add new Product")
        print("2. Update the product")
        print("3. Delete the Product")
        print("4. Check Stock Level")
        print("5. Update the Stock Level")
        print("6. Generate the low stock report")
        print("7. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            try:
                product_id = input("Enter the Product_id: ")
                name = input("Enter the name of product: ")
                category = input("Enter the category of the product: ")
                price = float(input("Enter the price of the product: "))
                quantity = int(input("Enter the Quantity: "))
                product = Products(product_id, name, category, price, quantity)
                inven.add_new_product(product)
                print("Product add success")
            except Exception as err:
                print(f"Error: {err}")

        elif choice == "2":
            try:
                product_id = input("Enter the product_id to update: ")
                name = input("Enter the new name: ")
                category = input("Enter the new category of the product: ")
                price = float(input("Enter the new price: "))
                quantity = int(input("Enter the new quantity: "))
                inven.update_product(product_id, name, category, price, quantity)
                print("Product update success")
            except Exception as err:
                print(f"Error: {err}")

        elif choice == "3":
            try:
                product_id = input("Enter the product_id to delete: ")
                inven.delete_product(product_id)
                print("Delete success")
            except Exception as err:
                print(f"Error: {err}")

        elif choice == "4":
            try:
                product_id = input("Enter the product_id: ")
                res = inven.check_stock_level(product_id)
                print(f"The current stock is {res}")
            except Exception as err:
                print(f"Error: {err}")

        elif choice == "5":
            try:
                product_id = input("Enter the product id: ")
                quantity_change = int(input("Enter the value to change stock: "))
                inven.update_stock_level(product_id, quantity_change)
                print("Stock level update success")
            except Exception as err:
                print(f"Error: {err}")
            
        elif choice == "6":
            try:
                res = inven.generate_low_stock_report()
                if res:
                    print("Low stock products:")
                    for product in res:
                        print(product)
                else:
                    print("No products are low in stock.")
            except Exception as err:
                print(f"Error: {err}")

        elif choice == "7":
            print("Goodbye..")
            exit()
        else:
            print("Invalid Option! Please try Again")

if __name__ == "__main__":
    main()
