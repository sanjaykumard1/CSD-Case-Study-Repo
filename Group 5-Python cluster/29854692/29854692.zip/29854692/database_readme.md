We first create the Database named Inventory

We create 3 Tables:
    Products,Sales,Restocks by specifying the columns with type of data

Then we will insert the random values into the tables to perform querying operation

1)Our Objective is to find total quantity of each product sold -->
We use SELECT to extract the specified columns form specified table and use GROUP BY to group the products with same id in Sales table.

result: 
product_id, total_quantity_sold
    1	        24
    2	        30
    3	        6
    4	        24
    5	        0
    6	        12
    7	        18
    8	        36
    9	        21


2)Our Objective is to extract the data of quantity of each product sold and name of product -->
As the Product name is in Product table and quantity sold data is in Sales table We perform JOIN operation by using Primary Key from Product Table and Foreign Key from Sales Table

result:
namee, total_quantity_sold
Desk Lamp	12
Headphones	24
Keyboard	21
Laptop	    24
Monitor 	18
Mouse	    36
Office Chair 0
Smartphone	30
Tablet	    6

3)Here Our Objective is to fing the name of products which are never sold-->
Similary here we Perform JOIN operation and check Condition using WHERE quantity_sold = 0

result:
namee
Office Chair
Office Chair
Office Chair

4)Here,We need to get the products which is restocked more than 2 times -->
We use COUNT function to get the number of times the restock as happened by using GROUP BY clause

result:
product_id, restock_count
1           6
2           6

5)Here,It is to retrive the name and stock quantities of products from Product table and having more than 20 units sold as it can be calculated from sales table -->
We use SubQuery to get the data of product_id and sum of quantity sold from sales table having quantity_sold more than 20 and then perform JOIN with Product table to get the name and quantity_in_stock which as total_quantity_sold > 20


results:
namee, quantity_in_stock
Laptop	    50
Smartphone	200
Headphones	150
Mouse	    500
Keyboard	300

