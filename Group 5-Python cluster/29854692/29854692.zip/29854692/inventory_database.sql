
Create Database Inventory;

USE Inventory;

Create Table Products(
	product_id INT auto_increment primary KEY,
    namee varchar(100) NOT Null,
    category Varchar(50) Not Null,
    price decimal(10,2) not null,
    quantity_in_stock INT not null
    );

Create Table Sales(
	sale_id INT auto_increment PRIMARY KEY,
    product_id INT,
    quantity_in_stock INT not null,
    sale_date DATE,
    foreign key(product_id) references Products(product_id)
);

Alter Table Sales Add column quantity_sold INT;


Create Table Restocks(
	restock_id INT auto_increment primary key,
    product_id INT,
    quantity_restocked INT,
    restock_date DATE,
    foreign key(product_id) references Products(product_id)
);

INSERT INTO Products (namee, category, price, quantity_in_stock) VALUES ('Laptop', 'Electronics', 999.99, 50),('Smartphone', 'Electronics', 699.99, 200),('Tablet', 'Electronics', 299.99, 100),('Headphones', 'Accessories', 199.99, 150),
('Office Chair', 'Furniture', 89.99, 30),('Desk Lamp', 'Furniture', 29.99, 70),('Monitor', 'Electronics', 149.99, 80),('Mouse', 'Accessories', 19.99, 500),('Keyboard', 'Accessories', 49.99, 300),('Printer', 'Electronics', 129.99, 40);

/*I add inserted same data thrice in sales table to perfome some query*/
INSERT INTO Sales (product_id, quantity_sold, sale_date) VALUES (1, 5, '2024-07-01'),(2, 10, '2024-07-01'),(3, 2, '2024-07-02'),(4, 8, '2024-07-03'),(1, 3, '2024-07-04'),
(5, 0, '2024-07-05'),(6, 4, '2024-07-06'),(7, 6, '2024-07-06'),(8, 12, '2024-07-07'),(9, 7, '2024-07-08');

/*I add inserted same data thrice in Restocks table to perfome some query*/
INSERT INTO Restocks (product_id, quantity_restocked, restock_date) VALUES (1, 20, '2024-07-02'),(2, 50, '2024-07-03'),(3, 30, '2024-07-04'),(4, 25, '2024-07-05'),(5, 10, '2024-07-06'),
(6, 40, '2024-07-07'),(7, 50, '2024-07-08'),(8, 100, '2024-07-09'),(9, 60, '2024-07-10'),(10, 30, '2024-07-11');

/*1.Write a query to find the total quantity of each product sold.*/
select product_id,SUM(quantity_sold) as total_quantity_sold
from Sales group by product_id;

/*2.Write a query to find the product name and total quantity sold for each product.*/
select p.namee,SUM(s.quantity_sold) as total_quantity_sold
from Sales s JOIN Products p ON s.product_id = p.product_id
group by p.namee;

/*3.Write a query to find the names of products that have never been sold.*/
select p.namee from Products p join Sales s on s.product_id = p.product_id
where s.quantity_sold = 0;

/*4.Write a query to find the products that have been restocked more than 5 times.*/
select product_id,COUNT(*) AS restock_count
from restocks
group by product_id having restock_count >5;

/*5.	Write a query to find the product names and their current stock levels for products that have sold more than 20 units.*/
select p.namee, p.quantity_in_stock
from Products p
join ( select product_id, SUM(quantity_sold) as total_quantity_sold
from Sales group by product_id having total_quantity_sold > 20 ) s on p.product_id = s.product_id;



