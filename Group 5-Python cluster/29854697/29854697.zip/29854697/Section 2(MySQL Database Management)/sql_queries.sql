1.Write a query to find the total number of students enrolled in each course.
SELECT course_id, COUNT(student_id) AS total_students
FROM Enrollments
GROUP BY course_id;
2.Write a query to find the names of students and the courses they are enrolled in.
SELECT s.name, c.course_name
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
JOIN Courses c ON e.course_id = c.course_id;
3.Write a query to find the names of students who are not enrolled in any courses.
SELECT name
FROM Students
WHERE student_id NOT IN (SELECT DISTINCT student_id FROM Enrollments);
4.Write a query to find the courses that have more than 30 students enrolled.
SELECT course_id
FROM Enrollments
GROUP BY course_id
HAVING COUNT(student_id) > 30;
5.Write a query to find the student names and their corresponding majors for those who are enrolled in more than 3 courses.
SELECT s.name AS student_name, s.major
FROM Students s
JOIN Enrollments e ON s.student_id = e.student_id
GROUP BY s.student_id, s.name, s.major
HAVING COUNT(e.course_id) > 3;


