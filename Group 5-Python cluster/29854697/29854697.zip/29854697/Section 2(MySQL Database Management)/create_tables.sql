CREATE DATABASE IF NOT EXISTS student_enrollment;
USE student_enrollment;

CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    major VARCHAR(50),
    year VARCHAR(10)
);

CREATE TABLE Courses (
    course_id INT PRIMARY KEY,
    course_name VARCHAR(100),
    credits INT
);

CREATE TABLE Enrollments (
    enrollment_id INT PRIMARY KEY,
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);
USE student_enrollment;

INSERT INTO Students (student_id, name, age, major, year) VALUES
(1, 'Alice', 20, 'Computer Science', 'Sophomore'),
(2, 'Bob', 22, 'Mathematics', 'Senior'),
(3, 'Charlie', 21, 'Physics', 'Junior');

INSERT INTO Courses (course_id, course_name, credits) VALUES
(101, 'Data Structures', 3),
(102, 'Algorithms', 3),
(103, 'Database Systems', 4);

INSERT INTO Enrollments (enrollment_id, student_id, course_id, enrollment_date) VALUES
(1, 1, 101, '2023-01-10'),
(2, 1, 102, '2023-01-15'),
(3, 2, 101, '2023-01-11'),
(4, 3, 102, '2023-01-20');

