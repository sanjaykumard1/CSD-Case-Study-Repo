import sqlite3
class Product:
    def __init__(self,product_id,name,description,price,stock_quantity):
        self.product_id=product_id
        self.name=name
        self.description=description
        self.price=price
        self.stock_quantity=stock_quantity
    @staticmethod
    def add_product(conn,product):
        sql='''insert into products(product_id,name,description,price,stock_quantity)values(10411,'Tablet','Android tablet',25000,15)'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
    @staticmethod
    def update_product(conn,product):
        sql='''update products set name='Updated Tablet',description='Updated Android tablet',price=26000,stock_quantity=10
                 where product_id=10411'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
    @staticmethod
    def delete_product(conn,product_id):
        sql='''delete from products where product_id=10411'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
class Customer:
    def __init__(self,customer_id,name,email,address):
        self.customer_id=customer_id
        self.name=name
        self.email=email
        self.address=address
    @staticmethod
    def add_customer(conn,customer):
        sql='''insert into customers(customer_id,name,email,address)values(3,'AAA','aaa@gmail.com','XYZ')'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
    @staticmethod
    def update_customer(conn,customer):
        sql='''update customers set name='LMN',email='lmn@gmail.com',address='GGG' where customer_id=3'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
    @staticmethod
    def delete_customer(conn,customer_id):
        sql='''delete from customers where customer_id=3'''
        cur=conn.cursor()
        cur.execute(sql)
        conn.commit()
class Order:
    def __init__(self,order_id,customer_id,product_id,order_date,quantity):
        self.order_id=order_id
        self.customer_id=customer_id
        self.product_id=product_id
        self.order_date=order_date
        self.quantity=quantity
    @staticmethod
    def place_order(conn,order):
        try:
            cur=conn.cursor()
            cur.execute('select stock_quantity from products where product_id=10411')
            stock_quantity=cur.fetchone()[0]
            if stock_quantity>=5:
                cur.execute('''insert into orders(order_id,customer_id,product_id,order_date,quantity)
                               values(3,6,10411,'10-12-2023',6)''')
                cur.execute('''update products set stock_quantity=stock_quantity-5
                               where product_id=10411''')
                conn.commit()
                return True
            else:
                raise Exception("Insufficient stock")
        except Exception as e:
            print(f"Error:{e}")
            return False
    @staticmethod
    def update_order(conn,order):
        try:
            cur=conn.cursor()
            cur.execute('select quantity from orders where order_id=3')
            old_quantity=cur.fetchone()[0]
            cur.execute('select stock_quantity from products where product_id=10411')
            stock_quantity=cur.fetchone()[0]
            if stock_quantity+old_quantity>=10:
                cur.execute('''update products set stock_quantity=stock_quantity+1-1 where product_id=10411''',(old_quantity,10))
                cur.execute('''update orders set quantity=10,order_date='2023-07-15' where order_id=3''')
                conn.commit()
                return True
            else:
                raise Exception("Insufficient stock to update order")
        except Exception as e:
            print(f"Error:{e}")
            return False
    @staticmethod
    def delete_order(conn,order_id):
        try:
            cur=conn.cursor()
            cur.execute('select product_id,quantity from orders where order_id=1')
            result=cur.fetchone()
            product_id,quantity = result[0],result[1]
            cur.execute('''update products set stock_quantity=stock_quantity+2 where product_id=10011''')
            cur.execute('delete from orders where order_id=1')
            conn.commit()
            return True
        except Exception as e:
            print(f"Error:{e}")
            return False
def initialize_db():
    conn=sqlite3.connect(':memory:')
    cur=conn.cursor()
    cur.execute('''create table products(product_id integer primary key,name text,description text,price decimal(10,2),
                   stock_quantity integer)''')
    cur.execute('''create table customers(customer_id integer primary key,name text,email text,
                   address text)''')
    cur.execute('''create table orders(order_id integer primary key,customer_id integer,product_id integer,
                   order_date text,quantity integer,
                   foreign key(customer_id)references customers(customer_id),
                   foreign key(product_id)references products(product_id))''')
    cur.execute('''insert into products(product_id,name,description,price,stock_quantity)values(10011,'Iphone','Pro models',139000,5),
                    (10211,'Laptop','12th generation',79000,10),
                    (10311,'Headphones','Bluetooth',1000,20)''')
    cur.execute('''insert into customers(customer_id,name,email,address)values(9,'ABC','abc@gmail.com','XYZ'),
                    (2, 'PQRS', 'pqrs@gmail.com', 'YYY')''')
    cur.execute('''insert into orders(order_id,customer_id,product_id,order_date,quantity)values(1,8,10011,'12-03-2022',5),
                    (2,4,10211,'20-12-2023',7)''')
    conn.commit()
    return conn
def total_revenue(conn,month):
    cur=conn.cursor()
    cur.execute("""select sum(price*quantity) as total_revenue from orders
        inner join products on orders.product_id=products.product_id where strftime('%m',order_date)=12""",(month,))
    result=cur.fetchone()
    return result[0] if result else None
def five_orders(conn):
    cur=conn.cursor()
    cur.execute("""select c.name, c.email from customers c inner join (select customer_id from orders group by customer_id
        having count(*)>5) o on c.customer_id=o.customer_id""")
    return cur.fetchall()
def restocking(conn):
    cur=conn.cursor()
    cur.execute("""select name,stock_quantity from products where stock_quantity<10""")
    return cur.fetchall()
def most_popular(conn):
    cur=conn.cursor()
    cur.execute("""select p.name as product_name,sum(o.quantity) as total_orders from orders o
        inner join products p on o.product_id=p.product_id group by p.product_id order by total_orders desc""")
    return cur.fetchall()
def specific_customer(conn, customer_id):
    cur=conn.cursor()
    cur.execute("""select p.name as product_name,o.quantity,o.order_date from orders o inner join products p on o.product_id=p.product_id
        where o.customer_id=?""",(customer_id,))
    return cur.fetchall()

def main():
    conn = initialize_db()
    print("Total revenue in December:",total_revenue(conn,'12'))
    print("\nCustomers who have placed more than five orders:")
    customers=five_orders(conn)
    for customer in customers:
        print(customer)
    print("\nProducts that need restocking:")
    restock_products=restocking(conn)
    for product in restock_products:
        print(product)
    print("\nMost popular products (most ordered):")
    popular_products=most_popular(conn)
    for product in popular_products:
        print(product)
    print("\nDetails of orders placed by a specific customer:")
    orders=specific_customer(conn,1)
    for order in orders:
        print(order)
    conn.close()

if __name__ == "__main__":
    main()
