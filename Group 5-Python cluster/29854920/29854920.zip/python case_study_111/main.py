from book import Book
from Orders import Orders
from bookstore import Bookstore


def main():
    bookstore = Bookstore()

    while True:
        print("\nOnline Bookstore Management System")
        print("1. Add Book")
        print("2. Update Book")
        print("3. Delete Book")
        print("4. Process Order")
        print("5. Low Stock Report")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            title = input("Enter title: ")
            author = input("Enter author: ")
            genre = input("Enter genre: ")
            price = float(input("Enter price: "))
            stock = int(input("Enter stock: "))
            bookstore.add_book(title, author, genre, price, stock)

        elif choice == '2':
            book_id = int(input("Enter book ID to update: "))
            title = input("Enter new title (leave blank to skip): ")
            author = input("Enter new author (leave blank to skip): ")
            genre = input("Enter new genre (leave blank to skip): ")
            price = input("Enter new price (leave blank to skip): ")
            stock = input("Enter new stock (leave blank to skip): ")
            bookstore.update_book(
                book_id,
                title if title else None,
                author if author else None,
                genre if genre else None,
                float(price) if price else None,
                int(stock) if stock else None
            )

        elif choice == '3':
            book_id = int(input("Enter book ID to delete: "))
            bookstore.delete_book(book_id)

        elif choice == '4':
            customer_id = int(input("Enter customer ID: "))
            book_id = int(input("Enter book ID: "))
            quantity = int(input("Enter quantity: "))
            bookstore.process_order(customer_id, book_id, quantity)

        elif choice == '5':
            bookstore.generate_low_stock_report()

        elif choice == '6':
            print("Exiting the system. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
