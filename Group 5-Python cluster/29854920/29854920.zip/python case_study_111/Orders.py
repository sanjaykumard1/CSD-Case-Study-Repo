class Orders:
    def __init__(self, order_id, customer_id, book_id, quantity, order_date):
        self.order_id = order_id
        self.customer_id = customer_id
        self.book_id = book_id
        self.quantity = quantity
        self.order_date = order_date

    def __str__(self):
        return f"Orders(ID={self.order_id},CustomerID={self.customer_id},BookID={self.book_id},Quantity={self.quantity},Orderdate={self.order_date})"
