from book import Book
import Orders


class Bookstore:
    def __init__(self):
        self.books = {}
        self.orders = {}
        self.next_book_id = 1
        self.next_order_id = 1

    def add_book(self, title, author, genre, price, stock):
        book_id = self.next_book_id
        new_book = Book(book_id, title, author, genre, price, stock)
        self.books[book_id] = new_book
        self.next_book_id += 1
        print(f"Book added: {new_book }")

    def update_book(self, book_id, title=None, author=None, genre=None, price=None, stock=None):
        if book_id in self.books:
            book = self.books[book_id]
            if title is not None:
                book.title = title
            if author is not None:
                book.author = author
            if genre is not None:
                book.genre = genre
            if price is not None:
                book.price = price
            if stock is not None:
                book.stock = stock
            print(f"Book updated: {book} ")
        else:
            print(f"Book with id {book_id} not found")

    def delete_book(self, book_id):
        if book_id in self.books:
            del self.books[book_id]
            print(f"Book deleted: {book_id} ")
        else:
            print(f"Book with id {book_id} not found")

    def process_order(self, customer_id, book_id, quantity):
        if book_id not in self.books:
            print(f"Book with id {book_id} not found")
            return

        book = self.books[book_id]
        if book.stock < quantity:
            print(
                f"Insufficient stock for book id {book_id}. Available stock : {book.stock}")
            return
        order_id = self.next_order_id
        new_order = Orders(order_id, customer_id, book_id, quantity)
        self.orders[order_id] = new_order
        book.stock -= quantity
        self.next_book_id += 1
        print(f"Order processed: {new_order}")
        print(f"Updated book stock: {book}")

        def low_sock_report(self):
            print("Books with low stocks(less than 5): ")
            low_stock_books = [
                book for book in self.book.values() if book.stock < 5]
            for book in low_stock_books:
                print(book)
