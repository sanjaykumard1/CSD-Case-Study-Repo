class Book:
    def __init__(self, book_id, title, author, genre, price, stock):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.price = price
        self.stock = stock

        def __str__(self):
            return f"Book(Id={self.book_id},Title={self.title},Author={self.author},Genre={self.genre},Price={self.price},Stock={self.stock})"
