select c.name,sum(o.quantity*b.price) as Total_order_amt
from customers c 
Join orders o On o.customer_id=c.customer_id
Join
books b On b.book_id=o.book_id
group by c.customer_id;