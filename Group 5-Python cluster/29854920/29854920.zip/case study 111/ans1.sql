Select b.book_id,b.title, Sum(o.quantity* b.price) as total_sales
from books b
JOIN
orders o On o.book_id=b.book_id
group by b.book_id ,b.title;
