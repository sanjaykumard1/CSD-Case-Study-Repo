select b.title 
from books b
Left join orders o
ON b.book_id=o.book_id
where o.order_id is null;