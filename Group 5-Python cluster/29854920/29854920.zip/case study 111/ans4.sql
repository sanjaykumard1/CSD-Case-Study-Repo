SELECT Customers.customer_id, Customers.name, COUNT(Orders.order_id) AS order_count
FROM Customers
JOIN Orders ON Customers.customer_id = Orders.customer_id
GROUP BY Customers.customer_id, Customers.name
HAVING COUNT(Orders.order_id) > 5;
