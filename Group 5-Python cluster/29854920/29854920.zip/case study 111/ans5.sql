select title,stock 
from books
where stock <5;