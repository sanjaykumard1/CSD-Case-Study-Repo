create table Books(
book_id int Not null,
title varchar(100),
author varchar(100),
genre varchar(50),
price decimal(10,2),
stock int,
Primary Key(book_id)
);

create table Customers(
customer_id int  Not null,
name varchar(100),
email varchar(100),
primary key(customer_id)
);

create table Orders(
order_id int primary key ,
customer_id int,
book_id int,
quantity int,
order_date date,
foreign key(customer_id) references Customers(customer_id),
foreign key(book_id) references Books(book_id)
);create table Books( book_id int Primary Key Not null, title varchar(100), author varchar(100), genre varchar(50), price decimal(10,2), stock int )
