insert into Books 
Values(2,'Subtle art','Not idea','Non-fiction',700.23,10),
(1,'Subconsious mind','Got idea','Non-fiction',900,7),
(3,'Ikigai','J.J','fiction',1000,4);