create database Hotel;
use Hotel;
create table Rooms (
    room_id int primary key,
    room_type varchar(50),
    price_per_night decimal(10, 2),
    is_available boolean);    
insert into Rooms (room_id, room_type, price_per_night, is_available) values
(1, 'Single', 500.00, TRUE),
(2, 'Double', 800.00, TRUE),
(3, 'Suite', 1500.00, FALSE);

create table Guests (
    guest_id int primary key,
    name varchar(100),
    contact_number varchar(15),
    address varchar(255));    
insert into Guests (guest_id, name, contact_number, address) values
(101, 'Harry', '1234567890', '123 Elm Street'),
(102, 'Charles', '0987654321', '456 Oak Avenue'),
(103, 'Lily', '1122334455', '789 Pine Road');

    
create table Bookings (
    booking_id int primary key,
    guest_id int,
    room_id int,
    check_in_date date,
    check_out_date date,
    foreign key(guest_id) references Guests(guest_id),
    foreign key (room_id) references Rooms(room_id));
insert into Bookings (booking_id, guest_id, room_id, check_in_date, check_out_date) values
(1001, 101, 1, '2024-07-01', '2024-07-05'),
(1002, 102, 2, '2024-07-10', '2024-07-15'),
(1003, 103, 3, '2024-07-20', '2024-07-25');

select*from Rooms;

select SUM(price_per_night * DATEDIFF(check_out_date, check_in_date)) as total_revenue
from Bookings
join Rooms on Bookings.room_id = Rooms.room_id;

select Guests.name, Guests.contact_number from Guests
join Bookings on Guests.guest_id = Bookings.guest_id
group by Guests.guest_id
having COUNT(Bookings.room_id) > 1;

select distinct room_type from Rooms
where is_available = TRUE;

select Guests.* from Guests
join Bookings on Guests.guest_id = Bookings.guest_id
where DATEDIFF(check_out_date, check_in_date) > 5;

select * from Bookings
where check_in_date between DATE_SUB(CURDATE(), INTERVAL 1 MONTH) AND CURDATE();



    



