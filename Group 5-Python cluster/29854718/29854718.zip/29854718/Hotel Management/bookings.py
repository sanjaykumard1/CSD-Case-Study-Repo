from connection import create_connection, close_connection

class Booking:
    def __init__(self, booking_id, guest_id=None, room_id=None, check_in_date=None, check_out_date=None):
        self.booking_id = booking_id
        self.guest_id = guest_id
        self.room_id = room_id
        self.check_in_date = check_in_date
        self.check_out_date = check_out_date

    def add_booking(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "INSERT INTO Bookings (booking_id, guest_id, room_id, check_in_date, check_out_date) VALUES (%s, %s, %s, %s, %s)"
            values = (self.booking_id, self.guest_id, self.room_id, self.check_in_date, self.check_out_date)
            cursor.execute(query, values)
            connection.commit()
            print("Booking added successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def update_booking(self, guest_id=None, room_id=None, check_in_date=None, check_out_date=None):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            if guest_id:
                query = "UPDATE Bookings SET guest_id = %s WHERE booking_id = %s"
                cursor.execute(query, (guest_id, self.booking_id))
            if room_id:
                query = "UPDATE Bookings SET room_id = %s WHERE booking_id = %s"
                cursor.execute(query, (room_id, self.booking_id))
            if check_in_date:
                query = "UPDATE Bookings SET check_in_date = %s WHERE booking_id = %s"
                cursor.execute(query, (check_in_date, self.booking_id))
            if check_out_date:
                query = "UPDATE Bookings SET check_out_date = %s WHERE booking_id = %s"
                cursor.execute(query, (check_out_date, self.booking_id))
            connection.commit()
            print("Booking updated successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def cancel_booking(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "DELETE FROM Bookings WHERE booking_id = %s"
            cursor.execute(query, (self.booking_id,))
            connection.commit()
            print("Booking cancelled successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)


