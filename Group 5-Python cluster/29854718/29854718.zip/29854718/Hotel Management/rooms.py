from connection import create_connection, close_connection

class Room:
    def __init__(self, room_id, room_type=None, price_per_night=None, is_available=None):
        self.room_id = room_id
        self.room_type = room_type
        self.price_per_night = price_per_night
        self.is_available = is_available

    def add_room(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "INSERT INTO Rooms (room_id, room_type, price_per_night, is_available) VALUES (%s, %s, %s, %s)"
            values = (self.room_id, self.room_type, self.price_per_night, self.is_available)
            cursor.execute(query, values)
            connection.commit()
            print("Room added successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def update_room(self, room_type=None, price_per_night=None, is_available=None):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            if room_type:
                query = "UPDATE Rooms SET room_type = %s WHERE room_id = %s"
                cursor.execute(query, (room_type, self.room_id))
            if price_per_night:
                query = "UPDATE Rooms SET price_per_night = %s WHERE room_id = %s"
                cursor.execute(query, (price_per_night, self.room_id))
            if is_available is not None:
                query = "UPDATE Rooms SET is_available = %s WHERE room_id = %s"
                cursor.execute(query, (is_available, self.room_id))
            connection.commit()
            print("Room updated successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def delete_room(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "DELETE FROM Rooms WHERE room_id = %s"
            cursor.execute(query, (self.room_id,))
            connection.commit()
            print("Room deleted successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)
