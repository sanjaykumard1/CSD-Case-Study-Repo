from rooms import Room
from guests import Guest
from bookings import Booking
import datetime

def main():
    while True:
        print("\nHotel Management System")
        print("1. Manage Rooms")
        print("2. Manage Guests")
        print("3. Manage Bookings")
        print("4. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                manage_rooms()
            elif choice == '2':
                manage_guests()
            elif choice == '3':
                manage_bookings()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

def manage_rooms():
    while True:
        print("\nManage Rooms")
        print("1. Add Room")
        print("2. Update Room")
        print("3. Delete Room")
        print("4. Back")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                room_id = int(input("Enter Room ID: "))
                room_type = input("Enter Room Type: ")
                price_per_night = float(input("Enter Price per Night: "))
                is_available = input("Is Available (True/False): ") == 'True'
                room = Room(room_id, room_type, price_per_night, is_available)
                room.add_room()
            elif choice == '2':
                room_id = int(input("Enter Room ID to update: "))
                room = Room(room_id)
                room_type = input("Enter Room Type: ")
                price_per_night = float(input("Enter Price per Night: "))
                is_available = input("Is Available (True/False): ") == 'True'
                room.update_room(room_type, price_per_night, is_available)
            elif choice == '3':
                room_id = int(input("Enter Room ID to delete: "))
                room = Room(room_id)
                room.delete_room()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

def manage_guests():
    while True:
        print("\nManage Guests")
        print("1. Add Guest")
        print("2. Update Guest")
        print("3. Delete Guest")
        print("4. Back")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                guest_id = int(input("Enter Guest ID: "))
                name = input("Enter Name: ")
                contact_number = input("Enter Contact Number: ")
                address = input("Enter Address: ")
                guest = Guest(guest_id, name, contact_number, address)
                guest.add_guest()
            elif choice == '2':
                guest_id = int(input("Enter Guest ID to update: "))
                guest = Guest(guest_id)
                name = input("Enter Name: ")
                contact_number = input("Enter Contact Number: ")
                address = input("Enter Address: ")
                guest.update_guest(name, contact_number, address)
            elif choice == '3':
                guest_id = int(input("Enter Guest ID to delete: "))
                guest = Guest(guest_id)
                guest.delete_guest()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

def manage_bookings():
    while True:
        print("\nManage Bookings")
        print("1. Add Booking")
        print("2. Update Booking")
        print("3. Cancel Booking")
        print("4. Back")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                booking_id = int(input("Enter Booking ID: "))
                guest_id = int(input("Enter Guest ID: "))
                room_id = int(input("Enter Room ID: "))
                check_in_date = input("Enter Check-in Date (YYYY-MM-DD): ")
                check_out_date = input("Enter Check-out Date (YYYY-MM-DD): ")
                booking = Booking(booking_id, guest_id, room_id, check_in_date, check_out_date)
                booking.add_booking()
            elif choice == '2':
                booking_id = int(input("Enter Booking ID to update: "))
                booking = Booking(booking_id)
                guest_id = int(input("Enter Guest ID: "))
                room_id = int(input("Enter Room ID: "))
                check_in_date = input("Enter Check-in Date (YYYY-MM-DD): ")
                check_out_date = input("Enter Check-out Date (YYYY-MM-DD): ")
                booking.update_booking(guest_id, room_id, check_in_date, check_out_date)
            elif choice == '3':
                booking_id = int(input("Enter Booking ID to cancel: "))
                booking = Booking(booking_id)
                booking.cancel_booking()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
