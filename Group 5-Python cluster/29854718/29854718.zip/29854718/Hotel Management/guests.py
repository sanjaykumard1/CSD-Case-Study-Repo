from connection import create_connection, close_connection

class Guest:
    def __init__(self, guest_id, name=None, contact_number=None, address=None):
        self.guest_id = guest_id
        self.name = name
        self.contact_number = contact_number
        self.address = address

    def add_guest(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "INSERT INTO Guests (guest_id, name, contact_number, address) VALUES (%s, %s, %s, %s)"
            values = (self.guest_id, self.name, self.contact_number, self.address)
            cursor.execute(query, values)
            connection.commit()
            print("Guest added successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def update_guest(self, name=None, contact_number=None, address=None):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            if name:
                query = "UPDATE Guests SET name = %s WHERE guest_id = %s"
                cursor.execute(query, (name, self.guest_id))
            if contact_number:
                query = "UPDATE Guests SET contact_number = %s WHERE guest_id = %s"
                cursor.execute(query, (contact_number, self.guest_id))
            if address:
                query = "UPDATE Guests SET address = %s WHERE guest_id = %s"
                cursor.execute(query, (address, self.guest_id))
            connection.commit()
            print("Guest updated successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)

    def delete_guest(self):
        connection = create_connection()
        if connection is None:
            print("Failed to connect to database")
            return
        cursor = connection.cursor()
        try:
            query = "DELETE FROM Guests WHERE guest_id = %s"
            cursor.execute(query, (self.guest_id,))
            connection.commit()
            print("Guest deleted successfully.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            close_connection(connection)
