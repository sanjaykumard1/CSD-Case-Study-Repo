#!/usr/bin/env python
# coding: utf-8

# In[2]:


import mysql.connector
from mysql.connector import Error#to handel errors during operation on database

#class student with given attributes
class Student:
    def __init__(self,student_id,name,age,major,year):
        self.student_id=student_id
        self.name=name
        self.age=age
        self.major=major
        self.year=year
    def __str__(self):
        return f"Student(ID:{self.student_id},Name:{self.name},Age:{self.age},Major:{self.major},Year:{self.year})"
    
#Exception
class StudentNotFoundException(Exception):
    pass

#class enrollement system to implement given functions
class EnrollementSystem:
    def  __init__(self):
        self.connection=self.create_connection()
    #function to create connection with database
    def create_connection(self):
        PASSWORD='saurabh@123B'
        try:
            connection=mysql.connector.connect(host="localhost",user="root",password=PASSWORD,database="StudentEnrollmentSystem")
            if connection.is_connected():
                print("Connected to mysql database.")
                return connection
        except Error as e:
            print(f"Error: {e}")
            return None
    
    #function to use database
    def execute_query(self,query):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            self.connection.commit()
        except Error as e:
            print(f"Error executing query: {e}")
    
    def fetch_query(self, query):
        try:
            cursor = self.connection.cursor()
            cursor.execute(query)
            return cursor.fetchall()
        except Error as e:
            print(f"Error fetching query: {e}")
            return []
    #student management methods
    def AddStudent(self,student):
        try:
            query = f"""INSERT INTO Students (student_id, name, age, major, year)
            VALUES ({student.student_id}, '{student.name}', {student.age}, '{student.major}', '{student.year}')"""
            self.execute_query(query)
        except Error as e:
            print(f"Error adding student: {e}")

    def UpdateStudent(self, student_id, name=None, age=None, major=None, year=None):
        if student_id not in [s[0] for s in self.fetch_query("SELECT student_id FROM Students")]:
            raise StudentNotFoundError(f"Student with ID {student_id} not found")
        try:
            query = "UPDATE Students SET "
            updates = []
            if name:
                updates.append(f"name='{name}'")
            if age:
                updates.append(f"age={age}")
            if major:
                updates.append(f"major='{major}'")
            if year:
                updates.append(f"year='{year}'")
            query += ", ".join(updates)
            query += f" WHERE student_id={student_id}"
            self.execute_query(query)
        except Error as e:
            print(f"Error updating student: {e}")
    def DeleteStudent(self,student_id):
        if student_id not in [s[0] for s in self.fetch_query("SELECT student_id FROM Students")]:
            raise StudentNotFoundError(f"Student with ID {student_id} not found")
        try:
            query = f"DELETE FROM Students WHERE student_id={student_id}"
            self.execute_query(query)
        except Error as e:
            print(f"Error deleting student: {e}")

            
    #course management methods
    def AddCourse(self, course_id, course_name, credits):
        try:
            query = f"""INSERT INTO Courses (course_id, course_name, credits)
            VALUES ({course_id}, '{course_name}', {credits})"""
            self.execute_query(query)
        except Error as e:
            print(f"Error adding course: {e}")
    
    def EnrollStudent(self,student_id,course_id):
        try:
            query = f"""
            INSERT INTO Enrollments (student_id, course_id, enrollment_date)
            VALUES ({student_id}, {course_id}, CURDATE())
            """
            self.execute_query(query)
        except Error as e:
            print(f"Error enrolling student in course: {e}")
    
    def drop_student_from_course(self, student_id, course_id):
        try:
            query = f"DELETE FROM Enrollments WHERE student_id={student_id} AND course_id={course_id}"
            self.execute_query(query)
        except Error as e:
            print(f"Error dropping student from course: {e}")

    def generate_response(self, course_id):
        try:
            query = f"""
            SELECT s.name
            FROM Enrollments e
            JOIN Students s ON e.student_id = s.student_id
            WHERE e.course_id = {course_id}
            """
            return self.fetch_query(query)
        except Error as e:
            print(f"Error getting students enrolled in course: {e}")
            return []
if __name__=="__main__":
    db_system=EnrollementSystem()
    #create new students
    student1=Student(1,"Saurabh Kumar",22,"Computer Science","fourth")
    student2=Student(2,"Sahil kumar",21,"Computer Science","third")
    db_system.AddCourse(101,"Computer Science",4)
    try:
        #add students to database
        db_system.AddStudent(student1)
        db_system.AddStudent(student2)
        
        #enroll students in courses
        db_system.EnrollStudent(1,101)
        db_system.EnrollStudent(2,101)
        
        #get report of student enrolled in a course
        enrolled_students=db_system.generate_response(101)
        print(enrolled_students)
    except StudentNotFoundError as e:
        print(e)
    except Error as e:
        print(f"Database error: {e}")


# In[ ]:




