from Handler.AdminHandle import AdminHandler
from Handler.DoctorHandle import DoctorHandler
from Handler.PatientHandle import PatientHandler
from Manage.AdminData import Admin

def main():
    hospital_manager = Admin()
    admin_Handler = AdminHandler(hospital_manager)
    doctor_Handler = DoctorHandler(hospital_manager)
    patient_Handler = PatientHandler(hospital_manager)

    while True:
        print("**********************************************")
        print("WELCOME TO HOSPITAL MANAGEMENT SYSTEM")
        print("\nMain Menu:")
        print("1. Admin Login")
        print("2. Doctor Login")
        print("3. Patient Login")
        print("4. Exit")
        print("**********************************************")
        choice = input("Enter your choice: ")

        if choice == '1':
            admin_Handler.login()
        elif choice == '2':
            doctor_id = input("Enter Doctor ID: ")
            doctor_Handler.login(doctor_id)
        elif choice == '3':
            patient_id = input("Enter Patient ID: ")
            patient_Handler.login(patient_id)
        elif choice == '4':
            print("Thank You!!!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
