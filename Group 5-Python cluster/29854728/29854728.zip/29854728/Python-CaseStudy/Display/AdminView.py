class Adminview:
    def display_main_menu(self):
        print("\nAdmin Menu:")
        print("1. Manage Patients")
        print("2. Manage Doctors")
        print("3. Generate Report")
        print("4. Logout")
        return input("Enter your choice: ")

    def display_patient_menu(self):
        print("\nPatient Management:")
        print("1. Add Patient")
        print("2. Update Patient")
        print("3. Delete Patient")
        print("4. View All Patients")
        print("5. Assign Doctor to Patient")
        print("6. Back")
        return input("Enter your choice: ")

    def display_doctor_menu(self):
        print("\nDoctor Management:")
        print("1. Add Doctor")
        print("2. Update Doctor")
        print("3. Delete Doctor")
        print("4. View All Doctors")
        print("5. Back")
        return input("Enter your choice: ")

    def get_patient_data(self):
        patient_id = input("Enter Patient ID: ")
        name = input("Enter Name: ")
        age = input("Enter Age: ")
        gender = input("Enter Gender: ")
        disease = input("Enter Disease: ")
        doctor_id = input("Enter Doctor ID (optional): ")
        return patient_id, name, age, gender, disease, doctor_id

    def get_patient_update_data(self):
        patient_id = input("Enter Patient ID: ")
        updates = {}
        updates['name'] = input("Enter Name: ")
        updates['age'] = input("Enter Age: ")
        updates['gender'] = input("Enter Gender: ")
        updates['disease'] = input("Enter Disease: ")
        updates['doctor_id'] = input("Enter Doctor ID: ")
        return patient_id, updates

    def get_patient_id(self):
        return input("Enter Patient ID: ")

    def get_doctor_data(self):
        doctor_id = input("Enter Doctor ID: ")
        name = input("Enter Name: ")
        specialization = input("Enter Specialization: ")
        return doctor_id, name, specialization

    def get_doctor_update_data(self):
        doctor_id = input("Enter Doctor ID: ")
        updates = {}
        updates['name'] = input("Enter Name: ")
        updates['specialization'] = input("Enter Specialization: ")
        return doctor_id, updates

    def get_doctor_id(self):
        return input("Enter Doctor ID: ")

    def get_assignment_data(self):
        patient_id = input("Enter Patient ID: ")
        doctor_id = input("Enter Doctor ID: ")
        return patient_id, doctor_id

    def display_error(self, message):
        print(f"Error: {message}")

    def display_patients(self, patients):
        print("\nPatients:")
        print("=" * 95)
        print(f"| {'Patient ID':<12} | {'Name':<20} | {'Age':<5} | {'Gender':<10} | {'Disease':<30} | {'Doctor ID':<12} |")
        print("=" * 95)
        for patient in patients:
            print(f"| {patient.patient_id:<12} | {patient.name:<20} | {patient.age:<5} | {patient.gender:<10} | {patient.disease:<30} | {patient.doctor_id:<12} |")
        print("=" * 95)

    def display_doctors(self, doctors):
        print("\nDoctors:")
        print("=" * 55)
        print(f"| {'Doctor ID':<12} | {'Name':<20} | {'Specialization':<20} |")
        print("=" * 55)
        for doctor in doctors:
            print(f"| {doctor.doctor_id:<12} | {doctor.name:<20} | {doctor.specialization:<20} |")
        print("=" * 55)