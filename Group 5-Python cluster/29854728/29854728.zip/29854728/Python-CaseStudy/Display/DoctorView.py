class Doctorview:
    def display_doctor_info(self, doctor):
        print(f"\nDoctor ID: {doctor.doctor_id}")
        print(f"Doctor Name: {doctor.name}")
        print(f"Specialization: {doctor.specialization}")

    def display_patients(self, patients):
        print("\nPatients assigned to you:")
        print("=" * 85)
        print(f"| {'Patient ID':<12} | {'Name':<20} | {'Age':<5} | {'Gender':<10} | {'Disease':<30} |")
        print("=" * 85)
        for patient in patients:
            print(f"| {patient.patient_id:<12} | {patient.name:<20} | {patient.age:<5} | {patient.gender:<10} | {patient.disease:<30} |")
        print("=" * 85)

    def display_error(self, message):
        print(f"Error: {message}")
