class Patientview:
    def display_patient_info(self, patient):
        print(f"Patient ID: {patient.patient_id}")
        print(f"Name: {patient.name}")
        print(f"Age: {patient.age}")
        print(f"Gender: {patient.gender}")
        print(f"Disease: {patient.disease}")
        print(f"Doctor ID: {patient.doctor_id}")

    def display_doctor_info(self, doctor):
        print("\nDoctor assigned to you:")
        print(f"Doctor ID: {doctor.doctor_id}")
        print(f"Doctor Name: {doctor.name}")
        print(f"Specialization: {doctor.specialization}")

    def display_error(self, message):
        print(f"Error: {message}")
