from Display.PatientView import Patientview
from Manage.Exceptions import PatientNotFound, DoctorNotFound

class PatientHandler:
    def __init__(self, hospital_manager):
        self.hospital_manager = hospital_manager
        self.view = Patientview()

    def login(self, patient_id):
        try:
            patient = self.hospital_manager.get_patient(patient_id)
            self.view.display_patient_info(patient)
            self.view_doctor(patient.doctor_id)
        except PatientNotFound as e:
            self.view.display_error(str(e))

    def view_doctor(self, doctor_id):
        try:
            doctor = self.hospital_manager.get_doctor(doctor_id)
            self.view.display_doctor_info(doctor)
        except DoctorNotFound as e:
            self.view.display_error(str(e))
