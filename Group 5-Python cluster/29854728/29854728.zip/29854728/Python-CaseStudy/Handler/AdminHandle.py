from Display.AdminView import Adminview
from Manage.Exceptions import PatientNotFound, DoctorNotFound
from Manage.PatientData import Patient
from Manage.DoctorData import Doctor

class AdminHandler:
    def __init__(self, hospital_manager):
        self.hospital_manager = hospital_manager
        self.view = Adminview()

    def login(self):
        self.manage()

    def manage(self):
        while True:
            choice = self.view.display_main_menu()
            if choice == '1':
                self.manage_patients()
            elif choice == '2':
                self.manage_doctors()
            elif choice == '3':
                self.generate_report()
            elif choice == '4':
                break

    def manage_patients(self):
        while True:
            choice = self.view.display_patient_menu()
            if choice == '1':
                patient_data = self.view.get_patient_data()
                patient = Patient(*patient_data)
                self.hospital_manager.add_patient(patient)
            elif choice == '2':
                patient_id, updates = self.view.get_patient_update_data()
                try:
                    self.hospital_manager.update_patient(patient_id, **updates)
                except PatientNotFound as e:
                    self.view.display_error(str(e))
            elif choice == '3':
                patient_id = self.view.get_patient_id()
                try:
                    self.hospital_manager.delete_patient(patient_id)
                except PatientNotFound as e:
                    self.view.display_error(str(e))
            elif choice == '4':
                self.view_all_patients()
            elif choice == '5':
                self.assign_doctor_to_patient()
            elif choice == '6':
                break

    def manage_doctors(self):
        while True:
            choice = self.view.display_doctor_menu()
            if choice == '1':
                doctor_data = self.view.get_doctor_data()
                doctor = Doctor(*doctor_data)
                self.hospital_manager.add_doctor(doctor)
            elif choice == '2':
                doctor_id, updates = self.view.get_doctor_update_data()
                try:
                    self.hospital_manager.update_doctor(doctor_id, **updates)
                except DoctorNotFound as e:
                    self.view.display_error(str(e))
            elif choice == '3':
                doctor_id = self.view.get_doctor_id()
                try:
                    self.hospital_manager.delete_doctor(doctor_id)
                except DoctorNotFound as e:
                    self.view.display_error(str(e))
            elif choice == '4':
                self.view_all_doctors()
            elif choice == '5':
                break

    def generate_report(self):
        doctor_id = self.view.get_doctor_id()
        try:
            patients = self.hospital_manager.get_patients_by_doctor(doctor_id)
            self.view.display_patients(patients)
        except DoctorNotFound as e:
            self.view.display_error(str(e))

    def view_all_patients(self):
        patients = self.hospital_manager.get_all_patients()
        self.view.display_patients(patients)

    def view_all_doctors(self):
        doctors = self.hospital_manager.get_all_doctors()
        self.view.display_doctors(doctors)

    def assign_doctor_to_patient(self):
        patient_id, doctor_id = self.view.get_assignment_data()
        try:
            self.hospital_manager.assign_doctor_to_patient(patient_id, doctor_id)
        except (PatientNotFound, DoctorNotFound) as e:
            self.view.display_error(str(e))
