from Display.DoctorView import Doctorview
from Manage.Exceptions import DoctorNotFound
from Manage.PatientData import Patient

class DoctorHandler:
    def __init__(self, hospital_manager):
        self.hospital_manager = hospital_manager
        self.view = Doctorview()

    def login(self, doctor_id):
        try:
            doctor = self.hospital_manager.get_doctor(doctor_id)
            self.view.display_doctor_info(doctor)
            self.view_patients(doctor_id)
        except DoctorNotFound as e:
            self.view.display_error(str(e))

    def view_patients(self, doctor_id):
        try:
            patients = self.hospital_manager.get_patients_by_doctor(doctor_id)
            self.view.display_patients(patients)
        except DoctorNotFound as e:
            self.view.display_error(str(e))
