class PatientNotFound(Exception):
    pass

class DoctorNotFound(Exception):
    pass
