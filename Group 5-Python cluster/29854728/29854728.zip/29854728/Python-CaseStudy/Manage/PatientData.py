class Patient:
    def __init__(self, patient_id, name, age, gender, disease, doctor_id=None):
        self.patient_id = patient_id
        self.name = name
        self.age = age
        self.gender = gender
        self.disease = disease
        self.doctor_id = doctor_id

    def update_details(self, name=None, age=None, gender=None, disease=None, doctor_id=None):
        if name:
            self.name = name
        if age:
            self.age = age
        if gender:
            self.gender = gender
        if disease:
            self.disease = disease
        if doctor_id:
            self.doctor_id = doctor_id
