from Manage.Exceptions import PatientNotFound, DoctorNotFound

class Admin:
    def __init__(self):
        self.patients = {}
        self.doctors = {}

    def add_patient(self, patient):
        self.patients[patient.patient_id] = patient

    def update_patient(self, patient_id, **kwargs):
        if patient_id not in self.patients:
            raise PatientNotFound(f"Patient with ID {patient_id} not found.")
        self.patients[patient_id].update_details(**kwargs)

    def delete_patient(self, patient_id):
        if patient_id not in self.patients:
            raise PatientNotFound(f"Patient with ID {patient_id} not found.")
        del self.patients[patient_id]

    def get_patient(self, patient_id):
        if patient_id not in self.patients:
            raise PatientNotFound(f"Patient with ID {patient_id} not found.")
        return self.patients[patient_id]

    def add_doctor(self, doctor):
        self.doctors[doctor.doctor_id] = doctor

    def update_doctor(self, doctor_id, **kwargs):
        if doctor_id not in self.doctors:
            raise DoctorNotFound(f"Doctor with ID {doctor_id} not found.")
        self.doctors[doctor_id].update_details(**kwargs)

    def delete_doctor(self, doctor_id):
        if doctor_id not in self.doctors:
            raise DoctorNotFound(f"Doctor with ID {doctor_id} not found.")
        del self.doctors[doctor_id]

    def get_doctor(self, doctor_id):
        if doctor_id not in self.doctors:
            raise DoctorNotFound(f"Doctor with ID {doctor_id} not found.")
        return self.doctors[doctor_id]

    def get_patients_by_doctor(self, doctor_id):
        if doctor_id not in self.doctors:
            raise DoctorNotFound(f"Doctor with ID {doctor_id} not found.")
        return [patient for patient in self.patients.values() if patient.doctor_id == doctor_id]

    def get_all_patients(self):
        return list(self.patients.values())

    def get_all_doctors(self):
        return list(self.doctors.values())
    
    def assign_doctor_to_patient(self, patient_id, doctor_id):
        if patient_id not in self.patients:
            raise PatientNotFound(f"Patient with ID {patient_id} not found.")
        if doctor_id not in self.doctors:
            raise DoctorNotFound(f"Doctor with ID {doctor_id} not found.")
        self.patients[patient_id].doctor_id = doctor_id
