class Doctor:
    def __init__(self, doctor_id, name, specialization):
        self.doctor_id = doctor_id
        self.name = name
        self.specialization = specialization

    def update_details(self, name=None, specialization=None):
        if name:
            self.name = name
        if specialization:
            self.specialization = specialization
