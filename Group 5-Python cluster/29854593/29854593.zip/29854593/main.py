from datetime import date

class Student:
  def __init__(self, student_id, name, date_of_birth, grade_level):
    self.student_id = student_id
    self.name = name
    self.date_of_birth = date.fromisoformat(date_of_birth)  # Parse date string
    self.grade_level = grade_level

  def __str__(self):
    return f"Student ID: {self.student_id}, Name: {self.name}, DoB: {self.date_of_birth.strftime('%Y-%m-%d')}, Grade: {self.grade_level}"

  @staticmethod
  def add_student(students):
    student_id = int(input("Enter Student ID: "))
    if student_id in students:
      print("Error: Student ID already exists.")
      return
    name = input("Enter Student Name: ")
    date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
    grade_level = int(input("Enter Grade Level: "))
    students[student_id] = Student(student_id, name, date_of_birth, grade_level)
    print("Student added successfully!")

  @staticmethod
  def update_student(students):
    student_id = int(input("Enter Student ID to update: "))
    if student_id not in students:
      print("Error: Student not found.")
      return
    student = students[student_id]
    name = input("Update Name (leave blank to keep current): ") or student.name
    date_of_birth = input("Update DoB (YYYY-MM-DD, leave blank to keep current): ") or student.date_of_birth.strftime('%Y-%m-%d')
    try:
      date_of_birth = date.fromisoformat(date_of_birth)
    except ValueError:
      print("Error: Invalid date format.")
      return
    grade_level = input("Update Grade Level (leave blank to keep current): ") or student.grade_level
    try:
      grade_level = int(grade_level)
    except ValueError:
      print("Error: Invalid grade level.")
      return
    student.name = name
    student.date_of_birth = date_of_birth
    student.grade_level = grade_level
    print("Student details updated successfully!")

  @staticmethod
  def delete_student(students):
    student_id = int(input("Enter Student ID to delete: "))
    if student_id not in students:
      print("Error: Student not found.")
      return
    del students[student_id]
    print("Student deleted successfully!")

class Teacher:
  def __init__(self, teacher_id, name, contact_number, subject_taught):
    self.teacher_id = teacher_id
    self.name = name
    self.contact_number = contact_number
    self.subject_taught = subject_taught

  def __str__(self):
    return f"Teacher ID: {self.teacher_id}, Name: {self.name}, Contact: {self.contact_number}, Subject: {self.subject_taught}"

  @staticmethod
  def add_teacher(teachers):
    teacher_id = int(input("Enter Teacher ID: "))
    if teacher_id in teachers:
      print("Error: Teacher ID already exists.")
      return
    name = input("Enter Teacher Name: ")
    contact_number = input("Enter Contact Number: ")
    subject_taught = input("Enter Subject Taught: ")
    teachers[teacher_id] = Teacher(teacher_id, name, contact_number, subject_taught)
    print("Teacher added successfully!")

  @staticmethod
  def update_teacher(teachers):
    teacher_id = int(input("Enter Teacher ID to update: "))
    if teacher_id not in teachers:
      print("Error: Teacher not found.")
      return
    teacher = teachers[teacher_id]
    name = input("Update Name (leave blank to keep current): ") or teacher.name
    contact_number = input("Update Contact Number (leave blank to keep current): ") or teacher.contact_number
    subject_taught = input("Update Subject Taught (leave blank to keep current): ") or teacher.subject_taught
    teacher.name = name
    teacher.contact_number = contact_number
    teacher.subject_taught = subject_taught
    print("Teacher details updated successfully!")

  @staticmethod
  def delete_teacher(teachers):
    teacher_id = int(input("Enter Teacher ID to delete: "))
    if teacher_id not in teachers:
      print("Error: Teacher not found.")
      return
    del teachers[teacher_id]
    print("Teacher deleted successfully!")
class Course:
  def __init__(self, course_id, name, teacher_id, maximum_students):
    self.course_id = course_id
    self.name = name
    self.teacher_id = teacher_id
    self.maximum_students = maximum_students

  def __str__(self):
    return f"Course ID: {self.course_id}, Name: {self.name}, Teacher: {self.teacher_id}, Max Students: {self.maximum_students}"

  @staticmethod
  def add_course(courses, teachers):
    course_id = int(input("Enter Course ID: "))
    if course_id in courses:
      print("Error: Course ID already exists.")
      return
    name = input("Enter Course Name: ")
    while True:
      try:
        teacher_id = int(input("Enter Teacher ID: "))
        if teacher_id not in teachers:
          print("Error: Teacher not found.")
          continue
        break
      except ValueError:
        print("Error: Invalid teacher ID.")
    maximum_students = int(input("Enter Maximum Students: "))
    courses[course_id] = Course(course_id, name, teacher_id, maximum_students)
    print("Course added successfully!")

  @staticmethod
  def update_course(courses, teachers):
    course_id = int(input("Enter Course ID to update: "))
    if course_id not in courses:
      print("Error: Course not found.")
      return
    course = courses[course_id]
    name = input("Update Name (leave blank to keep current): ") or course.name
    while True:
      try:
        update_teacher_id = input("Update Teacher ID (leave blank to keep current): ") or str(course.teacher_id)
        if update_teacher_id and int(update_teacher_id) not in teachers:
          print("Error: Teacher not found.")
          continue
        break
      except ValueError:
        print("Error: Invalid teacher ID.")
    maximum_students = input("Update Maximum Students (leave blank to keep current): ") or str(course.maximum_students)
    try:
      maximum_students = int(maximum_students)
    except ValueError:
      print("Error: Invalid maximum students value.")
      return
    course.name = name
    if update_teacher_id:
      course.teacher_id = int(update_teacher_id)
    course.maximum_students = maximum_students
    print("Course details updated successfully!")

  @staticmethod
  def delete_course(courses):
    course_id = int(input("Enter Course ID to delete: "))
    if course_id not in courses:
      print("Error: Course not found.")
      return
    del courses[course_id]
    print("Course deleted successfully!")

class Grade:
  def __init__(self, student_id, course_id, grade):
    self.student_id = student_id
    self.course_id = course_id
    self.grade = grade

  def __str__(self):
    return f"Student ID: {self.student_id}, Course ID: {self.course_id}, Grade: {self.grade}"

  @staticmethod
  def assign_grade(grades, students, courses):
    while True:
      try:
        student_id = int(input("Enter Student ID: "))
        if student_id not in students:
          print("Error: Student not found.")
          continue
        break
      except ValueError:
        print("Error: Invalid student ID.")
    while True:
      try:
        course_id = int(input("Enter Course ID: "))
        if course_id not in courses:
          print("Error: Course not found.")
          continue
        break
      except ValueError:
        print("Error: Invalid course ID.")
    grade = input("Enter Grade: ")
    grades.append(Grade(student_id, course_id, grade))
    print("Grade assigned successfully!")

# Main program loop
students = {}
teachers = {}
courses = {}
grades = []

while True:
  print("\nSchool Management System")
  print("1. Manage Students")
  print("2. Manage Teachers")
  print("3. Manage Courses")
  print("4. Manage Grades")
  print("5. Exit")
  choice = input("Enter your choice: ")

  if choice == '1':
    print("\nStudent Management")
    print("1. Add Student")
    print("2. Update Student")
    print("3. Delete Student")
    print("4. List Students")
    student_choice = input("Enter your choice: ")
    if student_choice == '1':
      Student.add_student(students)
    elif student_choice == '2':
      Student.update_student(students)
    elif student_choice == '3':
      Student.delete_student(students)
    elif student_choice == '4':
      if not students:
        print("No students found.")
      else:
        for student in students.values():
          print(student)

  elif choice == '2':
    print("\nTeacher Management")
    print("1. Add Teacher")
    print("2. Update Teacher")
    print("3. Delete Teacher")
    print("4. List Teachers")
    teacher_choice = input("Enter your choice: ")
    if teacher_choice == '1':
      Teacher.add_teacher(teachers)
    elif teacher_choice == '2':
      Teacher.update_teacher(teachers)
    elif teacher_choice == '3':
      Teacher.delete_teacher(teachers)
    elif teacher_choice == '4':
      if not teachers:
        print("No teachers found.")
      else:
        for teacher in teachers.values():
          print(teacher)

  elif choice == '3':
    print("\nCourse Management")
    print("1. Add Course")
    print("2. Update Course")
    print("3. Delete Course")
    print("4. List Courses")
    course_choice = input("Enter your choice: ")
    if course_choice == '1':
      Course.add_course(courses, teachers)
    elif course_choice == '2':
      Course.update_course(courses, teachers)
    elif course_choice == '3':
      Course.delete_course(courses)
    elif course_choice == '4':
      if not courses:
        print("No courses found.")
      else:
        for course in courses.values():
          print(course)

  elif choice == '4':
    print("\nGrade Management")
    print("1. Assign Grade")
    print("2. List Grades")
    grade_choice = input("Enter your choice: ")
    if grade_choice == '1':
      Grade.assign_grade(grades, students, courses)
    elif grade_choice == '2':
      if not grades:
        print("No grades assigned yet.")
      else:
        for grade in grades:
          print(grade)

  elif choice == '5':
    print("\nExiting School Management System...")
    break

  else:
    print("Invalid choice. Please try again.")
