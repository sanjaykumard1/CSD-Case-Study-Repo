--MYSQL 
CREATE TABLE Students (
  student_id INT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  date_of_birth DATE,
  grade_level INT
);

CREATE TABLE Teachers (
  teacher_id INT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  contact_number VARCHAR(15),
  subject_taught VARCHAR(255)
);

CREATE TABLE Courses (
  course_id INT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  teacher_id INT,
  maximum_students INT,
  FOREIGN KEY (teacher_id) REFERENCES Teachers(teacher_id)
);

CREATE TABLE Grades (
  grade_id INT PRIMARY KEY,
  student_id INT,
  course_id INT,
  grade VARCHAR(2),
  FOREIGN KEY (student_id) REFERENCES Students(student_id),
  FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);




--Write a query to find the students who have the highest grade in a specific course.
SELECT s.name, g.grade 
FROM Students s 
INNER JOIN Grades g ON s.student_id = g.student_id 
INNER JOIN Courses c ON g.course_id = c.course_id 
WHERE c.course_id = [Course ID] -- Replace with desired course ID 
AND g.grade = ( SELECT MAX(grade) FROM Grades WHERE course_id = [Course ID] );

--Write a query to find the teachers who are teaching the maximum number of courses.
SELECT t.name FROM Teachers t 
INNER JOIN Courses c ON t.teacher_id = c.teacher_id 
GROUP BY t.teacher_id HAVING COUNT(*) = ( SELECT MAX(course_count) 
FROM ( SELECT teacher_id, COUNT(*) AS course_count FROM Courses 
GROUP BY teacher_id ) AS course_counts );          

--Write a query to find the courses that have not reached the maximum number of students                                                                                                                                                                           
SELECT c.name, c.maximum_students - COUNT(g.student_id) AS available_slots
FROM Courses c
LEFT JOIN Grades g ON c.course_id = g.course_id
GROUP BY c.course_id, c.name, c.maximum_students
HAVING available_slots > 0;

--Write a query to find the average grade for each course.
SELECT c.name, AVG(CAST(g.grade AS DECIMAL(2,1))) AS average_grade
FROM Courses c
INNER JOIN Grades g ON c.course_id = g.course_id
GROUP BY c.course_id, c.name;

--Write a query to find the students who have failed a course.
SELECT s.name, c.name, g.grade
FROM Students s
INNER JOIN Grades g ON s.student_id = g.student_id
INNER JOIN Courses c ON g.course_id = c.course_id
WHERE g.grade IN ('F', 'D');  -- Adjust failing grades as needed


