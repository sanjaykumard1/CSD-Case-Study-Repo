
CREATE DATABASE IF NOT EXISTS InventoryDB;


USE InventoryDB;


DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Sales;
DROP TABLE IF EXISTS Restocks;


CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10, 2),
    quantity_in_stock INT
);


CREATE TABLE Sales (
    sale_id INT PRIMARY KEY,
    product_id INT,
    quantity_sold INT,
    sale_date DATE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);


CREATE TABLE Restocks (
    restock_id INT PRIMARY KEY,
    product_id INT,
    quantity_restocked INT,
    restock_date DATE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);


INSERT INTO Products (product_id, name, category, price, quantity_in_stock) VALUES
(1, 'Product A', 'Category 1', 10.5, 230),
(2, 'Product B', 'Category 1', 19.00, 150),
(3, 'Product C', 'Category 2', 27.00, 5),
(4, 'Product D', 'Category 3', 17.75, 120),
(5, 'Product E', 'Category 2', 32.00, 21);


INSERT INTO Sales (sale_id, product_id, quantity_sold, sale_date) VALUES
(1, 1, 15, '2024-01-01'),
(2, 2, 10, '2024-07-12'),
(3, 1, 31, '2024-02-23'),
(4, 3, 2, '2024-01-04'),
(5, 4, 25, '2024-12-05'),
(6, 2, 5, '2024-03-06'),
(7, 3, 100, '2024-07-07'),
(8, 1, 27, '2024-09-08'),
(9, 5, 13, '2024-10-09');


INSERT INTO Restocks (restock_id, product_id, quantity_restocked, restock_date) VALUES
(1, 1, 10, '2025-07-11'),
(2, 3, 5, '2025-05-31'),
(3, 2, 20, '2025-07-03'),
(4, 4, 50, '2025-06-04'),
(5, 5, 3, '2025-10-05'),
(6, 1, 7, '2025-12-06'),
(7, 4, 10, '2025-05-07'),
(8, 2, 15, '2025-02-08'),
(9, 3, 3, '2025-01-09');

-- Query 1: Total quantity of each product sold
SELECT 
    product_id,
    SUM(quantity_sold) AS total_quantity_sold
FROM 
    Sales
GROUP BY 
    product_id;

-- Query 2: Product name and total quantity sold for each product
SELECT 
    p.name,
    COALESCE(SUM(s.quantity_sold), 0) AS total_quantity_sold
FROM 
    Products p
LEFT JOIN 
    Sales s ON p.product_id = s.product_id
GROUP BY 
    p.name;

-- Query 3: Names of products that have never been sold
SELECT 
    p.name
FROM 
    Products p
LEFT JOIN 
    Sales s ON p.product_id = s.product_id
WHERE 
    s.product_id IS NULL;

-- Query 4: Products that have been restocked more than 5 times
SELECT 
    product_id,
    COUNT(restock_id) AS restock_count
FROM 
    Restocks
GROUP BY 
    product_id
HAVING 
    COUNT(restock_id) > 5;

-- Query 5: Product names and their current stock levels for products that have sold more than 20 units
SELECT 
    p.name,
    p.quantity_in_stock
FROM 
    Products p
JOIN 
    Sales s ON p.product_id = s.product_id
GROUP BY 
    p.name, p.quantity_in_stock
HAVING 
    SUM(s.quantity_sold) > 20;
