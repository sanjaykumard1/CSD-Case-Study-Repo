import datetime

class Event:
    def __init__(self, event_id, event_name, event_date, location, max_participants):
        self.event_id = event_id
        self.event_name = event_name
        self.event_date = event_date
        self.location = location
        self.max_participants = max_participants
        self.participants = []
    def __str__(self):
        return f"Event({self.event_id}, {self.event_name}, {self.event_date}, {self.location}, {self.max_participants})"

    def add_participant(self, participant):
        if len(self.participants) < self.max_participants:
            self.participants.append(participant)
            print(f"{participant.name} has been registered for {self.event_name}.")
        else:
            print(f"Sorry, {self.event_name} is already full. Registration failed.")

    def remove_participant(self, participant_id):
        for participant in self.participants:
            if participant.participant_id == participant_id:
                self.participants.remove(participant)
                print(f"{participant.name} has been unregistered from {self.event_name}.")
                return
        print(f"Participant with ID {participant_id} is not registered for {self.event_name}.")

class Participant:
    def __init__(self, participant_id, name, email, phone_number):
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.phone_number = phone_number
    def __str__(self):
        return f"Participant({self.participant_id}, {self.name}, {self.email}, {self.phone_number})"

class Registration:
    def __init__(self, registration_id, event_id, participant_id, registration_date):
        self.registration_id = registration_id
        self.event_id = event_id
        self.participant_id = participant_id
        self.registration_date = registration_date
    def __str__(self):
        return f"Registration({self.registration_id}, {self.event_id}, {self.participant_id}, {self.registration_date})"

class EventManagementSystem:
    def __init__(self):
        self.events = []
        self.participants = []
        self.registrations = []

    def add_event(self, event):
        if self.find_event_by_id(event.event_id):
            raise Exception("Event ID already exists.")
        self.events.append(event)
        print(f"Event {event.event_name} added successfully.")

    def update_event(self, event_id, event_name=None, event_date=None, location=None, max_participants=None):
        event = self.find_event_by_id(event_id)
        if event:
            if event_name:
                event.event_name = event_name
            if event_date:
                event.event_date = event_date
            if location:
                event.location = location
            if max_participants:
                event.max_participants = max_participants
            print(f"Event {event_id} updated successfully.")
        else:
            raise Exception("Event ID not found.")

    def delete_event(self, event_id):
        event = self.find_event_by_id(event_id)
        if event:
            self.events.remove(event)
            print(f"Event {event_id} deleted successfully.")
        else:
            raise Exception("Event ID not found.")

    def find_event_by_id(self, event_id):
        for event in self.events:
            if event.event_id == event_id:
                return event
        return None

    def add_participant(self, participant):
        if self.find_participant_by_id(participant.participant_id):
            raise Exception("Participant ID already exists.")
        self.participants.append(participant)
        print(f"Participant {participant.name} added successfully.")

    def update_participant(self, participant_id, name=None, email=None, phone_number=None):
        participant = self.find_participant_by_id(participant_id)
        if participant:
            if name:
                participant.name = name
            if email:
                participant.email = email
            if phone_number:
                participant.phone_number = phone_number
            print(f"Participant {participant_id} updated successfully.")
        else:
            raise Exception("Participant ID not found.")

    def delete_participant(self, participant_id):
        participant = self.find_participant_by_id(participant_id)
        if participant:
            self.participants.remove(participant)
            print(f"Participant {participant_id} deleted successfully.")
        else:
            raise Exception("Participant ID not found.")

    def find_participant_by_id(self, participant_id):
        for participant in self.participants:
            if participant.participant_id == participant_id:
                return participant
        return None

    def add_registration(self, registration):
        if self.find_registration_by_id(registration.registration_id):
            raise Exception("Registration ID already exists.")
        if not self.find_event_by_id(registration.event_id):
            raise Exception("Event ID not found.")
        if not self.find_participant_by_id(registration.participant_id):
            raise Exception("Participant ID not found.")
        self.registrations.append(registration)
        print(f"Registration {registration.registration_id} added successfully.")

    def update_registration(self, registration_id, event_id=None, participant_id=None, registration_date=None):
        registration = self.find_registration_by_id(registration_id)
        if registration:
            if event_id:
                registration.event_id = event_id
            if participant_id:
                registration.participant_id = participant_id
            if registration_date:
                registration.registration_date = registration_date
            print(f"Registration {registration_id} updated successfully.")
        else:
            raise Exception("Registration ID not found.")

    def delete_registration(self, registration_id):
        registration = self.find_registration_by_id(registration_id)
        if registration:
            self.registrations.remove(registration)
            print(f"Registration {registration_id} deleted successfully.")
        else:
            raise Exception("Registration ID not found.")

    def find_registration_by_id(self, registration_id):
        for registration in self.registrations:
            if registration.registration_id == registration_id:
                return registration
        return None

def parse_date(date_str):
    try:
        return datetime.datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        raise Exception("Invalid date format. Use YYYY-MM-DD.")


def main():
    ems = EventManagementSystem()
    while True:
        print("\nEvent Management System")
        print("1. Manage Events")
        print("2. Manage Participants")
        print("3. Manage Registrations")
        print("4. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            while True:
                print("\nManage Events")
                print("1. Add Event")
                print("2. Update Event")
                print("3. Delete Event")
                print("4. View Events")
                print("5. Back ")
                event_choice = input("Enter your choice: ")
                if event_choice == '1':
                    try:
                        event_id = int(input("Enter Event ID: "))
                        event_name = input("Enter Event Name: ")
                        event_date = parse_date(input("Enter Event Date (YYYY-MM-DD): "))
                        location = input("Enter Event Location: ")
                        max_participants = int(input("Enter Maximum Participants: "))
                        event = Event(event_id, event_name, event_date, location, max_participants)
                        ems.add_event(event)
                    except Exception as e:
                        print(f"Error: {e}")
                elif event_choice == '2':
                    try:
                        event_id = int(input("Enter Event ID to update: "))
                        event_name = input("Enter new Event Name (leave blank to keep current): ")
                        event_date = input("Enter new Event Date (YYYY-MM-DD, leave blank to keep current): ")
                        location = input("Enter new Event Location (leave blank to keep current): ")
                        max_participants = input("Enter new Maximum Participants (leave blank to keep current): ")
                        ems.update_event(event_id, event_name, parse_date(event_date) if event_date else None,
                                         location, int(max_participants) if max_participants else None)
                    except Exception as e:
                        print(f"Error: {e}")
                elif event_choice == '3':
                    try:
                        event_id = int(input("Enter Event ID to delete: "))
                        ems.delete_event(event_id)
                    except Exception as e:
                        print(f"Error: {e}")
                elif event_choice == '4':
                    for event in ems.events:
                        print(event)        
                elif event_choice == '5':
                    break
                else:
                    print("Invalid Choice")

        elif choice == '2':
            while True:
                print("\nManage Participants")
                print("1. Add Participant")
                print("2. Update Participant")
                print("3. Delete Participant")
                print("4. View Participants")
                print("5. Back")
                participant_choice = input("Enter your choice: ")
                if participant_choice == '1':
                    try:
                        participant_id = int(input("Enter Participant ID: "))
                        name = input("Enter Name: ")
                        email = input("Enter Email: ")
                        phone_number = input("Enter Phone Number: ")
                        participant = Participant(participant_id, name, email, phone_number)
                        ems.add_participant(participant)
                    except Exception as e:
                        print(f"Error: {e}")
                elif participant_choice == '2':
                    try:
                        participant_id = int(input("Enter Participant ID to update: "))
                        name = input("Enter new Name (leave blank to keep current): ")
                        email = input("Enter new Email (leave blank to keep current): ")
                        phone_number = input("Enter new Phone Number (leave blank to keep current): ")
                        ems.update_participant(participant_id, name, email, phone_number)
                    except Exception as e:
                        print(f"Error: {e}")
                elif participant_choice == '3':
                    try:
                        participant_id = int(input("Enter Participant ID to delete: "))
                        ems.delete_participant(participant_id)
                    except Exception as e:
                        print(f"Error: {e}")
                elif participant_choice == '4':
                    for participant in ems.participants:
                        print(participant)
                elif participant_choice == '5':
                    break
                else:
                    print("Invalid choice")

        elif choice == '3':
            while True:
                print("\nManage Registrations")
                print("1. Add Registration")
                print("2. Update Registration")
                print("3. Delete Registration")
                print("4. View Registrations")
                print("5. Back")
                registration_choice = input("Enter your choice: ")
                if registration_choice == '1':
                    try:
                        registration_id = int(input("Enter Registration ID: "))
                        event_id = int(input("Enter Event ID: "))
                        participant_id = int(input("Enter Participant ID: "))
                        registration_date = parse_date(input("Enter Registration Date (YYYY-MM-DD): "))
                        registration = Registration(registration_id, event_id, participant_id, registration_date)
                        ems.add_registration(registration)
                    except Exception as e:
                        print(f"Error: {e}")
                elif registration_choice == '2':
                    try:
                        registration_id = int(input("Enter Registration ID to update: "))
                        event_id = input("Enter new Event ID (leave blank to keep current): ")
                        participant_id = input("Enter new Participant ID (leave blank to keep current): ")
                        registration_date = input("Enter new Registration Date (YYYY-MM-DD, leave blank to keep current): ")
                        ems.update_registration(registration_id, int(event_id) if event_id else None,
                                                int(participant_id) if participant_id else None,
                                                parse_date(registration_date) if registration_date else None)
                    except Exception as e:
                        print(f"Error: {e}")
                elif registration_choice == '3':
                    try:
                        registration_id = int(input("Enter Registration ID to delete: "))
                        ems.delete_registration(registration_id)
                    except Exception as e:
                        print(f"Error: {e}")
                elif registration_choice == '4':
                    for registration in ems.registrations:
                        print(registration)
                elif registration_choice == '5':
                    break
                else:
                    print("Invalid choice")

        elif choice == '4':
            print("Exiting the program. Thank you!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 4.")

if __name__ == "__main__":
    main()
