class Membership:
    def __init__(self, membership_id, member_name, member_contact, membership_type, membership_expiry):
        self.membership_id = membership_id
        self.member_name = member_name
        self.member_contact = member_contact
        self.membership_type = membership_type
        self.membership_expiry = membership_expiry

    @staticmethod
    def add_membership(memberships):
        membership_id = input("Enter Membership ID: ")
        member_name = input("Enter Member Name: ")
        member_contact = input("Enter Member Contact: ")
        membership_type = input("Enter Membership Type: ")
        membership_expiry = input("Enter Membership Expiry: ")
        new_membership = Membership(membership_id, member_name, member_contact, membership_type, membership_expiry)
        memberships.append(new_membership)
        print("Membership added successfully.")

    @staticmethod
    def update_membership(memberships):
        membership_id = input("Enter Membership ID to update: ")
        for membership in memberships:
            if membership.membership_id == membership_id:
                membership.member_name = input("Enter new Member Name: ")
                membership.member_contact = input("Enter new Member Contact: ")
                membership.membership_type = input("Enter new Membership Type: ")
                membership.membership_expiry = input("Enter new Membership Expiry: ")
                print("Membership updated successfully.")
                return
        print("Membership not found.")

    @staticmethod
    def delete_membership(memberships):
        membership_id = input("Enter Membership ID to delete: ")
        for membership in memberships:
            if membership.membership_id == membership_id:
                memberships.remove(membership)
                print("Membership deleted successfully.")
                return
        print("Membership not found.")
