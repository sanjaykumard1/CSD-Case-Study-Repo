from .membership import Membership
from .trainer import Trainer
from .fitness_class import FitnessClass
from .attendance import Attendance

def main():
    memberships = []
    trainers = []
    classes = []
    attendance_records = []

    while True:
        print("\nFitness Center Management System")
        print("1. Manage Memberships")
        print("2. Manage Trainers")
        print("3. Manage Classes")
        print("4. Manage Attendance")
        print("5. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            manage_memberships(memberships)
        elif choice == '2':
            manage_trainers(trainers)
        elif choice == '3':
            manage_classes(classes)
        elif choice == '4':
            manage_attendance(attendance_records)
        elif choice == '5':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_memberships(memberships):
    while True:
        print("\nManage Memberships")
        print("1. Add Membership")
        print("2. Update Membership")
        print("3. Delete Membership")
        print("4. Back")
        choice = input("Enter your choice: ")

        if choice == '1':
            Membership.add_membership(memberships)
        elif choice == '2':
            Membership.update_membership(memberships)
        elif choice == '3':
            Membership.delete_membership(memberships)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_trainers(trainers):
    while True:
        print("\nManage Trainers")
        print("1. Add Trainer")
        print("2. Update Trainer")
        print("3. Delete Trainer")
        print("4. Back")
        choice = input("Enter your choice: ")

        if choice == '1':
            Trainer.add_trainer(trainers)
        elif choice == '2':
            Trainer.update_trainer(trainers)
        elif choice == '3':
            Trainer.delete_trainer(trainers)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_classes(classes):
    while True:
        print("\nManage Classes")
        print("1. Add Class")
        print("2. Update Class")
        print("3. Delete Class")
        print("4. Back")
        choice = input("Enter your choice: ")

        if choice == '1':
            FitnessClass.add_class(classes)
        elif choice == '2':
            FitnessClass.update_class(classes)
        elif choice == '3':
            FitnessClass.delete_class(classes)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

def manage_attendance(attendance_records):
    while True:
        print("\nManage Attendance")
        print("1. Record Attendance")
        print("2. Update Attendance")
        print("3. Delete Attendance")
        print("4. Back")
        choice = input("Enter your choice: ")

        if choice == '1':
            Attendance.record_attendance(attendance_records)
        elif choice == '2':
            Attendance.update_attendance(attendance_records)
        elif choice == '3':
            Attendance.delete_attendance(attendance_records)
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
