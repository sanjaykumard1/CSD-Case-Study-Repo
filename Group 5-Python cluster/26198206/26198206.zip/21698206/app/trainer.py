class Trainer:
    def __init__(self, trainer_id, name, specialty, contact_info, availability):
        self.trainer_id = trainer_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.availability = availability

    @staticmethod
    def add_trainer(trainers):
        trainer_id = input("Enter Trainer ID: ")
        name = input("Enter Trainer Name: ")
        specialty = input("Enter Specialty: ")
        contact_info = input("Enter Contact Info: ")
        availability = input("Enter Availability: ")
        new_trainer = Trainer(trainer_id, name, specialty, contact_info, availability)
        trainers.append(new_trainer)
        print("Trainer added successfully.")

    @staticmethod
    def update_trainer(trainers):
        trainer_id = input("Enter Trainer ID to update: ")
        for trainer in trainers:
            if trainer.trainer_id == trainer_id:
                trainer.name = input("Enter new Trainer Name: ")
                trainer.specialty = input("Enter new Specialty: ")
                trainer.contact_info = input("Enter new Contact Info: ")
                trainer.availability = input("Enter new Availability: ")
                print("Trainer updated successfully.")
                return
        print("Trainer not found.")

    @staticmethod
    def delete_trainer(trainers):
        trainer_id = input("Enter Trainer ID to delete: ")
        for trainer in trainers:
            if trainer.trainer_id == trainer_id:
                trainers.remove(trainer)
                print("Trainer deleted successfully.")
                return
        print("Trainer not found.")
