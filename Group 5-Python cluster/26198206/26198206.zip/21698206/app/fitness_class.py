class FitnessClass:
    def __init__(self, class_id, class_name, trainer_id, schedule, capacity):
        self.class_id = class_id
        self.class_name = class_name
        self.trainer_id = trainer_id
        self.schedule = schedule
        self.capacity = capacity

    @staticmethod
    def add_class(classes):
        class_id = input("Enter Class ID: ")
        class_name = input("Enter Class Name: ")
        trainer_id = input("Enter Trainer ID: ")
        schedule = input("Enter Schedule: ")
        capacity = input("Enter Capacity: ")
        new_class = FitnessClass(class_id, class_name, trainer_id, schedule, capacity)
        classes.append(new_class)
        print("Class added successfully.")

    @staticmethod
    def update_class(classes):
        class_id = input("Enter Class ID to update: ")
        for fitness_class in classes:
            if fitness_class.class_id == class_id:
                fitness_class.class_name = input("Enter new Class Name: ")
                fitness_class.trainer_id = input("Enter new Trainer ID: ")
                fitness_class.schedule = input("Enter new Schedule: ")
                fitness_class.capacity = input("Enter new Capacity: ")
                print("Class updated successfully.")
                return
        print("Class not found.")

    @staticmethod
    def delete_class(classes):
        class_id = input("Enter Class ID to delete: ")
        for fitness_class in classes:
            if fitness_class.class_id == class_id:
                classes.remove(fitness_class)
                print("Class deleted successfully.")
                return
        print("Class not found.")

