class Attendance:
    def __init__(self, attendance_id, member_id, class_id, attendance_date):
        self.attendance_id = attendance_id
        self.member_id = member_id
        self.class_id = class_id
        self.attendance_date = attendance_date

    @staticmethod
    def record_attendance(attendance_records):
        attendance_id = input("Enter Attendance ID: ")
        member_id = input("Enter Member ID: ")
        class_id = input("Enter Class ID: ")
        attendance_date = input("Enter Attendance Date: ")
        new_attendance = Attendance(attendance_id, member_id, class_id, attendance_date)
        attendance_records.append(new_attendance)
        print("Attendance recorded successfully.")

    @staticmethod
    def update_attendance(attendance_records):
        attendance_id = input("Enter Attendance ID to update: ")
        for attendance in attendance_records:
            if attendance.attendance_id == attendance_id:
                attendance.member_id = input("Enter new Member ID: ")
                attendance.class_id = input("Enter new Class ID: ")
                attendance.attendance_date = input("Enter new Attendance Date: ")
                print("Attendance updated successfully.")
                return
        print("Attendance not found.")

    @staticmethod
    def delete_attendance(attendance_records):
        attendance_id = input("Enter Attendance ID to delete: ")
        for attendance in attendance_records:
            if attendance.attendance_id == attendance_id:
                attendance_records.remove(attendance)
                print("Attendance deleted successfully.")
                return
        print("Attendance not found.")

