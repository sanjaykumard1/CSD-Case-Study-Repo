# Fitness Center Management System
All the code of the console  based application is in the app folder 
and all the results and queries of sql are in the doc file

## Overview
This is a standalone console application to manage a fitness center, including memberships, trainers, classes, and attendance records.


## Setup
1. Clone the repository:
    ```sh
    git clone <repository-url>
    ```


## Usage

Run the application:
open the terminal form base folder that is 26198206
```sh
python -m app.main  

