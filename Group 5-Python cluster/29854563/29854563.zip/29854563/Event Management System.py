class Event:
    def __init__(self, event_id, event_name, event_date, location, max_participants):
        self.event_id = event_id
        self.event_name = event_name
        self.event_date = event_date
        self.location = location
        self.max_participants = max_participants

class EventManager:
    def __init__(self):
        self.events = {}

    def add_event(self, event):
        if event.event_id in self.events:
            print("Event ID already exists.")
        else:
            self.events[event.event_id] = event
            print("Event added.")

    def update_event(self, event_id, event_name=None, event_date=None, location=None, max_participants=None):
        if event_id in self.events:
            if event_name is not None:
                self.events[event_id].event_name = event_name
            if event_date is not None:
                self.events[event_id].event_date = event_date
            if location is not None:
                self.events[event_id].location = location
            if max_participants is not None:
                self.events[event_id].max_participants = max_participants
            print("Event updated.")
        else:
            print("Event not found.")

    def delete_event(self, event_id):
        if event_id in self.events:
            del self.events[event_id]
            print("Event deleted.")
        else:
            print("Event not found.")

class Participant:
    def __init__(self, participant_id, name, email, phone_number):
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.phone_number = phone_number

class ParticipantManager:
    def __init__(self):
        self.participants = {}

    def add_participant(self, participant):
        if participant.participant_id in self.participants:
            print("Participant ID already exists.")
        else:
            self.participants[participant.participant_id] = participant
            print("Participant added.")

    def update_participant(self, participant_id, name=None, email=None, phone_number=None):
        if participant_id in self.participants:
            if name is not None:
                self.participants[participant_id].name = name
            if email is not None:
                self.participants[participant_id].email = email
            if phone_number is not None:
                self.participants[participant_id].phone_number = phone_number
            print("Participant updated.")
        else:
            print("Participant not found.")

    def delete_participant(self, participant_id):
        if participant_id in self.participants:
            del self.participants[participant_id]
            print("Participant deleted.")
        else:
            print("Participant not found.")

class Registration:
    def __init__(self, registration_id, event_id, participant_id, registration_date):
        self.registration_id = registration_id
        self.event_id = event_id
        self.participant_id = participant_id
        self.registration_date = registration_date

class RegistrationManager:
    def __init__(self, event_manager, participant_manager):
        self.registrations = {}
        self.event_manager = event_manager
        self.participant_manager = participant_manager

    def add_registration(self, registration):
        if registration.registration_id in self.registrations:
            print("Registration ID already exists.")
        elif registration.event_id not in self.event_manager.events:
            print("Event not found.")
        elif registration.participant_id not in self.participant_manager.participants:
            print("Participant not found.")
        else:
            event = self.event_manager.events[registration.event_id]
            current_registrations = [reg for reg in self.registrations.values() if reg.event_id == event.event_id]
            if len(current_registrations) >= event.max_participants:
                print("Event is at maximum capacity.")
            else:
                self.registrations[registration.registration_id] = registration
                print("Registration added.")

    def update_registration(self, registration_id, event_id=None, participant_id=None, registration_date=None):
        if registration_id in self.registrations:
            if event_id is not None:
                if event_id in self.event_manager.events:
                    self.registrations[registration_id].event_id = event_id
                else:
                    print("Event not found.")
                    return
            if participant_id is not None:
                if participant_id in self.participant_manager.participants:
                    self.registrations[registration_id].participant_id = participant_id
                else:
                    print("Participant not found.")
                    return
            if registration_date is not None:
                self.registrations[registration_id].registration_date = registration_date
            print("Registration updated.")
        else:
            print("Registration not found.")

    def delete_registration(self, registration_id):
        if registration_id in self.registrations:
            del self.registrations[registration_id]
            print("Registration deleted.")
        else:
            print("Registration not found.")

def main():
    event_manager = EventManager()
    participant_manager = ParticipantManager()
    registration_manager = RegistrationManager(event_manager, participant_manager)

    while True:
        print("\nEvent Management System")
        print("1. Manage Events")
        print("2. Manage Participants")
        print("3. Manage Registrations")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            print("\nManage Events")
            print("1. Add Event")
            print("2. Update Event")
            print("3. Delete Event")
            event_choice = input("Enter your choice: ")
            if event_choice == '1':
                event_id = input("Enter Event ID: ")
                event_name = input("Enter Event Name: ")
                event_date = input("Enter Event Date (YYYY-MM-DD): ")
                location = input("Enter Location: ")
                max_participants = int(input("Enter Maximum Participants: "))
                event = Event(event_id, event_name, event_date, location, max_participants)
                event_manager.add_event(event)
            elif event_choice == '2':
                event_id = input("Enter Event ID: ")
                event_name = input("Enter Event Name: ")
                event_date = input("Enter Event Date (YYYY-MM-DD): ")
                location = input("Enter Location: ")
                max_participants = int(input("Enter Maximum Participants: "))
                event_manager.update_event(event_id, event_name, event_date, location, max_participants)
            elif event_choice == '3':
                event_id = input("Enter Event ID: ")
                event_manager.delete_event(event_id)

        elif choice == '2':
            print("\nManage Participants")
            print("1. Add Participant")
            print("2. Update Participant")
            print("3. Delete Participant")
            participant_choice = input("Enter your choice: ")
            if participant_choice == '1':
                participant_id = input("Enter Participant ID: ")
                name = input("Enter Name: ")
                email = input("Enter Email: ")
                phone_number = input("Enter Phone Number: ")
                participant = Participant(participant_id, name, email, phone_number)
                participant_manager.add_participant(participant)
            elif participant_choice == '2':
                participant_id = input("Enter Participant ID: ")
                name = input("Enter Name: ")
                email = input("Enter Email: ")
                phone_number = input("Enter Phone Number: ")
                participant_manager.update_participant(participant_id, name, email, phone_number)
            elif participant_choice == '3':
                participant_id = input("Enter Participant ID: ")
                participant_manager.delete_participant(participant_id)

        elif choice == '3':
            print("\nManage Registrations")
            print("1. Add Registration")
            print("2. Update Registration")
            print("3. Delete Registration")
            registration_choice = input("Enter your choice: ")
            if registration_choice == '1':
                registration_id = input("Enter Registration ID: ")
                event_id = input("Enter Event ID: ")
                participant_id = input("Enter Participant ID: ")
                registration_date = input("Enter Registration Date (YYYY-MM-DD): ")
                registration = Registration(registration_id, event_id, participant_id, registration_date)
                registration_manager.add_registration(registration)
            elif registration_choice == '2':
                registration_id = input("Enter Registration ID: ")
                event_id = input("Enter Event ID: ")
                participant_id = input("Enter Participant ID: ")
                registration_date = input("Enter Registration Date (YYYY-MM-DD): ")
                registration_manager.update_registration(registration_id, event_id, participant_id, registration_date)
            elif registration_choice == '3':
                registration_id = input("Enter Registration ID: ")
                registration_manager.delete_registration(registration_id)

        elif choice == '4':
            print("Exiting...")
            break

if __name__ == "__main__":
    main()
