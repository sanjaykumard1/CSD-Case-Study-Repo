CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_info VARCHAR(100),
    loyalty_points INT
);

INSERT INTO Customers (customer_id, name, contact_info, loyalty_points) VALUES
(1, 'Alice Johnson', 'alice@example.com', 120),
(2, 'Bob Smith', 'bob@example.com', 80),
(3, 'Charlie Brown', 'charlie@example.com', 150),
(4, 'Diana Prince', 'diana@example.com', 60),
(5, 'Eve Adams', 'eve@example.com', 200);


CREATE TABLE Transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    product_name VARCHAR(100),
    quantity_sold INT,
    sale_amount DECIMAL(10, 2),
    transaction_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

INSERT INTO transcations (transcation_id, customer_id, product_name, quantity_sold, sale_amount, transcation_date) VALUES
(1, 1, 'Laptop', 1, 1000.00, '2023-01-10'),
(2, 1, 'Mouse', 2, 40.00, '2023-01-15'),
(3, 2, 'Keyboard', 1, 50.00, '2023-02-01'),
(4, 3, 'Monitor', 2, 300.00, '2023-02-10'),
(5, 3, 'Mouse', 1, 20.00, '2023-02-15'),
(6, 3, 'Laptop', 1, 900.00, '2023-03-01'),
(7, 4, 'Mouse', 1, 20.00, '2023-03-10'),
(8, 5, 'Keyboard', 1, 50.00, '2023-03-20'),
(9, 5, 'Laptop', 1, 1200.00, '2023-04-01'),
(10, 5, 'Mouse', 2, 40.00, '2023-04-10'),
(11, 1, 'Keyboard', 1, 60.00, '2023-04-20');


-- 1. Find the total sales amount for each customer.
SELECT customer_id, SUM(sale_amount) AS total_sales
FROM Transcations
GROUP BY customer_id;

-- 2. Find the names of customers and their total sales amounts.
SELECT c.name, SUM(t.sale_amount) AS total_sales
FROM Customers c
JOIN Transcations t ON c.customer_id = t.customer_id
GROUP BY c.name;

-- 3. Find the names of customers who have never made a purchase.
SELECT c.name
FROM Customers c
LEFT JOIN Transcations t ON c.customer_id = t.customer_id
WHERE t.transcation_id IS NULL;

-- 4. Find the products that have been sold more than 50 times.
SELECT product_name
FROM Transcations
GROUP BY product_name
HAVING SUM(quantity_sold) > 50;

-- 5. Find the customer names and their loyalty points for those who have made more than 10 transactions.
SELECT c.name, c.loyalty_points
FROM Customers c
JOIN Transcations t ON c.customer_id = t.customer_id
GROUP BY c.customer_id
HAVING COUNT(t.transcation_id) > 10;
