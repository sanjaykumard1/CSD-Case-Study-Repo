class Customer:
    def __init__(self, customer_id, name, contact_info, loyalty_points=0):
        self.customer_id = customer_id
        self.name = name
        self.contact_info = contact_info
        self.loyalty_points = loyalty_points

class Transaction:
    def __init__(self, transaction_id, customer_id, product_name, quantity_sold, sale_amount):
        self.transaction_id = transaction_id
        self.customer_id = customer_id
        self.product_name = product_name
        self.quantity_sold = quantity_sold
        self.sale_amount = sale_amount

class RetailSalesManagementSystem:
    def __init__(self):
        self.customers = {}
        self.transactions = {}

    def add_customer(self, customer_id, name, contact_info, loyalty_points=0):
        if customer_id in self.customers:
            print(f"Customer with ID {customer_id} already exists.")
            return
        self.customers[customer_id] = Customer(customer_id, name, contact_info, loyalty_points)
        print(f"Customer {name} added successfully.")

    def update_customer(self, customer_id, name=None, contact_info=None, loyalty_points=None):
        if customer_id not in self.customers:
            print(f"Customer with ID {customer_id} does not exist.")
            return
        customer = self.customers[customer_id]
        if name:
            customer.name = name
        if contact_info:
            customer.contact_info = contact_info
        if loyalty_points is not None:
            customer.loyalty_points = loyalty_points
        print(f"Customer {customer_id} updated successfully.")

    def delete_customer(self, customer_id):
        if customer_id not in self.customers:
            print(f"Customer with ID {customer_id} does not exist.")
            return
        del self.customers[customer_id]
        print(f"Customer {customer_id} deleted successfully.")

    def record_transaction(self, transaction_id, customer_id, product_name, quantity_sold, sale_amount):
        if transaction_id in self.transactions:
            print(f"Transaction with ID {transaction_id} already exists.")
            return
        if customer_id not in self.customers:
            print(f"Customer with ID {customer_id} does not exist.")
            return
        self.transactions[transaction_id] = Transaction(transaction_id, customer_id, product_name, quantity_sold, sale_amount)
        self.customers[customer_id].loyalty_points += quantity_sold
        print(f"Transaction {transaction_id} recorded successfully.")

    def get_top_customers(self):
        top_customers = [customer for customer in self.customers.values() if customer.loyalty_points > 100]
        return top_customers

def main():
    system = RetailSalesManagementSystem()

    while True:
        print("\nRetail Sales Management System")
        print("1. Add Customer")
        print("2. Update Customer")
        print("3. Delete Customer")
        print("4. Record Sales Transaction")
        print("5. Display Top Customers")
        print("6. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                customer_id = input("Enter customer ID: ")
                name = input("Enter customer name: ")
                contact_info = input("Enter contact info: ")
                loyalty_points = int(input("Enter loyalty points: "))
                system.add_customer(customer_id, name, contact_info, loyalty_points)
            elif choice == '2':
                customer_id = input("Enter customer ID: ")
                name = input("Enter new name (leave blank to keep current): ")
                contact_info = input("Enter new contact info (leave blank to keep current): ")
                loyalty_points = input("Enter new loyalty points (leave blank to keep current): ")
                loyalty_points = int(loyalty_points) if loyalty_points else None
                system.update_customer(customer_id, name, contact_info, loyalty_points)
            elif choice == '3':
                customer_id = input("Enter customer ID to delete: ")
                system.delete_customer(customer_id)
            elif choice == '4':
                transaction_id = input("Enter transaction ID: ")
                customer_id = input("Enter customer ID: ")
                product_name = input("Enter product name: ")
                quantity_sold = int(input("Enter quantity sold: "))
                sale_amount = float(input("Enter sale amount: "))
                system.record_transaction(transaction_id, customer_id, product_name, quantity_sold, sale_amount)
            elif choice == '5':
                top_customers = system.get_top_customers()
                for customer in top_customers:
                    print(f"ID: {customer.customer_id}, Name: {customer.name}, Points: {customer.loyalty_points}")
            elif choice == '6':
                print("Exiting the system.")
                break
            else:
                print("Invalid choice. Please try again.")
        except ValueError as e:
            print(f"Error: {e}. Please enter valid data.")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()
