-- create required tables
CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10, 2),
    quantity_in_stock INT
);

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    quantity_sold INT,
    sale_date DATE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

CREATE TABLE Restocks (
    restock_id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT,
    quantity_restocked INT,
    restock_date DATE,
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- insert dummy data
INSERT INTO Products (product_id, name, category, price, quantity_in_stock)
VALUES
(1, 'Product A', 'Category 1', 10.00, 50),
(2, 'Product B', 'Category 2', 20.00, 30),
(3, 'Product C', 'Category 1', 15.00, 5),
(4, 'Product D', 'Category 3', 25.00, 60),
(5, 'Product E', 'Category 2', 30.00, 0);

INSERT INTO Sales (product_id, quantity_sold, sale_date)
VALUES
(1, 15, '2024-07-01'),
(1, 5, '2024-07-02'),
(2, 10, '2024-07-01'),
(3, 3, '2024-07-01'),
(4, 25, '2024-07-01'),
(5, 22, '2024-07-01');

INSERT INTO Restocks (product_id, quantity_restocked, restock_date)
VALUES
(1, 20, '2024-06-01'),
(2, 10, '2024-06-05'),
(3, 7, '2024-06-10'),
(4, 30, '2024-06-15'),
(5, 10, '2024-06-20'),
(3, 8, '2024-07-01'),
(3, 6, '2024-07-05'),
(3, 10, '2024-07-07'),
(3, 5, '2024-07-10'),
(3, 2, '2024-07-12');

-- Show the inserted data
select * from Products;
select * from Sales;
select * from Restocks;

-- Problem Statements

-- 1.Query to find the total quantity of each product sold.
SELECT product_id, SUM(quantity_sold) AS total_quantity_sold
FROM Sales
GROUP BY product_id;

-- 2.Query to find the product name and total quantity sold for each product.
SELECT p.name, SUM(s.quantity_sold) AS total_quantity_sold
FROM Products p
JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.name;

-- 3.Query to find the names of products that have never been sold.
SELECT name
FROM Products
WHERE product_id NOT IN (SELECT DISTINCT product_id FROM Sales);

-- 4.Query to find the products that have been restocked more than 5 times.
SELECT product_id, COUNT(restock_id) AS restock_count
FROM Restocks
GROUP BY product_id
HAVING restock_count > 5;

-- 5.Query to find the product names and their current stock levels for products that have sold more than 20 units.
SELECT p.name, p.quantity_in_stock
FROM Products p
JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.name, p.quantity_in_stock
HAVING SUM(s.quantity_sold) > 20;