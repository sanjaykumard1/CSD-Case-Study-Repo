import mysql.connector
from mysql.connector import Error

class Product:
    def __init__(self, product_id, name, category, price, quantity_in_stock):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def __repr__(self):
        return f"Product({self.product_id}, {self.name}, {self.category}, {self.price}, {self.quantity_in_stock})"

class Inventory:
    def __init__(self):
        self.connection = self.create_connection()

    def create_connection(self):
        try:
            connection = mysql.connector.connect(
                host='localhost',
                database='ims',
                user='root',
                password='root'
            )
            if connection.is_connected():
                print("Connected to MySQL database")
            return connection
        except Error as e:
            print(f"Error: {e}")
            return None

    def close_connection(self):
        if self.connection.is_connected():
            self.connection.close()
            print("MySQL connection is closed")

    def add_product(self, product):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Products (product_id, name, category, price, quantity_in_stock) VALUES (%s, %s, %s, %s, %s)"
            values = (product.product_id, product.name, product.category, product.price, product.quantity_in_stock)
            cursor.execute(query, values)
            self.connection.commit()
            print("Product added successfully.")
        except Error as e:
            print(f"Error: {e}")

    def update_product(self, product_id, name=None, category=None, price=None, quantity_in_stock=None):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Products SET "
            updates = []
            values = []
            if name is not None:
                updates.append("name = %s")
                values.append(name)
            if category is not None:
                updates.append("category = %s")
                values.append(category)
            if price is not None:
                updates.append("price = %s")
                values.append(price)
            if quantity_in_stock is not None:
                updates.append("quantity_in_stock = %s")
                values.append(quantity_in_stock)
            query += ", ".join(updates) + " WHERE product_id = %s"
            values.append(product_id)
            cursor.execute(query, values)
            self.connection.commit()
            print("Product updated successfully.")
        except Error as e:
            print(f"Error: {e}")

    def delete_product(self, product_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Products WHERE product_id = %s"
            cursor.execute(query, (product_id,))
            self.connection.commit()
            print("Product deleted successfully.")
        except Error as e:
            print(f"Error: {e}")

    def check_stock(self, product_id):
        try:
            cursor = self.connection.cursor()
            query = "SELECT quantity_in_stock FROM Products WHERE product_id = %s"
            cursor.execute(query, (product_id,))
            result = cursor.fetchone()
            return result[0] if result else None
        except Error as e:
            print(f"Error: {e}")

    def update_stock(self, product_id, quantity):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Products SET quantity_in_stock = quantity_in_stock + %s WHERE product_id = %s"
            cursor.execute(query, (quantity, product_id))
            self.connection.commit()
            print("Stock level updated successfully.")
        except Error as e:
            print(f"Error: {e}")

    def low_stock_report(self):
        try:
            cursor = self.connection.cursor()
            query = "SELECT * FROM Products WHERE quantity_in_stock < 10"
            cursor.execute(query)
            results = cursor.fetchall()
            return [Product(*result) for result in results]
        except Error as e:
            print(f"Error: {e}")

def main():
    inventory = Inventory()

    while True:
        print("\nInventory Management System")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Check Stock Level")
        print("5. Update Stock Level")
        print("6. Low Stock Report")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            product_id = int(input("Enter Product ID: "))
            name = input("Enter Product Name: ")
            category = input("Enter Product Category: ")
            price = float(input("Enter Product Price: "))
            quantity_in_stock = int(input("Enter Quantity in Stock: "))
            product = Product(product_id, name, category, price, quantity_in_stock)
            inventory.add_product(product)

        elif choice == '2':
            product_id = int(input("Enter Product ID to Update: "))
            name = input("Enter new Product Name (leave blank to keep current): ")
            category = input("Enter new Product Category (leave blank to keep current): ")
            price = input("Enter new Product Price (leave blank to keep current): ")
            quantity_in_stock = input("Enter new Quantity in Stock (leave blank to keep current): ")
            name = name if name else None
            category = category if category else None
            price = float(price) if price else None
            quantity_in_stock = int(quantity_in_stock) if quantity_in_stock else None
            inventory.update_product(product_id, name, category, price, quantity_in_stock)

        elif choice == '3':
            product_id = int(input("Enter Product ID to Delete: "))
            inventory.delete_product(product_id)

        elif choice == '4':
            product_id = int(input("Enter Product ID to Check Stock: "))
            stock_level = inventory.check_stock(product_id)
            print(f"Stock level of Product ID {product_id}: {stock_level}")

        elif choice == '5':
            product_id = int(input("Enter Product ID to Update Stock: "))
            quantity = int(input("Enter Quantity to Add/Subtract: "))
            inventory.update_stock(product_id, quantity)

        elif choice == '6':
            low_stock_products = inventory.low_stock_report()
            print("Products low in stock:")
            for product in low_stock_products:
                print(product)

        elif choice == '7':
            inventory.close_connection()
            break

        else:
            print("Invalid choice. Please try again.")

if _name_ == "_main_":
    main()