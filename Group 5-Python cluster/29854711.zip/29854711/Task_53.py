class Product:
    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    def update_product(self, name=None, category=None, price=None, stock_quantity=None):
        if name:
            self.name = name
        if category:
            self.category = category
        if price:
            self.price = price
        if stock_quantity:
            self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Product ID: {self.product_id}, Name: {self.name}, Category: {self.category}, Price: {self.price}, Stock: {self.stock_quantity}"


class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def update_customer(self, name=None, email=None, address=None):
        if name:
            self.name = name
        if email:
            self.email = email
        if address:
            self.address = address

    def __str__(self):
        return f"Customer ID: {self.customer_id}, Name: {self.name}, Email: {self.email}, Address: {self.address}"


class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def update_order(self, customer_id=None, product_id=None, order_date=None, quantity=None):
        if customer_id:
            self.customer_id = customer_id
        if product_id:
            self.product_id = product_id
        if order_date:
            self.order_date = order_date
        if quantity:
            self.quantity = quantity

    def __str__(self):
        return f"Order ID: {self.order_id}, Customer ID: {self.customer_id}, Product ID: {self.product_id}, Order Date: {self.order_date}, Quantity: {self.quantity}"


products = {}
customers = {}
orders = {}


def add_product(product_id, name, category, price, stock_quantity):
    if product_id in products:
        print("\nProduct ID already exists.")
        return
    products[product_id] = Product(product_id, name, category, price, stock_quantity)
    print("\nProduct added successfully.")


def update_product(product_id, name=None, category=None, price=None, stock_quantity=None):
    if product_id not in products:
        print("\nProduct ID not found.")
        return
    products[product_id].update_product(name, category, price, stock_quantity)
    print("\nProduct updated successfully.")


def delete_product(product_id):
    if product_id not in products:
        print("\nProduct ID not found.")
        return
    del products[product_id]
    print("\nProduct deleted successfully.")


def add_customer(customer_id, name, email, address):
    if customer_id in customers:
        print("\nCustomer ID already exists.")
        return
    customers[customer_id] = Customer(customer_id, name, email, address)
    print("\nCustomer added successfully.")


def update_customer(customer_id, name=None, email=None, address=None):
    if customer_id not in customers:
        print("\nCustomer ID not found.")
        return
    customers[customer_id].update_customer(name, email, address)
    print("\nCustomer updated successfully.")


def delete_customer(customer_id):
    if customer_id not in customers:
        print("\nCustomer ID not found.")
        return
    del customers[customer_id]
    print("\nCustomer deleted successfully.")


def add_order(order_id, customer_id, product_id, order_date, quantity):
    if order_id in orders:
        print("\nOrder ID already exists.")
        return
    if customer_id not in customers:
        print("\nCustomer ID not found.")
        return
    if product_id not in products:
        print("\nProduct ID not found.")
        return
    if products[product_id].stock_quantity < quantity:
        print("\nInsufficient stock.")
        return
    products[product_id].stock_quantity -= quantity
    orders[order_id] = Order(order_id, customer_id, product_id, order_date, quantity)
    print("\nOrder added successfully.")


def update_order(order_id, customer_id=None, product_id=None, order_date=None, quantity=None):
    if order_id not in orders:
        print("\nOrder ID not found.") 
        return
    orders[order_id].update_order(customer_id, product_id, order_date, quantity)
    print("\nOrder updated successfully.")


def cancel_order(order_id):
    if order_id not in orders:
        print("\nOrder ID not found.")
        return
    product_id = orders[order_id].product_id
    quantity = orders[order_id].quantity
    products[product_id].stock_quantity += quantity
    del orders[order_id]
    print("\nOrder canceled successfully.")


def main():
    while True:
        print("\nOnline Shopping System")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Add Customer")
        print("5. Update Customer")
        print("6. Delete Customer")
        print("7. Add Order")
        print("8. Update Order")
        print("9. Cancel Order")
        print("10. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            product_id = input("Enter product ID: ")
            name = input("Enter product name: ")
            category = input("Enter product category: ")
            price = float(input("Enter product price: "))
            stock_quantity = int(input("Enter stock quantity: "))
            add_product(product_id, name, category, price, stock_quantity)
        elif choice == '2':
            product_id = input("Enter product ID: ")
            name = input("Enter new name (leave blank to skip): ")
            category = input("Enter new category (leave blank to skip): ")
            price = input("Enter new price (leave blank to skip): ")
            stock_quantity = input("Enter new stock quantity (leave blank to skip): ")
            update_product(product_id, name or None, category or None, float(price) if price else None, int(stock_quantity) if stock_quantity else None)
        elif choice == '3':
            product_id = input("Enter product ID: ")
            delete_product(product_id)
        elif choice == '4':
            customer_id = input("Enter customer ID: ")
            name = input("Enter customer name: ")
            email = input("Enter customer email: ")
            address = input("Enter customer address: ")
            add_customer(customer_id, name, email, address)
        elif choice == '5':
            customer_id = input("Enter customer ID: ")
            name = input("Enter new name (leave blank to skip): ")
            email = input("Enter new email (leave blank to skip): ")
            address = input("Enter new address (leave blank to skip): ")
            update_customer(customer_id, name or None, email or None, address or None)
        elif choice == '6':
            customer_id = input("Enter customer ID: ")
            delete_customer(customer_id)
        elif choice == '7':
            order_id = input("Enter order ID: ")
            customer_id = input("Enter customer ID: ")
            product_id = input("Enter product ID: ")
            order_date = input("Enter order date: ")
            quantity = int(input("Enter quantity: "))
            add_order(order_id, customer_id, product_id, order_date, quantity)
        elif choice == '8':
            order_id = input("Enter order ID: ")
            customer_id = input("Enter new customer ID (leave blank to skip): ")
            product_id = input("Enter new product ID (leave blank to skip): ")
            order_date = input("Enter new order date (leave blank to skip): ")
            quantity = input("Enter new quantity (leave blank to skip): ")
            update_order(order_id, customer_id or None, product_id or None, order_date or None, int(quantity) if quantity else None)
        elif choice == '9':
            order_id = input("Enter order ID: ")
            cancel_order(order_id)
        elif choice == '10':
            break
        else:
            print("Invalid choice, please try again.")


if __name__ == "__main__":
    main()