import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from datetime import datetime

class Product:
    def __init__(self, product_id, name, description, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.price = price
        self.stock_quantity = stock_quantity

    def update_product(self, name=None, description=None, price=None, stock_quantity=None):
        if name:
            self.name = name
        if description:
            self.description = description
        if price:
            self.price = price
        if stock_quantity:
            self.stock_quantity = stock_quantity

    def __str__(self):
        return f"Product[ID: {self.product_id}, Name: {self.name}, Description: {self.description}, Price: {self.price}, Stock: {self.stock_quantity}]"

class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def update_customer(self, name=None, email=None, address=None):
        if name:
            self.name = name
        if email:
            self.email = email
        if address:
            self.address = address

    def __str__(self):
        return f"Customer[ID: {self.customer_id}, Name: {self.name}, Email: {self.email}, Address: {self.address}]"

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order[ID: {self.order_id}, Customer ID: {self.customer_id}, Product ID: {self.product_id}, Date: {self.order_date}, Quantity: {self.quantity}]"

class ECommerceSystem:
    def __init__(self):
        self.products = {}
        self.customers = {}
        self.orders = {}
        self.next_product_id = 1
        self.next_customer_id = 1
        self.next_order_id = 1

    def add_product(self, name, description, price, stock_quantity):
        product = Product(self.next_product_id, name, description, price, stock_quantity)
        self.products[self.next_product_id] = product
        self.next_product_id += 1
        return product

    def update_product(self, product_id, name=None, description=None, price=None, stock_quantity=None):
        if product_id in self.products:
            self.products[product_id].update_product(name, description, price, stock_quantity)
            return self.products[product_id]
        else:
            return None

    def delete_product(self, product_id):
        if product_id in self.products:
            del self.products[product_id]
            return True
        else:
            return False

    def add_customer(self, name, email, address):
        customer = Customer(self.next_customer_id, name, email, address)
        self.customers[self.next_customer_id] = customer
        self.next_customer_id += 1
        return customer

    def update_customer(self, customer_id, name=None, email=None, address=None):
        if customer_id in self.customers:
            self.customers[customer_id].update_customer(name, email, address)
            return self.customers[customer_id]
        else:
            return None

    def delete_customer(self, customer_id):
        if customer_id in self.customers:
            del self.customers[customer_id]
            return True
        else:
            return False

    def place_order(self, customer_id, product_id, quantity):
        if customer_id not in self.customers:
            return None, "Customer not found"
        if product_id not in self.products:
            return None, "Product not found"
        product = self.products[product_id]
        if product.stock_quantity < quantity:
            return None, "Insufficient stock"
        order_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        order = Order(self.next_order_id, customer_id, product_id, order_date, quantity)
        self.orders[self.next_order_id] = order
        product.stock_quantity -= quantity
        self.next_order_id += 1
        return order, None

    def update_order(self, order_id, customer_id=None, product_id=None, quantity=None):
        if order_id not in self.orders:
            return None, "Order not found"
        order = self.orders[order_id]
        if customer_id and customer_id in self.customers:
            order.customer_id = customer_id
        if product_id and product_id in self.products:
            order.product_id = product_id
        if quantity:
            product = self.products[order.product_id]
            if product.stock_quantity + order.quantity < quantity:
                return None, "Insufficient stock to update order"
            product.stock_quantity += order.quantity - quantity
            order.quantity = quantity
        return order, None

    def delete_order(self, order_id):
        if order_id in self.orders:
            order = self.orders[order_id]
            self.products[order.product_id].stock_quantity += order.quantity
            del self.orders[order_id]
            return True
        else:
            return False

class ECommerceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("E-Commerce Management System")
        self.system = ECommerceSystem()

        # Set initial window size
        self.root.geometry("800x600")

        self.create_widgets()

    def create_widgets(self):
        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(expand=1, fill='both')

        self.product_tab = tk.Frame(self.tabs)
        self.customer_tab = tk.Frame(self.tabs)
        self.order_tab = tk.Frame(self.tabs)

        self.tabs.add(self.product_tab, text="Products")
        self.tabs.add(self.customer_tab, text="Customers")
        self.tabs.add(self.order_tab, text="Orders")

        self.tabs.pack(expand=1, fill='both')

        self.create_product_tab()
        self.create_customer_tab()
        self.create_order_tab()

    def create_product_tab(self):
        tk.Label(self.product_tab, text="Product Management", font=("Helvetica", 16)).grid(row=0, columnspan=2)
        
        tk.Label(self.product_tab, text="Name", font=("Helvetica", 12)).grid(row=1, column=0, padx=10, pady=10)
        self.product_name = tk.Entry(self.product_tab, font=("Helvetica", 12), width=30)
        self.product_name.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(self.product_tab, text="Description", font=("Helvetica", 12)).grid(row=2, column=0, padx=10, pady=10)
        self.product_description = tk.Entry(self.product_tab, font=("Helvetica", 12), width=30)
        self.product_description.grid(row=2, column=1, padx=10, pady=10)

        tk.Label(self.product_tab, text="Price", font=("Helvetica", 12)).grid(row=3, column=0, padx=10, pady=10)
        self.product_price = tk.Entry(self.product_tab, font=("Helvetica", 12), width=30)
        self.product_price.grid(row=3, column=1, padx=10, pady=10)

        tk.Label(self.product_tab, text="Stock Quantity", font=("Helvetica", 12)).grid(row=4, column=0, padx=10, pady=10)
        self.product_stock_quantity = tk.Entry(self.product_tab, font=("Helvetica", 12), width=30)
        self.product_stock_quantity.grid(row=4, column=1, padx=10, pady=10)

        self.product_id_label = tk.Label(self.product_tab, text="Product ID (for update/delete)", font=("Helvetica", 12))
        self.product_id_label.grid(row=5, column=0, padx=10, pady=10)
        self.product_id = tk.Entry(self.product_tab, font=("Helvetica", 12), width=30)
        self.product_id.grid(row=5, column=1, padx=10, pady=10)

        self.add_product_button = tk.Button(self.product_tab, text="Add Product", font=("Helvetica", 12), command=self.add_product)
        self.add_product_button.grid(row=6, columnspan=2, padx=10, pady=10)

        self.update_product_button = tk.Button(self.product_tab, text="Update Product", font=("Helvetica", 12), command=self.update_product)
        self.update_product_button.grid(row=7, columnspan=2, padx=10, pady=10)

        self.delete_product_button = tk.Button(self.product_tab, text="Delete Product", font=("Helvetica", 12), command=self.delete_product)
        self.delete_product_button.grid(row=8, columnspan=2, padx=10, pady=10)

    def create_customer_tab(self):
        tk.Label(self.customer_tab, text="Customer Management", font=("Helvetica", 16)).grid(row=0, columnspan=2)
        
        tk.Label(self.customer_tab, text="Name", font=("Helvetica", 12)).grid(row=1, column=0, padx=10, pady=10)
        self.customer_name = tk.Entry(self.customer_tab, font=("Helvetica", 12), width=30)
        self.customer_name.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(self.customer_tab, text="Email", font=("Helvetica", 12)).grid(row=2, column=0, padx=10, pady=10)
        self.customer_email = tk.Entry(self.customer_tab, font=("Helvetica", 12), width=30)
        self.customer_email.grid(row=2, column=1, padx=10, pady=10)

        tk.Label(self.customer_tab, text="Address", font=("Helvetica", 12)).grid(row=3, column=0, padx=10, pady=10)
        self.customer_address = tk.Entry(self.customer_tab, font=("Helvetica", 12), width=30)
        self.customer_address.grid(row=3, column=1, padx=10, pady=10)

        self.customer_id_label = tk.Label(self.customer_tab, text="Customer ID (for update/delete)", font=("Helvetica", 12))
        self.customer_id_label.grid(row=4, column=0, padx=10, pady=10)
        self.customer_id = tk.Entry(self.customer_tab, font=("Helvetica", 12), width=30)
        self.customer_id.grid(row=4, column=1, padx=10, pady=10)

        self.add_customer_button = tk.Button(self.customer_tab, text="Add Customer", font=("Helvetica", 12), command=self.add_customer)
        self.add_customer_button.grid(row=5, columnspan=2, padx=10, pady=10)

        self.update_customer_button = tk.Button(self.customer_tab, text="Update Customer", font=("Helvetica", 12), command=self.update_customer)
        self.update_customer_button.grid(row=6, columnspan=2, padx=10, pady=10)

        self.delete_customer_button = tk.Button(self.customer_tab, text="Delete Customer", font=("Helvetica", 12), command=self.delete_customer)
        self.delete_customer_button.grid(row=7, columnspan=2, padx=10, pady=10)

    def create_order_tab(self):
        tk.Label(self.order_tab, text="Order Management", font=("Helvetica", 16)).grid(row=0, columnspan=2)
        
        tk.Label(self.order_tab, text="Customer ID", font=("Helvetica", 12)).grid(row=1, column=0, padx=10, pady=10)
        self.order_customer_id = tk.Entry(self.order_tab, font=("Helvetica", 12), width=30)
        self.order_customer_id.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(self.order_tab, text="Product ID", font=("Helvetica", 12)).grid(row=2, column=0, padx=10, pady=10)
        self.order_product_id = tk.Entry(self.order_tab, font=("Helvetica", 12), width=30)
        self.order_product_id.grid(row=2, column=1, padx=10, pady=10)

        tk.Label(self.order_tab, text="Quantity", font=("Helvetica", 12)).grid(row=3, column=0, padx=10, pady=10)
        self.order_quantity = tk.Entry(self.order_tab, font=("Helvetica", 12), width=30)
        self.order_quantity.grid(row=3, column=1, padx=10, pady=10)

        self.order_id_label = tk.Label(self.order_tab, text="Order ID (for update/delete)", font=("Helvetica", 12))
        self.order_id_label.grid(row=4, column=0, padx=10, pady=10)
        self.order_id = tk.Entry(self.order_tab, font=("Helvetica", 12), width=30)
        self.order_id.grid(row=4, column=1, padx=10, pady=10)

        self.place_order_button = tk.Button(self.order_tab, text="Place Order", font=("Helvetica", 12), command=self.place_order)
        self.place_order_button.grid(row=5, columnspan=2, padx=10, pady=10)

        self.update_order_button = tk.Button(self.order_tab, text="Update Order", font=("Helvetica", 12), command=self.update_order)
        self.update_order_button.grid(row=6, columnspan=2, padx=10, pady=10)

        self.delete_order_button = tk.Button(self.order_tab, text="Delete Order", font=("Helvetica", 12), command=self.delete_order)
        self.delete_order_button.grid(row=7, columnspan=2, padx=10, pady=10)

    def add_product(self):
        name = self.product_name.get()
        description = self.product_description.get()
        price = float(self.product_price.get())
        stock_quantity = int(self.product_stock_quantity.get())
        product = self.system.add_product(name, description, price, stock_quantity)
        messagebox.showinfo("Product Added", f"Product added: {product}")
        self.clear_product_fields()

    def update_product(self):
        product_id = int(self.product_id.get())
        name = self.product_name.get()
        description = self.product_description.get()
        price = float(self.product_price.get())
        stock_quantity = int(self.product_stock_quantity.get())
        product = self.system.update_product(product_id, name, description, price, stock_quantity)
        if product:
            messagebox.showinfo("Product Updated", f"Product updated: {product}")
            self.clear_product_fields()
        else:
            messagebox.showerror("Error", "Product not found")

    def delete_product(self):
        product_id = int(self.product_id.get())
        if self.system.delete_product(product_id):
            messagebox.showinfo("Product Deleted", f"Product with ID {product_id} deleted")
            self.clear_product_fields()
        else:
            messagebox.showerror("Error", "Product not found")

    def add_customer(self):
        name = self.customer_name.get()
        email = self.customer_email.get()
        address = self.customer_address.get()
        customer = self.system.add_customer(name, email, address)
        messagebox.showinfo("Customer Added", f"Customer added: {customer}")
        self.clear_customer_fields()

    def update_customer(self):
        customer_id = int(self.customer_id.get())
        name = self.customer_name.get()
        email = self.customer_email.get()
        address = self.customer_address.get()
        customer = self.system.update_customer(customer_id, name, email, address)
        if customer:
            messagebox.showinfo("Customer Updated", f"Customer updated: {customer}")
            self.clear_customer_fields()
        else:
            messagebox.showerror("Error", "Customer not found")

    def delete_customer(self):
        customer_id = int(self.customer_id.get())
        if self.system.delete_customer(customer_id):
            messagebox.showinfo("Customer Deleted", f"Customer with ID {customer_id} deleted")
            self.clear_customer_fields()
        else:
            messagebox.showerror("Error", "Customer not found")

    def place_order(self):
        customer_id = int(self.order_customer_id.get())
        product_id = int(self.order_product_id.get())
        quantity = int(self.order_quantity.get())
        order, error = self.system.place_order(customer_id, product_id, quantity)
        if order:
            messagebox.showinfo("Order Placed", f"Order placed: {order}")
            self.clear_order_fields()
        else:
            messagebox.showerror("Error", error)

    def update_order(self):
        order_id = int(self.order_id.get())
        customer_id = int(self.order_customer_id.get())
        product_id = int(self.order_product_id.get())
        quantity = int(self.order_quantity.get())
        order, error = self.system.update_order(order_id, customer_id, product_id, quantity)
        if order:
            messagebox.showinfo("Order Updated", f"Order updated: {order}")
            self.clear_order_fields()
        else:
            messagebox.showerror("Error", error)

    def delete_order(self):
        order_id = int(self.order_id.get())
        if self.system.delete_order(order_id):
            messagebox.showinfo("Order Deleted", f"Order with ID {order_id} deleted")
            self.clear_order_fields()
        else:
            messagebox.showerror("Error", "Order not found")

    def clear_product_fields(self):
        self.product_name.delete(0, tk.END)
        self.product_description.delete(0, tk.END)
        self.product_price.delete(0, tk.END)
        self.product_stock_quantity.delete(0, tk.END)
        self.product_id.delete(0, tk.END)

    def clear_customer_fields(self):
        self.customer_name.delete(0, tk.END)
        self.customer_email.delete(0, tk.END)
        self.customer_address.delete(0, tk.END)
        self.customer_id.delete(0, tk.END)

    def clear_order_fields(self):
        self.order_customer_id.delete(0, tk.END)
        self.order_product_id.delete(0, tk.END)
        self.order_quantity.delete(0, tk.END)
        self.order_id.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = ECommerceApp(root)
    root.mainloop()