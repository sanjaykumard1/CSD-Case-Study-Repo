CREATE TABLE Products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INT NOT NULL
);

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    product_id INT,
    order_date DATE NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

1.Find the total sales revenue generated in a specific month:
SELECT SUM(o.quantity * p.price) AS total_revenue
FROM Orders o
JOIN Products p ON o.product_id = p.product_id
WHERE DATE_FORMAT(o.order_date, '%Y-%m') = '2024-14';

2.Find the customers who have placed more than five orders:

SELECT c.customer_id, c.name, c.email, c.address, COUNT(o.order_id) AS order_count
FROM Customers c
JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name, c.email, c.address
HAVING COUNT(o.order_id) > 5;

3.Find the products that need restocking (stock_quantity < 10):
SELECT product_id, name, stock_quantity
FROM Products
WHERE stock_quantity < 10;

4.Find the most popular products (most ordered):
SELECT p.product_id, p.name, SUM(o.quantity) AS total_ordered
FROM Orders o
JOIN Products p ON o.product_id = p.product_id
GROUP BY p.product_id, p.name
ORDER BY total_ordered DESC
LIMIT 5;

5.Find the details of orders placed by a specific customer:
SELECT o.order_id, o.customer_id, o.product_id, o.order_date, o.quantity, p.name AS product_name, p.price AS product_price
FROM Orders o
JOIN Products p ON o.product_id = p.product_id
WHERE o.customer_id = 1;









