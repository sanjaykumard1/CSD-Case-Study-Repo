class CustomerManager:
    def __init__(self, connection):
        self.connection = connection

    def add_customer(self, customer_id, name, contact_info, loyalty_points=0):
        cursor = self.connection.cursor()
        query = "INSERT INTO Customers (customer_id, name, contact_info, loyalty_points) VALUES (%s, %s, %s, %s)"
        cursor.execute(query, (customer_id, name, contact_info, loyalty_points))
        self.connection.commit()

    def update_customer(self, customer_id, name=None, contact_info=None, loyalty_points=None):
        cursor = self.connection.cursor()
        updates = []
        params = []
        if name:
            updates.append("name = %s")
            params.append(name)
        if contact_info:
            updates.append("contact_info = %s")
            params.append(contact_info)
        if loyalty_points is not None:
            updates.append("loyalty_points = %s")
            params.append(loyalty_points)
        params.append(customer_id)
        query = f"UPDATE Customers SET {', '.join(updates)} WHERE customer_id = %s"
        cursor.execute(query, tuple(params))
        self.connection.commit()

    def delete_customer(self, customer_id):
        cursor = self.connection.cursor()
        query = "DELETE FROM Customers WHERE customer_id = %s"
        cursor.execute(query, (customer_id,))
        self.connection.commit()

    def get_top_customers(self, min_loyalty_points=100):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Customers WHERE loyalty_points > %s"
        cursor.execute(query, (min_loyalty_points,))
        return cursor.fetchall()
