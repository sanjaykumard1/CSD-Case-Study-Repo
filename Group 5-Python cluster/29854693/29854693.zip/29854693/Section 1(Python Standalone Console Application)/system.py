from customer import CustomerManager
from transaction import TransactionManager

class RetailSalesManagementSystem:
    def __init__(self, connection):
        self.customer_manager = CustomerManager(connection)
        self.transaction_manager = TransactionManager(connection)

    def add_customer(self, customer_id, name, contact_info, loyalty_points=0):
        self.customer_manager.add_customer(customer_id, name, contact_info, loyalty_points)

    def update_customer(self, customer_id, name=None, contact_info=None, loyalty_points=None):
        self.customer_manager.update_customer(customer_id, name, contact_info, loyalty_points)

    def delete_customer(self, customer_id):
        self.customer_manager.delete_customer(customer_id)

    def record_transaction(self, transaction_id, customer_id, product_name, quantity_sold, sale_amount):
        self.transaction_manager.add_transaction(transaction_id, customer_id, product_name, quantity_sold, sale_amount)

    def get_top_customers(self, min_loyalty_points=100):
        return self.customer_manager.get_top_customers(min_loyalty_points)
