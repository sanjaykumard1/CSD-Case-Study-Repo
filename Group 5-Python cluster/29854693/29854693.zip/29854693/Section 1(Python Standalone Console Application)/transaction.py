class TransactionManager:
    def __init__(self, connection):
        self.connection = connection

    def add_transaction(self, transaction_id, customer_id, product_name, quantity_sold, sale_amount):
        cursor = self.connection.cursor()
        query = "INSERT INTO Transactions (transaction_id, customer_id, product_name, quantity_sold, sale_amount, transaction_date) VALUES (%s, %s, %s, %s, %s, CURDATE())"
        cursor.execute(query, (transaction_id, customer_id, product_name, quantity_sold, sale_amount))
        self.connection.commit()

    def get_transactions_by_customer(self, customer_id):
        cursor = self.connection.cursor()
        query = "SELECT * FROM Transactions WHERE customer_id = %s"
        cursor.execute(query, (customer_id,))
        return cursor.fetchall()
