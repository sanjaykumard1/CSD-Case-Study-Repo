from db_connection import create_connection
from system import RetailSalesManagementSystem

def main():
    connection = create_connection()
    if connection is None:
        print("Failed to create database connection. Exiting...")
        return  # Exit if connection is not established
    

    system = RetailSalesManagementSystem(connection)

    while True:
        print("\nRetail Sales Management System")
        print("1. Add Customer")
        print("2. Update Customer")
        print("3. Delete Customer")
        print("4. Record Transaction")
        print("5. View Top Customers")
        print("6. Exit")

        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                customer_id = int(input("Enter Customer ID: "))
                name = input("Enter Customer Name: ")
                contact_info = input("Enter Contact Info: ")
                loyalty_points = int(input("Enter Loyalty Points: "))
                system.add_customer(customer_id, name, contact_info, loyalty_points)
                print("Customer added successfully.")

            elif choice == '2':
                customer_id = int(input("Enter Customer ID: "))
                name = input("Enter Customer Name (leave blank to keep unchanged): ")
                contact_info = input("Enter Contact Info (leave blank to keep unchanged): ")
                loyalty_points = input("Enter Loyalty Points (leave blank to keep unchanged): ")
                loyalty_points = int(loyalty_points) if loyalty_points else None
                system.update_customer(customer_id, name or None, contact_info or None, loyalty_points)
                print("Customer updated successfully.")

            elif choice == '3':
                customer_id = int(input("Enter Customer ID: "))
                system.delete_customer(customer_id)
                print("Customer deleted successfully.")

            elif choice == '4':
                transaction_id = int(input("Enter Transaction ID: "))
                customer_id = int(input("Enter Customer ID: "))
                product_name = input("Enter Product Name: ")
                quantity_sold = int(input("Enter Quantity Sold: "))
                sale_amount = float(input("Enter Sale Amount: "))
                system.record_transaction(transaction_id, customer_id, product_name, quantity_sold, sale_amount)
                print("Transaction recorded successfully.")

            elif choice == '5':
                top_customers = system.get_top_customers()
                if top_customers:
                    for customer in top_customers:
                        print(customer)
                else:
                    print("No top customers found.")

            elif choice == '6':
                break

            else:
                print("Invalid choice. Please try again.")

        except ValueError as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
