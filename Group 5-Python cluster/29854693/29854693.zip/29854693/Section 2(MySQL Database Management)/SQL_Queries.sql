1: Total Sales Amount for Each Customer

QUERY:
SELECT customer_id, SUM(sale_amount) AS total_sales
FROM Transactions
GROUP BY customer_id;

2: Names of Customers and Their Total Sales Amounts

QUERY:
SELECT Customers.name, SUM(Transactions.sale_amount) AS total_sales
FROM Customers
JOIN Transactions ON Customers.customer_id = Transactions.customer_id
GROUP BY Customers.name;


3: Names of Customers Who Have Never Made a Purchase

QUERY:
SELECT name
FROM Customers
WHERE customer_id NOT IN (SELECT DISTINCT customer_id FROM Transactions);


4: Products Sold More Than 50 Times

QUERY:
SELECT product_name
FROM Transactions
GROUP BY product_name
HAVING SUM(quantity_sold) > 50;


5: Customer Names and Their Loyalty Points for Those Who Have Made More Than 10 Transactions

QUERY:
SELECT Customers.name, Customers.loyalty_points
FROM Customers
JOIN (
    SELECT customer_id, COUNT(*) AS transaction_count
    FROM Transactions
    GROUP BY customer_id
    HAVING COUNT(*) > 10
) AS TransactionCounts ON Customers.customer_id = TransactionCounts.customer_id;