CREATE DATABASE retail_sales_management;

USE retail_sales_management;

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    contact_info VARCHAR(100),
    loyalty_points INT
);

CREATE TABLE Transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT,
    product_name VARCHAR(100),
    quantity_sold INT,
    sale_amount DECIMAL(10, 2),
    transaction_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
