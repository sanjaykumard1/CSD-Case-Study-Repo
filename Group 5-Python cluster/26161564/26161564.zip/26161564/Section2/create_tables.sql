#create_tables.sql

CREATE DATABASE IF NOT EXISTS school_management;

USE school_management;

CREATE TABLE IF NOT EXISTS Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(255),
    date_of_birth DATE,
    grade_level INT
);

CREATE TABLE IF NOT EXISTS Teachers (
    teacher_id INT PRIMARY KEY,
    name VARCHAR(255),
    contact_number VARCHAR(15),
    subject_taught VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Courses (
    course_id INT PRIMARY KEY,
    name VARCHAR(255),
    teacher_id INT,
    maximum_students INT,
    FOREIGN KEY (teacher_id) REFERENCES Teachers(teacher_id)
);

CREATE TABLE IF NOT EXISTS Grades (
    grade_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    grade VARCHAR(2),
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);


#Insert_data.sql

USE school_management;

INSERT INTO Students (student_id, name, date_of_birth, grade_level) VALUES
(1, 'Alice', '2005-05-15', 10),
(2, 'Bob', '2006-06-20', 9),
(3, 'Charlie', '2005-07-25', 10);

INSERT INTO Teachers (teacher_id, name, contact_number, subject_taught) VALUES
(1, 'Mr. Smith', '1234567890', 'Mathematics'),
(2, 'Ms. Johnson', '0987654321', 'Science');

INSERT INTO Courses (course_id, name, teacher_id, maximum_students) VALUES
(1, 'Math 101', 1, 30),
(2, 'Science 101', 2, 30);

INSERT INTO Grades (student_id, course_id, grade) VALUES
(1, 1, 'A'),
(2, 1, 'B'),
(3, 2, 'C');
