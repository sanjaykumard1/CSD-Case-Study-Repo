1. Find the students who have the highest grade in a specific course:

Query:
SELECT student_id, grade 
FROM Grades 
WHERE course_id = 1 AND grade = (SELECT MAX(grade) FROM Grades WHERE course_id = 1);

2. Find the teachers who are teaching the maximum number of courses:

Query:
SELECT teacher_id, COUNT(course_id) as course_count 
FROM Courses 
GROUP BY teacher_id 
ORDER BY course_count DESC;

3. Find the courses that have not reached the maximum number of students:

Query:
SELECT course_id, name 
FROM Courses 
WHERE (SELECT COUNT(*) FROM Grades WHERE course_id = Courses.course_id) < maximum_students;


4. Find the average grade for each course:

Query:
SELECT course_id, AVG(grade) as average_grade 
FROM Grades 
GROUP BY course_id;


5. Find the students who have failed a course:

Query:
SELECT student_id 
FROM Grades 
WHERE grade = 'F';