if not system.student_manager.connection:
        print("Database connection failed. Exiting...")
        return
