from db_connection import create_connection

class CourseManager:
    def __init__(self):
        self.connection = create_connection()

    def add_course(self, course_id, name, teacher_id, maximum_students):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Courses (course_id, name, teacher_id, maximum_students) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (course_id, name, teacher_id, maximum_students))
            self.connection.commit()
            print("Course added successfully")
        except Exception as e:
            print(f"Failed to add course: {e}")

    def update_course(self, course_id, name, teacher_id, maximum_students):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Courses SET name = %s, teacher_id = %s, maximum_students = %s WHERE course_id = %s"
            cursor.execute(query, (name, teacher_id, maximum_students, course_id))
            self.connection.commit()
            print("Course updated successfully")
        except Exception as e:
            print(f"Failed to update course: {e}")

    def delete_course(self, course_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Courses WHERE course_id = %s"
            cursor.execute(query, (course_id,))
            self.connection.commit()
            print("Course deleted successfully")
        except Exception as e:
            print(f"Failed to delete course: {e}")
