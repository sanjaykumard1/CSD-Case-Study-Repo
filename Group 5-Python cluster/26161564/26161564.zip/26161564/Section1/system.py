from student import StudentManager
from teacher import TeacherManager
from course import CourseManager
from grade import GradeManager

class SchoolManagementSystem:
    def __init__(self):
        self.student_manager = StudentManager()
        self.teacher_manager = TeacherManager()
        self.course_manager = CourseManager()
        self.grade_manager = GradeManager()

    def display_menu(self):
        print("\nSchool Management System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Add Teacher")
        print("5. Update Teacher")
        print("6. Delete Teacher")
        print("7. Add Course")
        print("8. Update Course")
        print("9. Delete Course")
        print("10. Assign Grade")
        print("11. View Top Students in Course")
        print("12. Exit")

    def run(self):
        while True:
            self.display_menu()
            choice = input("Enter your choice: ")

            if choice == '1':
                student_id = input("Enter Student ID: ")
                name = input("Enter Student Name: ")
                date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
                grade_level = input("Enter Grade Level: ")
                self.student_manager.add_student(student_id, name, date_of_birth, grade_level)

            elif choice == '2':
                student_id = input("Enter Student ID: ")
                name = input("Enter Student Name: ")
                date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
                grade_level = input("Enter Grade Level: ")
                self.student_manager.update_student(student_id, name, date_of_birth, grade_level)

            elif choice == '3':
                student_id = input("Enter Student ID: ")
                self.student_manager.delete_student(student_id)

            elif choice == '4':
                teacher_id = input("Enter Teacher ID: ")
                name = input("Enter Teacher Name: ")
                contact_number = input("Enter Contact Number: ")
                subject_taught = input("Enter Subject Taught: ")
                self.teacher_manager.add_teacher(teacher_id, name, contact_number, subject_taught)

            elif choice == '5':
                teacher_id = input("Enter Teacher ID: ")
                name = input("Enter Teacher Name: ")
                contact_number = input("Enter Contact Number: ")
                subject_taught = input("Enter Subject Taught: ")
                self.teacher_manager.update_teacher(teacher_id, name, contact_number, subject_taught)

            elif choice == '6':
                teacher_id = input("Enter Teacher ID: ")
                self.teacher_manager.delete_teacher(teacher_id)

            elif choice == '7':
                course_id = input("Enter Course ID: ")
                name = input("Enter Course Name: ")
                teacher_id = input("Enter Teacher ID: ")
                maximum_students = input("Enter Maximum Students: ")
                self.course_manager.add_course(course_id, name, teacher_id, maximum_students)

            elif choice == '8':
                course_id = input("Enter Course ID: ")
                name = input("Enter Course Name: ")
               
