from db_connection import create_connection

class TeacherManager:
    def __init__(self):
        self.connection = create_connection()

    def add_teacher(self, teacher_id, name, contact_number, subject_taught):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Teachers (teacher_id, name, contact_number, subject_taught) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (teacher_id, name, contact_number, subject_taught))
            self.connection.commit()
            print("Teacher added successfully")
        except Exception as e:
            print(f"Failed to add teacher: {e}")

    def update_teacher(self, teacher_id, name, contact_number, subject_taught):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Teachers SET name = %s, contact_number = %s, subject_taught = %s WHERE teacher_id = %s"
            cursor.execute(query, (name, contact_number, subject_taught, teacher_id))
            self.connection.commit()
            print("Teacher updated successfully")
        except Exception as e:
            print(f"Failed to update teacher: {e}")

    def delete_teacher(self, teacher_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Teachers WHERE teacher_id = %s"
            cursor.execute(query, (teacher_id,))
            self.connection.commit()
            print("Teacher deleted successfully")
        except Exception as e:
            print(f"Failed to delete teacher: {e}")
