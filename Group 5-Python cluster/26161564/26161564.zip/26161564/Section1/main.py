from system import SchoolManagementSystem

def main():
    system = SchoolManagementSystem()

    while True:
        system.display_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            student_id = input("Enter Student ID: ")
            name = input("Enter Student Name: ")
            date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
            grade_level = input("Enter Grade Level: ")
            system.student_manager.add_student(student_id, name, date_of_birth, grade_level)

        elif choice == '2':
            student_id = input("Enter Student ID: ")
            name = input("Enter Student Name: ")
            date_of_birth = input("Enter Date of Birth (YYYY-MM-DD): ")
            grade_level = input("Enter Grade Level: ")
            system.student_manager.update_student(student_id, name, date_of_birth, grade_level)

        elif choice == '3':
            student_id = input("Enter Student ID: ")
            system.student_manager.delete_student(student_id)

        elif choice == '4':
            teacher_id = input("Enter Teacher ID: ")
            name = input("Enter Teacher Name: ")
            contact_number = input("Enter Contact Number: ")
            subject_taught = input("Enter Subject Taught: ")
            system.teacher_manager.add_teacher(teacher_id, name, contact_number, subject_taught)

        elif choice == '5':
            teacher_id = input("Enter Teacher ID: ")
            name = input("Enter Teacher Name: ")
            contact_number = input("Enter Contact Number: ")
            subject_taught = input("Enter Subject Taught: ")
            system.teacher_manager.update_teacher(teacher_id, name, contact_number, subject_taught)

        elif choice == '6':
            teacher_id = input("Enter Teacher ID: ")
            system.teacher_manager.delete_teacher(teacher_id)

        elif choice == '7':
            course_id = input("Enter Course ID: ")
            name = input("Enter Course Name: ")
            teacher_id = input("Enter Teacher ID: ")
            maximum_students = input("Enter Maximum Students: ")
            system.course_manager.add_course(course_id, name, teacher_id, maximum_students)

        elif choice == '8':
            course_id = input("Enter Course ID: ")
            name = input("Enter Course Name: ")
            teacher_id = input("Enter Teacher ID: ")
            maximum_students = input("Enter Maximum Students: ")
            system.course_manager.update_course(course_id, name, teacher_id, maximum_students)

        elif choice == '9':
            course_id = input("Enter Course ID: ")
            system.course_manager.delete_course(course_id)

        elif choice == '10':
            student_id = input("Enter Student ID: ")
            course_id = input("Enter Course ID: ")
            grade = input("Enter Grade: ")
            system.grade_manager.assign_grade(student_id, course_id, grade)

        elif choice == '11':
            course_id = input("Enter Course ID: ")
            top_students = system.student_manager.get_top_students_in_course(course_id)
            print("Top Students:")
            for student in top_students:
                print(f"ID: {student[0]}, Name: {student[1]}, Grade: {student[2]}")

        elif choice == '12':
            print("Exiting the system. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
