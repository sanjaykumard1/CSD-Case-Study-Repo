from db_connection import create_connection

class StudentManager:
    def __init__(self):
        self.connection = create_connection()

    def add_student(self, student_id, name, date_of_birth, grade_level):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Students (student_id, name, date_of_birth, grade_level) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (student_id, name, date_of_birth, grade_level))
            self.connection.commit()
            print("Student added successfully")
        except Exception as e:
            print(f"Failed to add student: {e}")

    def update_student(self, student_id, name, date_of_birth, grade_level):
        try:
            cursor = self.connection.cursor()
            query = "UPDATE Students SET name = %s, date_of_birth = %s, grade_level = %s WHERE student_id = %s"
            cursor.execute(query, (name, date_of_birth, grade_level, student_id))
            self.connection.commit()
            print("Student updated successfully")
        except Exception as e:
            print(f"Failed to update student: {e}")

    def delete_student(self, student_id):
        try:
            cursor = self.connection.cursor()
            query = "DELETE FROM Students WHERE student_id = %s"
            cursor.execute(query, (student_id,))
            self.connection.commit()
            print("Student deleted successfully")
        except Exception as e:
            print(f"Failed to delete student: {e}")

    def get_top_students_in_course(self, course_id):
        try:
            cursor = self.connection.cursor()
            query = """
            SELECT s.student_id, s.name, g.grade
            FROM Students s
            JOIN Grades g ON s.student_id = g.student_id
            WHERE g.course_id = %s
            ORDER BY g.grade DESC
            """
            cursor.execute(query, (course_id,))
            return cursor.fetchall()
        except Exception as e:
            print(f"Failed to get top students: {e}")
            return []
