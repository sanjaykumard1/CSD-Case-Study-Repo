from db_connection import create_connection

class GradeManager:
    def __init__(self):
        self.connection = create_connection()

    def assign_grade(self, student_id, course_id, grade):
        try:
            cursor = self.connection.cursor()
            query = "INSERT INTO Grades (student_id, course_id, grade) VALUES (%s, %s, %s)"
            cursor.execute(query, (student_id, course_id, grade))
            self.connection.commit()
            print("Grade assigned successfully")
        except Exception as e:
            print(f"Failed to assign grade: {e}")
