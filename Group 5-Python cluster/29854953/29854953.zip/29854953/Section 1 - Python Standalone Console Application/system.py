from models import Product, Customer, Order
import datetime

class OnlineShoppingSystem:
    def __init__(self):
        self.products = {}
        self.customers = {}
        self.orders = {}
        self.next_product_id = 1
        self.next_customer_id = 1
        self.next_order_id = 1

    # Product Management
    def add_product(self, name, category, price, stock_quantity):
        product = Product(self.next_product_id, name, category, price, stock_quantity)
        self.products[self.next_product_id] = product
        self.next_product_id += 1
        print("Product added successfully.")

    def update_product(self, product_id, name=None, category=None, price=None, stock_quantity=None):
        if product_id in self.products:
            product = self.products[product_id]
            if name:
                product.name = name
            if category:
                product.category = category
            if price:
                product.price = price
            if stock_quantity:
                product.stock_quantity = stock_quantity
            print("Product updated successfully.")
        else:
            print("Product not found.")

    def delete_product(self, product_id):
        if product_id in self.products:
            del self.products[product_id]
            print("Product deleted successfully.")
        else:
            print("Product not found.")

    # Customer Management
    def add_customer(self, name, email, address):
        customer = Customer(self.next_customer_id, name, email, address)
        self.customers[self.next_customer_id] = customer
        self.next_customer_id += 1
        print("Customer added successfully.")

    def update_customer(self, customer_id, name=None, email=None, address=None):
        if customer_id in self.customers:
            customer = self.customers[customer_id]
            if name:
                customer.name = name
            if email:
                customer.email = email
            if address:
                customer.address = address
            print("Customer updated successfully.")
        else:
            print("Customer not found.")

    def delete_customer(self, customer_id):
        if customer_id in self.customers:
            del self.customers[customer_id]
            print("Customer deleted successfully.")
        else:
            print("Customer not found.")

    # Order Management
    def add_order(self, customer_id, product_id, quantity):
        if customer_id not in self.customers:
            print("Customer not found.")
            return
        if product_id not in self.products:
            print("Product not found.")
            return
        if self.products[product_id].stock_quantity < quantity:
            print("Not enough stock.")
            return
        order_date = datetime.datetime.now()
        order = Order(self.next_order_id, customer_id, product_id, order_date, quantity)
        self.orders[self.next_order_id] = order
        self.products[product_id].stock_quantity -= quantity
        self.next_order_id += 1
        print("Order added successfully.")

    def update_order(self, order_id, quantity):
        if order_id in self.orders:
            order = self.orders[order_id]
            product_id = order.product_id
            if self.products[product_id].stock_quantity + order.quantity < quantity:
                print("Not enough stock.")
                return
            self.products[product_id].stock_quantity += order.quantity - quantity
            order.quantity = quantity
            print("Order updated successfully.")
        else:
            print("Order not found.")

    def cancel_order(self, order_id):
        if order_id in self.orders:
            order = self.orders[order_id]
            self.products[order.product_id].stock_quantity += order.quantity
            del self.orders[order_id]
            print("Order cancelled successfully.")
        else:
            print("Order not found.")

    # Display functions
    def display_products(self):
        print("Products:")
        for product in self.products.values():
            print(product)

    def display_customers(self):
        print("Customers:")
        for customer in self.customers.values():
            print(customer)

    def display_orders(self):
        print("Orders:")
        for order in self.orders.values():
            print(order)