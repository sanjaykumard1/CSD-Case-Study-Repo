class Product:
    def __init__(self, product_id, name, category, price, stock_quantity):
        self.product_id = product_id
        self.name = name
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity

    def __str__(self):
        return f"{self.product_id}: {self.name} ({self.category}) - Rs.{self.price}, Stock: {self.stock_quantity}"

class Customer:
    def __init__(self, customer_id, name, email, address):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.address = address

    def __str__(self):
        return f"{self.customer_id}: {self.name}, Email: {self.email}, Address: {self.address}"

class Order:
    def __init__(self, order_id, customer_id, product_id, order_date, quantity):
        self.order_id = order_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.order_date = order_date
        self.quantity = quantity

    def __str__(self):
        return f"Order {self.order_id}: Customer {self.customer_id}, Product {self.product_id}, Date: {self.order_date}, Quantity: {self.quantity}"
