from system import OnlineShoppingSystem

def main():
    system = OnlineShoppingSystem()

    while True:
        print("\nOnline Shopping System")
        print("1. Add Product")
        print("2. Update Product")
        print("3. Delete Product")
        print("4. Display Products")
        print("5. Add Customer")
        print("6. Update Customer")
        print("7. Delete Customer")
        print("8. Display Customers")
        print("9. Add Order")
        print("10. Update Order")
        print("11. Cancel Order")
        print("12. Display Orders")
        print("0. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                name = input("Enter product name: ")
                category = input("Enter product category: ")
                price = float(input("Enter product price: "))
                stock_quantity = int(input("Enter product stock quantity: "))
                system.add_product(name, category, price, stock_quantity)
            elif choice == '2':
                product_id = int(input("Enter product ID: "))
                name = input("Enter new product name (leave blank to skip): ")
                category = input("Enter new product category (leave blank to skip): ")
                price = input("Enter new product price (leave blank to skip): ")
                stock_quantity = input("Enter new product stock quantity (leave blank to skip): ")
                system.update_product(product_id, name if name else None, category if category else None, float(price) if price else None, int(stock_quantity) if stock_quantity else None)
            elif choice == '3':
                product_id = int(input("Enter product ID: "))
                system.delete_product(product_id)
            elif choice == '4':
                system.display_products()
            elif choice == '5':
                name = input("Enter customer name: ")
                email = input("Enter customer email: ")
                address = input("Enter customer address: ")
                system.add_customer(name, email, address)
            elif choice == '6':
                customer_id = int(input("Enter customer ID: "))
                name = input("Enter new customer name (leave blank to skip): ")
                email = input("Enter new customer email (leave blank to skip): ")
                address = input("Enter new customer address (leave blank to skip): ")
                system.update_customer(customer_id, name if name else None, email if email else None, address if address else None)
            elif choice == '7':
                customer_id = int(input("Enter customer ID: "))
                system.delete_customer(customer_id)
            elif choice == '8':
                system.display_customers()
            elif choice == '9':
                customer_id = int(input("Enter customer ID: "))
                product_id = int(input("Enter product ID: "))
                quantity = int(input("Enter quantity: "))
                system.add_order(customer_id, product_id, quantity)
            elif choice == '10':
                order_id = int(input("Enter order ID: "))
                quantity = int(input("Enter new quantity: "))
                system.update_order(order_id, quantity)
            elif choice == '11':
                order_id = int(input("Enter order ID: "))
                system.cancel_order(order_id)
            elif choice == '12':
                system.display_orders()
            elif choice == '0':
                break
            else:
                print("Invalid choice. Please try again.")
        except ValueError:
            print("Invalid input. Please enter the correct data type.")
        except Exception as e:
            print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
