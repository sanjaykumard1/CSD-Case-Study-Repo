-- Query to find the total number of students enrolled in each course
SELECT course_id, COUNT(student_id) AS total_students
FROM enrollments
GROUP BY course_id;

-- Query to find the names and emails of students who are enrolled in more than three courses
SELECT s.name, s.email
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
GROUP BY s.student_id
HAVING COUNT(e.course_id) > 3;

-- Query to find the courses that have not reached their maximum student capacity
SELECT c.course_id, c.course_name
FROM courses c
LEFT JOIN enrollments e ON c.course_id = e.course_id
GROUP BY c.course_id, c.course_name, c.max_students
HAVING COUNT(e.student_id) < c.max_students;

-- Query to find the students who are enrolled in courses taught by a specific instructor
SELECT s.name, s.email
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN courses c ON e.course_id = c.course_id
WHERE c.instructor = 'Specific Instructor';

-- Query to find the details of enrollments made in the last semester
SELECT * 
FROM enrollments 
WHERE enrollment_date >= '2024-01-01' AND enrollment_date <= '2024-06-30';
