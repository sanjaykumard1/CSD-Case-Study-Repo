import mysql.connector


class Student:
    def __init__(self, student_id, name, age, email, major):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.email = email
        self.major = major

    def add_student(self, cursor, db):
        query = "INSERT INTO students (student_id, name, age, email, major) VALUES (%s, %s, %s, %s, %s)"
        values = (self.student_id, self.name, self.age, self.email, self.major)
        cursor.execute(query, values)
        db.commit()
        print("Student added successfully.")

    def update_student(self, cursor, db):
        query = "UPDATE students SET name=%s, age=%s, email=%s, major=%s WHERE student_id=%s"
        values = (self.name, self.age, self.email, self.major, self.student_id)
        cursor.execute(query, values)
        db.commit()
        print("Student updated successfully.")

    def delete_student(self, cursor, db):
        query = "DELETE FROM students WHERE student_id=%s"
        values = (self.student_id,)
        cursor.execute(query, values)
        db.commit()
        print("Student deleted successfully.")
    
   
