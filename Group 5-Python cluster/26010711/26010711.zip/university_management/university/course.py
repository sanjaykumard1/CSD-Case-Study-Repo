import mysql.connector

class Course:
    def __init__(self, course_id, course_name, instructor, credits, max_students):
        self.course_id = course_id
        self.course_name = course_name
        self.instructor = instructor
        self.credits = credits
        self.max_students = max_students

    def add_course(self, cursor, db):
        query = "INSERT INTO courses (course_id, course_name, instructor, credits, max_students) VALUES (%s, %s, %s, %s, %s)"
        values = (self.course_id, self.course_name, self.instructor, self.credits, self.max_students)
        cursor.execute(query, values)
        db.commit()
        print("Course added successfully.")

    def update_course(self, cursor, db):
        query = "UPDATE courses SET course_name=%s, instructor=%s, credits=%s, max_students=%s WHERE course_id=%s"
        values = (self.course_name, self.instructor, self.credits, self.max_students, self.course_id)
        cursor.execute(query, values)
        db.commit()
        print("Course updated successfully.")

    def delete_course(self, cursor, db):
        query = "DELETE FROM courses WHERE course_id=%s"
        values = (self.course_id,)
        cursor.execute(query, values)
        db.commit()
        print("Course deleted successfully.")
