import mysql.connector
from datetime import date

class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date

    def add_enrollment(self, cursor, db):
        query = "INSERT INTO enrollments (enrollment_id, student_id, course_id, enrollment_date) VALUES (%s, %s, %s, %s)"
        values = (self.enrollment_id, self.student_id, self.course_id, self.enrollment_date)
        cursor.execute(query, values)
        db.commit()
        print("Enrollment added successfully.")

    def update_enrollment(self, cursor, db):
        query = "UPDATE enrollments SET student_id=%s, course_id=%s, enrollment_date=%s WHERE enrollment_id=%s"
        values = (self.student_id, self.course_id, self.enrollment_date, self.enrollment_id)
        cursor.execute(query, values)
        db.commit()
        print("Enrollment updated successfully.")

    def delete_enrollment(self, cursor, db):
        query = "DELETE FROM enrollments WHERE enrollment_id=%s"
        values = (self.enrollment_id,)
        cursor.execute(query, values)
        db.commit()
        print("Enrollment deleted successfully.")
