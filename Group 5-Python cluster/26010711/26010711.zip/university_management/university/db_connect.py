
import mysql.connector

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="gaya@1909",
    database="university_management"
)
cursor = db.cursor()