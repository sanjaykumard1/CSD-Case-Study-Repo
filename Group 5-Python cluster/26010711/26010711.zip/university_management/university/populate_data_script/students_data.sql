-- Clear existing data
DELETE FROM students;

-- Populating the students table

INSERT INTO students (student_id, name, age, email, major) VALUES
(1, 'Alice Johnson', 20, 'alice.johnson@example.com', 'Computer Science'),
(2, 'Bob Smith', 22, 'bob.smith@example.com', 'Electrical Engineering'),
(3, 'Charlie Brown', 21, 'charlie.brown@example.com', 'Mechanical Engineering'),
(4, 'David Williams', 23, 'david.williams@example.com', 'Civil Engineering'),
(5, 'Eve Davis', 20, 'eve.davis@example.com', 'Computer Science');