-- Clear existing data
DELETE FROM enrollments;


-- Populating the enrollments table
INSERT INTO enrollments (enrollment_id, student_id, course_id, enrollment_date) VALUES
(1, 1, 1, '2024-01-15'),
(2, 2, 2, '2024-01-16'),
(3, 3, 3, '2024-01-17'),
(4, 4, 4, '2024-01-18'),
(5, 5, 5, '2024-01-19'),
(6, 1, 2, '2024-01-20'),
(7, 2, 3, '2024-01-21'),
(8, 3, 4, '2024-01-22'),
(9, 4, 5, '2024-01-23'),
(10, 5, 1, '2024-01-24');