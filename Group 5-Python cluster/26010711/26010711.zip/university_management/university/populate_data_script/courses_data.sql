-- Clear existing data
DELETE FROM courses;
-- Populating the courses table
INSERT INTO courses (course_id, course_name, instructor, credits, max_students) VALUES
(1, 'Introduction to Computer Science', 'Dr. Alan Turing', 3, 30),
(2, 'Calculus I', 'Dr. Isaac Newton', 4, 40),
(3, 'Physics I', 'Dr. Albert Einstein', 4, 35),
(4, 'Circuit Analysis', 'Dr. Nikola Tesla', 3, 25),
(5, 'Mechanics', 'Dr. James Watt', 3, 30);