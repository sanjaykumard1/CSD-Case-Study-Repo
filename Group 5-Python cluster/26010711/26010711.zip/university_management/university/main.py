import mysql.connector
from student import Student
from course import Course
from enrollment import Enrollment
from db_connect import db, cursor


# Menu-driven interface
def main():
    while True:
        print("\nUniversity Management System")
        print("1. Add Student")
        print("2. Update Student")
        print("3. Delete Student")
        print("4. Add Course")
        print("5. Update Course")
        print("6. Delete Course")
        print("7. Add Enrollment")
        print("8. Update Enrollment")
        print("9. Delete Enrollment")
        print("10. Exit")

        choice = int(input("Enter your choice: "))

        if choice == 1:
            student_id = int(input("Enter Student ID: "))
            name = input("Enter Name: ")
            age = int(input("Enter Age: "))
            email = input("Enter Email: ")
            major = input("Enter Major: ")
            student = Student(student_id, name, age, email, major)
            student.add_student(cursor, db)

        elif choice == 2:
            student_id = int(input("Enter Student ID: "))
            name = input("Enter Name: ")
            age = int(input("Enter Age: "))
            email = input("Enter Email: ")
            major = input("Enter Major: ")
            student = Student(student_id, name, age, email, major)
            student.update_student(cursor, db)

        elif choice == 3:
            student_id = int(input("Enter Student ID: "))
            student = Student(student_id, None, None, None, None)
            student.delete_student(cursor, db)

        elif choice == 4:
            course_id = int(input("Enter Course ID: "))
            course_name = input("Enter Course Name: ")
            instructor = input("Enter Instructor: ")
            credits = int(input("Enter Credits: "))
            max_students = int(input("Enter Max Students: "))
            course = Course(course_id, course_name, instructor, credits, max_students)
            course.add_course(cursor, db)

        elif choice == 5:
            course_id = int(input("Enter Course ID: "))
            course_name = input("Enter Course Name: ")
            instructor = input("Enter Instructor: ")
            credits = int(input("Enter Credits: "))
            max_students = int(input("Enter Max Students: "))
            course = Course(course_id, course_name, instructor, credits, max_students)
            course.update_course(cursor, db)

        elif choice == 6:
            course_id = int(input("Enter Course ID: "))
            course = Course(course_id, None, None, None, None)
            course.delete_course(cursor, db)

        elif choice == 7:
            enrollment_id = int(input("Enter Enrollment ID: "))
            student_id = int(input("Enter Student ID: "))
            course_id = int(input("Enter Course ID: "))
            enrollment_date = input("Enter Enrollment Date (YYYY-MM-DD): ")
            enrollment = Enrollment(enrollment_id, student_id, course_id, enrollment_date)
            enrollment.add_enrollment(cursor, db)

        elif choice == 8:
            enrollment_id = int(input("Enter Enrollment ID: "))
            student_id = int(input("Enter Student ID: "))
            course_id = int(input("Enter Course ID: "))
            enrollment_date = input("Enter Enrollment Date (YYYY-MM-DD): ")
            enrollment = Enrollment(enrollment_id, student_id, course_id, enrollment_date)
            enrollment.update_enrollment(cursor, db)

        elif choice == 9:
            enrollment_id = int(input("Enter Enrollment ID: "))
            enrollment = Enrollment(enrollment_id, None, None, None)
            enrollment.delete_enrollment(cursor, db)

        elif choice == 10:
            cursor.close()
            db.close()
            break
       


        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
