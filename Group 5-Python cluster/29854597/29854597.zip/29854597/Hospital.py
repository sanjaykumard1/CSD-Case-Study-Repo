class Patient:
    def __init__(self,patient_id,name,age,gender,disease, doctor_id):
        self.patient_id = patient_id
        self.name = name
        self.age = age
        self.gender = gender
        self.disease = disease
        self.doctor_id = doctor_id
class Doctor:
    def __init__(self,doctor_id,name,specilization):
        self.doctor_id = doctor_id
        self.name = name
        self.specilization = specilization
class Managment:
    def __init__(self):
        self.patients = {}
        self.doctors = {}
    def add_patient(self):
        patient_id = int(input("Enter patient id : "))
        name = input("Enter patient name : ")
        age = int(input("Enter patient age : "))
        gender = input("Enter the patient gender : ")
        disease = input("Enter the patient disease : ")
        doctor_id = int(input("Enter doctor id or None : "))
        
        if patient_id in self.patients:
            print("Patient ID already exists.")
            return
        self.patients[patient_id] = Patient(patient_id, name, age, gender, disease, doctor_id)
        print(f"Patient {name} added.")
        
    def update_patient(self):
        patient_id = int(input("Enter patient ID to update: "))
        if patient_id not in self.patients:
            print("Patient ID does not exist.")
            return

        name = input("Enter new name or leave : ")
        age = input("Enter new age or leave : ")
        gender = input("Enter new gender or leave : ")
        disease = input("Enter new disease or leave : ")
        doctor_id = input("Enter new doctor ID or leave : ")

        patient = self.patients[patient_id]
        if name: 
            patient.name = name
        if age:
            patient.age = int(age)
        if gender:
            patient.gender = gender
        if disease: 
            patient.disease = disease
        if doctor_id: 
            patient.doctor_id = int(doctor_id) or None

        print(f"Patient {patient_id} updated.")

    
    def delete_patient(self):
        patient_id = int(input("Enter the patient id to delete :"))
        if patient_id not in self.patients:
            print("Patient id dose not match")
            return
        del self.patients[patient_id]
        print(f"Patient {patient_id} deleted ")
        
    def add_doctor(self):
        doctor_id = int(input("Enter the doctor id : "))
        name = input("Enter the name of the doctor :")
        specilization = input("Enter specilizaation :")
        if doctor_id in self.doctors:
            print("Doctor already exists")
            return
        self.doctors[doctor_id] = Doctor(doctor_id,name,specilization)
        print(f"Doctor {name} added")
        
    def assign_doctor_patient(self):
        patient_id = int(input("Entet patient id :"))
        doctor_id = int(input("Enter doctor id :"))
        if patient_id not in self.patients:
            print("Patient not exist")
            return
        if doctor_id not in self.doctors:
            print("Doctor dose not exis")
            return
        patient = self.patients[patient_id]
        patient.doctor_id = doctor_id
        print(f"Doctor {doctor_id} assigned to patient {patient_id}")
        
    def generate_patient_report_doctor(self):
        doctor_id = int(input("Enter doctor id : "))
        if doctor_id not in self.doctors:
            print("Doctor dose not exist")
            return
        
        doctor = self.doctors[doctor_id]
        print(f"Patients assigned to Dr.{doctor.name}")
        for patient_id,patient in self.patients.items():
            if patient.doctor_id == doctor_id:
                 print(f"{patient.name} ({patient.patient_id}) - {patient.disease}")
def main():
    Hos = Managment()

    while True:
        print("\nHospital Management System")
        print("1. Add Patient")
        print("2. Add Doctor")
        print("3. Update Patient")
        print("4. Delete patient")
        print("5. Assign Doctor to Patient")
        print("6. Generate Patient Report by Doctor")
        print("7. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            Hos.add_patient()
        elif choice == "2":
            Hos.add_doctor()
        elif choice == "3":
            Hos.update_patient()
        elif choice == "4":
            Hos.delete_patient()
        elif choice == "5":
            Hos.assign_doctor_patient()
        elif choice == "6":
            Hos.generate_patient_report_doctor()
        elif choice == "7":
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()

    
        
        