Create database Hosipital; /*Creating the Hospital database*/
show databases;
use Hosipital; /* Useing the created database*/

/* In the hospital database need to create the tables related*/
create table Doctor(Doctor_id int primary key, Name varchar(100), Specilization varchar(100));  /* Creating the doctor tabel*/
select * from Doctor; /* Checking the with the query all the colums are created or not*/
/* Creating the Patient tabel*/
create table Patient(Patient_id int not null primary key, Name varchar(100), Age int, Gender varchar(10), Disease varchar(100), Doctor_id int, Foreign key(Doctor_id) references Doctor(doctor_id));

select * from Patient;
/* Inserting the values to the Doctor tabel*/
INSERT INTO Doctor (doctor_id, name, Specilization) VALUES
(101, 'Dr. Abhiram', 'Cardiologist'),
(102, 'Dr. Harshith', 'Oncology'),
(103, 'Dr. Leo', 'General'),
(104, 'Dr. Sathis', 'Neurologist'),
(105, 'Dr. Renuka', 'ENT'),
(106, 'Dr. Naveen', 'Family medicine'),
(107, 'Dr. Bhadri', 'Internal medicine');
INSERT INTO Doctor (doctor_id, name, Specilization) VALUES 
(108, 'Dr. Vikram', 'Surgery'),
(109, 'Dr. Kesava', 'Cardiologist'),
(110, 'Dr. Laxman', 'General');
select * from Doctor;
/* Inserting the records to the patient table*/
INSERT INTO Patient (patient_id, name, age, gender, disease, doctor_id) VALUES
(1, 'RAMA', 20, 'Male', 'Asthma', 101),
(2, 'Rajesh', 25, 'MAle', 'Diabetes', 102),
(3, 'Rani', 30, 'Female', 'Asthma', 103),
(4, 'Sujith', 35, 'Male', 'Heart Disease', 104),
(5, 'Vivek', 40, 'Male', 'Lungs', 105),
(6, 'Shiva', 45, 'Male', 'Sugar', 106),
(7, 'Sitha', 50, 'Female', 'Migraine', 107),
(8, 'Harsh', 55, 'Male', 'Brain', 108),
(9, 'Ammu', 55, 'Female', 'Cancer', 109),
(10, 'Charan', 60, 'Male', 'Kidney Disease', 110),
(11, 'Keerthi', 28, 'Female', 'Breething', 101),
(12, 'Karthik', 38, 'Male', 'GAS', 102),
(13, 'Kamali', 48, 'Female', 'Lungs', 103),
(14, 'Surav', 52, 'Male', 'Back', 104),
(15, 'Super', 43, 'Female', 'Cold', 105);

INSERT INTO Patient (patient_id, name, age, gender, disease) VALUES
(16, 'Venkat', 53, 'Male', 'Cold');




select d_name from doctor;


/*1.	Write a query to find the total number of patients assigned to each doctor.*/
select doctor_id, count(patient_id) as TOTAL from Patient group by doctor_id;
/*2.	Write a query to find the names of doctors and the total number of patients assigned to them.*/
select d_name, count(p.patient_id) as TOTAL from Doctor d left join Patient p on d.doctor_id = p.doctor_id group by d_name;
/*3.	Write a query to find the names of patients who have not been assigned a doctor.*/
select name from patient where doctor_id is null;
/*4.	Write a query to find the specializations of doctors who have more than 10 patients assigned.*/
select Specilization, count(patient_id) from Doctor d join Patient p on d.doctor_id = p.doctor_id group by d.Specilization HAVING count(p.patient_id) > 10;
/*5.	Write a query to find the patient names and their corresponding diseases for patients assigned to a specific doctor.*/
select name, disease from patient where doctor_id = '101';
