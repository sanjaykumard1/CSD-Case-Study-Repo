CREATE DATABASE EventManagementSystem;


USE EventManagementSystem;

CREATE TABLE Events (
    event_id INT PRIMARY KEY,
    event_name VARCHAR(255),
    event_date DATE,
    location VARCHAR(255),
    max_participants INT
);

CREATE TABLE Participants (
    participant_id INT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone_number VARCHAR(20)
);

CREATE TABLE Registrations (
    registration_id INT PRIMARY KEY,
    event_id INT,
    participant_id INT,
    registration_date DATE NOT NULL,
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
    FOREIGN KEY (participant_id) REFERENCES Participants(participant_id)
);

INSERT INTO Events (event_id, event_name, event_date, location, max_participants)
VALUES (1, 'CTS Training 2024', '2024-09-13', 'Chennai', 500);

INSERT INTO Participants (participant_id, name, email, phone_number)
VALUES (44, 'Samuel', 'maithresamuel@gmail.com', '9864896524');

INSERT INTO Registrations (registration_id, event_id, participant_id, registration_date)
VALUES (1, 1, 44, CURDATE());

SELECT * FROM Events;

-- queries 

SELECT e.event_id, e.event_name, COUNT(r.participant_id) AS total_participants
FROM Events e LEFT JOIN Registrations r ON e.event_id = r.event_id
GROUP BY e.event_id, e.event_name;

SELECT event_id, event_name, event_date, location, max_participants
FROM Events WHERE event_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 1 MONTH);

SELECT p.participant_id, p.name, p.email, p.phone_number, COUNT(r.event_id) AS event_count
FROM Participants p JOIN Registrations r ON p.participant_id = r.participant_id
GROUP BY p.participant_id, p.name, p.email, p.phone_number
HAVING COUNT(r.event_id) > 1;

SELECT e.event_id, e.event_name, e.event_date, e.location, e.max_participants,
COUNT(r.participant_id) AS registered_participants
FROM Events e JOIN Registrations r ON e.event_id = r.event_id
GROUP BY e.event_id, e.event_name, e.event_date, e.location, e.max_participants
HAVING COUNT(r.participant_id) >= e.max_participants;

SELECT r.registration_id, r.event_id, e.event_name, e.event_date, e.location, r.registration_date
FROM Registrations r
JOIN Events e ON r.event_id = e.event_id
WHERE r.participant_id = 44;

