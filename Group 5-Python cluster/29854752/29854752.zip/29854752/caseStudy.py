class Event:
    def __init__(self, event_id, event_name, event_date, location, max_participants):
        self.event_id = event_id
        self.event_name = event_name
        self.event_date = event_date
        self.location = location
        self.max_participants = max_participants

    def __str__(self):
        return f"Event ID: {self.event_id}\nEvent Name: {self.event_name}\nEvent Date: {self.event_date}\nLocation: {self.location}\nMax Participants: {self.max_participants}\n"

    @classmethod
    def add_event(cls, events):
        event_id = int(input("Event ID: "))
        event_name = input("Event Name: ")
        event_date = input("Event Date (YYYY-MM-DD): ")
        location = input("Location: ")
        max_participants = int(input("Max Participants: "))
        
        event = cls(event_id, event_name, event_date, location, max_participants)
        events.append(event)
        print(f"Event {event.event_name} added successfully.")

    @classmethod
    def update_event(cls, events):
        event_id = int(input("Event ID to update: "))
        for event in events:
            if event.event_id == event_id:
                event_name = input(f"Current Event Name: {event.event_name}. Enter new Event Name or press Enter to keep unchanged: ")
                if event_name.strip():
                    event.event_name = event_name
                event_date = input(f"Current Event Date: {event.event_date}. Enter new Event Date (YYYY-MM-DD) or press Enter to keep unchanged: ")
                if event_date.strip():
                    event.event_date = event_date
                location = input(f"Current Location: {event.location}. Enter new Location or press Enter to keep unchanged: ")
                if location.strip():
                    event.location = location
                max_participants = input(f"Current Max Participants: {event.max_participants}. Enter new Max Participants or press Enter to keep unchanged: ")
                if max_participants.strip():
                    event.max_participants = int(max_participants)
                print(f"Event {event.event_name} updated successfully.")
                break
        else:
            print(f"Event with ID {event_id} not found.")

    @classmethod
    def delete_event(cls, events):
        event_id = int(input("Enter Event ID to delete: "))
        for event in events:
            if event.event_id == event_id:
                events.remove(event)
                print(f"Event with ID {event_id} deleted successfully.")
                break
        else:
            print(f"Event with ID {event_id} not found.")

class Participant:
    def __init__(self, participant_id, name, email, phone_number):
        self.participant_id = participant_id
        self.name = name
        self.email = email
        self.phone_number = phone_number

    def __str__(self):
        return f"Participant ID: {self.participant_id}\nName: {self.name}\nEmail: {self.email}\nPhone Number: {self.phone_number}\n"

    @classmethod
    def add_participant(cls, participants):
        participant_id = int(input("Enter Participant ID: "))
        name = input("Enter Name: ")
        email = input("Enter Email: ")
        phone_number = input("Enter Phone Number: ")
        
        participant = cls(participant_id, name, email, phone_number)
        participants.append(participant)
        print(f"Participant {participant.name} added successfully.")

    @classmethod
    def update_participant(cls, participants):
        participant_id = int(input("Enter Participant ID to update: "))
        for participant in participants:
            if participant.participant_id == participant_id:
                name = input(f"Current Name: {participant.name}. Enter new Name or press Enter to keep unchanged: ")
                if name.strip():
                    participant.name = name
                email = input(f"Current Email: {participant.email}. Enter new Email or press Enter to keep unchanged: ")
                if email.strip():
                    participant.email = email
                phone_number = input(f"Current Phone Number: {participant.phone_number}. Enter new Phone Number or press Enter to keep unchanged: ")
                if phone_number.strip():
                    participant.phone_number = phone_number
                print(f"Participant {participant.name} updated successfully.")
                break
        else:
            print(f"Participant with ID {participant_id} not found.")

    @classmethod
    def delete_participant(cls, participants):
        participant_id = int(input("Enter Participant ID to delete: "))
        for participant in participants:
            if participant.participant_id == participant_id:
                participants.remove(participant)
                print(f"Participant with ID {participant_id} deleted successfully.")
                break
        else:
            print(f"Participant with ID {participant_id} not found.")

class Registration:
    def __init__(self, registration_id, event_id, participant_id, registration_date):
        self.registration_id = registration_id
        self.event_id = event_id
        self.participant_id = participant_id
        self.registration_date = registration_date

    def __str__(self):
        return f"Registration ID: {self.registration_id}\nEvent ID: {self.event_id}\nParticipant ID: {self.participant_id}\nRegistration Date: {self.registration_date}\n"

    @classmethod
    def add_registration(cls, registrations):
        registration_id = int(input("Enter Registration ID: "))
        event_id = int(input("Enter Event ID: "))
        participant_id = int(input("Enter Participant ID: "))
        registration_date = input("Enter Registration Date (YYYY-MM-DD): ")
        
        registration = cls(registration_id, event_id, participant_id, registration_date)
        registrations.append(registration)
        print(f"Registration {registration.registration_id} added successfully.")

    @classmethod
    def update_registration(cls, registrations):
        registration_id = int(input("Enter Registration ID to update: "))
        for registration in registrations:
            if registration.registration_id == registration_id:
                event_id = int(input(f"Current Event ID: {registration.event_id}. Enter new Event ID or press Enter to keep unchanged: "))
                if event_id:
                    registration.event_id = event_id
                participant_id = int(input(f"Current Participant ID: {registration.participant_id}. Enter new Participant ID or press Enter to keep unchanged: "))
                if participant_id:
                    registration.participant_id = participant_id
                registration_date = input(f"Current Registration Date: {registration.registration_date}. Enter new Registration Date (YYYY-MM-DD) or press Enter to keep unchanged: ")
                if registration_date.strip():
                    registration.registration_date = registration_date
                print(f"Registration {registration.registration_id} updated successfully.")
                break
        else:
            print(f"Registration with ID {registration_id} not found.")

    @classmethod
    def cancel_registration(cls, registrations):
        registration_id = int(input("Enter Registration ID to cancel: "))
        for registration in registrations:
            if registration.registration_id == registration_id:
                registrations.remove(registration)
                print(f"Registration with ID {registration_id} cancelled successfully.")
                break
        else:
            print(f"Registration with ID {registration_id} not found.")

# Example Usage:
if __name__ == "__main__":
    participants = []
    events = []
    registrations = []

    while True:
        print("\n1. Manage Events")
        print("2. Manage Participants")
        print("3. Manage Registrations")
        print("4. Exit")

        choice = input("\nEnter your choice: ")

        if choice == "1":
            print("\n1. Add Event")
            print("2. Update Event")
            print("3. Delete Event")

            event_choice = input("\nEnter your choice: ")

            if event_choice == "1":
                Event.add_event(events)
            elif event_choice == "2":
                Event.update_event(events)
            elif event_choice == "3":
                Event.delete_event(events)
            else:
                print("Invalid choice.")

        elif choice == "2":
            print("\n1. Add Participant")
            print("2. Update Participant")
            print("3. Delete Participant")

            participant_choice = input("\nEnter your choice: ")

            if participant_choice == "1":
                Participant.add_participant(participants)
            elif participant_choice == "2":
                Participant.update_participant(participants)
            elif participant_choice == "3":
                Participant.delete_participant(participants)
            else:
                print("Invalid choice.")

        elif choice == "3":
            print("\n1. Add Registration")
            print("2. Update Registration")
            print("3. Cancel Registration")

            registration_choice = input("\nEnter your choice: ")

            if registration_choice == "1":
                Registration.add_registration(registrations)
            elif registration_choice == "2":
                Registration.update_registration(registrations)
            elif registration_choice == "3":
                Registration.cancel_registration(registrations)
            else:
                print("Invalid choice.")

        elif choice == "4":
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Please enter a valid option.")