class Patient:
    def __init__(self, patient_id, name, date_of_birth, gender, contact_info):
        self.patient_id = patient_id
        self.name = name
        self.date_of_birth = date_of_birth
        self.gender = gender
        self.contact_info = contact_info

    def __str__(self):
        return f"Patient ID: {self.patient_id}\nName: {self.name}\nDate of Birth: {self.date_of_birth}\nGender: {self.gender}\nContact Info: {self.contact_info}"
class Doctor:
    def __init__(self, doctor_id, name, specialty, contact_info, available_dates=None):
        self.doctor_id = doctor_id
        self.name = name
        self.specialty = specialty
        self.contact_info = contact_info
        self.available_dates = available_dates if available_dates else []

    def __str__(self):
        return f"Doctor ID: {self.doctor_id}\nName: {self.name}\nSpecialty: {self.specialty}\nContact Info: {self.contact_info}\nAvailable Dates: {', '.join(self.available_dates)}"
class Appointment:
    def __init__(self, appointment_id, patient_id, doctor_id, appointment_date, reason):
        self.appointment_id = appointment_id
        self.patient_id = patient_id
        self.doctor_id = doctor_id
        self.appointment_date = appointment_date
        self.reason = reason

    def __str__(self):
        return f"Appointment ID: {self.appointment_id}\nPatient ID: {self.patient_id}\nDoctor ID: {self.doctor_id}\nDate: {self.appointment_date}\nReason: {self.reason}"
class ClinicManager:
    def __init__(self):
        self.patients = []
        self.doctors = []
        self.appointments = []
        self.next_patient_id = 1
        self.next_doctor_id = 1
        self.next_appointment_id = 1

    def add_patient(self, name, date_of_birth, gender, contact_info):
        patient_id = self.next_patient_id
        patient = Patient(patient_id, name, date_of_birth, gender, contact_info)
        self.patients.append(patient)
        self.next_patient_id += 1
        return patient

    def update_patient(self, patient_id, name=None, date_of_birth=None, gender=None, contact_info=None):
        for patient in self.patients:
            if patient.patient_id == patient_id:
                if name:
                    patient.name = name
                if date_of_birth:
                    patient.date_of_birth = date_of_birth
                if gender:
                    patient.gender = gender
                if contact_info:
                    patient.contact_info = contact_info
                return True
        return False

    def delete_patient(self, patient_id):
        for patient in self.patients:
            if patient.patient_id == patient_id:
                self.patients.remove(patient)
                return True
        return False
    def add_doctor(self, name, specialty, contact_info, available_dates=None):
        doctor_id = self.next_doctor_id
        doctor = Doctor(doctor_id, name, specialty, contact_info, available_dates)
        self.doctors.append(doctor)
        self.next_doctor_id += 1
        return doctor

    def update_doctor(self, doctor_id, name=None, specialty=None, contact_info=None, available_dates=None):
        for doctor in self.doctors:
            if doctor.doctor_id == doctor_id:
                if name:
                    doctor.name = name
                if specialty:
                    doctor.specialty = specialty
                if contact_info:
                    doctor.contact_info = contact_info
                if available_dates:
                    doctor.available_dates = available_dates
                return True
        return False

    def delete_doctor(self, doctor_id):
        for doctor in self.doctors:
            if doctor.doctor_id == doctor_id:
                self.doctors.remove(doctor)
                return True
        return False
    def schedule_appointment(self, patient_id, doctor_id, appointment_date, reason):
        appointment_id = self.next_appointment_id
        appointment = Appointment(appointment_id, patient_id, doctor_id, appointment_date, reason)
        self.appointments.append(appointment)
        self.next_appointment_id += 1
        return appointment

    def update_appointment(self, appointment_id, patient_id=None, doctor_id=None, appointment_date=None, reason=None):
        for appointment in self.appointments:
            if appointment.appointment_id == appointment_id:
                if patient_id:
                    appointment.patient_id = patient_id
                if doctor_id:
                    appointment.doctor_id = doctor_id
                if appointment_date:
                    appointment.appointment_date = appointment_date
                if reason:
                    appointment.reason = reason
                return True
        return False

    def cancel_appointment(self, appointment_id):
        for appointment in self.appointments:
            if appointment.appointment_id == appointment_id:
                self.appointments.remove(appointment)
                return True
        return False
def main():
    clinic_manager = ClinicManager()

    while True:
        print("\n==== Health Clinic Management System ====")
        print("1. Manage Patients")
        print("2. Manage Doctors")
        print("3. Manage Appointments")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            manage_patients(clinic_manager)
        elif choice == '2':
            manage_doctors(clinic_manager)
        elif choice == '3':
            manage_appointments(clinic_manager)
        elif choice == '4':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

def manage_patients(clinic_manager):
    while True:
        print("\n==== Manage Patients ====")
        print("1. Add a new patient")
        print("2. Update a patient record")
        print("3. Delete a patient")
        print("4. Back to main menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter patient's name: ")
            dob = input("Enter date of birth (YYYY-MM-DD): ")
            gender = input("Enter gender: ")
            contact_info = input("Enter contact info: ")
            clinic_manager.add_patient(name, dob, gender, contact_info)
            print("Patient added successfully.")
        elif choice == '2':
            patient_id = int(input("Enter patient ID to update: "))
            if clinic_manager.update_patient(patient_id):
                print("Patient record updated successfully.")
            else:
                print("Patient not found.")
        elif choice == '3':
            patient_id = int(input("Enter patient ID to delete: "))
            if clinic_manager.delete_patient(patient_id):
                print("Patient deleted successfully.")
            else:
                print("Patient not found.")
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

def manage_doctors(clinic_manager):
    while True:
        print("\n==== Manage Doctors ====")
        print("1. Add a new doctor")
        print("2. Update a doctor record")
        print("3. Delete a doctor")
        print("4. Back to main menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter doctor's name: ")
            specialty = input("Enter doctor's specialty: ")
            contact_info = input("Enter contact info: ")
            clinic_manager.add_doctor(name, specialty, contact_info)
            print("Doctor added successfully.")
        elif choice == '2':
            doctor_id = int(input("Enter doctor ID to update: "))
            if clinic_manager.update_doctor(doctor_id):
                print("Doctor record updated successfully.")
            else:
                print("Doctor not found.")
        elif choice == '3':
            doctor_id = int(input("Enter doctor ID to delete: "))
            if clinic_manager.delete_doctor(doctor_id):
                print("Doctor deleted successfully.")
            else:
                print("Doctor not found.")
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

def manage_appointments(clinic_manager):
    while True:
        print("\n==== Manage Appointments ====")
        print("1. Schedule a new appointment")
        print("2. Update an appointment")
        print("3. Cancel an appointment")
        print("4. Back to main menu")

        choice = input("Enter your choice: ")

        if choice == '1':
            patient_id = int(input("Enter patient ID: "))
            doctor_id = int(input("Enter doctor ID: "))
            appointment_date = input("Enter appointment date (YYYY-MM-DD HH:MM): ")
            reason = input("Enter reason for appointment: ")
            clinic_manager.schedule_appointment(patient_id, doctor_id, appointment_date, reason)
            print("Appointment scheduled successfully.")
        elif choice == '2':
            appointment_id = int(input("Enter appointment ID to update: "))
            if clinic_manager.update_appointment(appointment_id):
                print("Appointment updated successfully.")
            else:
                print("Appointment not found.")
        elif choice == '3':
            appointment_id = int(input("Enter appointment ID to cancel: "))
            if clinic_manager.cancel_appointment(appointment_id):
                print("Appointment canceled successfully.")
            else:
                print("Appointment not found.")
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please enter a valid option.")

def main():
    clinic_manager = ClinicManager()

    while True:
        print("\n==== Health Clinic Management System ====")
        print("1. Manage Patients")
        print("2. Manage Doctors")
        print("3. Manage Appointments")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            manage_patients(clinic_manager)
        elif choice == '2':
            manage_doctors(clinic_manager)
        elif choice == '3':
            manage_appointments(clinic_manager)
        elif choice == '4':
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
