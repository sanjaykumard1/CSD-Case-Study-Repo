CREATE DATABASE hospital;

CREATE TABLE Patients (
    patient_id INT PRIMARY KEY,
    name VARCHAR(255),
    date_of_birth DATE,
    gender VARCHAR(10),
    contact_info VARCHAR(255)
);

CREATE TABLE Doctors (
    doctor_id INT PRIMARY KEY,
    name VARCHAR(255),
    specialty VARCHAR(255),
    contact_info VARCHAR(255),
    available_dates TEXT
);

CREATE TABLE Appointments (
    appointment_id INT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATE,
    reason VARCHAR(255),
    FOREIGN KEY (patient_id) REFERENCES Patients(patient_id),
    FOREIGN KEY (doctor_id) REFERENCES Doctors(doctor_id)
);

#Write a query to find the number of appointments scheduled for each doctor
SELECT doctor_id, COUNT(*) AS appointment_count
FROM Appointments
GROUP BY doctor_id;

#Write a query to find the patients who have appointments in the next week
SELECT p.*
FROM Patients p
JOIN Appointments a ON p.patient_id = a.patient_id
WHERE a.appointment_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY);

#Write a query to find the doctors who specialize in a specific field.
SELECT * 
FROM Doctors
WHERE specialty = 'specific_field'; -- Replace 'specific_field' with the actual specialty

#Write a query to find the available dates for a particular doctor
SELECT available_dates 
FROM Doctors
WHERE doctor_id = specific_doctor_id;  -- Replace 'specific_doctor_id' with the actual doctor_id


#Write a query to find the appointment history of a specific patient.
SELECT * 
FROM Appointments
WHERE patient_id = 'specific_patient_id' ; -- Replace 'specific_patient_id' with the actual patient_id

