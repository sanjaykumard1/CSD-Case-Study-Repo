package com.javatraining;
import java.util.Scanner;

public class MainMenu {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Digital Magazine Management System");
            System.out.println("1. Magazine Management");
            System.out.println("2. Article Management");
            System.out.println("3. Subscription Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    MagazineManagement.menu();
                    break;
                case 2:
                    ArticleManagement.menu();
                    break;
                case 3:
                    SubscriptionManagement.menu();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

}
