package com.javatraining;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//class for Magazine management
public class MagazineManagement {
	public static void menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMagazine Management");
            System.out.println("1. Add a new magazine");
            System.out.println("2. View magazine details");
            System.out.println("3. Update magazine information");
            System.out.println("4. Delete a magazine");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addMagazine();
                    break;
                case 2:
                    viewMagazine();
                    break;
                case 3:
                    updateMagazine();
                    break;
                case 4:
                    deleteMagazine();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
    

    private static void addMagazine() {
        // Code to add magazine
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter publication frequency: ");
        String frequency = scanner.nextLine();
        System.out.print("Enter publisher: ");
        String publisher = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "INSERT INTO Magazine (title, genre, publication_frequency, publisher) VALUES (?, ?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, genre);
            pstmt.setString(3, frequency);
            pstmt.setString(4, publisher);
            pstmt.executeUpdate();
            System.out.println("Magazine added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error adding magazine: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void viewMagazine() {
        // Code to view magazine details
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter magazine ID to view details: ");
        int id = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM Magazine WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Genre: " + rs.getString("genre"));
                System.out.println("Publication Frequency: " + rs.getString("publication_frequency"));
                System.out.println("Publisher: " + rs.getString("publisher"));
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error viewing magazine details: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void updateMagazine() {
        // Code to update magazine information
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter magazine ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new title: ");
        String title = scanner.nextLine();
        System.out.print("Enter new genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter new publication frequency: ");
        String frequency = scanner.nextLine();
        System.out.print("Enter new publisher: ");
        String publisher = scanner.nextLine();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "UPDATE Magazine SET title = ?, genre = ?, publication_frequency = ?, publisher = ? WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, genre);
            pstmt.setString(3, frequency);
            pstmt.setString(4, publisher);
            pstmt.setInt(5, id);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Magazine updated successfully!");
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating magazine: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void deleteMagazine() {
        // Code to delete a magazine
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter magazine ID to delete: ");
        int id = scanner.nextInt();

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String sql = "DELETE FROM Magazine WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Magazine deleted successfully!");
            } else {
                System.out.println("Magazine not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting magazine: " + e.getMessage());
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
