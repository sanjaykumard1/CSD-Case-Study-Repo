package com.bankingsystem;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CustomerManager customerManager = new CustomerManager();
        AccountManager accountManager = new AccountManager();
        TransactionManager transactionManager = new TransactionManager();

        while (true) {
            System.out.println("\nWelcome to the Banking System");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Add Account");
            System.out.println("6. View Account Details");
            System.out.println("7. Update Account");
            System.out.println("8. Close Account");
            System.out.println("9. Deposit");
            System.out.println("10. Withdraw");
            System.out.println("11. Transfer");
            System.out.println("12. View Transaction History");
            System.out.println("13. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.next();
                    System.out.print("Enter address: ");
                    String address = scanner.next();
                    System.out.print("Enter phone: ");
                    String phone = scanner.next();
                    System.out.print("Enter email: ");
                    String email = scanner.next();
                    Customer customer = new Customer(name, address, phone, email);
                    customerManager.addCustomer(customer);
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    customerManager.viewCustomerDetails(customerId);
                    break;
                case 3:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter name: ");
                    name = scanner.next();
                    System.out.print("Enter address: ");
                    address = scanner.next();
                    System.out.print("Enter phone: ");
                    phone = scanner.next();
                    System.out.print("Enter email: ");
                    email = scanner.next();
                    customer = new Customer(name, address, phone, email);
                    customer.setCustomerId(customerId);
                    customerManager.updateCustomer(customer);
                    break;
                case 4:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    customerManager.deleteCustomer(customerId);
                    break;
                case 5:
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter account type (Savings/Checking): ");
                    String accountType = scanner.next();
                    System.out.print("Enter initial balance: ");
                    double balance = scanner.nextDouble();
                    Account account = new Account(customerId, accountType, balance);
                    accountManager.addAccount(account);
                    break;
                case 6:
                    System.out.print("Enter account ID: ");
                    int accountId = scanner.nextInt();
                    accountManager.viewAccountDetails(accountId);
                    break;
                case 7:
                    System.out.print("Enter account ID: ");
                    accountId = scanner.nextInt();
                    System.out.print("Enter account type (Savings/Checking): ");
                    accountType = scanner.next();
                    System.out.print("Enter balance: ");
                    balance = scanner.nextDouble();
                    account = new Account(accountId, accountType, balance);
                    accountManager.updateAccount(account);
                    break;
                case 8:
                    System.out.print("Enter account ID: ");
                    accountId = scanner.nextInt();
                    accountManager.closeAccount(accountId);
                    break;
                case 9:
                    System.out.print("Enter account ID: ");
                    accountId = scanner.nextInt();
                    System.out.print("Enter amount: ");
                    Double amount = scanner.nextDouble();
                    transactionManager.deposit(accountId, amount);
                    break;
                case 10:
                    System.out.print("Enter account ID: ");
                    accountId = scanner.nextInt();
                    System.out.print("Enter amount: ");
                    amount = scanner.nextDouble();
                    transactionManager.withdraw(accountId, amount);
                    break;
                case 11:
                    System.out.print("Enter from account ID: ");
                    int fromAccountId = scanner.nextInt();
                    System.out.print("Enter to account ID: ");
                    int toAccountId = scanner.nextInt();
                    System.out.print("Enter amount: ");
                    amount = scanner.nextDouble();
                    transactionManager.transfer(fromAccountId, toAccountId, amount);
                    break;
                case 12:
                    System.out.print("Enter account ID: ");
                    accountId = scanner.nextInt();
                    for (Transaction transaction : transactionManager.getTransactionHistory(accountId)) {
                        System.out.println(transaction);
                    }
                    break;
                case 13:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
