import java.util.Scanner;

public class App {
    
    private static Student studentManager = new Student();
    private static Teacher teacherManager = new Teacher();
    private static Course courseManager = new Course();
    private static Grade gradeManager = new Grade();

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageStudents(scanner);
                    break;
                case 2:
                    manageTeachers(scanner);
                    break;
                case 3:
                    manageCourses(scanner);
                    break;
                case 4:
                    manageGrades(scanner);
                    break;
                case 5:
                    System.out.println("Exiting the application.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void showMenu() {
        System.out.println("School Management System");
        System.out.println("1. Manage Students");
        System.out.println("2. Manage Teachers");
        System.out.println("3. Manage Courses");
        System.out.println("4. Manage Grades");
        System.out.println("5. Exit");
        System.out.println("Enter your choice: ");

    }


    private static void manageStudents(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------------\n");
            System.out.println("Student Management");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Back to Main Menu");
            System.out.println("Enter your choice: ");
            int choice = scanner.nextInt();
            
            System.out.println("\n");

            switch (choice) {
                case 1:
                    
                    System.out.print("Enter ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter DOB: ");
                    String DOB = scanner.nextLine();
                    System.out.print("Enter address: ");
                    String address=scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    studentManager.add_student(id, name, DOB,address, email);
                    break;
                case 2:
                    studentManager.View_Students();
                    break;
                case 3:
                    System.out.print("Enter student ID to update: ");
                    int newid = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new name: ");
                    String newName = scanner.next();
                    System.out.print("Enter new DOB: ");
                    String newDOB = scanner.next();
                    System.out.print("Enter new address: ");
                    String newaddress=scanner.next();
                    System.out.print("Enter new email: ");
                    String newEmail = scanner.next();
                    studentManager.update_student(newid, newName, newDOB, newaddress, newEmail);
                    break;
                case 4:
                    System.out.print("Enter student ID to delete: ");
                    int deleteId = scanner.nextInt();
                    studentManager.delete_student(deleteId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void manageTeachers(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------------\n");
            System.out.println("Teacher Management");
            System.out.println("1. Add Teacher");
            System.out.println("2. View Teachers");
            System.out.println("3. Update Teacher");
            System.out.println("4. Delete Teacher");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            
            System.out.println("\n");

            switch (choice) {
                case 1:
                    
                    System.out.print("Enter ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter DOB: ");
                    String DOB = scanner.nextLine();
                    System.out.print("Enter address: ");
                    String address=scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    teacherManager.add_teacher(id, name, DOB, address, email);
                    break;
                case 2:
                    teacherManager.View_Teachers();
                    break;
                case 3:
                    System.out.print("Enter Teacher ID to update: ");
                    int newid = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new DOB: ");
                    String newDOB = scanner.nextLine();
                    System.out.print("Enter new address: ");
                    String newaddress=scanner.nextLine();
                    System.out.print("Enter new email: ");
                    String newEmail = scanner.nextLine();
                    teacherManager.update_Teacher(newid, newName, newDOB, newaddress, newEmail);
                    break;
                case 4:
                    System.out.print("Enter student ID to delete: ");
                    int deleteId = scanner.nextInt();
                    teacherManager.delete_teacher(deleteId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageCourses(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------------\n");
            System.out.println("Course Management");
            System.out.println("1. Add Course");
            System.out.println("2. View Course");
            System.out.println("3. Update Course");
            System.out.println("4. Delete Course");
            System.out.println("5. Back to Main Menu");
            System.out.println("Enter your choice: ");
            int choice = scanner.nextInt();
            
            System.out.println("\n");

            switch (choice) {
                case 1:
                    
                    System.out.print("Enter course ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String Desc = scanner.nextLine();
                    System.out.print("Enter teacher id: ");
                    int t_id=scanner.nextInt();
                    courseManager.add_course(id, title, Desc, t_id);
                    break;
                case 2:
                    courseManager.view_course();
                    break;
                case 3:
                    System.out.print("Enter Course ID to update: ");
                    int new_id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new title: ");
                    String new_title = scanner.nextLine();
                    System.out.print("Enter new Description: ");
                    String new_description = scanner.nextLine();
                    System.out.print("Enter new teacher id: ");
                    int new_t_id=scanner.nextInt();
                    courseManager.update_course(new_id, new_title, new_description, new_t_id);
                    break;
                case 4:
                    System.out.print("Enter course ID to delete: ");
                    int deleteId = scanner.nextInt();
                    courseManager.delete_course(deleteId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            }
        }

        private static void manageGrades(Scanner scanner) {
            while (true) {
                System.out.println("------------------------------------\n");
                System.out.println("Grade Management");
                System.out.println("1. Add Grade");
                System.out.println("2. View Grade");
                System.out.println("3. Update Grade");
                System.out.println("4. Calculate GPA");
                System.out.println("5. Back to Main Menu");
                System.out.println("Enter your choice: ");
                int choice = scanner.nextInt();
                
                System.out.println("\n");
    
                switch (choice) {
                    case 1:
                        
                        System.out.print("Enter student ID: ");
                        int s_id = scanner.nextInt();
                        System.out.print("Enter Grade ID: ");
                        int g_id = scanner.nextInt();
                        System.out.print("Enter course ID: ");
                        int c_id=scanner.nextInt();
                        System.out.print("Enter Grade: ");
                        String grade = scanner.next();
                        gradeManager.add_grade(g_id, s_id,c_id,grade);
                        break;
                    case 2:
                        gradeManager.View_Grades();
                        break;
                    case 3:
                        System.out.print("Enter Grade ID to update: ");
                        int new_g_id = scanner.nextInt();
                        System.out.print("Enter new Grade: ");
                        String new_grade=scanner.next();
                        gradeManager.update_grade(new_g_id, new_grade);
                        break;
                    case 4:
                        System.out.print("Enter student ID to calculate GPA: ");
                        int gpa_Id = scanner.nextInt();
                        gradeManager.calculate_gpa(gpa_Id);
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }



    }






}
