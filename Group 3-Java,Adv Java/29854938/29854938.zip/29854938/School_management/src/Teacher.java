import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Teacher {
    private Connection connection;

    public Teacher(){
        connection=Databaseconnection.getconnection();
    }


    public void add_teacher(int id,String name,String DOB,String address,String email){
        String query="insert into teacher(t_id,name,DOB,address,email) values(?,?,?,?,?)";

        try (PreparedStatement psmt=connection.prepareStatement(query))
        {   psmt.setInt(1, id);
            psmt.setString(2,name);
            psmt.setString(3, DOB);
            psmt.setString(4, address);
            psmt.setString(5,email);
            
            psmt.executeUpdate();
            System.out.println("\n");
            System.out.println("Teacher added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

     public void View_Teachers(){
        String query="select * from teacher";
        try(PreparedStatement pmst=connection.prepareStatement(query)) {
            ResultSet rs=pmst.executeQuery();
            while(rs.next()){
                System.out.println("--------------------------------------------------");
                System.out.println("Teacher_id:"+" "+rs.getInt(1));
                System.out.println("Name:"+" "+rs.getString(2));
                System.out.println("DOB:"+" "+rs.getString(3));
                System.out.println("Address:"+" "+rs.getString(4));
                System.out.println("email:"+" "+rs.getString(5));
            }
            System.out.println("\n");
           
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }


    public void update_Teacher(int id,String name,String DOB,String address,String email){
        String query="update teacher SET name=?, DOB=?, address=?, email=? where t_id=?";

        try (PreparedStatement psmt=connection.prepareStatement(query))
        {   psmt.setString(1,name);
            psmt.setString(2, DOB);
            psmt.setString(3, address);
            psmt.setString(4,email);
            psmt.setInt(5, id);
            psmt.executeUpdate();
            System.out.println("\n");
            System.out.println("Teacher updated Successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete_teacher(int id){
        String query="Delete from teacher where t_id=?";
        try(PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(1, id);
            pmst.executeUpdate();

            System.out.println("Teacher deleted successfully.");
        }catch(SQLException e){
            e.printStackTrace();
        };
    }

}
