import java.sql.Connection;
import java.sql.DriverManager;

public class Databaseconnection {
    private static final String URL = "jdbc:mysql://localhost:3306/school_management";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection  getconnection(){
        try{
            return DriverManager.getConnection(URL, USER, PASSWORD);
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
}
