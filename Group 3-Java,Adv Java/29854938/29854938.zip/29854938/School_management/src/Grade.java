import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class Grade {
    private Connection connection;

    public Grade(){
        connection=Databaseconnection.getconnection();
    }


    public void add_grade(int g_id,int s_id,int c_id,String grade){
        String query="insert into grade (g_id,id,c_id,Grade) values(?,?,?,?)";

        try (PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(1, g_id);
            pmst.setInt(2, s_id);
            pmst.setInt(3, c_id);
            pmst.setString(4,grade);

            pmst.executeUpdate();
            System.out.println("\n");
            System.out.println("Grade added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

     public void View_Grades(){
        String query="select * from grade";
        try(PreparedStatement pmst=connection.prepareStatement(query)) {
            ResultSet rs=pmst.executeQuery();
            while(rs.next()){
                System.out.println("--------------------------------------------------");
                System.out.println("grade ID:"+" "+rs.getInt(1));
                System.out.println("Student ID:"+" "+rs.getInt(2));
                System.out.println("Course ID:"+" "+rs.getInt(3));
                System.out.println("Grade:"+" "+rs.getString(4));
                //System.out.println("email"+" "+rs.getString(5));
                
            }    
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }

    public void update_grade(int g_id,String grade){
        String query="update grade set Grade=? where g_id=?";

        try (PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(2, g_id);
            pmst.setString(1, grade);

            pmst.executeUpdate();
            System.out.println("\n");
            System.out.println("Grade updated successfully.");
            
        } catch (SQLException e) {
            e.printStackTrace();
            
        }
    }


    private double getNumericValue(String grade) {
        Map<String, Double> gradeMap = new HashMap<>();
        gradeMap.put("A", 4.0);
        gradeMap.put("B", 3.0);
        gradeMap.put("C", 2.0);
        gradeMap.put("D", 1.0);
        gradeMap.put("F", 0.0);

        return gradeMap.getOrDefault(grade, 0.0);
    
    }

    public void calculate_gpa(int id){
        String query="select Grade from grade where id=?";
        try (PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(1, id);
            ResultSet rs=pmst.executeQuery();

            double total_points=0;
            int no_of_grades=0;

            while(rs.next()){
                String s=rs.getString("grade");
                total_points+=getNumericValue(s);
                no_of_grades++;
            }

            if(no_of_grades==0){
                System.out.println("\n");
                System.out.println("NO grades found for this student.");
            }

            double gpa=total_points/no_of_grades;
            System.out.println("GPA for student ID"+id+" is: "+gpa);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
