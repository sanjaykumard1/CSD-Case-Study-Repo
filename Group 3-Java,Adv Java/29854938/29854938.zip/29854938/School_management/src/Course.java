import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Course {
    private Connection connection;

    public Course(){
        connection=Databaseconnection.getconnection();
    }

    public void add_course(int c_id,String title,String description,int t_id){
        String query="insert into course(c_id,title,description,t_id) values(?,?,?,?)";

        try(PreparedStatement pst=connection.prepareStatement(query)) {
            pst.setInt(1, c_id);
            pst.setString(2, title);
            pst.setString(3, description);
            pst.setInt(4, t_id);

            pst.executeUpdate();
            System.out.println("Course added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void view_course(){
        String query="select *from course";

        try (PreparedStatement pmst=connection.prepareStatement(query)){
            ResultSet rs=pmst.executeQuery();

            while(rs.next()){
                System.out.println("--------------------------------------------------");
                System.out.println("Course_id: "+rs.getInt(1));
                System.out.println("Title:" +rs.getString(2));
                System.out.println("Description: "+rs.getString(3));
                System.out.println("teacher_id: "+rs.getInt(4));
            }
            System.out.println("\n"); 

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update_course(int c_id,String title,String description,int t_id){
        String query="update course set title=?,description=?,t_id=? where c_id=? ";

        try(PreparedStatement pst=connection.prepareStatement(query)) {
            pst.setInt(4, c_id);
            pst.setString(1, title);
            pst.setString(2, description);
            pst.setInt(3, t_id);
            pst.executeUpdate();

            System.out.println("Course updated Successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void delete_course(int id){
        String query="Delete from course where c_id=?";
        try(PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(1, id);
            pmst.executeUpdate();

            System.out.println("Course deleted successfully.");
        }catch(SQLException e){
            e.printStackTrace();
        };
    }

}
