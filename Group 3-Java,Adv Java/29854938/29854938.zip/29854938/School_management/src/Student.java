import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Student {
    private Connection connection;
    public Student(){
        connection=Databaseconnection.getconnection();
    }

    public void add_student(int id,String name,String DOB,String address,String email){
        String query="insert into student(id,name,DOB,address,email) values(?,?,?,?,?)";

        try (PreparedStatement psmt=connection.prepareStatement(query))
        {   psmt.setInt(1, id);
            psmt.setString(2,name);
            psmt.setString(3, DOB);
            psmt.setString(4, address);
            psmt.setString(5,email);

            psmt.executeUpdate();
            System.out.println("\n");
            System.out.println("Student added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void View_Students(){
        String query="select * from student";
        try(PreparedStatement pmst=connection.prepareStatement(query)) {
            ResultSet rs=pmst.executeQuery();
            while(rs.next()){
                System.out.println("--------------------------------------------------");
                System.out.println("student_id:"+" "+rs.getInt(1));
                System.out.println("Name:"+" "+rs.getString(2));
                System.out.println("DOB:"+" "+rs.getString(3));
                System.out.println("Address:"+" "+rs.getString(4));
                System.out.println("email"+" "+rs.getString(5));
            }    
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
    }

    public void update_student(int id,String name,String DOB,String address,String email){
        String query="update student SET name=?, DOB=?, address=?, email=? where id=?";

        try (PreparedStatement psmt=connection.prepareStatement(query))
        {   psmt.setString(1,name);
            psmt.setString(2, DOB);
            psmt.setString(3, address);
            psmt.setString(4,email);
            psmt.setInt(5, id);
            psmt.executeUpdate();
            System.out.println("\n");
            System.out.println("Student updated Successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete_student(int id){
        String query="Delete from student where id=?";
        try(PreparedStatement pmst=connection.prepareStatement(query)){
            pmst.setInt(1, id);
            pmst.executeUpdate();

            System.out.println("Student deleted successfully.");
        }catch(SQLException e){
            e.printStackTrace();
        };
    }
    
}
