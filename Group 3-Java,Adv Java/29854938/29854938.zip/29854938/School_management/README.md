## Getting Started

Welcome to the VS Code Java world. Here is a guideline to help you get started to write Java code in Visual Studio Code.

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

## Dependency Management

For this project dependencies are found in settings.json file and other information to run the given project.

The `JAVA PROJECTS` view allows you to manage your dependencies. More details can be found [here](https://github.com/microsoft/vscode-java-dependency#manage-dependencies).

## steps to run the project

1.First we have to Download required JDBC driver to make connection to the code from the website.
2.clone this project to your local machine and add dependencies from the settings.json file using build command or you can manually add jar file from the editor.
3.After downloading dependencies run the project and create the required database in mysql.
4.run the app.java file.
