package DMMS_JAVA;
import java.util.*;
import java.sql.*;

public class MagazineService {
	public static void addMagazine(Magazine magazine) {
        String sql = "INSERT INTO Magazine (title, genre, publication_frequency, publisher) VALUES (?, ?, ?, ?)";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, magazine.getTitle());
            stmt.setInt(2, magazine.getGenre());
            stmt.setString(3, magazine.getPublicationFrequency());
            stmt.setString(4, magazine.getPublisher());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void updateMagazine(Magazine magazine) {
        String sql = "UPDATE Magazine SET title = ?, genre = ?, publication_frequency = ?, publisher = ? WHERE magazine_id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, magazine.getTitle());
            stmt.setInt(2, magazine.getGenre());
            stmt.setString(3, magazine.getPublicationFrequency());
            stmt.setString(4, magazine.getPublisher());
            stmt.setInt(5, magazine.getMagazineId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteMagazine(int magazineId) {
        String sql = "DELETE FROM Magazine WHERE magazine_id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, magazineId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void viewAllMagazines()
    {
    	 String sql = "SELECT * FROM Magazine";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);
	             ResultSet rs = stmt.executeQuery(sql)) {
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("magazine_id") +
	                                   ", Title: " + rs.getString("title") +
	                                   ", Generation: " + rs.getString("genre") +
	                                   ", Frequency: " + rs.getString("publication_frequency") +
	                                   ", Author: " + rs.getString("publisher"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
    }

    
}
