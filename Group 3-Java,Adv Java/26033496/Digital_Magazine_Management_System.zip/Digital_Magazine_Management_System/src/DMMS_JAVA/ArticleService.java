package DMMS_JAVA;
import java.util.*;
import java.sql.*;

public class ArticleService {
	 public static void addArticle(Article article) {
	        String sql = "INSERT INTO Article (magazine_id, title, author, content, publish_date) VALUES (?, ?, ?, ?, ?)";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, article.getMagazineId());
	            stmt.setString(2, article.getTitle());
	            stmt.setString(3, article.getAuthor());
	            stmt.setString(4, article.getContent());
	            stmt.setDate(5, new java.sql.Date(article.getPublishDate().getTime()));
	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }


	    public static void updateArticle(Article article) {
	        String sql = "UPDATE Article SET magazine_id = ?, title = ?, author = ?, content = ?, publish_date = ? WHERE article_id = ?";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, article.getMagazineId());
	            stmt.setString(2, article.getTitle());
	            stmt.setString(3, article.getAuthor());
	            stmt.setString(4, article.getContent());
	            stmt.setDate(5, new java.sql.Date(article.getPublishDate().getTime()));
	            stmt.setInt(6, article.getArticleId());
	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public static void deleteArticle(int articleId) {
	        String sql = "DELETE FROM Article WHERE article_id = ?";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, articleId);
	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	    
	    
	    public static void viewAllArticles()
	    {
	    	 String sql = "SELECT * FROM Article";
		        try (Connection conn = DbConnection.getConnection();
		             PreparedStatement stmt = conn.prepareStatement(sql);
		             ResultSet rs = stmt.executeQuery(sql)) {
		            while (rs.next()) {
		                System.out.println("ArticleID: " + rs.getInt("article_id") +
		                                   ", MagazineID: " + rs.getInt("magazine_id") +
		                                   ", Title: " + rs.getString("title") +
		                                   ", Author: " + rs.getString("author") +
		                                   ", Content: " + rs.getString("content")+
		                                   ",PublishDate: "+rs.getDate("publish_date"));
		            }
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }
	    }

}
