package DMMS_JAVA;
import java.util.*;
import java.sql.*;
import java.sql.Date;

public class SubscriptionService {
	public static void subscribe(Subscription subscription) {
        String sql = "INSERT INTO Subscription (user_id, magazine_id, subscription_date, expiry_date, status) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, subscription.getUserId());
            stmt.setInt(2, subscription.getMagazineId());
            stmt.setDate(3, new java.sql.Date(subscription.getSubscriptionDate().getTime()));
            stmt.setDate(4, new java.sql.Date(subscription.getExpiryDate().getTime()));
            stmt.setString(5, subscription.getStatus());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	
	
	public static void updateSubscription(Subscription subscription) {
        String sql = "UPDATE Subscription SET user_id = ?, magazine_id = ?, subscription_date = ?, expiry_date = ?, status = ? WHERE subscription_id = ?";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, subscription.getUserId());
            stmt.setInt(2, subscription.getMagazineId());
            stmt.setDate(3, new java.sql.Date(subscription.getSubscriptionDate().getTime()));
            stmt.setDate(4, new java.sql.Date(subscription.getExpiryDate().getTime()));
            stmt.setString(5, subscription.getStatus());
            stmt.setInt(6, subscription.getSubscriptionId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	
	 public static void cancelSubscription(int subscriptionId) {
	        String sql = "DELETE FROM Subscription WHERE subscription_id = ?";

	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql)) {
	            stmt.setInt(1, subscriptionId);

	            stmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	 
	
	 public static void viewAllSubscriptions()
	 {
		 String sql = "SELECT * FROM Subscription";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);
	             ResultSet rs = stmt.executeQuery(sql)) {
	            while (rs.next()) {
	                System.out.println("SubscriptionId: "+rs.getInt("subscription_id")+
	                				   ", UserID: " + rs.getInt("user_id") +
	                                   ", MagazineID: " + rs.getInt("magazine_id") +
	                                   ", SubscriptionDate: " + rs.getDate("subscription_date") +
	                                   ", ExpiryDate: " + rs.getDate("expiry_date") +
	                                   ", Status: " + rs.getString("status"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	 }
	 
	 public static Date todayDate()
	 {
		 String sql = "SELECT CURRENT_DATE";

		 Date currentDate=null;
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql);
	             ResultSet rs = pstmt.executeQuery()) {

	            if (rs.next()) {
	                currentDate = rs.getDate(1);
	               
	            }
	            return currentDate;

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return null;
	 }
	 
	 public static Date expDate()
	 {
		 String sql = "SELECT CURRENT_DATE + INTERVAL 30 DAY";

		 Date currentDate=null;
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql);
	             ResultSet rs = pstmt.executeQuery()) {

	            if (rs.next()) {
	                currentDate = rs.getDate(1);
	               
	            }
	            return currentDate;

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        
	        return null;
	 }
	 public void status()
	 {
		 String sql = "UPDATE subscription SET status = 'inactive' WHERE expiry_date < CURDATE()";
         int rowsAffected=0;
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql)) {

	            
	            rowsAffected = pstmt.executeUpdate();
	            System.out.println("Number of subscriptions updated: " + rowsAffected);

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	       
	        
	 }
	 

}
