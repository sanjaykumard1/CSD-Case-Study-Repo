package DMMS_JAVA;
import java.util.*;

public class Magazine {
     private int magazineId;
     private String title;
     private int genre;
     private String publicationFrequency;
     private String publisher;
     
     
	public Magazine(int magazineId, String title, int genre, String publicationFrequency, String publisher) {
		
		this.magazineId = magazineId;
		this.title = title;
		this.genre = genre;
		this.publicationFrequency = publicationFrequency;
		this.publisher = publisher;
	}
	
	public Magazine() {
		
	}
	
	public int getMagazineId() {
		return magazineId;
	}
	public void setMagazineId(int magazineId) {
		this.magazineId = magazineId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getGenre() {
		return genre;
	}
	public void setGenre(int genre) {
		this.genre = genre;
	}
	public String getPublicationFrequency() {
		return publicationFrequency;
	}
	public void setPublicationFrequency(String publicationFrequency) {
		this.publicationFrequency = publicationFrequency;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
     
}
