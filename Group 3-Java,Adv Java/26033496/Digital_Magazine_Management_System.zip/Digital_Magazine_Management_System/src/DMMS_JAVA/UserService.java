package DMMS_JAVA;
import java.util.*;
import java.sql.*;


public class UserService {
	public static void addUser(User user) {
        String sql = "INSERT INTO User (username, email, date_of_birth, registration_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setDate(3, new java.sql.Date(user.getDateOfBirth().getTime()));
            stmt.setDate(4, new java.sql.Date(user.getRegistrationDate().getTime()));

            int row=stmt.executeUpdate();
            System.out.print(row +" row Inserted");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
	
	public static User getUser(int userId) {
        String sql = "SELECT * FROM User WHERE user_id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        rs.getDate("date_of_birth"),
                        rs.getDate("registration_date")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

	
    public static void updateUser(User user) {
        String sql = "UPDATE User SET username = ?, email = ?, date_of_birth = ?, registration_date = ? WHERE user_id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setDate(3, new java.sql.Date(user.getDateOfBirth().getTime()));
            stmt.setDate(4, new java.sql.Date(user.getRegistrationDate().getTime()));
            stmt.setInt(5, user.getUserId());
            int row=stmt.executeUpdate();
            System.out.print(row+" row Affected");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public static void deleteUser(int userId) {
        String sql = "DELETE FROM User WHERE user_id = ?";
        try (Connection conn = DbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            int row=stmt.executeUpdate();
            System.out.print(row+" row Deleted");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


	public static void viewAllUsers() {
		 String sql = "SELECT * FROM User";
	        try (Connection conn = DbConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(sql);
	             ResultSet rs = stmt.executeQuery(sql)) {
	            while (rs.next()) {
	                System.out.println("ID: " + rs.getInt("user_id") +
	                                   ", Username: " + rs.getString("username") +
	                                   ", Email: " + rs.getString("email") +
	                                   ", Date of Birth: " + rs.getDate("date_of_birth") +
	                                   ", Registration Date: " + rs.getDate("registration_date"));
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	
    
    
	
}

