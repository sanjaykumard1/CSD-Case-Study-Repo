import java.sql.*;
import java.util.Scanner;

public class GymManagementSystem {
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    // Load the MySQL JDBC driver
    private static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/gym_management_system";
    private static final String USER = "root";
    private static final String PASS = "Priyanshu";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        while (true) {
            System.out.println("Gym Management System");
            System.out.println("1. Members");
            System.out.println("2. Trainer");
            System.out.println("3. Membership Plan Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    manageMembers(sc);
                    break;
                case 2:
                    manageTrainer(sc);
                    break;
                case 3:
                    Membership_Plan_Management(sc);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageMembers(Scanner scanner) {
        while (true) {
            System.out.println("Members");
            System.out.println("1. Add Members");
            System.out.println("2. View Members");
            System.out.println("3. Update Members");
            System.out.println("4. Delete Members");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addMembers(scanner);
                    break;
                case 2:
                    viewMembers();
                    break;
                case 3:
                    updateMember(scanner);
                    break;
                case 4:
                    deleteMember(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageTrainer(Scanner scanner) {
        while (true) {
            System.out.println("Manage Trainer");
            System.out.println("1. Add Trainer");
            System.out.println("2. View Trainer");
            System.out.println("3. Update Trainer");
            System.out.println("4. Delete Trainer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addtrainer(scanner);
                    break;
                case 2:
                    viewtrainer();
                    break;
                case 3:
                    updatetrainer(scanner);
                    break;
                case 4:
                    deletetrainer(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void Membership_Plan_Management(Scanner scanner) {
        while (true) {
            System.out.println("Membership Plan Management");
            System.out.println("1. Add Membership");
            System.out.println("2. View Membership");
            System.out.println("3. Update Membership");
            System.out.println("4. Delete Membership");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addMembership_Plan(scanner);
                    break;
                case 2:
                    viewMembership_Plan();
                    break;
                case 3:
                    updateMembership_Plan(scanner);
                    break;
                case 4:
                    deleteMembership_Plan(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addMembers(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Members (name, email, phone_number) VALUES (?, ?, ?)")) {

            System.out.print("Enter Member Name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter Member Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Member Phone Number: ");
            String phoneNumber = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.executeUpdate();

            System.out.println("Member added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private static void viewMembers() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Members")) {

            while (rs.next()) {
                int id = rs.getInt("member_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone_number");
                //String specialization = rs.getString("specialization");

                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email + ", Phone: " + phoneNumber );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateMember(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Researchers SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?")) {

            System.out.print("Enter Member ID to Update: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Member Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Member Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter New Member Phone Number: ");
            String phoneNumber = scanner.nextLine();
           //System.out.print("Enter New Research Specialization: ");
            //String specialization = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            //pstmt.setString(4, specialization);
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            System.out.println("Member updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteMember(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Researchers WHERE researcher_id = ?")) {

            System.out.print("Enter Member ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Member deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addtrainer(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Trainer (name, description, start_date, end_date) VALUES (?, ?, ?, ?)")) {

            System.out.print("Enter Trainer Name: ");
            scanner.nextLine(); // Consume newline
            String name = scanner.nextLine();
            System.out.print("Enter Trainer Details: ");
            String description = scanner.nextLine();
           // System.out.print("Enter Start Date (YYYY-MM-DD): ");
            //String startDate = scanner.nextLine();
            //System.out.print("Enter End Date (YYYY-MM-DD): ");
            //String endDate = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, description);
           // pstmt.setDate(3, Date.valueOf(startDate));
            //pstmt.setDate(4, Date.valueOf(endDate));
            pstmt.executeUpdate();

            System.out.println("Trainer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewtrainer() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Trainer")) {

            while (rs.next()) {
                int id = rs.getInt("Trainer_id");
                String name = rs.getString("name");
                String details = rs.getString("details");
                //Date startDate = rs.getDate("start_date");
                //Date endDate = rs.getDate("end_date");

                System.out.println("ID: " + id + ", Name: " + name + ", Details: " + details );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updatetrainer(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE trainer SET name = ?, description = ?, start_date = ?, end_date = ? WHERE trainer_id = ?")) {

            System.out.print("Enter Trainer ID to Update: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New Trainer Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Trainer Details: ");
            String description = scanner.nextLine();
           // System.out.print("Enter New Start Date (YYYY-MM-DD): ");
            //String startDate = scanner.nextLine();
            //System.out.print("Enter New End Date (YYYY-MM-DD): ");
            //String endDate = scanner.nextLine();

            pstmt.setString(1, name);
            pstmt.setString(2, description);
           // pstmt.setDate(3, Date.valueOf(startDate));
            //pstmt.setDate(4, Date.valueOf(endDate));
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            System.out.println("Trainer updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deletetrainer(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Trainer WHERE trainer_id = ?")) {

            System.out.print("Enter Trainer ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Trainer deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addMembership_Plan(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Membership_Plan (Membership_Plan, details, information, delete) VALUES (?, ?, ?, ?)")) {

            System.out.print("Enter Member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter Member Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Member email ");
            String email = scanner.nextLine();
            System.out.print("Enter Member phone number: ");
            int phone_number = scanner.nextInt();

            pstmt.setInt(1, memberId);
            pstmt.setString(2, name);
            pstmt.setString(3, email);
            pstmt.setInt(4, phone_number);
            pstmt.executeUpdate();

            System.out.println("Membership plan changed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewMembership_Plan() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Membership_Plan")) {

            while (rs.next()) {
                int id = rs.getInt("member_id");
                int memberId = rs.getInt("experiment_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                int phone_number = rs.getInt("phone_number");

                System.out.println("ID: " + id + ", Experiment ID: " + memberId + ", Name: " + name + ", email: " + email + ", Phone_number: " + phone_number);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateMembership_Plan(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("UPDATE Membership_Plan( SET member_id = ?, name = ?, email = ?, phone_number = ? WHERE member_id = ?")) {

            System.out.print("Enter member ID to Update: ");
            int id = scanner.nextInt();
            System.out.print("Enter New member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter New member Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New member email: ");
            String email = scanner.nextLine();
            System.out.print("Enter New Member Phone_number: ");
            int phone_number = scanner.nextInt();

            pstmt.setInt(1, memberId);
            pstmt.setString(2, name);
            pstmt.setString(3, email);
            pstmt.setInt(4, phone_number);
            pstmt.setInt(5, id);
            pstmt.executeUpdate();
            System.out.println("Membership_Plan updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteMembership_Plan(Scanner scanner) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Membership_Plan WHERE member_id = ?")) {

            System.out.print("Enter member ID to Delete: ");
            int id = scanner.nextInt();

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

            System.out.println("Member deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
