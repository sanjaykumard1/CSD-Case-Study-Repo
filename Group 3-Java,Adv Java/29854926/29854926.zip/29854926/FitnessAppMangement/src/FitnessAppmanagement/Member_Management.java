package FitnessAppmanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;



public class Member_Management {
	static Scanner scanner = new Scanner(System.in);
	
	// New User Registration -->
	public void registermember() throws Exception {
		System.out.println("Enter your name");
		String name = scanner.nextLine();
		
		System.out.println("Enter your email id");
		String email = scanner.next();
		if(email.endsWith(".com")){
			System.out.println("Validating Email Please Wait....");
			
			Thread.sleep(2000);
			
			System.out.println("Valid Email");
		}
		else {
			throw new Exception("Invalid Email");
		}
		System.out.println();
			
		System.out.println("Enter phone number");
		String mobile = scanner.next();
		
		System.out.println("Validating mobile number....");
		
		Thread.sleep(2000);

		if(mobile.length()==10) {
			
			System.out.println("Valid Mobile number");
		}
		else {
			throw new Exception("Invalid Movile Number");
		}
		
		System.out.println();
		
		System.out.println("Enter membership type (Quarterly/Half-yearly/Annual)");
		String membership = scanner.next();
		
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = "Insert into member_management(member_name,email,phone_number,membership_type) values (?,?,?,?)";
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, mobile);
			ps.setString(4, membership);
			
			
			int rowsadded = ps.executeUpdate();
			if(rowsadded>0) {
				System.out.println("Data Added successfully");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	// View Details -->
	public void viewmember() {
		System.out.println("Enter member id ");
		int id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = ("Select * from member_management where member_id =?");
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			if( rs.next()){
				System.out.println("member_id : "+rs.getInt("member_id"));
				System.out.println("Member_name : "+rs.getString("member_name"));
				System.out.println("Email : "+rs.getString("email"));
				System.out.println("Phone Number : "+rs.getString("phone_number"));
				System.out.println("Membership_type : "+rs.getString("membership_type"));
			}
			else {
				System.out.println("No data Found....");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
	
	// Update Details -->
	
	public void updatemember() throws Exception {
		System.out.println("Enter the member id");
		int id =scanner.nextInt();
		scanner.nextLine();
		
		System.out.println("Enter your email id");
		String email = scanner.next();
		if(email.endsWith(".com")){
			System.out.println("Validating Email Please Wait....");
			
			Thread.sleep(2000);
			
			System.out.println("Valid Email");
		}
		else {
			throw new Exception("Invalid Email");
		}
		System.out.println();
			
		
		
		System.out.println("Enter phone number");
		String mobile = scanner.next();
		
		System.out.println("Validating mobile number....");
		
		Thread.sleep(2000);

		if(mobile.length()==10) {
			
			System.out.println("Valid Mobile number");
		}
		else {
			throw new Exception("Invalid Movile Number");
		}
		
		System.out.println();
		
		
		System.out.println("Enter membership type (Quarterly/Half-yearly/Annual)");
		String membership = scanner.next();
		
		try {
			Connection connection =SqlConnection.getconnection();
			String query ="UPDATE Member_management SET email = ?, phone_number = ?, membership_type = ? WHERE member_id = ?";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, mobile);
			ps.setString(3, membership);
			ps.setInt(4, id);
			
			
			
			int rowupdate = ps.executeUpdate();
			if(rowupdate>0) {
				System.out.println("Data Updated Successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	
	// Deleting a member;
	
	public void deletemember() {
		
		System.out.println("Enter ID ");
		int id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = "DELETE FROM Member_management WHERE member_id = ?";
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1,id);
			
			int update = ps.executeUpdate();
			if(update>0)
				System.out.println("Data Deleted");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
	
		
