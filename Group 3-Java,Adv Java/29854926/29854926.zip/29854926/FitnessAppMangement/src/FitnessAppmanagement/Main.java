package FitnessAppmanagement;

import java.util.Scanner;

public class Main {
	
	public static void main(String [] args) throws Exception{
		// object creation 
		Scanner scanner = new Scanner(System.in);
		MemberServiceDisplay mem = new MemberServiceDisplay();
		TrainerServiceDisplay train = new TrainerServiceDisplay();
		classServiceDisplay classc = new classServiceDisplay();
		
	// WELCOME PAGE
		boolean flag = true;
		
			System.out.println("***********************************");
			System.out.println("Welcome to Fitness Management");
			System.out.println("Enter Any one option to proceed");
			System.out.println("1. Member Management");
			System.out.println("2. Trainer Management");
			System.out.println("3. Class Management");
			System.out.println("4. Exit");
	// redirecting to service pages 		
			int ch = scanner.nextInt();
			
			while(flag) {
			
			switch (ch) {
			case 1: {
				mem.Membermethoddisplay();
				break;
				}
			case 2:{
				train.trainnerService();
				break;
				}
			case 3:{
				classc.classservicedisplay();
				break;
				}
			case 4:{
				flag = false;
				System.out.println("Thank You");
				break;
				}
			default :{
				System.err.println("please provide valid input");
				
				}
				
			}
			break;
			}
			scanner.close();
	}
}
	
