package FitnessAppmanagement;
import java.sql.*;
public class SqlConnection {
	
	static String urlString = "jdbc:mysql://localhost:3306/fitness";
	static String username ="root";
	static String password ="root";
	
	public static Connection getconnection () throws Exception{
		return DriverManager.getConnection(urlString,username,password);
		
	}
	
}
