package FitnessAppmanagement;

import java.util.Scanner;

public class classServiceDisplay {
	// service menu creation 
	public void classservicedisplay() throws Exception {
		boolean condition = true;
		Scanner scanner = new Scanner(System.in);
		ClassManagement classManagement = new ClassManagement();
		
	// Trainer Service Display Page 
		
		do {
		System.out.println("******************************");
		System.out.println("welcome to Class Management");
		System.out.println("Select Any One Options Below");
		
		System.out.println("1. Schedule a new Class");
		System.out.println("2. View Class details");
		System.out.println("3. Update Class information");
		System.out.println("4. Cancel Class ");
		System.out.println("5. Exit ");
		int choice = scanner.nextInt();
		switch (choice){
		case 1: {
			classManagement.scheduleClass();
			System.out.println();
			break;
		}
		case 2:{
			classManagement.viewclass();
			System.out.println();
			break;
			
		}
		case 3 :{
			classManagement.updateclass();
			System.out.println();
			break;
		}
		case 4:{
			classManagement.deleteclass();
			System.out.println();
			break;
		}
		case 5:{//--> redirecting main menu
			System.out.println("Redirecting to Main...");
			Thread.sleep(3000);
			condition = false;
			Main.main(null);	
			break;
		}
		default:
			System.err.println("please provice valid input");
		}
			
		} while (condition);
		scanner.close();
	}

}
