package FitnessAppmanagement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
;
public class ClassManagement {
	
	static Scanner scanner = new Scanner(System.in);
	
	// scheduler function
	
	public void scheduleClass() {
		
		System.out.println("Enter Trainer Id");
		int Trainer_id = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("Enter the class Name");
		String classString = scanner.nextLine();
		
		System.out.println("Class Schedule");
		String timestamp = scanner.nextLine();
		
		System.out.println("Enter total Capacity");
		int Capacity = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("class Status ");
		String statuString = scanner.nextLine();
		
		try {
			Connection conn = SqlConnection.getconnection();
			
			String queryString = "Insert into class(trainer_id,class_name,class_schedule,capacity,class_status) values (?,?,?,?,?)";
			PreparedStatement ps = conn.prepareStatement(queryString);
			
			ps.setInt(1, Trainer_id);
			ps.setString(2, classString);
			ps.setString(3, timestamp);
			ps.setInt(4, Capacity);
			ps.setString(5, statuString);
			
			int rowupdate = ps.executeUpdate();
			if(rowupdate>0) {
				System.out.println("Class Scheduled");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	// view class schedule 
	public void viewclass() {
		System.out.println("Enter Class id");
		int class_id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String query=("Select * from class where class_id = ?");
			PreparedStatement ps = connection.prepareStatement(query);
			
			ps.setInt(1, class_id);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Class id : "+rs.getInt("class_id"));
				System.out.println("Trainer id : "+rs.getInt("Trainer_id"));
				System.out.println("Class Name : "+rs.getString("class_name"));
				System.out.println("Class Schedule : "+rs.getTimestamp("class_schedule"));
				System.out.println("Capacity : "+rs.getInt("capacity"));
				System.out.println("class_status :"+rs.getString("class_status"));
			}
			else {
				System.out.println("Data Not Found");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// update class schedule
	
	public void updateclass() {
		
		System.out.println("Enter Class id");
		int class_id = scanner.nextInt();
		
		System.out.println("Enter Trainer Id");
		int Trainer_id = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("Enter the class Name");
		String classString = scanner.nextLine();
		
		System.out.println("Class Schedule");
		String timestamp = scanner.nextLine();
		
		System.out.println("Enter total Capacity");
		int Capacity = scanner.nextInt();
		
		scanner.nextLine();
		
		System.out.println("class Status ");
		String statuString = scanner.nextLine();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String sqlString = "UPDATE class SET trainer_id = ?, class_name = ?, class_schedule = ?, capacity = ?, class_status = ? WHERE class_id = ?";
			PreparedStatement ps = connection.prepareStatement(sqlString);
			ps.setInt(1, Trainer_id);
			ps.setString(2, classString);
			ps.setString(3, timestamp);
			ps.setInt(4, Capacity);
			ps.setString(5, statuString);
			ps.setInt(6, class_id);
			
			int row = ps.executeUpdate();
			if(row>0) {
				System.out.println("Data Updated Successfully");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	// Cancel class  schedule
	public void deleteclass() {
		
		System.out.println("Enter class id ");
		int class_id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString ="UPDATE class SET class_status = 'cancelled' WHERE class_id = ?;";
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1, class_id);
			
			int row = ps.executeUpdate();
			if(row>0)
				System.out.println("Class cancelled Successfully");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
}
