package FitnessAppmanagement;

import java.util.Scanner;

public class MemberServiceDisplay {
	
	public void Membermethoddisplay() throws Exception {
		boolean condition = true;
		Scanner scanner = new Scanner(System.in);
		Member_Management mem = new Member_Management();
		
	// Member Service Display Page 
		
		do {
		System.out.println("******************************");
		System.out.println("welcome to Member Management");
		System.out.println("Select Any One Options Below");
		
		System.out.println("1. Register a new member");
		System.out.println("2. View member details");
		System.out.println("3. Update member information");
		System.out.println("4. Delete member information");
		System.out.println("5. Exit ");
		int choice = scanner.nextInt();
		switch (choice){
		case 1: {
			mem.registermember();
			System.out.println();
			break;
		}
		case 2:{
			mem.viewmember();
			System.out.println();
			break;
			
		}
		case 3 :{
			mem.updatemember();
			System.out.println();
			break;
		}
		case 4:{
			mem.deletemember();
			System.out.println();
			break;
		}
		case 5:{
			System.out.println("Redirecting to Main...");
			System.out.println();
			Thread.sleep(3000);
			condition = false;
			Main.main(null);	
			break ;
		}
		default:
			System.err.println("please provice valid input");
		}
			
		} while (condition);
		
		scanner.close();
	}

}
