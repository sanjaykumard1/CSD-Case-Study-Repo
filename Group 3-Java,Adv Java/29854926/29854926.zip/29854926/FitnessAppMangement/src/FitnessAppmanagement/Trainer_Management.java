package FitnessAppmanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Trainer_Management {

	
static Scanner scanner = new Scanner(System.in);
	
	// New User Registration -->
	public void registrTrainer() throws Exception {
		System.out.println("Enter your name");
		String name = scanner.nextLine();
		
		System.out.println("Enter your email id");
		String email = scanner.next();
		if(email.endsWith(".com")){
			System.out.println("Validating Email Please Wait....");
			
			Thread.sleep(2000);
			
			System.out.println("Valid Email");
		}
		else {
			throw new Exception("Invalid Email");
		}
		System.out.println();
			
		System.out.println("Enter phone number");
		String mobile = scanner.next();
		
		System.out.println("Validating mobile number....");
		
		Thread.sleep(2000);

		if(mobile.length()==10) {
			
			System.out.println("Valid Mobile number");
		}
		else {
			throw new Exception("Invalid Movile Number");
		}
		
		System.out.println();
		
		System.out.println("Enter your Specialization");
		String Specialization = scanner.next();
		
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = "Insert into trainer(Trainer_name,email,phone_number,Specialization) values (?,?,?,?)";
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, mobile);
			ps.setString(4, Specialization);
			
			
			int rowsadded = ps.executeUpdate();
			if(rowsadded>0) {
				System.out.println("Data Added successfully");
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	// View Details -->
	public void viewtrainer() {
		System.out.println("Enter Trainer id ");
		int id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = ("Select * from trainer where trainer_id =?");
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			if( rs.next()){
				System.out.println("Trainer_id : "+rs.getInt("Trainer_id"));
				System.out.println("Trainer_name : "+rs.getString("Trainer_name"));
				System.out.println("Email : "+rs.getString("email"));
				System.out.println("Phone Number : "+rs.getString("phone_number"));
				System.out.println("Specialization : "+rs.getString("specialization"));
			}
			else {
				System.out.println("Data Not Found");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}
	
	// Update Details -->
	
	public void updateTrainerinfo() throws Exception {
		System.out.println("Enter the Trainer id");
		int id =scanner.nextInt();
		scanner.nextLine();
		
		System.out.println();
		
		System.out.println("Enter your email id");
		String email = scanner.next();
		if(email.endsWith(".com")){
			System.out.println("Validating Email Please Wait....");
			
			Thread.sleep(2000);
			
			System.out.println("Valid Email");
		}
		else {
			throw new Exception("Invalid Email");
		}
		System.out.println();
			
		
		
		System.out.println("Enter phone number");
		String mobile = scanner.next();
		
		System.out.println("Validating mobile number....");
		
		Thread.sleep(2000);

		if(mobile.length()==10) {
			
			System.out.println("Valid Mobile number");
		}
		else {
			throw new Exception("Invalid Movile Number");
		}
		
		System.out.println();
		
		
		System.out.println("Enter Specialization ");
		String specializeString = scanner.next();
		
		try {
			Connection connection =SqlConnection.getconnection();
			String query ="UPDATE trainer  SET email = ?, phone_number = ?, specialization = ? WHERE trainer_id = ?";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, mobile);
			ps.setString(3, specializeString);
			ps.setInt(4, id);
			
			
			
			int rowupdate = ps.executeUpdate();
			if(rowupdate>0) {
				System.out.println("Trainer Data Updated Successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	
	// Delete Trainer;
	
	public void deletetrainer() {
		
		System.out.println("Enter Trainer ID ");
		int id = scanner.nextInt();
		
		try {
			Connection connection = SqlConnection.getconnection();
			String queryString = "DELETE FROM trainer WHERE trainer_id = ?";
			PreparedStatement ps = connection.prepareStatement(queryString);
			ps.setInt(1,id);
			
			int update = ps.executeUpdate();
			if(update>0)
				System.out.println("Trainer Data Deleted");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}

