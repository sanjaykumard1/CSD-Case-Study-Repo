package FitnessAppmanagement;

import java.util.Scanner;

public class TrainerServiceDisplay {
	
	public void trainnerService() throws Exception {
		
		boolean condition = true;
		Scanner scanner = new Scanner(System.in);
		Trainer_Management train = new Trainer_Management();
		
	// Trainer Service Display Page 
		
		do {
		System.out.println("******************************");
		System.out.println("welcome to Trainer Management");
		System.out.println("Select Any One Options Below");
		
		System.out.println("1. Register a new Trainer");
		System.out.println("2. View Trainer details");
		System.out.println("3. Update Trainer information");
		System.out.println("4. Delete Trainer information");
		System.out.println("5. Exit ");
		int choice = scanner.nextInt();
		switch (choice){
		case 1: {
			train.registrTrainer();
			System.out.println();
			break;
		}
		case 2:{
			train.viewtrainer();
			System.out.println();
			break;
			
		}
		case 3 :{
			train.updateTrainerinfo();
			System.out.println();
			break;
		}
		case 4:{
			train.deletetrainer();
			System.out.println();
			break;
		}
		case 5:{
			System.out.println("Redirecting to Main...");
			Thread.sleep(3000);
			condition = false;
			Main.main(null);	
			break;
		}
		default:
			System.err.println("please provice valid input");
		}
			
		} while (condition);
		scanner.close();
		
	}

}
