!! Read Me !!

Hi all,
This application is a Fitness Management System where we have 3 modules 
1. Member management 2. Trainer Management 3. Class Management using JDBC API.

How to Run ::

Step  1 : Make sure that we have installed the mysql-connector jar file as referenced libraries 
Step  2 : Run the Main.java located in the FitnessAppManagement package.
step  3 : The Program works in a console based application.


How it works ::
This projects has 8 java class files to run the application in a understandable way.
So the project flow is first the main.java file will be executed where the three major management will be displayed 
based on the user input choices the application will redirect into service display pages 
Service display pages contains the CRUD operations display menus again based on the input of users it will be redirected to management_function pages 
where I have written all the function code for the three modules. Additional in order to get some live application fee i have use sleep thread function. and also all the internal exit
function will redirect to main function.

Tree directory ::
      |->main.java
                  |-> memberservicedisplay || classservicedisplay || trainerservicedisplay (based on user input)
                  
                  																		|-> classManagement || Membermanagement || trainermanagement (based on user input)			
                  																

If Any issues found please let me know

Thank You !! and Enjoy the Application !!