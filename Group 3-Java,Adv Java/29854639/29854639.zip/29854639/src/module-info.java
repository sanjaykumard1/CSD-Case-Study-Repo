/**
 * 
 */
/**
 * 
 */
module Clinic_Management_System {
	requires java.sql;
}