package ecomerce;

import java.sql.*;
import java.util.Scanner;

public class OrderManagement {
    public static void manageOrders(Scanner scanner) {
        int choice;
        do {
            System.out.println("1. Create a new order");
            System.out.println("2. View order details");
            System.out.println("3. Update order information");
            System.out.println("4. Cancel an order");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    createOrder(scanner);
                    break;
                case 2:
                    viewOrder(scanner);
                    break;
                case 3:
                    updateOrder(scanner);
                    break;
                case 4:
                    cancelOrder(scanner);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void createOrder(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO `Order` (customer_id, order_date, total_amount, status) VALUES (?, NOW(), 0, 'pending')",
                    Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, customerId);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    int orderId = rs.getInt(1);
                    double totalAmount = 0;
                    while (true) {
                        System.out.print("Enter product ID (or 0 to finish): ");
                        int productId = scanner.nextInt();
                        if (productId == 0) break;

                        System.out.print("Enter quantity: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine();

                        double price;
                        try (PreparedStatement productStmt = conn.prepareStatement(
                                "SELECT price, quantity_in_stock FROM Product WHERE product_id = ?")) {
                            productStmt.setInt(1, productId);
                            ResultSet productRs = productStmt.executeQuery();
                            if (productRs.next()) {
                                price = productRs.getDouble("price");
                                int quantityInStock = productRs.getInt("quantity_in_stock");
                                if (quantity > quantityInStock) {
                                    System.out.println("Insufficient stock. Available quantity: " + quantityInStock);
                                    continue;
                                }
                            } else {
                                System.out.println("Product not found.");
                                continue;
                            }
                        }

                        try (PreparedStatement orderItemStmt = conn.prepareStatement(
                                "INSERT INTO OrderItem (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)")) {
                            orderItemStmt.setInt(1, orderId);
                            orderItemStmt.setInt(2, productId);
                            orderItemStmt.setInt(3, quantity);
                            orderItemStmt.setDouble(4, price);
                            orderItemStmt.executeUpdate();
                        }

                        try (PreparedStatement updateStockStmt = conn.prepareStatement(
                                "UPDATE Product SET quantity_in_stock = quantity_in_stock - ? WHERE product_id = ?")) {
                            updateStockStmt.setInt(1, quantity);
                            updateStockStmt.setInt(2, productId);
                            updateStockStmt.executeUpdate();
                        }

                        totalAmount += price * quantity;
                    }

                    try (PreparedStatement updateOrderStmt = conn.prepareStatement(
                            "UPDATE `Order` SET total_amount = ? WHERE order_id = ?")) {
                        updateOrderStmt.setDouble(1, totalAmount);
                        updateOrderStmt.setInt(2, orderId);
                        updateOrderStmt.executeUpdate();
                    }

                    conn.commit();
                    System.out.println("Order created successfully.");
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//




    private static void viewOrder(Scanner scanner) {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT o.order_id, o.customer_id, o.order_date, o.total_amount, o.status, " +
                             "oi.order_item_id, oi.product_id, oi.quantity, oi.price, p.name " +
                             "FROM `Order` o " +
                             "JOIN OrderItem oi ON o.order_id = oi.order_id " +
                             "JOIN Product p ON oi.product_id = p.product_id " +
                             "WHERE o.order_id = ?")) {
            stmt.setInt(1, orderId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Order Date: " + rs.getTimestamp("order_date"));
                System.out.println("Total Amount: " + rs.getDouble("total_amount"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("Order Items:");
                do {
                    System.out.println("  Order Item ID: " + rs.getInt("order_item_id"));
                    System.out.println("  Product ID: " + rs.getInt("product_id"));
                    System.out.println("  Product Name: " + rs.getString("name"));
                    System.out.println("  Quantity: " + rs.getInt("quantity"));
                    System.out.println("  Price: " + rs.getDouble("price"));
                } while (rs.next());
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//
    private static void updateOrder(Scanner scanner) {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new status (pending/confirmed/shipped/delivered/cancelled): ");
        String status = scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE `Order` SET status = ? WHERE order_id = ?")) {
            stmt.setString(1, status);
            stmt.setInt(2, orderId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Order updated successfully.");
            } else {
                System.out.println("Order not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//
    private static void cancelOrder(Scanner scanner) {
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement updateOrderStmt = conn.prepareStatement(
                    "UPDATE `Order` SET status = 'cancelled' WHERE order_id = ?")) {
                updateOrderStmt.setInt(1, orderId);
                int rowsAffected = updateOrderStmt.executeUpdate();
                if (rowsAffected > 0) {
                    try (PreparedStatement orderItemStmt = conn.prepareStatement(
                            "SELECT product_id, quantity FROM OrderItem WHERE order_id = ?")) {
                        orderItemStmt.setInt(1, orderId);
                        ResultSet rs = orderItemStmt.executeQuery();
                        while (rs.next()) {
                            int productId = rs.getInt("product_id");
                            int quantity = rs.getInt("quantity");

                            try (PreparedStatement updateStockStmt = conn.prepareStatement(
                                    "UPDATE Product SET quantity_in_stock = quantity_in_stock + ? WHERE product_id = ?")) {
                                updateStockStmt.setInt(1, quantity);
                                updateStockStmt.setInt(2, productId);
                                updateStockStmt.executeUpdate();
                            }
                        }
                    }

                    conn.commit();
                    System.out.println("Order cancelled successfully.");
                } else {
                    System.out.println("Order not found.");
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

