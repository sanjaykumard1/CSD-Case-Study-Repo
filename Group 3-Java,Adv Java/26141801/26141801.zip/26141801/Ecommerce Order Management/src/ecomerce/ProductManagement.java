package ecomerce;

import java.sql.*;
import java.util.Scanner;

public class ProductManagement {
    public static void manageProducts(Scanner scanner) {
        int choice;
        do {
            System.out.println("1. Add a new product");
            System.out.println("2. View product details");
            System.out.println("3. Update product information");
            System.out.println("4. Delete a product");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addProduct(scanner);
                    break;
                case 2:
                    viewProduct(scanner);
                    break;
                case 3:
                    updateProduct(scanner);
                    break;
                case 4:
                    deleteProduct(scanner);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }



    private static void addProduct(Scanner scanner) {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter quantity in stock: ");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO Product (name, description, price, quantity_in_stock) VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setInt(4, quantityInStock);
            stmt.executeUpdate();
            System.out.println("Product added successfully.");
        } catch (SQLException e) {
            System.out.println("Error Occured..."+ e);
        }
    }



    private static void viewProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Product WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("***********************************************");
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Quantity in Stock: " + rs.getInt("quantity_in_stock"));
                System.out.println("***********************************************");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    private static void updateProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new product name (leave blank to keep current): ");
        String name = scanner.nextLine();
        System.out.print("Enter new product description (leave blank to keep current): ");
        String description = scanner.nextLine();
        System.out.print("Enter new product price (leave blank to keep current): ");
        String priceStr = scanner.nextLine();
        System.out.print("Enter new quantity in stock (leave blank to keep current): ");
        String quantityStr = scanner.nextLine();

        StringBuilder query = new StringBuilder("UPDATE Product SET ");
        boolean first = true;

        if (!name.isEmpty()) {
            query.append("name = '").append(name).append("'");
            first = false;
        }
        if (!description.isEmpty()) {
            if (!first) query.append(", ");
            query.append("description = '").append(description).append("'");
            first = false;
        }
        if (!priceStr.isEmpty()) {
            if (!first) query.append(", ");
            query.append("price = ").append(Double.parseDouble(priceStr));
            first = false;
        }
        if (!quantityStr.isEmpty()) {
            if (!first) query.append(", ");
            query.append("quantity_in_stock = ").append(Integer.parseInt(quantityStr));
        }
        query.append(" WHERE product_id = ").append(productId);

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            int rowsAffected = stmt.executeUpdate(query.toString());
            if (rowsAffected > 0) {
                System.out.println("Product updated successfully.");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
              System.out.println("Error Occured... " +e);
        }
        System.out.println("***********************************************");

    }



    private static void deleteProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Product WHERE product_id = ?")) {
            stmt.setInt(1, productId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product deleted successfully.");
            } else {
                System.out.println("Product not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
