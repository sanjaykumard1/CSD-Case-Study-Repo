package ecomerce;

import java.sql.*;
import java.util.Scanner;

public class CustomerManagement {
    public static void manageCustomers(Scanner scanner) {
        int choice;
        do {
            System.out.println("1. Add a new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete a customer");
            System.out.println("5. Back to main menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addCustomer(scanner);
                    break;
                case 2:
                    viewCustomer(scanner);
                    break;
                case 3:
                    updateCustomer(scanner);
                    break;
                case 4:
                    deleteCustomer(scanner);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void addCustomer(Scanner scanner) {
        System.out.println("***********************************************");
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)")) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, address);
            stmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            System.out.println("Error Occured... "+e);
        }
    }



    private static void viewCustomer(Scanner scanner) {
        System.out.println("***********************************************");

        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Customer WHERE customer_id = ?")) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("***********************************************");

    }




    private static void updateCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter new customer name (leave blank to keep current): ");
        String name = scanner.nextLine();
        System.out.print("Enter new customer email (leave blank to keep current): ");
        String email = scanner.nextLine();
        System.out.print("Enter new customer phone number (leave blank to keep current): ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter new customer address (leave blank to keep current): ");
        String address = scanner.nextLine();

        StringBuilder query = new StringBuilder("UPDATE Customer SET ");
        boolean first = true;

        if (!name.isEmpty()) {
            query.append("name = '").append(name).append("'");
            first = false;
        }
        if (!email.isEmpty()) {
            if (!first) query.append(", ");
            query.append("email = '").append(email).append("'");
            first = false;
        }
        if (!phoneNumber.isEmpty()) {
            if (!first) query.append(", ");
            query.append("phone_number = '").append(phoneNumber).append("'");
            first = false;
        }
        if (!address.isEmpty()) {
            if (!first) query.append(", ");
            query.append("address = '").append(address).append("'");
        }
        query.append(" WHERE customer_id = ").append(customerId);

        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            int rowsAffected = stmt.executeUpdate(query.toString());
            if (rowsAffected > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




    private static void deleteCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM Customer WHERE customer_id = ?")) {
            stmt.setInt(1, customerId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
