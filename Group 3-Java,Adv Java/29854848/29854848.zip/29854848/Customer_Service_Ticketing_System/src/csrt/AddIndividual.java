package csrt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import csrt.exception.InvalidFieldException;

public class AddIndividual {

	// Adding a new customer to the database.

	private static Scanner scanner = new Scanner(System.in);

	public static void addCustomer() throws InvalidFieldException  {
		System.out.print("Enter customer name: ");
		String name = scanner.nextLine();
		System.out.print("Enter customer email: ");
		String email = scanner.nextLine();
		
		if(name=="" ||  email=="") {
			throw new InvalidFieldException ("Either of name or email is empty");
			
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "INSERT INTO Customer (name, email) VALUES (?, ?)";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1, name);
				stmt.setString(2, email);
				
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Customer added successfully.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Adding a new representative to the database.

	public static void addRepresentative() throws InvalidFieldException  {
		System.out.print("Enter representative name: ");
		String name = scanner.nextLine();
		System.out.print("Enter representative email: ");
		String email = scanner.nextLine();
		if(name=="" ||  email=="") {
			throw new InvalidFieldException ("Either of name or email is empty");
			
		}

		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "INSERT INTO Representative (name, email) VALUES (?, ?)";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1, name);
				stmt.setString(2, email);
				
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Representative added successfully.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
