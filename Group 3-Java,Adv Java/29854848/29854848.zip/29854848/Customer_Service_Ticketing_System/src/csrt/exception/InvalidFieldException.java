package csrt.exception;

public class InvalidFieldException extends Exception {
	
	String msg;
	
	public InvalidFieldException(String msg)
	{
		super(msg);
		this.msg=msg;
	}

}
