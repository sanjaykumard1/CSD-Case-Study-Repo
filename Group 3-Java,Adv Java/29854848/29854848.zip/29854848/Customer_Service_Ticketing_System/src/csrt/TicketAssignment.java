package csrt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import csrt.exception.InvalidFieldException;

//class containing methods for assignment of ticket.

public class TicketAssignment {
	private static Scanner scanner = new Scanner(System.in);

	// Assigns a ticket to a customer service representative.

	public static void assignTicket() throws InvalidFieldException {
		System.out.print("Enter ticket ID: ");
		int ticketId = scanner.nextInt();
		System.out.print("Enter representative ID: ");
		int representativeId = scanner.nextInt();
		scanner.nextLine(); 
		
		if(ticketId<=0 || representativeId<=0) {
			throw new InvalidFieldException("Either of ticket id or representative id less than equal to zero");
		}

		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "INSERT INTO Assignment (ticket_id, representative_id, assignment_date, status) VALUES (?, ?, CURDATE(), 'Assigned')";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, ticketId);
				stmt.setInt(2, representativeId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Ticket assigned successfully.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Views all assigned tickets.

	public static void viewAssignedTickets() {
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "SELECT * FROM Assignment";
			try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
				while (rs.next()) {
					System.out.println("Assignment ID: " + rs.getInt("assignment_id"));
					System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
					System.out.println("Representative ID: " + rs.getInt("representative_id"));
					System.out.println("Assignment Date: " + rs.getDate("assignment_date"));
					System.out.println("Status: " + rs.getString("status"));
					System.out.println("----");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Updates assignment information of a ticket.

	public static void updateAssignmentInformation() throws InvalidFieldException {
		System.out.print("Enter assignment ID: ");
		int assignmentId = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		System.out.print("Enter new status: ");
		String status = scanner.nextLine();
		
		if(assignmentId<=0 || status=="")
		{
			throw new InvalidFieldException("Either assignment id is less than equal to zero or status is empty");
		}

		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "UPDATE Assignment SET status = ? WHERE assignment_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1, status);
				stmt.setInt(2, assignmentId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Assignment updated successfully.");
				} else {
					System.out.println("Assignment not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Deletes an assignment record.

	public static void deleteAssignmentRecords() throws InvalidFieldException {
		System.out.print("Enter assignment ID: ");
		int assignmentId = scanner.nextInt();
		if(assignmentId<=0)
		{
			throw new InvalidFieldException("assignment id is less than equal to zero");
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "DELETE FROM Assignment WHERE assignment_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, assignmentId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Assignment deleted successfully.");
				} else {
					System.out.println("Assignment not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
