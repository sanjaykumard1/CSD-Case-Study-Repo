package csrt;

import java.util.Scanner;

import csrt.exception.InvalidFieldException;

// Main loop for menu-driven interaction

public class CustomerServiceApp {

	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args)   {
		while (true) {
			System.out.println("\nCustomer Service Ticketing System");
			System.out.println("1. Add New Customer");
			System.out.println("2. Add New Representative");
			System.out.println("3. Create Ticket");
			System.out.println("4. View Ticket Details");
			System.out.println("5. Update Ticket Information");
			System.out.println("6. Delete Ticket");
			System.out.println("7. Assign Ticket");
			System.out.println("8. View Assigned Tickets");
			System.out.println("9. Update Assignment Information");
			System.out.println("10. Delete Assignment Records");
			System.out.println("11. Resolve Ticket");
			System.out.println("12. View Resolved Tickets");
			System.out.println("13. Update Resolution Information");
			System.out.println("14. Delete Resolution Records");
			System.out.println("0. Exit");
			System.out.print("Choose an option: ");
			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume newline
			
			
			switch (choice) {
			case 1:
				
				try {
					AddIndividual.addCustomer();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
			case 2:
				try {
					AddIndividual.addRepresentative();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					TicketCreation.createTicket();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				try {
					TicketCreation.viewTicketDetails();
				} catch (InvalidFieldException  e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 5:
				try {
					TicketCreation.updateTicketInformation();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 6:
				try {
					TicketCreation.deleteTicket();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 7:
				try {
					TicketAssignment.assignTicket();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 8:
				TicketAssignment.viewAssignedTickets();
				break;
			case 9:
				try {
					TicketAssignment.updateAssignmentInformation();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 10:
				try {
					TicketAssignment.deleteAssignmentRecords();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 11:
				try {
					TicketResolution.resolveTicket();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 12:
				TicketResolution.viewResolvedTickets();
				break;
			case 13:
				try {
					TicketResolution.updateResolutionInformation();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 14:
				try {
					TicketResolution.deleteResolutionRecords();
				} catch (InvalidFieldException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 0:
				System.exit(0);
			default:
				System.out.println("Invalid option. Please try again.");
			}
			
		}
		
	}

}
