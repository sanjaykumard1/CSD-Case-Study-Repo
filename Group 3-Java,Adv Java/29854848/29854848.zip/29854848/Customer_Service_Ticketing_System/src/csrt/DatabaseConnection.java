package csrt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Establishes a connection to the database.


// Database connection parameters
public class DatabaseConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/cstm";
	private static final String USER = "root"; // MySQL user name
	private static final String PASSWORD = "Deepak@2024"; // MySQL pass word

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}
}
