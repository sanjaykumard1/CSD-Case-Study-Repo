package csrt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import csrt.exception.InvalidFieldException;

// class containing methods for creation of ticket.
public class TicketCreation {

	private static Scanner scanner = new Scanner(System.in);

	// Creates a new customer service ticket.

	public static void createTicket() throws InvalidFieldException  {
		System.out.print("Enter customer ID: ");
		int customerId = scanner.nextInt();
		scanner.nextLine(); 
		System.out.print("Enter issue description: ");
		String issueDescription = scanner.nextLine();
		if(customerId<=0 ||  issueDescription=="") {
			throw new InvalidFieldException("Either of customer is less than or equal to zero or issue description is empty");
			
		}


		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "INSERT INTO Ticket (customer_id, creation_date, issue_description, status) VALUES (?, CURDATE(), ?, 'Open')";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, customerId);
				stmt.setString(2, issueDescription);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Ticket created successfully.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

// Views the details of a specified ticket.

	public static void viewTicketDetails() throws InvalidFieldException  {
		System.out.print("Enter ticket ID: ");
		int ticketId = scanner.nextInt();
		if(ticketId<=0 ) {
			throw new InvalidFieldException("Ticket ID less than equal to zero");
			
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "SELECT * FROM Ticket WHERE ticket_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, ticketId);
				try (ResultSet rs = stmt.executeQuery()) {
					if (rs.next()) {
						System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
						System.out.println("Customer ID: " + rs.getInt("customer_id"));
						System.out.println("Creation Date: " + rs.getDate("creation_date"));
						System.out.println("Issue Description: " + rs.getString("issue_description"));
						System.out.println("Status: " + rs.getString("status"));
					} else {
						System.out.println("Ticket not found.");
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

// Updates information of an existing ticket.

	public static void updateTicketInformation() throws InvalidFieldException {
		System.out.print("Enter ticket ID: ");
		int ticketId = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		System.out.print("Enter new issue description: ");
		String issueDescription = scanner.nextLine();
		System.out.print("Enter new status: ");
		String status = scanner.nextLine();
		if(ticketId<=0 ||  issueDescription==""  || status=="") {
			throw new InvalidFieldException("Either of ticket is less than or equal to zero or issue description or status is empty");
			
		}


		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "UPDATE Ticket SET issue_description = ?, status = ? WHERE ticket_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1, issueDescription);
				stmt.setString(2, status);
				stmt.setInt(3, ticketId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Ticket updated successfully.");
				} else {
					System.out.println("Ticket not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

// Deletes a specified ticket.

	public static void deleteTicket() throws InvalidFieldException {
		System.out.print("Enter ticket ID: ");
		int ticketId = scanner.nextInt();

		if(ticketId<=0)
		{
			throw new InvalidFieldException("Ticket id is less than or equal to zero");
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "DELETE FROM Ticket WHERE ticket_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, ticketId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Ticket deleted successfully.");
				} else {
					System.out.println("Ticket not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}