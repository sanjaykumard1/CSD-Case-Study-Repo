package csrt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import csrt.exception.InvalidFieldException;

//class containing methods for ticket resolution.

public class TicketResolution {

	private static Scanner scanner = new Scanner(System.in);

	// Resolves a customer service ticket.

	public static void resolveTicket() throws InvalidFieldException {
		System.out.print("Enter ticket ID: ");
		int ticketId = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		System.out.print("Enter resolution details: ");
		String resolutionDetails = scanner.nextLine();
		if(ticketId<=0 ||resolutionDetails=="" )
		{
			throw new InvalidFieldException("Ticket id is less than or equal to zero or empty resolution details");
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "INSERT INTO Resolution (ticket_id, resolution_date, resolution_details, status) VALUES (?, CURDATE(), ?, 'Resolved')";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, ticketId);
				stmt.setString(2, resolutionDetails);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Ticket resolved successfully.");
				}
			}

			String updateSql = "UPDATE Ticket SET status = 'Resolved' WHERE ticket_id = ?";
			try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
				updateStmt.setInt(1, ticketId);
				updateStmt.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Views all resolved tickets.

	public static void viewResolvedTickets() {
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "SELECT * FROM Resolution";
			try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
				while (rs.next()) {
					System.out.println("Resolution ID: " + rs.getInt("resolution_id"));
					System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
					System.out.println("Resolution Date: " + rs.getDate("resolution_date"));
					System.out.println("Resolution Details: " + rs.getString("resolution_details"));
					System.out.println("Status: " + rs.getString("status"));
					System.out.println("----");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Updates information of an existing resolution record.

	public static void updateResolutionInformation() throws InvalidFieldException {
		System.out.print("Enter resolution ID: ");
		int resolutionId = scanner.nextInt();
		scanner.nextLine(); // Consume newline
		System.out.print("Enter new resolution details: ");
		String resolutionDetails = scanner.nextLine();
		System.out.print("Enter new status: ");
		String status = scanner.nextLine();
		
		if(resolutionId<=0 ||resolutionDetails=="" || status=="" )
		{
			throw new InvalidFieldException("Either resolution id is less than or equal to zero or empty resolution details or status");
		}

		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "UPDATE Resolution SET resolution_details = ?, status = ? WHERE resolution_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setString(1, resolutionDetails);
				stmt.setString(2, status);
				stmt.setInt(3, resolutionId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Resolution updated successfully.");
				} else {
					System.out.println("Resolution not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// Deletes a resolved ticket record.

	public static void deleteResolutionRecords() throws InvalidFieldException {
		System.out.print("Enter resolution ID: ");
		int resolutionId = scanner.nextInt();
		if(resolutionId<=0)
		{
			throw new InvalidFieldException("resolution id is less than or equal to zero");
		}
		try (Connection conn = DatabaseConnection.getConnection()) {
			String sql = "DELETE FROM Resolution WHERE resolution_id = ?";
			try (PreparedStatement stmt = conn.prepareStatement(sql)) {
				stmt.setInt(1, resolutionId);
				int rowsAffected = stmt.executeUpdate();
				if (rowsAffected > 0) {
					System.out.println("Resolution deleted successfully.");
				} else {
					System.out.println("Resolution not found.");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
