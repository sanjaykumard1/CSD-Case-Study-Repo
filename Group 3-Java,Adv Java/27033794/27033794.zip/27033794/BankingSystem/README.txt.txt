# Banking System Project

## Candidate ID: 27033794

### Project Description
This project is a simple banking system implemented in Java, with MySQL as the database. It allows for basic banking operations such as adding customer accounts, viewing account details, updating account information, closing accounts, depositing funds, withdrawing funds, transferring funds, and viewing transaction history.

### Prerequisites
- Java Development Kit (JDK)
- MySQL Database
- IDE (IntelliJ IDEA, Eclipse, etc.)
- MySQL JDBC Connector

### Setup Instructions
1. Clone the repository to your local machine.
2. Open the project in your IDE.
3. Add the MySQL JDBC Connector to your project classpath.
4. Create the database and tables by running the provided SQL script.
5. Update the JDBC connection details in `BankingSystem.java` with your MySQL credentials.
6. Compile and run the project.

### Usage Instructions
1. Run the `BankingSystem` class.
2. Follow the on-screen menu to perform various banking operations.

### Contact
For any questions, please contact Varun Sharma at varunsharma0380@gmail.com .