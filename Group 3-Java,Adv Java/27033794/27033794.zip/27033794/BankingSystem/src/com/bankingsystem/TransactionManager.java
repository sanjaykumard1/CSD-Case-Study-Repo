package com.bankingsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TransactionManager {
    public void deposit(int accountId, double amount) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            // Update account balance
            String sqlUpdate = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
            try (PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
                pstmtUpdate.setDouble(1, amount);
                pstmtUpdate.setInt(2, accountId);
                pstmtUpdate.executeUpdate();
            }

            // Record transaction
            String sqlInsert = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Deposit', ?)";
            try (PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert)) {
                pstmtInsert.setInt(1, accountId);
                pstmtInsert.setDouble(2, amount);
                pstmtInsert.executeUpdate();
            }

            conn.commit();
            System.out.println("Deposit successful.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void withdraw(int accountId, double amount) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            // Check if sufficient balance is available
            String sqlCheckBalance = "SELECT balance FROM Account WHERE account_id = ?";
            try (PreparedStatement pstmtCheckBalance = conn.prepareStatement(sqlCheckBalance)) {
                pstmtCheckBalance.setInt(1, accountId);
                ResultSet rs = pstmtCheckBalance.executeQuery();
                if (rs.next()) {
                    double balance = rs.getDouble("balance");
                    if (balance < amount) {
                        System.out.println("Insufficient balance.");
                        conn.rollback();
                        return;
                    }
                } else {
                    System.out.println("Account not found.");
                    conn.rollback();
                    return;
                }
            }

            // Update account balance
            String sqlUpdate = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
            try (PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate)) {
                pstmtUpdate.setDouble(1, amount);
                pstmtUpdate.setInt(2, accountId);
                pstmtUpdate.executeUpdate();
            }

            // Record transaction
            String sqlInsert = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Withdrawal', ?)";
            try (PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert)) {
                pstmtInsert.setInt(1, accountId);
                pstmtInsert.setDouble(2, amount);
                pstmtInsert.executeUpdate();
            }

            conn.commit();
            System.out.println("Withdrawal successful.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void transfer(int fromAccountId, int toAccountId, double amount) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            // Check if sufficient balance is available
            String sqlCheckBalance = "SELECT balance FROM Account WHERE account_id = ?";
            try (PreparedStatement pstmtCheckBalance = conn.prepareStatement(sqlCheckBalance)) {
                pstmtCheckBalance.setInt(1, fromAccountId);
                ResultSet rs = pstmtCheckBalance.executeQuery();
                if (rs.next()) {
                    double balance = rs.getDouble("balance");
                    if (balance < amount) {
                        System.out.println("Insufficient balance.");
                        conn.rollback();
                        return;
                    }
                } else {
                    System.out.println("From account not found.");
                    conn.rollback();
                    return;
                }
            }

            // Update from account balance
            String sqlUpdateFrom = "UPDATE Account SET balance = balance - ? WHERE account_id = ?";
            try (PreparedStatement pstmtUpdateFrom = conn.prepareStatement(sqlUpdateFrom)) {
                pstmtUpdateFrom.setDouble(1, amount);
                pstmtUpdateFrom.setInt(2, fromAccountId);
                pstmtUpdateFrom.executeUpdate();
            }

            // Update to account balance
            String sqlUpdateTo = "UPDATE Account SET balance = balance + ? WHERE account_id = ?";
            try (PreparedStatement pstmtUpdateTo = conn.prepareStatement(sqlUpdateTo)) {
                pstmtUpdateTo.setDouble(1, amount);
                pstmtUpdateTo.setInt(2, toAccountId);
                pstmtUpdateTo.executeUpdate();
            }

            // Record transaction for from account
            String sqlInsertFrom = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Transfer', ?)";
            try (PreparedStatement pstmtInsertFrom = conn.prepareStatement(sqlInsertFrom)) {
                pstmtInsertFrom.setInt(1, fromAccountId);
                pstmtInsertFrom.setDouble(2, amount);
                pstmtInsertFrom.executeUpdate();
            }

            // Record transaction for to account
            String sqlInsertTo = "INSERT INTO Transaction (account_id, transaction_type, amount) VALUES (?, 'Transfer', ?)";
            try (PreparedStatement pstmtInsertTo = conn.prepareStatement(sqlInsertTo)) {
                pstmtInsertTo.setInt(1, toAccountId);
                pstmtInsertTo.setDouble(2, amount);
                pstmtInsertTo.executeUpdate();
            }

            conn.commit();
            System.out.println("Transfer successful.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Transaction> getTransactionHistory(int accountId) {
        List<Transaction> transactions = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Transaction WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAccountId(rs.getInt("account_id"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getString("transaction_date"));
                transactions.add(transaction);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }
}
