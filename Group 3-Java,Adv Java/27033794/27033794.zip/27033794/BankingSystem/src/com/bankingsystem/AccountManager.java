package com.bankingsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountManager {
    public void addAccount(Account account) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Account (customer_id, account_type, balance) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, account.getCustomerId());
            pstmt.setString(2, account.getAccountType());
            pstmt.setDouble(3, account.getBalance());
            pstmt.executeUpdate();
            System.out.println("Account added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAccountDetails(int accountId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Account WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Account ID: " + rs.getInt("account_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Account Type: " + rs.getString("account_type"));
                System.out.println("Balance: " + rs.getDouble("balance"));
            } else {
                System.out.println("Account not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAccount(Account account) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE Account SET account_type = ?, balance = ? WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, account.getAccountType());
            pstmt.setDouble(2, account.getBalance());
            pstmt.setInt(3, account.getAccountId());
            pstmt.executeUpdate();
            System.out.println("Account updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeAccount(int accountId) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM Account WHERE account_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, accountId);
            pstmt.executeUpdate();
            System.out.println("Account closed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
