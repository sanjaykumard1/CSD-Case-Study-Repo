import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Item {
    private int id; // Unique identifier for the item
    private String name; // Name of the item
    private String description; // Description of the item
    private double startingPrice; // Starting price of the item for auction
    private double currentHighestBid; // Current highest bid on the item
    private boolean isAuctionOpen; // Flag indicating if the auction for the item is open or closed
    private LocalDateTime auctionEndTime; // Date and time when the auction for the item will end

    // Constructor to initialize an Item object
    public Item(int id, String name, String description, double startingPrice, LocalDateTime auctionEndTime) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startingPrice = startingPrice;
        this.currentHighestBid = startingPrice; // Initial highest bid equals starting price
        this.isAuctionOpen = false; // Auction is initially closed
        this.auctionEndTime = auctionEndTime;
    }

    // Getter for retrieving the item ID
    public int getId() {
        return id;
    }

    // Getter for retrieving the item name
    public String getName() {
        return name;
    }

    // Setter for updating the item name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for retrieving the item description
    public String getDescription() {
        return description;
    }

    // Setter for updating the item description
    public void setDescription(String description) {
        this.description = description;
    }

    // Getter for retrieving the starting price of the item
    public double getStartingPrice() {
        return startingPrice;
    }

    // Setter for updating the starting price of the item
    public void setStartingPrice(double startingPrice) {
        this.startingPrice = startingPrice;
    }

    // Getter for retrieving the current highest bid on the item
    public double getCurrentHighestBid() {
        return currentHighestBid;
    }

    // Setter for updating the current highest bid on the item
    public void setCurrentHighestBid(double currentHighestBid) {
        this.currentHighestBid = currentHighestBid;
    }

    // Getter for retrieving the auction open status of the item
    public boolean isAuctionOpen() {
        return isAuctionOpen;
    }

    // Setter for updating the auction open status of the item
    public void setAuctionOpen(boolean auctionOpen) {
        isAuctionOpen = auctionOpen;
    }

    // Getter for retrieving the auction end time of the item
    public LocalDateTime getAuctionEndTime() {
        return auctionEndTime;
    }

    // Setter for updating the auction end time of the item
    public void setAuctionEndTime(LocalDateTime auctionEndTime) {
        this.auctionEndTime = auctionEndTime;
    }

    /**
     * Calculates the time remaining until auction end in minutes.
     * @return Time remaining in minutes, or 0 if auction has ended.
     */
    public long getTimeRemainingMinutes() {
        if (!isAuctionOpen || auctionEndTime == null) {
            return 0; // Auction is closed or end time not set
        }
        LocalDateTime now = LocalDateTime.now();
        if (now.isAfter(auctionEndTime)) {
            return 0; // Auction has ended
        }
        return ChronoUnit.MINUTES.between(now, auctionEndTime);
    }

    // Override toString method to provide a formatted string representation of the Item object
    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return "Item{" +
                "\n  id=" + id +
                ",\n  name='" + name + '\'' +
                ",\n  description='" + description + '\'' +
                ",\n  startingPrice=" + startingPrice +
                ",\n  currentHighestBid=" + currentHighestBid +
                ",\n  isAuctionOpen=" + isAuctionOpen +
                ",\n  auctionEndTime=" + (auctionEndTime != null ? auctionEndTime.format(formatter) : "Not set") +
                ",\n  timeRemainingMinutes=" + getTimeRemainingMinutes() +
                "\n}";
    }

    // Override equals method to compare two Item objects based on their ID
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return id == item.id;
    }

    // Override hashCode method to generate a hash code for the Item object based on its ID
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
