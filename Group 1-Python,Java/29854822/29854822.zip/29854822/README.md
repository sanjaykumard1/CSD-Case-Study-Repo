## Online Auction System Documentation

### 1.How to Run the Application

#### Prerequisites

- Java Development Kit (JDK) installed (version 8 or higher).
- A Java IDE (such as IntelliJ IDEA, Eclipse, or NetBeans) or a text editor and command-line tools.

#### Steps to Run

**1.Clone or Download the Repository**:

Clone the repository using Git :

git clone <https://github.com/your-repo/online-auction-system.git>

Or download the ZIP file from the repository and extract it to your desired location.

**2.Open the Project in Your IDE**:

- Open your Java IDE.
- Import or open the project from the cloned/downloaded location.

**3.Compile the Code**:

- Ensure all necessary .java files are in the src folder.
- Compile the code in your IDE or via the command line: javac *.java

**4 Run the Application**:

- Run the OnlineAuctionSystem class in your IDE.
- Or run it from the command line : java OnlineAuctionSystem

### 2.Instructions for Each Feature

#### 1\. Add Item

- **Purpose**: Add a new item for auction.
- **Instructions**:
  - Select the "Add Item" option from the main menu.
  - Enter the item ID, name, description, and starting price as prompted.

#### **Example**

Enter your choice: 1

Enter item id: 101

Enter item name: laptop

Enter item description: High performance and gaming laptop

Enter starting price: 33000

Item added successfully: Item{

id=101,

name='Laptop',

description='High performance and gaming laptop',

startingPrice=33000.0,

currentHighestBid=33000.0,

isAuctionOpen=false,

auctionEndTime=Not set,

timeRemainingMinutes=0

#### }
2. Remove Item

- **Purpose**: Remove an existing item from the auction.
- **Instructions**:
  - Select the "Remove Item" option from the main menu.
  - Enter the item ID to remove.
- ****Example****

Enter your choice: 2

Enter item id to remove: 201

#### Item removed successfully. Item ID: 201

#### 3.Update Item

- **Purpose**: Update details of an existing item.
- **Instructions**:
  - Select the "Update Item" option from the main menu.
  - Enter the item ID, followed by the new name, description, and starting price.
- **Example**

Enter your choice: 3

Enter item id to update: 101

Enter new item name: A gaming Laptop

Enter new item description: Equipped with the latest Intel Core i7 processor .

Enter new starting price: 38000

Item updated successfully: Item{

id=101,

name='A gaming Laptop',

description='Equipped with the latest Intel Core i7 processor .',

startingPrice=38000.0,

currentHighestBid=38000.0,

isAuctionOpen=false,

auctionEndTime=Not set,

timeRemainingMinutes=0

#### }

#### 4\. Start Auction

- **Purpose**: Start an auction for an item.
- **Instructions**:
  - Select the "Start Auction" option from the main menu.
  - Enter the item ID to start the auction.
- **Example**

Enter item id to start auction: 101

Auction started for item: Item{

id=101,

name='A gaming Laptop',

description='Equipped with the latest Intel Core i7 processor .',

startingPrice=38000.0,

currentHighestBid=38000.0,

isAuctionOpen=true,

auctionEndTime=2024-07-14 21:04:56,

timeRemainingMinutes=29

#### }
5. End Auction

- **Purpose**: End an ongoing auction for an item.
- **Instructions**:
  - Select the "End Auction" option from the main menu.
  - Enter the item ID to end the auction.
- **Example**

Auction ended for item: Item{

id=101,

name='A gaming Laptop',

description='Equipped with the latest Intel Core i7 processor .',

startingPrice=38000.0,

currentHighestBid=39000.0,

isAuctionOpen=false,

auctionEndTime=2024-07-14 21:04:56,

timeRemainingMinutes=0

}

#### 6\. Place Bid

- **Purpose**: Place a bid on an item.
- **Instructions**:
  - Select the "Place Bid" option from the main menu.
  - Enter the item ID, user ID, and bid amount as prompted.

**Example**

Enter your choice: 6

Enter item id to place bid: 101

Enter user id: 111

Enter bid amount: 5490

Bid amount is too low. Current highest bid: 38000.0

Enter a higher bid amount: 39000

#### Bid placed successfully: Bid{id=1, itemId=101, userId=111, bidAmount=39000.0, bidDateTime=2024-07-14T20:36:08.889530100}

#### 7\. View Auction Status

- **Purpose**: View the status of ongoing auctions.
- **Instructions**:
  - Select the "View Auction Status" option from the main menu.
- **Example**

Enter your choice: 7

Viewing auction status:

Item{

id=101,

name='A gaming Laptop',

description='Equipped with the latest Intel Core i7 processor .',

startingPrice=38000.0,

currentHighestBid=76000.0,

isAuctionOpen=true,

auctionEndTime=2024-07-14 21:08:18,

timeRemainingMinutes=29

}

Time remaining in auction: 29 minutes

Highest bid for this item is: 76000.0

Bid{id=1, itemId=101, userId=111, bidAmount=39000.0, bidDateTime=2024-07-14T20:36:08.889530100}

Bid{id=2, itemId=101, userId=222, bidAmount=76000.0, bidDateTime=2024-07-14T20:38:50.764237100}

#### 8\. View Items

- **Purpose**: View all items available for auction.
- **Instructions**:
  - Select the "View Items" option from the main menu.
- **Example**:

Enter your choice: 8

Viewing all items for auction:

Item{

id=101,

name='A gaming Laptop',

description='Equipped with the latest Intel Core i7 processor .',

startingPrice=38000.0,

currentHighestBid=76000.0,

isAuctionOpen=true,

auctionEndTime=2024-07-14 21:08:18,

timeRemainingMinutes=28

}

#### 9\. Exit

- **Purpose**: Exit the application.
- **Instructions**:
  - Select the "Exit" option from the main menu.
- **Example**

Enter your choice: 9

Online Auction has Ended !

### 3.Exception Handling

**1.Invalid Input Handling**:

- The application ensures that user inputs are validated for integers where required. If the user enters an invalid input, such as a non-integer when an integer is expected, the application prompts the user to re-enter the correct value. For example, when adding, updating, or removing items, the system verifies that numeric IDs are entered correctly.

**2.Item Not Found Handling**:

- In scenarios where an item is not found during operations such as updating, removing, starting, or ending an auction, the application informs the user appropriately with a clear message stating "Item Not Found." This ensures users are aware when operations cannot proceed due to non-existent item IDs.

**3.Auction Status Handling**:

The application provides comprehensive handling of auction status:

- Before displaying auction status or placing bids, it verifies if there are any items currently available for auction.
- If no items are added or all auctions have ended, the system prompts the user with a message indicating no active auctions are available.
- During bid placement or auction viewing, the application dynamically updates and informs users about ongoing auctions, highest bids, and remaining auction times.
