import java.time.LocalDateTime;

/**
 * Represents a bid placed in the online auction system.
 */
public class Bid {
    private int id;  // Unique identifier for the bid
    private int itemId;  // ID of the item the bid is placed on
    private int userId;  // ID of the user placing the bid
    private double bidAmount;  // Amount of the bid
    private LocalDateTime bidDateTime;  // Date and time when the bid was placed

    /**
     * Constructor to initialize a new bid.
     * @param id The unique identifier for the bid.
     * @param itemId The ID of the item the bid is placed on.
     * @param userId The ID of the user placing the bid.
     * @param bidAmount The amount of the bid.
     */
    public Bid(int id, int itemId, int userId, double bidAmount) {
        this.id = id;
        this.itemId = itemId;
        this.userId = userId;
        this.bidAmount = bidAmount;
        this.bidDateTime = LocalDateTime.now();  // Set the bid date and time to the current time
    }

    // Getters

    /**
     * Returns the unique identifier for the bid.
     * @return The bid ID.
     */
    public int getId() { return id; }

    /**
     * Returns the ID of the item the bid is placed on.
     * @return The item ID.
     */
    public int getItemId() { return itemId; }

    /**
     * Returns the ID of the user placing the bid.
     * @return The user ID.
     */
    public int getUserId() { return userId; }

    /**
     * Returns the amount of the bid.
     * @return The bid amount.
     */
    public double getBidAmount() { return bidAmount; }

    /**
     * Returns the date and time when the bid was placed.
     * @return The bid date and time.
     */
    public LocalDateTime getBidDateTime() { return bidDateTime; }

    @Override
    public String toString() {
        return "Bid{" +
                "id=" + id +
                ", itemId=" + itemId +
                ", userId=" + userId +
                ", bidAmount=" + bidAmount +
                ", bidDateTime=" + bidDateTime +
                '}';
    }
}
