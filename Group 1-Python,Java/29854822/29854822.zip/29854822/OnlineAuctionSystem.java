import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Represents an online auction system.
 */
public class OnlineAuctionSystem {
    private HashMap<Integer, Item> items;  // Stores items with their ID as the key
    private HashMap<Integer, ArrayList<Bid>> bids;  // Stores bids for each item ID
    private int nextBidId;  // Counter for the next bid ID

    /**
     * Constructor to initialize the auction system.
     */
    public OnlineAuctionSystem() {
        items = new HashMap<>();
        bids = new HashMap<>();
        nextBidId = 1;
    }

    /**
     * Adds a new item to the auction system.
     * @param item The item to be added.
     */
    public void addItem(Item item) {
        items.put(item.getId(), item);
        System.out.println("Item added successfully: " + item);
    }

    /**
     * Removes an item from the auction system.
     * @param itemId The ID of the item to be removed.
     */
    public void removeItem(int itemId) {
        if (items.containsKey(itemId)) {
            items.remove(itemId);
            bids.remove(itemId);
            System.out.println("Item removed successfully. Item ID: " + itemId);
        } else {
            System.out.println("Item not found. Item ID: " + itemId);
        }
    }

    /**
     * Updates an existing item in the auction system.
     * @param itemId The ID of the item to be updated.
     * @param updatedItem The updated item details.
     */
    public void updateItem(int itemId, Item updatedItem) {
        if (items.containsKey(itemId)) {
            items.put(itemId, updatedItem);
            System.out.println("Item updated successfully: " + updatedItem);
        } else {
            System.out.println("Item not found. Item ID: " + itemId);
        }
    }

    /**
     * Starts an auction for an item.
     * @param itemId The ID of the item for which the auction is to be started.
     */
    public void startAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null && !item.isAuctionOpen()) {
            item.setAuctionOpen(true);
            item.setAuctionEndTime(LocalDateTime.now().plusMinutes(30));  // Example: Auction ends in 30 minutes
            System.out.println("Auction started for item: " + item);
        } else {
            System.out.println("Item not found or auction already started. Item ID: " + itemId);
        }
    }

    /**
     * Ends an auction for an item.
     * @param itemId The ID of the item for which the auction is to be ended.
     */
    public void endAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null && item.isAuctionOpen()) {
            item.setAuctionOpen(false);
            System.out.println("Auction ended for item: " + item);
        } else {
            System.out.println("Item not found or auction already ended. Item ID: " + itemId);
        }
    }

    /**
     * Places a bid on an item.
     * @param itemId The ID of the item to bid on.
     * @param userId The ID of the user placing the bid.
     * @param bidAmount The amount of the bid.
     */
    public void placeBid(int itemId, int userId, double bidAmount) {
        Scanner scanner = new Scanner(System.in);
        Item item = items.get(itemId);
        if (item != null && item.isAuctionOpen()) {
            while (bidAmount <= item.getCurrentHighestBid()) {
                System.out.println("Bid amount is too low. Current highest bid: " + item.getCurrentHighestBid());
                System.out.print("Enter a higher bid amount: ");
                bidAmount = scanner.nextDouble();
            }
            item.setCurrentHighestBid(bidAmount);
            Bid bid = new Bid(nextBidId++, itemId, userId, bidAmount);
            bids.computeIfAbsent(itemId, k -> new ArrayList<>()).add(bid);
            System.out.println("Bid placed successfully: " + bid);
        } else {
            System.out.println("Item not found or auction not open. Item ID: " + itemId);
        }
    }

    /**
     * Views the status of ongoing auctions.
     */
    public void viewAuctionStatus() {
        System.out.println("Viewing auction status:");
        for (Item item : items.values()) {
            if (item.isAuctionOpen()) {
                System.out.println(item);
                System.out.println("Time remaining in auction: " + item.getTimeRemainingMinutes() + " minutes");
                ArrayList<Bid> itemBids = bids.get(item.getId());
                if (itemBids != null && !itemBids.isEmpty()) {
                    System.out.println("Highest bid for this item is: " + item.getCurrentHighestBid());
                    for (Bid bid : itemBids) {
                        System.out.println("\t" + bid);
                    }
                } else {
                    System.out.println("\tNo bids placed yet.");
                }
            } else {
                System.out.println("Auction for item " + item.getName() + " (ID: " + item.getId() + ") has not yet started.");
            }
        }
    }

    /**
     * Views all items available for auction.
     */
    public void viewItems() {
        if (items.isEmpty()) {
            System.out.println("No items added yet.");
        } else {
            System.out.println("Viewing all items for auction:");
            for (Item item : items.values()) {
                System.out.println(item);
            }
        }
    }

    /**
     * Displays the menu options to the user.
     */
    private void displayMenu() {
        System.out.println("Choose an option:");
        System.out.println("1. Add Item");
        System.out.println("2. Remove Item");
        System.out.println("3. Update Item");
        System.out.println("4. Start Auction");
        System.out.println("5. End Auction");
        System.out.println("6. Place Bid");
        System.out.println("7. View Auction Status");
        System.out.println("8. View Items");
        System.out.println("9. Exit");
    }

    /**
     * Gets an integer input from the user.
     * @param scanner The scanner to read input from.
     * @param prompt The prompt to display to the user.
     * @return The integer input from the user.
     */
    private int getIntInput(Scanner scanner, String prompt) {
        int value;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                value = scanner.nextInt();
                scanner.nextLine();  // consume newline
                break;
            } else {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next();  // discard invalid input
            }
        }
        return value;
    }

    /**
     * Starts the online auction system.
     */
    public void start() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            displayMenu();
            int choice = getIntInput(scanner, "Enter your choice: ");

            switch (choice) {
                case 1:
                    int addId = getIntInput(scanner, "Enter item id: ");
                    System.out.print("Enter item name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter starting price: ");
                    double startingPrice = scanner.nextDouble();
                    scanner.nextLine();
                    addItem(new Item(addId, name, description, startingPrice, null));  // Initially, auction end time is null
                    break;

                case 2:
                    int removeId = getIntInput(scanner, "Enter item id to remove: ");
                    removeItem(removeId);
                    break;

                case 3:
                    int updateId = getIntInput(scanner, "Enter item id to update: ");
                    System.out.print("Enter new item name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new item description: ");
                    String newDescription = scanner.nextLine();
                    System.out.print("Enter new starting price: ");
                    double newStartingPrice = scanner.nextDouble();
                    scanner.nextLine();
                    updateItem(updateId, new Item(updateId, newName, newDescription, newStartingPrice, null));
                    break;

                case 4:
                    int startId = getIntInput(scanner, "Enter item id to start auction: ");
                    startAuction(startId);
                    break;

                case 5:
                    int endId = getIntInput(scanner, "Enter item id to end auction: ");
                    endAuction(endId);
                    break;

                case 6:
                    int bidItemId = getIntInput(scanner, "Enter item id to place bid: ");
                    System.out.print("Enter user id: ");
                    int userId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter bid amount: ");
                    double bidAmount = scanner.nextDouble();
                    scanner.nextLine();
                    placeBid(bidItemId, userId, bidAmount);
                    break;

                case 7:
                    viewAuctionStatus();
                    break;

                case 8:
                    viewItems();
                    break;

                case 9:
                    System.out.println("Online Auction has Ended !");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Main method to run the auction system.
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        OnlineAuctionSystem auctionSystem = new OnlineAuctionSystem();
        auctionSystem.start();
    }
}
