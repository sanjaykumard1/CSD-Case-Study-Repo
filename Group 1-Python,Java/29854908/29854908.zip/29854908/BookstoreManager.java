import java.util.*;

public class BookstoreManager {
    private HashMap<Integer, Book> books;
    private ArrayList<Order> orders;

    public BookstoreManager() {
        books = new HashMap<>();
        orders = new ArrayList<>();
    }

    public void addBook(Book b) {
        books.put(b.getId(), b);
    }

    public void removeBook(int bookId) {
        books.remove(bookId);
    }

    public void updateBook(int bookId, Book updatedBook) throws Exception {
        Book existingBook = books.get(bookId);
        if (existingBook != null) {
            if (updatedBook.getTitle() != null && !updatedBook.getTitle().isEmpty()) {
                existingBook.setTitle(updatedBook.getTitle());
            }
            if (updatedBook.getAuthor() != null && !updatedBook.getAuthor().isEmpty()) {
                existingBook.setAuthor(updatedBook.getAuthor());
            }
            if (updatedBook.getCategory() != null && !updatedBook.getCategory().isEmpty()) {
                existingBook.setCategory(updatedBook.getCategory());
            }
            if (updatedBook.getPrice() > 0) {
                existingBook.setPrice(updatedBook.getPrice());
            }
            if (updatedBook.getQuantity() >= 0) {
                existingBook.setQuantity(updatedBook.getQuantity());
            }
            books.put(bookId, existingBook);
        } else {
            throw new Exception("Book not found.");
        }
    }

    public Book getBook(int bookId) {
        return books.get(bookId);
    }

    public List<Book> searchBooks(String keyword) {
        List<Book> result = new ArrayList<>();
        String lowerCaseKeyword = keyword.toLowerCase();
        for (Book book : books.values()) {
            if (book.getTitle().toLowerCase().contains(lowerCaseKeyword) || 
                book.getAuthor().toLowerCase().contains(lowerCaseKeyword) || 
                book.getCategory().toLowerCase().contains(lowerCaseKeyword)) {
                result.add(book);
            }
        }
        return result;
    }

    
    public void processOrder(int bookId, int quantity) throws Exception {
        Book book = books.get(bookId);
        if (book != null && book.getQuantity() >= quantity) {
            Order order = new Order(orders.size() + 1, bookId, quantity);
            orders.add(order);
            book.setQuantity(book.getQuantity() - quantity);
        } else {
            throw new Exception("Book not available or insufficient quantity.");
        }
    }
}
