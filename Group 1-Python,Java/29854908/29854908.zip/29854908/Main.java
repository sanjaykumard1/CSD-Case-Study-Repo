import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BookstoreManager manager = new BookstoreManager();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Update Book");
            System.out.println("4. Search Books");
            System.out.println("5. Process Order");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Book ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter Category: ");
                    String category = scanner.nextLine();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine();
                    Book book = new Book(id, title, author, category, price, quantity);
                    manager.addBook(book);
                    break;
                case 2:
                    System.out.print("Enter Book ID to Remove: ");
                    int removeId = scanner.nextInt();
                    scanner.nextLine();
                    manager.removeBook(removeId);
                    break;
                case 3:
                    System.out.print("Enter Book ID to Update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    Book bookToUpdate = manager.getBook(updateId);

                    if (bookToUpdate != null) {
                        System.out.print("Enter New Title (press Enter to keep unchanged): ");
                        String newTitle = scanner.nextLine();
                        if (newTitle.isEmpty()) {
                            newTitle = bookToUpdate.getTitle();
                        }

                        System.out.print("Enter New Author (press Enter to keep unchanged): ");
                        String newAuthor = scanner.nextLine();
                        if (newAuthor.isEmpty()) {
                            newAuthor = bookToUpdate.getAuthor();
                        }

                        System.out.print("Enter New Category (press Enter to keep unchanged): ");
                        String newCategory = scanner.nextLine();
                        if (newCategory.isEmpty()) {
                            newCategory = bookToUpdate.getCategory();
                        }

                        System.out.print("Enter New Price (press Enter to keep unchanged): ");
                        String newPriceStr = scanner.nextLine();
                        double newPrice = bookToUpdate.getPrice();
                        if (!newPriceStr.isEmpty()) {
                            newPrice = Double.parseDouble(newPriceStr);
                        }

                        System.out.print("Enter New Quantity (press Enter to keep unchanged): ");
                        String newQuantityStr = scanner.nextLine();
                        int newQuantity = bookToUpdate.getQuantity();
                        if (!newQuantityStr.isEmpty()) {
                            newQuantity = Integer.parseInt(newQuantityStr);
                        }

                        Book updatedBook = new Book(updateId, newTitle, newAuthor, newCategory, newPrice, newQuantity);
                        try {
                            manager.updateBook(updateId, updatedBook);
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter Keyword to Search: ");
                    String keyword = scanner.nextLine();
                    List<Book> searchResults = manager.searchBooks(keyword);
                    for (Book b : searchResults) {
                        System.out.println(b);
                    }
                    break;
                case 5:
                    System.out.print("Enter Book ID to Order: ");
                    int orderId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Quantity: ");
                    int orderQuantity = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        manager.processOrder(orderId, orderQuantity);
                        System.out.println("Order processed successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage()); 
                    } 
                    break; 
                case 6: 
                    running = false; 
                    break; 
                default: 
                    System.out.println("Invalid choice. Please try again."); 
                    break; 
            }
        }
        scanner.close();
    }
}