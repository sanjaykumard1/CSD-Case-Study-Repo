public class Order {
    private int id;
    private int bookId;
    private int quantity;

    public Order(int id, int bookId, int quantity) {
        this.id = id;
        this.bookId = bookId;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public int getBookId() {
        return bookId;
    }

    public int getQuantity() {
        return quantity;
    }

    public String toString() {
        return "Order [id=" + id + ", bookId=" + bookId + ", quantity=" + quantity + "]";
    }
}
