import java.util.HashMap;
import java.util.Map;

// Student class to represent a student with grades and attendance
public class Student {
    private int id;
    private String name;
    private Map<Integer, Double> grades; // Map to store subject ID and corresponding grade
    private int attendedDays;
    private int totalDays;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
        this.grades = new HashMap<>();
        this.attendedDays = 0;
        this.totalDays = 0;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Map<Integer, Double> getGrades() {
        return grades;
    }

    public int getAttendedDays() {
        return attendedDays;
    }

    public int getTotalDays() {
        return totalDays;
    }

    public void addGrade(int subjectId, double grade) {
        grades.put(subjectId, grade);
    }

    public void trackAttendance(int attendedDays, int totalDays) {
        this.attendedDays += attendedDays;
        this.totalDays += totalDays;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", grades=" + grades +
                ", attendedDays=" + attendedDays +
                ", totalDays=" + totalDays +
                '}';
    }
}

