# School Management System

## Overview

The School Management System is a console-based application developed in Java. It allows users to manage student records and perform various operations related to school management, such as calculating average grades, tracking attendance, and determining top/bottom performers.

## Features

1. **Calculate Average Grade**
   - Calculate and display the average grade for each student based on their subjects.

2. **Find Top and Bottom Performer**
   - Determine and display the student(s) with the highest and lowest average grades in the school.

3. **Subject-wise Average Grade**
   - Calculate and display the average grade for each subject across all students.

4. **Student Attendance Tracking**
   - Track and display the attendance of each student.
   - Calculate and display the attendance percentage for each student.

## How to Run the Application

### Steps to Run
1. **Compile the Application:**
   - Open your terminal or command prompt.
   - Navigate to the directory containing the Java files (`SchoolManager.java`, `Student.java`, `Subject.java`).
   - Compile the files using the following command:
     ```
     javac *.java
     ```

2. **Run the Application:**
   - After successful compilation, run the application with the following command:
     ```
     java SchoolManager
     ```
   - This command will execute the `main` method in the `SchoolManager` class, demonstrating the functionality of the School Management System.

## Instructions for Each Feature

### Calculate Average Grade
- To calculate the average grade for a student, call the `calculateAverageGrade(int studentId)` method in the `SchoolManager` class, providing the `studentId` as an argument.

### Find Top and Bottom Performer
- Use the `findTopAndBottomPerformer()` method in the `SchoolManager` class to determine and display the student(s) with the highest and lowest average grades.

### Subject-wise Average Grade
- Calculate the average grade for a specific subject across all students using `calculateSubjectWiseAverageGrade(int subjectId)` method in the `SchoolManager` class, providing the `subjectId` as an argument.

### Student Attendance Tracking
- Track attendance and calculate attendance percentage for a student using `trackStudentAttendance(int studentId, int attendedDays, int totalDays)` method in the `SchoolManager` class, providing `studentId`, `attendedDays`, and `totalDays` as arguments.

## Object-Oriented Principles

### Encapsulation
- **Encapsulation** ensures that classes like `Student` and `Subject` encapsulate their data (attributes) and behaviors (methods), controlling access to data through getters and setters.

### Inheritance
- While not explicitly demonstrated in the provided code, **inheritance** can be applied by extending functionality. For example, you could create specialized classes like `HighSchoolStudent` or `CollegeStudent` inheriting from a base `Student` class to add specific attributes or methods.

### Polymorphism
- **Polymorphism** is achieved through method overriding, such as the `toString()` method in the `Student` and `Subject` classes, providing custom string representations.

### Abstraction
- **Abstraction** is used to hide complex implementation details. For instance, the `SchoolManager` class abstracts the management of students and subjects using collections (`HashMap`) and provides simple methods to interact with these entities.

## Exception Handling Implemented

- **Null Checks:** Methods validate inputs such as student IDs and subject IDs to handle cases where a student or subject does not exist.

- **Input Validation:** Ensure inputs like attended days and total days are within valid ranges to prevent errors during calculation.

- **Try-Catch Blocks:** Exception handling is used to catch and handle potential runtime exceptions, providing informative error messages for the user.

