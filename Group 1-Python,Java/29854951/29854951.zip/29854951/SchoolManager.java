import java.util.HashMap;
import java.util.Map;

// SchoolManager class to manage students, subjects, and perform operations
public class SchoolManager {
    private HashMap<Integer, Student> students;
    private HashMap<Integer, Subject> subjects;

    public SchoolManager() {
        students = new HashMap<>();
        subjects = new HashMap<>();
    }

    // Method to add a student to the system
    public void addStudent(Student student) {
        students.put(student.getId(), student);
    }

    // Method to add a subject to the system
    public void addSubject(Subject subject) {
        subjects.put(subject.getSubjectId(), subject);
    }

    // Method to calculate average grade for a student
    public double calculateAverageGrade(int studentId) {
        Student student = students.get(studentId);
        if (student == null) {
            throw new IllegalArgumentException("Student not found with ID: " + studentId);
        }

        Map<Integer, Double> grades = student.getGrades();
        if (grades.isEmpty()) {
            throw new IllegalStateException("Student has no grades.");
        }

        double total = 0;
        for (double grade : grades.values()) {
            total += grade;
        }

        return total / grades.size();
    }

    // Method to find and display top and bottom performing students
    public void findTopAndBottomPerformer() {
        if (students.isEmpty()) {
            throw new IllegalStateException("No students found.");
        }

        double highestGrade = Double.MIN_VALUE;
        double lowestGrade = Double.MAX_VALUE;
        Student topPerformer = null;
        Student bottomPerformer = null;

        for (Student student : students.values()) {
            double avgGrade = calculateAverageGrade(student.getId());

            if (avgGrade > highestGrade) {
                highestGrade = avgGrade;
                topPerformer = student;
            }

            if (avgGrade < lowestGrade) {
                lowestGrade = avgGrade;
                bottomPerformer = student;
            }
        }

        if (topPerformer != null && bottomPerformer != null) {
            System.out.println("Top Performer: " + topPerformer.getName() + " with average grade: " + highestGrade);
            System.out.println("Bottom Performer: " + bottomPerformer.getName() + " with average grade: " + lowestGrade);
        }
    }

    // Method to calculate and display subject-wise average grade
    public void calculateSubjectWiseAverageGrade(int subjectId) {
        Subject subject = subjects.get(subjectId);
        if (subject == null) {
            throw new IllegalArgumentException("Subject not found with ID: " + subjectId);
        }

        double total = 0;
        int count = 0;

        for (Student student : students.values()) {
            Map<Integer, Double> grades = student.getGrades();
            if (grades.containsKey(subjectId)) {
                total += grades.get(subjectId);
                count++;
            }
        }

        if (count == 0) {
            System.out.println("No students enrolled in subject: " + subject.getSubjectName());
        } else {
            double average = total / count;
            System.out.println("Average grade for subject " + subject.getSubjectName() + " is: " + average);
        }
    }

    // Method to track student attendance and calculate attendance percentage
    public double trackStudentAttendance(int studentId, int attendedDays, int totalDays) {
        Student student = students.get(studentId);
        if (student == null) {
            throw new IllegalArgumentException("Student not found with ID: " + studentId);
        }

        student.trackAttendance(attendedDays, totalDays);

        int attended = student.getAttendedDays();
        int total = student.getTotalDays();

        if (total == 0) {
            throw new ArithmeticException("Total days cannot be zero.");
        }

        double attendancePercentage = ((double) attended / total) * 100;
        return attendancePercentage;
    }

    // Main method to demonstrate usage of the School Management System
    public static void main(String[] args) {
        SchoolManager manager = new SchoolManager();

        // Adding subjects
        Subject maths = new Subject(1, "Mathematics");
        Subject science = new Subject(2, "Science");
        manager.addSubject(maths);
        manager.addSubject(science);

        // Adding students
        Student student1 = new Student(1, "Yash");
        student1.addGrade(1, 85.5); // Math grade
        student1.addGrade(2, 78.0); // Science grade
        manager.addStudent(student1);

        Student student2 = new Student(2, "Suyash");
        student2.addGrade(1, 90.0); // Math grade
        student2.addGrade(2, 82.5); // Science grade
        manager.addStudent(student2);

        try {
            // Testing functionalities with exception handling
            System.out.println("Average grade for student Yash: " + manager.calculateAverageGrade(1));
            System.out.println("Average grade for student Suyash: " + manager.calculateAverageGrade(2));

            manager.findTopAndBottomPerformer();

            manager.calculateSubjectWiseAverageGrade(1); // Math
            manager.calculateSubjectWiseAverageGrade(3); // Invalid subject ID to test exception handling

            double attendancePercentage = manager.trackStudentAttendance(1, 45, 50); // Yash attendance
            System.out.println("Attendance percentage for Yash: " + attendancePercentage);

            // Testing with invalid student ID to trigger exception
            // double invalidAttendancePercentage = manager.trackStudentAttendance(3, 0, 0);
        } catch (IllegalArgumentException | IllegalStateException | ArithmeticException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

