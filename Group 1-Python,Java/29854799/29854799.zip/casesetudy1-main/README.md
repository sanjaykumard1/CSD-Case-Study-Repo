# casesetudy1

Instructions for Each Feature:
Add Student:

Prompts for student ID, name, grade, and contact number.
Adds the student to the system if the ID is unique.
Remove Student:

Prompts for the student ID to remove.
Removes the student from the system if found, including removing from any assigned courses.
Update Student Details:

Prompts for the student ID to update.
Allows modification of name, grade, and contact number if the student exists.
Add Teacher:

Prompts for teacher ID, name, subject, and contact number.
Adds the teacher to the system if the ID is unique.
Remove Teacher:

Prompts for the teacher ID to remove.
Removes the teacher from the system if found, updating any courses assigned to them.
Update Teacher Details:

Prompts for the teacher ID to update.
Allows modification of name, subject, and contact number if the teacher exists.
Add Course:

Prompts for course ID, name, and teacher ID.
Adds the course to the system with the specified teacher if the ID is unique.
Remove Course:

Prompts for the course ID to remove.
Removes the course from the system if found.
Assign Student to Course:

Prompts for student ID and course ID.
Assigns the student to the specified course if both IDs exist in the system.
Assign Teacher to Course:

Prompts for teacher ID and course ID.
Assigns the teacher to the specified course if both IDs exist in the system.
Exception Handling:

Handles potential errors such as input mismatches, missing IDs, or invalid operations.
Uses try-catch blocks to catch exceptions like InputMismatchException and provides appropriate error messages to the user.
2. Report on Application Design and Object-Oriented Principles
Application Design:
Classes and Objects:

Student, Teacher, Course: Represent entities with attributes and methods to encapsulate data and behavior.
Main: Central class managing the School Management System, handling user interactions and system operations.
Data Structures:

HashMaps: Used to store students, teachers, and courses for efficient retrieval and management.
User Interface:

Menu-Driven System: Implemented using switch-case statements for user interaction, providing a structured menu for operations.
Object-Oriented Principles Applied:
Encapsulation:

Classes encapsulate data (attributes) and methods (behavior), ensuring data integrity and modularity.
Inheritance:

While not explicitly shown in this example, inheritance can be applied in future expansions, such as having different types of users (like admin, teacher, student) inheriting from a common user class.
Polymorphism:

Achieved through method overriding (e.g., toString() method) and potentially through interface implementations for different roles.
Abstraction:

Classes and methods provide abstractions over complex operations, hiding internal implementation details from users.
Exception Handling:

Ensures robustness and reliability by handling errors gracefully, preventing application crashes and providing meaningful error messages to users.
