package entity;
import java.time.LocalDateTime;
public class Orders {
	

	
	    private int id;
	    private int menuItemId;
	    private int quantity;
	    private LocalDateTime orderTime;
	    private String status;

	    public Orders(int id, int menuItemId, int quantity, LocalDateTime orderTime, String status) {
	        this.id = id;
	        this.menuItemId = menuItemId;
	        this.quantity = quantity;
	        this.orderTime = orderTime;
	        this.status = status;
	    }

		public Orders() {
			// TODO Auto-generated constructor stub
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public int getMenuItemId() {
			return menuItemId;
		}

		public void setMenuItemId(int menuItemId) {
			this.menuItemId = menuItemId;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public LocalDateTime getOrderTime() {
			return orderTime;
		}

		public void setOrderTime(LocalDateTime orderTime) {
			this.orderTime = orderTime;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}
}
