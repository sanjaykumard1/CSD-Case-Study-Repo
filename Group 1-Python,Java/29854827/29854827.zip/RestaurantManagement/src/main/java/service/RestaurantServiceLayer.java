package service;

import java.util.List;
import java.util.Scanner;


import dao.RestaurantManager;
import entity.*;
import myExceptions.MenuItemNotFoundException;


public class RestaurantServiceLayer {
	Scanner sc;
	RestaurantManager cdao ;

	public  RestaurantServiceLayer(){
		sc=new Scanner(System.in);
		cdao=new RestaurantManager();
	}
	public void addMenuItem() {
		 MenuItem menu=new MenuItem();
		 System.out.println("Enter menu Id");
		 menu.setId(sc.nextInt());
		 System.out.print("Enter name: ");
		 sc.nextLine();
         menu.setName(sc.nextLine());
         System.out.print("Enter category: ");
         menu.setCategory(sc.nextLine());
         System.out.print("Enter price: ");
         menu.setPrice(sc.nextDouble());
         System.out.print("Is available (true/false): ");
         menu.setAvailable(sc.nextBoolean());
         boolean result=cdao.addMenuItem(menu);
			if(result) {
				System.out.println("MenuItem added Successfully");
			}
			else {
				System.out.println("Failed to update");
			}
	}
	
	public void removeMenuItem() {
		MenuItem menu=new MenuItem();
		System.out.println("Enter menu Id");
		 menu.setId(sc.nextInt());
		 boolean result=cdao.removeMenuItem(menu.getId());
			if(result) {
				System.out.println("MenuItem removed Successfully");
			}
			else {
				System.out.println("Failed to remove");
			}
	}
	public void updateMenuItem() {
		MenuItem menu=new MenuItem();
		 System.out.println("Enter menu Id");
		 menu.setId(sc.nextInt());
		 System.out.print("Enter name: ");
		 sc.nextLine();
        menu.setName(sc.nextLine());
        
        System.out.print("Enter price: ");
        menu.setPrice(sc.nextDouble());
        boolean result=cdao.updateMenuItem(menu.getId(),menu.getName(),menu.getPrice());
		if(result) {
			System.out.println("MenuItem updated Successfully");
		}
		else {
			System.out.println("Failed to update");
		}
	}
	public List<MenuItem> searchMenuItem(){ 
		 
		
		 System.out.println("Enter the keyword");
		 String key=sc.nextLine();
	   
	    List<MenuItem> p = cdao.searchMenuItem(key);
	    return p;
	}
	public void placeOrder() throws MenuItemNotFoundException {
		Orders or=new Orders();
		 System.out.println("Enter menu Id");
		 or.setMenuItemId(sc.nextInt());
		 System.out.println("Enter quantity");
		 or.setQuantity(sc.nextInt());
		 boolean result=cdao.placeOrder(or.getMenuItemId(),or.getQuantity());
			if(result) {
				System.out.println("Order Placed Successfully");
			}
			else {
				System.out.println("Failed to place the order");
			}
	}
	public void processOrder() {
		Orders or=new Orders();
		 System.out.println("Enter order Id");
		 or.setId(sc.nextInt());
		 boolean result=cdao.processOrder(or.getId());
			if(result) {
				System.out.println("Ordrer processed Successfully");
			}
			else {
				System.out.println("Failed to process the order");
			}
	}
}
