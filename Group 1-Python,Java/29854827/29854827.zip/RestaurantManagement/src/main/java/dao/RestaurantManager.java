package dao;

import entity.*;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Scanner;

	public class RestaurantManager {
		public Connection con;
	    PreparedStatement stat;
	    public RestaurantManager() {
	      	 this.con=DBConnection.getConnect();
	       }
	    private HashMap<Integer, MenuItem> menuItems = new HashMap<Integer, MenuItem>();
	    private ArrayList<Orders> orders = new ArrayList<Orders>();
	    private int nextMenuItemId = 1;
	    private int nextOrderId = 1;

	    public boolean addMenuItem(MenuItem menu) {
	    	try {
	   		 stat = con.prepareStatement("insert into menuitem values(?,?,?,?,?)");
	   		 stat.setInt(1,menu.getId());
	   		 stat.setString(2, menu.getName());
	   		 stat.setString(3, menu.getCategory());
	   		 stat.setDouble(4, menu.getPrice());
	   		 stat.setBoolean(5, menu.isAvailable());
	   		 int rowsaffected=stat.executeUpdate();
	   		 
	   		 if(rowsaffected>0)
	   			{
	   				return true;
	   			}
	   			else
	   				return false;

	   	 }
	   	 catch(Exception e) {
	   		 System.out.println(e.getMessage());
	   		 return false;
	   	 }
	    }

	    public boolean removeMenuItem(int itemId) {
	    	try {
		   		 stat = con.prepareStatement("delete from menuitem where id=?");
		   		 stat.setInt(1,itemId);
		   		 
		   		 int rowsaffected=stat.executeUpdate();
		   		 
		   		 if(rowsaffected>0)
		   			{
		   				return true;
		   			}
		   			else
		   				return false;

		   	 }
		   	 catch(Exception e) {
		   		 System.out.println(e.getMessage());
		   		 return false;
		   	 }
		    
	    }

	   

		public boolean updateMenuItem(int itemId, String name, double price) {
			try {
		   		 stat = con.prepareStatement("update menuitem set price=? where id=? and name=?");
		   		 stat.setInt(2,itemId);
		   		stat.setString(3,name );
		   		 
		   		 stat.setDouble(1,price);
		   		 
		   		 int rowsaffected=stat.executeUpdate();
		   		 
		   		 if(rowsaffected>0)
		   			{
		   				return true;
		   			}
		   			else
		   				return false;

		   	 }
		   	 catch(Exception e) {
		   		 System.out.println(e.getMessage());
		   		 return false;
		   	 }
	    }

	    public List<MenuItem> searchMenuItem(String keyword) {
	        List<MenuItem> results = new ArrayList<MenuItem>();
	        for (MenuItem item : menuItems.values()) {
	            if (item.getName().contains(keyword) || item.getCategory().contains(keyword)) {
	                results.add(item);
	            }
	        }
	        if (results.isEmpty()) {
	            System.out.println("No menu items found.");
	        } else {
	            System.out.println("Search results:");
	            for (MenuItem item : results) {
	                System.out.println(item);
	            }
	        }
			return results;
	    }

	    public boolean placeOrder(int menuItemId,int quantity) {

	        MenuItem item = menuItems.get(menuItemId);
	    
	    	  try {
	              if (!menuItems.containsKey(menuItemId)) {
	                  throw new Exception("Menu item with ID " + menuItemId + " does not exist.");
	              }
	        if (item != null && item.isAvailable()) {
	            Orders newOrder = new Orders(nextOrderId++, menuItemId, quantity, LocalDateTime.now(), "pending");
	            orders.add(newOrder);
	            item.setAvailable(false);
	            System.out.println("Order placed: " + newOrder);
	        }}
	    	  catch (Exception e) {
	            System.err.println("Error placing order: " + e.getMessage());
	        }
			return false;
	    }

	    public boolean processOrder(int orderId) {
	        for (Orders order : orders) {
	            if (order.getId() == orderId) {
	                order.setStatus("served");
	                MenuItem item = menuItems.get(order.getMenuItemId());
	                item.setAvailable(true);
	                System.out.println("Order processed: " + order);
	               
	            }
	        }
	        System.out.println("Order not found.");
			return true;
	    }

	    }

		

		
		
	

