import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

// Book Class
class Book {
    private int id;
    private String title;
    private String author;
    private String category;
    private int availableCopies;

    public Book(int id, String title, String author, String category, int availableCopies) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.availableCopies = availableCopies;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    @Override
    public String toString() {
        return "Book [id=" + id + ", title=" + title + ", author=" + author + ", category=" + category + ", availableCopies=" + availableCopies + "]";
    }
}

// LibraryMember Class
class LibraryMember {
    private int id;
    private String name;
    private List<Book> booksBorrowed;
    private double fineAmount;

    public LibraryMember(int id, String name) {
        this.id = id;
        this.name = name;
        this.booksBorrowed = new ArrayList<>();
        this.fineAmount = 0.0;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Book> getBooksBorrowed() {
        return booksBorrowed;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    @Override
    public String toString() {
        return "LibraryMember [id=" + id + ", name=" + name + ", booksBorrowed=" + booksBorrowed + ", fineAmount=" + fineAmount + "]";
    }
}

// LibraryManager Class
class LibraryManager {
    private HashMap<Integer, Book> books;
    private HashMap<Integer, LibraryMember> members;

    public LibraryManager() {
        books = new HashMap<>();
        members = new HashMap<>();
    }

    public void addBook(Book book) throws Exception {
        if (books.containsKey(book.getId())) {
            throw new Exception("Book with ID " + book.getId() + " already exists. Enter a new ID.");
        }
        books.put(book.getId(), book);
    }

    public void removeBook(int bookId) {
        books.remove(bookId);
    }

    public void addMember(LibraryMember member) {
        members.put(member.getId(), member);
    }

    public List<Book> searchBooks(String keyword) {
        return books.values().stream()
                .filter(book -> book.getTitle().toLowerCase().contains(keyword.toLowerCase())
                        || book.getAuthor().toLowerCase().contains(keyword.toLowerCase())
                        || book.getCategory().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }

    public void checkoutBook(int memberId, int bookId) throws Exception {
        LibraryMember member = members.get(memberId);
        Book book = books.get(bookId);

        if (member == null || book == null) {
            throw new Exception("Member or Book not found.");
        }

        if (book.getAvailableCopies() > 0) {
            book.setAvailableCopies(book.getAvailableCopies() - 1);
            member.getBooksBorrowed().add(book);
        } else {
            throw new Exception("No available copies for the book.");
        }
    }

    public void returnBook(int memberId, int bookId) throws Exception {
        LibraryMember member = members.get(memberId);
        Book book = books.get(bookId);

        if (member == null || book == null) {
            throw new Exception("Member or Book not found.");
        }

        if (member.getBooksBorrowed().remove(book)) {
            book.setAvailableCopies(book.getAvailableCopies() + 1);
        } else {
            throw new Exception("This member did not borrow this book.");
        }
    }

    public double calculateFine(int memberId) {
        LibraryMember member = members.get(memberId);
        if (member == null) {
            return 0.0;
        }

        // Calculate fine based on some logic, for simplicity, assuming $1 per book.
        double fine = member.getBooksBorrowed().size() * 1.0;
        member.setFineAmount(fine);
        return fine;
    }

    public List<Book> generatePopularBooksReport() {
        return books.values().stream()
                .sorted((b1, b2) -> Integer.compare(b2.getAvailableCopies(), b1.getAvailableCopies()))
                .collect(Collectors.toList());
    }

    public HashMap<Integer, Book> getBooks() {
        return books;
    }

    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }
}

// Main Class
public class LibraryManagementSystem {
    public static void main(String[] args) {
        LibraryManager manager = new LibraryManager();
        Scanner scanner = new Scanner(System.in);

        // Sample Data
        try {
            manager.addBook(new Book(1, "Pride and Prejudice", "Jane Austen", "Novel", 5));
            manager.addBook(new Book(2, "To Kill a Mockingbird", "Harper Lee", "Novel", 3));
            manager.addBook(new Book(3, "The Great Gatsby", "F. Scott Fitzgerald", "Novel", 7));
            manager.addBook(new Book(4, "War and Peace", "Leo Tolstoy", "Novel", 4));
            manager.addBook(new Book(5, "One Hundred Years of Solitude", "Gabriel Garcia Marquez", "Novel", 6));
            manager.addBook(new Book(6, "The Catcher in the Rye", "J.D. Salinger", "Novel", 8));
            manager.addBook(new Book(7, "Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "Fantasy", 9));
            manager.addBook(new Book(8, "The Odyssey", "Homer", "Epic Poem", 3));
            manager.addBook(new Book(9, "Divine Comedy", "Dante Alighieri", "Epic Poem", 4));
            manager.addBook(new Book(10, "Selected Poems", "Emily Dickinson", "Poetry", 5));
            manager.addBook(new Book(11, "Leaves of Grass", "Walt Whitman", "Poetry", 6));
            manager.addBook(new Book(12, "Mahabharata", "Vyasa", "Epic", 8));
            manager.addBook(new Book(13, "Ramayana", "Valmiki", "Epic", 7));
            manager.addBook(new Book(14, "Kumara Sambhavam", "Kalidasa", "Telugu Literature", 4));
            manager.addBook(new Book(15, "Veyi Padagalu", "Viswanatha Satyanarayana", "Telugu Literature", 6));
            manager.addBook(new Book(16, "Maha Prasthanam", "Sri Sri", "Telugu Poetry", 5));
            manager.addBook(new Book(17, "Amuktamalyada", "Krishnadevaraya", "Telugu Poetry", 3));
            manager.addBook(new Book(18, "Bhagavad Gita", "Vyasa", "Spiritual", 6));
            manager.addBook(new Book(19, "The Brothers Karamazov", "Fyodor Dostoevsky", "Novel", 7));
            manager.addBook(new Book(20, "Crime and Punishment", "Fyodor Dostoevsky", "Novel", 5));
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Adding sample members
        manager.addMember(new LibraryMember(1, "Alice"));
        manager.addMember(new LibraryMember(2, "Bob"));
        manager.addMember(new LibraryMember(3, "Charlie"));
        manager.addMember(new LibraryMember(4, "David"));
        manager.addMember(new LibraryMember(5, "Eve"));
        manager.addMember(new LibraryMember(6, "Frank"));
        manager.addMember(new LibraryMember(7, "Grace"));
        manager.addMember(new LibraryMember(8, "Hank"));
        manager.addMember(new LibraryMember(9, "Ivy"));
        manager.addMember(new LibraryMember(10, "Jack"));

        while (true) {
            System.out.println("\nLibrary Management System:");
            System.out.println("1. Search Books");
            System.out.println("2. Checkout Book");
            System.out.println("3. Return Book");
            System.out.println("4. Calculate Fine");
            System.out.println("5. Generate Popular Books Report");
            System.out.println("6. Add Book");
            System.out.println("7. Remove Book");
            System.out.println("8. Show All Books");
            System.out.println("9. Exit");

            try {
                System.out.print("Enter choice: ");
                int choice = Integer.parseInt(scanner.nextLine().trim());

                switch (choice) {
                    case 1:
                        System.out.print("Enter Category: ");
                        String keyword = scanner.nextLine().trim();
                        List<Book> searchResults = manager.searchBooks(keyword);
                        if (searchResults.isEmpty()) {
                            System.out.println("No books found.");
                        } else {
                            searchResults.forEach(System.out::println);
                        }
                        break;
                    case 2:
                        System.out.print("Enter Member ID: ");
                        int memberId = Integer.parseInt(scanner.nextLine().trim());
                        System.out.print("Enter Book ID: ");
                        int bookId = Integer.parseInt(scanner.nextLine().trim());
                        manager.checkoutBook(memberId, bookId);
                        System.out.println("Book checked out successfully.");
                        break;
                    case 3:
                        System.out.print("Enter Member ID: ");
                        int memberIdReturn = Integer.parseInt(scanner.nextLine().trim());
                        System.out.print("Enter Book ID: ");
                        int bookIdReturn = Integer.parseInt(scanner.nextLine().trim());
                        manager.returnBook(memberIdReturn, bookIdReturn);
                        System.out.println("Book returned successfully.");
                        break;
                    case 4:
                        System.out.print("Enter Member ID: ");
                        int memberIdFine = Integer.parseInt(scanner.nextLine().trim());
                        double fine = manager.calculateFine(memberIdFine);
                        System.out.println("Fine Amount: " + fine);
                        break;
                    case 5:
                        List<Book> popularBooks = manager.generatePopularBooksReport();
                        if (popularBooks.isEmpty()) {
                            System.out.println("No books found.");
                        } else {
                            popularBooks.forEach(System.out::println);
                        }
                        break;
                    case 6:
                        boolean bookAdded = false;
                        while (!bookAdded) {
                            try {
                                System.out.print("Enter Book ID: ");
                                int newBookId = Integer.parseInt(scanner.nextLine().trim());
                                if (manager.getBooks().containsKey(newBookId)) {
                                    System.out.println("Book ID already exists. Enter a new ID.");
                                    continue;
                                }
                                System.out.print("Enter Book Title: ");
                                String newBookTitle = scanner.nextLine().trim();
                                System.out.print("Enter Author Name: ");
                                String newBookAuthor = scanner.nextLine().trim();
                                System.out.print("Enter Category: ");
                                String newBookCategory = scanner.nextLine().trim();
                                System.out.print("Enter Available Copies: ");
                                int newBookCopies = Integer.parseInt(scanner.nextLine().trim());
                                manager.addBook(new Book(newBookId, newBookTitle, newBookAuthor, newBookCategory, newBookCopies));
                                System.out.println("Book added successfully.");
                                bookAdded = true;
                            } catch (Exception e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                        }
                        break;
                    case 7:
                        System.out.print("Enter Book ID to remove: ");
                        int removeBookId = Integer.parseInt(scanner.nextLine().trim());
                        manager.removeBook(removeBookId);
                        System.out.println("Book removed successfully.");
                        break;
                    case 8:
                        List<Book> allBooks = manager.getAllBooks();
                        if (allBooks.isEmpty()) {
                            System.out.println("No books available in the library.");
                        } else {
                            allBooks.forEach(System.out::println);
                        }
                        break;
                    case 9:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
