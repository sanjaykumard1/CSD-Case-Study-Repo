package hotelmanagementsystem;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        HotelManagementSystem managementObject = new HotelManagementSystem();
        Scanner scanner = new Scanner(System.in);
        boolean running=true;
        while (running) {
        	System.out.println("=========================================");
            System.out.println("Hotel Management System");
            System.out.println("1 Add Room");
            System.out.println("2 Remove Room");
            System.out.println("3 Update Room");
            System.out.println("4 Check Room Availability");
            System.out.println("5 Make Reservation");
            System.out.println("6 Check-In Guest");
            System.out.println("7 Check-Out Guest");
            System.out.println("8 Exit");
            System.out.print("Enter your choice from (0-8): ");
            
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter room id : ");
                    int addRoomId = scanner.nextInt();
                    System.out.print("Enter room number : ");
                    int addRoomNumber = scanner.nextInt();
                    System.out.print("Enter room type : ");
                    String addRoomType = scanner.next();
                    System.out.print("Enter price per night : ");
                    double addPricePerNight = scanner.nextDouble();
                    Room room= new Room(addRoomId, addRoomNumber, addRoomType, addPricePerNight, true);
                    managementObject.addRoom(room);
                    break;
                case 2:
                    System.out.print("Enter room id you want to remove : ");
                    int removeRoomId = scanner.nextInt();
                    managementObject.removeRoom(removeRoomId);
                    break;
                case 3:
                    System.out.print("Enter room id to update : ");
                    int updatedRoomId = scanner.nextInt();
                    System.out.print("Enter new room number : ");
                    int updatedRoomNumber = scanner.nextInt();
                    System.out.print("Enter new room type : ");
                    String updatedRoomType = scanner.next();
                    System.out.print("Enter new price per night : ");
                    double updatedPricePerNight = scanner.nextDouble();
                    System.out.print("Enter new availability (true/false): ");
                    boolean updatedAvailability = scanner.nextBoolean();
                    Room roomToUpdate = new Room(updatedRoomId, updatedRoomNumber, updatedRoomType, updatedPricePerNight, updatedAvailability);
                    managementObject.updateRoom(updatedRoomId, roomToUpdate);
                    break;
                case 4:
                    System.out.print("Enter room number to check availability: ");
                    int roomNumber = scanner.nextInt();
                    System.out.print("Enter Start Date (YYYY-MM-DD): ");
                    LocalDate startDate = LocalDate.parse(scanner.next());
                    System.out.print("Enter End Date (YYYY-MM-DD): ");
                    LocalDate endDate = LocalDate.parse(scanner.next());
                    boolean isAvailable = managementObject.checkRoomAvailability(roomNumber, startDate, endDate);
                    System.out.println("Room is : " + (isAvailable ? "Available" : "Not Available"));
                    break;
                case 5:
                    System.out.print("Enter room id for reservation : ");
                    int reservationRoomId = scanner.nextInt();
                    System.out.print("Enter guest name : ");
                    String guestName = scanner.next();
                    System.out.print("Enter Start Date (YYYY-MM-DD): ");
                    LocalDate reservationStartDate = LocalDate.parse(scanner.next());
                    System.out.print("Enter End Date (YYYY-MM-DD): ");
                    LocalDate reservationEndDate = LocalDate.parse(scanner.next());
                    try {
                        managementObject.makeReservation(reservationRoomId, guestName, reservationStartDate, reservationEndDate);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 6:
                    System.out.print("Enter room id for check-in : ");
                    int checkInRoomId = scanner.nextInt();
                    System.out.print("Enter Guest Name: ");
                    String checkInGuestName = scanner.next();
                    try {
                        managementObject.checkInGuest(checkInRoomId, checkInGuestName);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 7:
                    System.out.print("Enter Room ID for check-out: ");
                    int checkOutRoomId = scanner.nextInt();
                    try {
                        managementObject.checkOutGuest(checkOutRoomId);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 8:
                	running=false;
                	break;
                default:
                    System.out.println("Invalid choice Please enter a valid choice from 0-8");
            }
        }
        scanner.close();
    }
}
