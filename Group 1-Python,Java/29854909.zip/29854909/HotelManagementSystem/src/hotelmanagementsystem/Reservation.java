package hotelmanagementsystem;

import java.time.LocalDate;
public class Reservation {
    private int id;
    private int roomId;
    private String guestName;
    private LocalDate startDate;
    private LocalDate endDate;
    
    public Reservation(int id, int roomId, String guestName, LocalDate startDate, LocalDate endDate) {
        this.id = id;
        this.roomId = roomId;
        this.guestName = guestName;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
    	this.id = id;
    }

    public int getRoomId() {
        return roomId;
    }
    
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
    
    public String getGuestName() {
        return guestName;
    }
    
    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }
    
    public LocalDate getStartDate() {
        return startDate;
    }

    public void setEndDate(LocalDate endDate) {
    	this.endDate = endDate;
    }
    
    public LocalDate getEndDate() {
        return endDate;
    }
    
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
    
}