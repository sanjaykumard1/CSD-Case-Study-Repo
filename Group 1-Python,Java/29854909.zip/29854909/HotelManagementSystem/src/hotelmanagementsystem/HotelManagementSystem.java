package hotelmanagementsystem;

import java.util.*;
import java.time.*;

public class HotelManagementSystem {
	 private HashMap<Integer, Room> rooms = new HashMap<>();
	 private ArrayList<Reservation> reservations = new ArrayList<>();
	 
	 public void addRoom(Room room) {
	        if (!rooms.containsKey(room.getId())) {
	            rooms.put(room.getId(), room);
	            System.out.println("Room added successfully");
	        } else {
	            System.out.println("Room already exists");
	        }
	 }
	 public void removeRoom(int roomId) {
		 if (rooms.containsKey(roomId)) {
	            rooms.remove(roomId);
	            System.out.println("Room removed successfully");
	        } else {
	            System.out.println("Room does not exist");
	        }
	}
	 public void updateRoom(int roomId, Room updatedRoom) {
	        if (rooms.containsKey(roomId)) {
	            rooms.put(roomId, updatedRoom);
	            System.out.println("Room updated successfully");
	        } else {
	            System.out.println("Room does not exist");
	        }
	    }
	 public boolean checkRoomAvailability(int roomNumber, LocalDate startDate, LocalDate endDate) {
	        for (Reservation reservation : reservations) {
	            Room room = rooms.get(reservation.getRoomId());
	            if (room != null && room.getRoomNumber() == roomNumber) {
	                if (reservation.getStartDate().isBefore(endDate) && startDate.isBefore(reservation.getEndDate())) {
	                    return false;
	                }
	            }
	        }
	        return true;
	    }
	 public void makeReservation(int roomId, String guestName, LocalDate startDate, LocalDate endDate) throws Exception {
	        if (rooms.containsKey(roomId) && rooms.get(roomId).isAvailable() && checkRoomAvailability(rooms.get(roomId).getRoomNumber(), startDate, endDate)) {
	            Reservation reservation = new Reservation(reservations.size() + 1, roomId, guestName, startDate, endDate);
	            reservations.add(reservation);
	            System.out.println("Reservation made successfully: " + reservation);
	        } else {
	            throw new Exception("Room is not available for the given dates.");
	        }
	    }
	 public void checkInGuest(int roomId, String guestName) throws Exception {
	        for (Reservation reservation : reservations) {
	            if (reservation.getRoomId() == roomId && reservation.getGuestName().equals(guestName) && reservation.getStartDate().isEqual(LocalDate.now())) {
	                rooms.get(roomId).setAvailable(false);
	                System.out.println("checked in successfully");
	                return;
	            }
	        }
	        throw new Exception("Reservation not found");
	    }
	 public void checkOutGuest(int roomId) throws Exception {
	        if (rooms.containsKey(roomId)) {
	            rooms.get(roomId).setAvailable(true);
	            System.out.println("checked out successfully");
	        } else {
	            throw new Exception("Room not found");
	        }
	    }
}
