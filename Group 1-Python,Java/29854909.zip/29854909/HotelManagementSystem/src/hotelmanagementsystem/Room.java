package hotelmanagementsystem;
public class Room {
	private int id;
    private int roomNumber;
    private String roomType;
    private double pricePerNight;
    private boolean isAvailable;
    
    public Room(int id, int roomNumber, String roomType, double pricePerNight,boolean isAvailable) {
    	this.id = id;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.isAvailable = isAvailable;
    }
    public int getId() {
		return id;
	}
    public void setId(int id) {
		this.id = id;
	}
    public int getRoomNumber() {
		return roomNumber;
	}
    public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}
    public double getPricePerNight() {
		return pricePerNight;
	}
    public void setPricePerNight(double pricePerNight) {
		this.pricePerNight = pricePerNight;
	}
    public String getRoomType() {
		return roomType;
	}
    public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
    public void setAvailable(boolean isAvailable) {
    	this.isAvailable = isAvailable;
    }
    public boolean isAvailable() {
		return isAvailable;
	}
}
