/**
 * 
 */
/**
 * 
 */
module HotelManagementSystem {
}