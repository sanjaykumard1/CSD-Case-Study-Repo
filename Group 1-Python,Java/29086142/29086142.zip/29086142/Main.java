import java.util.*;

// Class representing a Student
class Student {
    private int id;
    private String name;
    private String address;
    private String contactNumber;
    private List<Course> coursesEnrolled;

    // Constructor for Student
    public Student(int id, String name, String address, String contactNumber) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.contactNumber = contactNumber;
        this.coursesEnrolled = new ArrayList<>();
    }

    // Getters and Setters for Student attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public List<Course> getCoursesEnrolled() {
        return coursesEnrolled;
    }

    // Enroll a student in a course
    public void enrollCourse(Course course) {
        coursesEnrolled.add(course);
    }

    // Unenroll a student from a course
    public void unenrollCourse(Course course) {
        coursesEnrolled.remove(course);
    }

    // Override toString method to display student details
    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", coursesEnrolled=" + getCourseNames() +
                '}';
    }

    private String getCourseNames() {
        List<String> courseNames = new ArrayList<>();
        for (Course course : coursesEnrolled) {
            courseNames.add(course.getName());
        }
        return courseNames.toString();
    }
}

// Class representing a Course
class Course {
    private int id;
    private String name;
    private String instructor;
    private String schedule;
    private int capacity;
    private List<Student> studentsEnrolled;

    // Constructor for Course
    public Course(int id, String name, String instructor, String schedule, int capacity) {
        this.id = id;
        this.name = name;
        this.instructor = instructor;
        this.schedule = schedule;
        this.capacity = capacity;
        this.studentsEnrolled = new ArrayList<>();
    }

    // Getters and Setters for Course attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public List<Student> getStudentsEnrolled() {
        return studentsEnrolled;
    }

    // Enroll a student in the course
    public void enrollStudent(Student student) {
        if (studentsEnrolled.size() < capacity) {
            studentsEnrolled.add(student);
        }
    }

    // Unenroll a student from the course
    public void unenrollStudent(Student student) {
        studentsEnrolled.remove(student);
    }

    // Override toString method to display course details
    @Override
   public String toString() {
        return "Course{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", instructor='" + instructor + '\'' +
                ", schedule='" + schedule + '\'' +
                ", capacity=" + capacity +
                ", studentsEnrolled=" + getStudentNames() +
                '}';
    }

    private String getStudentNames() {
        List<String> studentNames = new ArrayList<>();
        for (Student student : studentsEnrolled) {
            studentNames.add(student.getName());
        }
        return studentNames.toString();
    }
}

// Class for managing enrollments
class EnrollmentManager {
    Map<Integer, Student> students;
    Map<Integer, Course> courses;

    // Constructor for EnrollmentManager
    public EnrollmentManager() {
        students = new HashMap<>();
        courses = new HashMap<>();
    }

    // Add a new student
    public void addStudent(Student student) throws EnrollmentException {
        if (!students.containsKey(student.getId())) {
            students.put(student.getId(), student);
        } else {
            throw new EnrollmentException("Student with ID " + student.getId() + " already exists.");
        }
    }

    // Remove a student
    public void removeStudent(int studentId) throws StudentNotFoundException {
        if (students.containsKey(studentId)) {
            students.remove(studentId);
        } else {
            throw new StudentNotFoundException(studentId);
        }
    }

    // Update a student's details
    public void updateStudent(int studentId, Student updatedStudent) throws StudentNotFoundException {
        if (students.containsKey(studentId)) {
            students.put(studentId, updatedStudent);
        } else {
            throw new StudentNotFoundException(studentId);
        }
    }

    // Search for a student by ID
    public Student searchStudentById(int studentId) throws StudentNotFoundException {
        Student student = students.get(studentId);
        if (student == null) {
            throw new StudentNotFoundException(studentId);
        }
        return student;
    }
    // Search for a student by Keywords
    public List<Student> searchStudentsByKeyword(String keyword)  {
    List<Student> matchingStudents = new ArrayList<>();
    for (Student student : students.values()) {
        if (student.getName().contains(keyword) || 
            student.getAddress().contains(keyword) || 
            student.getContactNumber().contains(keyword) ||
            Integer.toString(student.getId()).contains(keyword)) {
            matchingStudents.add(student);
        }
    }
        return matchingStudents;
    }
    

    // Enroll a student in a course
    public void enrollStudent(int studentId, int courseId) throws EnrollmentException {
        Student student = students.get(studentId);
        Course course = courses.get(courseId);
        if (student != null && course != null) {
            if (course.getCapacity() > course.getStudentsEnrolled().size()) {
                if (!course.getStudentsEnrolled().contains(student)) {
                    student.enrollCourse(course);
                    course.enrollStudent(student);
                } else {
                    System.out.println("Student with ID " + studentId + " is already enrolled in course " + courseId);
                }
            } else {
                throw new CapacityFullException(course.getName());
            }
        } else {
            if (student == null) {
                throw new StudentNotFoundException(studentId);
            }
            if (course == null) {
                throw new CourseNotFoundException(courseId);
            }
        }
    }

    // Unenroll a student from a course
    public void unenrollStudent(int studentId, int courseId) throws EnrollmentException {
        Student student = students.get(studentId);
        Course course = courses.get(courseId);
        if (student != null && course != null) {
            student.unenrollCourse(course);
            course.unenrollStudent(student);
        } else {
            if (student == null) {
                throw new StudentNotFoundException(studentId);
            }
            if (course == null) {
                throw new CourseNotFoundException(courseId);
            }
        }
    }

    // Helper method to validate student ID
    public boolean isValidStudentId(int studentId) {
        return studentId > 0;
    }

    // Helper method to validate course ID
    public boolean isValidCourseId(int courseId) {
        return courseId > 0;
    }

    // Custom Exceptions for various error scenarios
    public static class EnrollmentException extends Exception {
        public EnrollmentException(String message) {
            super(message);
        }
    }

    public static class StudentNotFoundException extends EnrollmentException {
        public StudentNotFoundException(int studentId) {
            super("Student with ID " + studentId + " not found.");
        }
    }

    public static class CourseNotFoundException extends EnrollmentException {
        public CourseNotFoundException(int courseId) {
            super("Course with ID " + courseId + " not found.");
        }
    }

    public static class CapacityFullException extends EnrollmentException {
        public CapacityFullException(String courseName) {
            super("Cannot enroll student. Course " + courseName + " capacity is full.");
        }
    }
}

// Main class containing the main method
public class Main {
    public static void main(String[] args) {
        // Print the title and welcome message
        System.out.println("\t\t\tStudent Enrollment System");
        System.out.println("Welcome to the Student Enrollment Console Application!");

        // Initialize the EnrollmentManager
        EnrollmentManager manager = new EnrollmentManager();
        Scanner scanner = new Scanner(System.in);

        // Sample data for students and courses
        manager.students.put(1, new Student(1, "Anirudh", "123 Main St", "923-456-7890"));
        manager.students.put(2, new Student(2, "Babu", "456 Sai St", "987-654-3210"));
        manager.courses.put(1, new Course(1, "Math 101", "Dr. Ram", "MWF 10AM-11AM", 2)); // Set capacity to 2 for testing
        manager.courses.put(2, new Course(2, "History 102", "Dr. Kamal", "TF 1PM-2:30PM", 25));
        manager.courses.put(3, new Course(3, "Economics 103", "Dr. Ganesh", "TTh 3PM-4:30PM", 35));
        manager.courses.put(4, new Course(4, "Biology 104", "Dr. Gokul", "TF 10AM-12:30PM", 45));
        manager.courses.put(5, new Course(5, "Physics 105", "Dr. Karthi", "MTTh 1PM-2:30PM", 15));
        manager.courses.put(6, new Course(6, "English 106", "Dr. Karan", "TWTh 11AM-2:30PM", 20));

        // Loop to display the menu and process user input
        while (true) {
            // Display menu options
            System.out.println("\n1. Add Student");
            System.out.println("\n2. Remove Student");
            System.out.println("\n3. Update Student");
            System.out.println("\n4. Search Student");
            System.out.println("\n5. Enroll Student in Course");
            System.out.println("\n6. Unenroll Student from Course");
            System.out.println("\n7. Display All Students");
            System.out.println("\n8. Display All Courses");
            System.out.println("\n9. Exit");
            System.out.print("\nChoose an option: ");
            
            // Read user input
            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline character
            
            try {
                switch (option) {
                    case 1:
                        // Add Student
                        System.out.print("\nEnter student ID: ");
                        int studentId = scanner.nextInt();
                        scanner.nextLine(); // consume newline character
                        System.out.print("\nEnter student name: ");
                        String name = scanner.nextLine();
                        System.out.print("\nEnter student address: ");
                        String address = scanner.nextLine();
                        System.out.print("\nEnter student contact number: ");
                        String contact = scanner.nextLine();
                        while(contact.length()!=10){
                            System.out.print("\nEnter correct contact number(10 digits must): ");
                            contact = scanner.nextLine();
                        }
                        manager.addStudent(new Student(studentId, name, address, contact));
                        System.out.println("Student added successfully.");
                        break;
                    case 2:
                        // Remove Student
                        System.out.print("\nEnter student ID to remove: ");
                        studentId = scanner.nextInt();
                        manager.removeStudent(studentId);
                        System.out.println("Student removed successfully.");
                        break;
                    case 3:
                        // Update Student
                        System.out.print("\nEnter student ID to update: ");
                        studentId = scanner.nextInt();
                        scanner.nextLine(); // consume newline character
                        Student student = manager.searchStudentById(studentId);
                        System.out.println("Enter new details (leave blank to keep current):");
                        System.out.print("Name (" + student.getName() + "): ");
                        String newName = scanner.nextLine();
                        if (!newName.isEmpty()) student.setName(newName);
                        System.out.print("Address (" + student.getAddress() + "): ");
                        String newAddress = scanner.nextLine();
                        if (!newAddress.isEmpty()) student.setAddress(newAddress);
                        System.out.print("Contact Number (" + student.getContactNumber() + "): ");
                        String newContact = scanner.nextLine();
                        if (!newContact.isEmpty()) student.setContactNumber(newContact);
                        manager.updateStudent(studentId, student);
                        System.out.println("Student updated successfully.");
                        break;
                    case 4:
                        // Search Student
                        System.out.print("Enter keyword to search for students: ");
                        String keyword = scanner.nextLine();
                        List<Student> students = manager.searchStudentsByKeyword(keyword);
                        if (students.isEmpty()) {
                            System.out.println("No students found matching the keyword.");
                        } else {
                            for (Student s : students) {
                                System.out.println(s);
                            }
                        }
                        break;
                    case 5:
                        // Enroll Student in Course
                        System.out.print("\nEnter student ID to enroll: ");
                        studentId = scanner.nextInt();
                        System.out.print("\nEnter course ID to enroll in: ");
                        int courseId = scanner.nextInt();
                        manager.enrollStudent(studentId, courseId);
                        System.out.println("Student enrolled in course successfully.");
                        break;
                    case 6:
                        // Unenroll Student from Course
                        System.out.print("\nEnter student ID to unenroll: ");
                        studentId = scanner.nextInt();
                        System.out.print("\nEnter course ID to unenroll from: ");
                        courseId = scanner.nextInt();
                        manager.unenrollStudent(studentId, courseId);
                        System.out.println("Student unenrolled from course successfully.");
                        break;
                    case 7:
                        // Display All Students
                        for (Student s : manager.students.values()) {
                            System.out.println(s);
                        }
                        break;
                    case 8:
                        // Display All Courses
                        for (Course c : manager.courses.values()) {
                            System.out.println(c);
                        }
                        break;
                    case 9:
                        // Exit the application
                        System.out.println("Thank you for using the Student Enrollment System!");
                        System.exit(0);
                    default:
                        // Invalid option
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } catch (EnrollmentManager.EnrollmentException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
