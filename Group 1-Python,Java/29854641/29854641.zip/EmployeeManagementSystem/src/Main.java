package com.company.ems;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    private static void displayMenu() {
        System.out.println("1. Add Employee");
        System.out.println("2. Remove Employee");
        System.out.println("3. Update Employee");
        System.out.println("4. Add Department");
        System.out.println("5. Remove Department");
        System.out.println("6. Assign Employee to Department");
        System.out.println("7. Update Employee Department");
        System.out.println("8. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void handleAddEmployee(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Employee ID: ");
        int empId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Employee Name: ");
        String empName = scanner.nextLine();
        System.out.print("Enter Employee Designation: ");
        String empDesignation = scanner.nextLine();
        System.out.print("Enter Employee Salary: ");
        double empSalary = scanner.nextDouble();
        System.out.print("Enter Employee Department ID: ");
        int empDeptId = scanner.nextInt();
        Employee employee = new Employee(empId, empName, empDesignation, empSalary, empDeptId);
        ems.addEmployee(employee);
    }

    private static void handleRemoveEmployee(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Employee ID to remove: ");
        int removeEmpId = scanner.nextInt();
        ems.removeEmployee(removeEmpId);
    }

    private static void handleUpdateEmployee(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Employee ID to update: ");
        int updateEmpId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter New Employee Name: ");
        String updateEmpName = scanner.nextLine();
        System.out.print("Enter New Employee Designation: ");
        String updateEmpDesignation = scanner.nextLine();
        System.out.print("Enter New Employee Salary: ");
        double updateEmpSalary = scanner.nextDouble();
        System.out.print("Enter New Employee Department ID: ");
        int updateEmpDeptId = scanner.nextInt();
        Employee updatedEmployee = new Employee(updateEmpId, updateEmpName, updateEmpDesignation, updateEmpSalary, updateEmpDeptId);
        ems.updateEmployee(updateEmpId, updatedEmployee);
    }

    private static void handleAddDepartment(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Department ID: ");
        int deptId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter Department Name: ");
        String deptName = scanner.nextLine();
        System.out.print("Enter Department Description: ");
        String deptDescription = scanner.nextLine();
        Department department = new Department(deptId, deptName, deptDescription);
        ems.addDepartment(department);
    }

    private static void handleRemoveDepartment(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Department ID to remove: ");
        int removeDeptId = scanner.nextInt();
        ems.removeDepartment(removeDeptId);
    }

    private static void handleAssignEmployeeToDepartment(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Employee ID: ");
        int assignEmpId = scanner.nextInt();
        System.out.print("Enter Department ID: ");
        int assignDeptId = scanner.nextInt();
        ems.assignEmployeeToDepartment(assignEmpId, assignDeptId);
    }

    private static void handleUpdateEmployeeDepartment(Scanner scanner, EmployeeManagementSystem ems) {
        System.out.print("Enter Employee ID: ");
        int updateDeptEmpId = scanner.nextInt();
        System.out.print("Enter New Department ID: ");
        int newDeptId = scanner.nextInt();
        ems.updateEmployeeDepartment(updateDeptEmpId, newDeptId);
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            displayMenu();

            int choice;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
                continue;
            }

            switch (choice) {
                case 1:
                    handleAddEmployee(scanner, ems);
                    break;
                case 2:
                    handleRemoveEmployee(scanner, ems);
                    break;
                case 3:
                    handleUpdateEmployee(scanner, ems);
                    break;
                case 4:
                    handleAddDepartment(scanner, ems);
                    break;
                case 5:
                    handleRemoveDepartment(scanner, ems);
                    break;
                case 6:
                    handleAssignEmployeeToDepartment(scanner, ems);
                    break;
                case 7:
                    handleUpdateEmployeeDepartment(scanner, ems);
                    break;
                case 8:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
}
