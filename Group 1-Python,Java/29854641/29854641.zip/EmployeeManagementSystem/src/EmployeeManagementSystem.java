package com.company.ems;

import java.util.HashMap;

public class EmployeeManagementSystem {
    private HashMap<Integer, Employee> employees;
    private HashMap<Integer, Department> departments;

    public EmployeeManagementSystem() {
        employees = new HashMap<>();
        departments = new HashMap<>();
    }

    public void addEmployee(Employee employee) {
        if (employees.containsKey(employee.getId())) {
            System.out.println("Employee ID already exists.");
        } else {
            employees.put(employee.getId(), employee);
            System.out.println("Employee added successfully.");
        }
    }

    public void removeEmployee(int employeeId) {
        if (employees.containsKey(employeeId)) {
            employees.remove(employeeId);
            System.out.println("Employee removed successfully.");
        } else {
            System.out.println("Employee ID not found.");
        }
    }

    public void updateEmployee(int employeeId, Employee updatedEmployee) {
        if (employees.containsKey(employeeId)) {
            employees.put(employeeId, updatedEmployee);
            System.out.println("Employee updated successfully.");
        } else {
            System.out.println("Employee ID not found.");
        }
    }

    public void addDepartment(Department department) {
        if (departments.containsKey(department.getId())) {
            System.out.println("Department ID already exists.");
        } else {
            departments.put(department.getId(), department);
            System.out.println("Department added successfully.");
        }
    }

    public void removeDepartment(int departmentId) {
        if (departments.containsKey(departmentId)) {
            departments.remove(departmentId);
            System.out.println("Department removed successfully.");
        } else {
            System.out.println("Department ID not found.");
        }
    }

    public void assignEmployeeToDepartment(int employeeId, int departmentId) {
        if (employees.containsKey(employeeId) && departments.containsKey(departmentId)) {
            Employee employee = employees.get(employeeId);
            employee.setDepartmentId(departmentId);
            System.out.println("Employee assigned to department successfully.");
        } else {
            System.out.println("Invalid employee ID or department ID.");
        }
    }

    public void updateEmployeeDepartment(int employeeId, int newDepartmentId) {
        if (employees.containsKey(employeeId) && departments.containsKey(newDepartmentId)) {
            Employee employee = employees.get(employeeId);
            employee.setDepartmentId(newDepartmentId);
            System.out.println("Employee department updated successfully.");
        } else {
            System.out.println("Invalid employee ID or department ID.");
        }
    }
}
