package dev.service;
import dev.model.Patient;

/*
HosptalService is an interface.Which provides a services for hospital management
System.The abstraction and loose coupling is achieved using this interface.
 */
public interface HospitalService
{
    public void admitPatient(Patient p, int bedNumber) ;
    public void dischargePatient(int patientId);
    public void updatePatientDetails(int patientId, Patient updatedPatient);
    public void searchPatient(String keyword);
    public void assignBed(int patientId, int bedNumber);
}
