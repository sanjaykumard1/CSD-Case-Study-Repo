package dev.model;

/* This is a model of Bed which has  attributes, setter , getters and constructors

 */

public class Bed
{
  private  int  bedNumber;
  private boolean occupied;

    public Bed(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public Bed(int bedNumber, boolean occupied) {
        this.bedNumber = bedNumber;
        this.occupied = occupied;
    }

    public int getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    /*
    print the all details of Bed Model
     */
    @Override
    public String toString() {
        return "Bed{" +
                "bedNumber=" + bedNumber +
                ", occupied=" + occupied +
                '}';
    }
}



