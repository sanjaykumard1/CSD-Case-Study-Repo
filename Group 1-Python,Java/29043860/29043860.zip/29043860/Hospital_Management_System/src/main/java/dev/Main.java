package dev;

import dev.serviceImpl.HospitalManager;
import  dev.model.*;
import java.util.Date;
import java.util.Scanner;

public class Main {
    //It represents the association
    static HospitalManager manager;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
         manager = new HospitalManager();

        while (true) {
            try {
                System.out.println("1. Admit Patient");
                System.out.println("2. Discharge Patient");
                System.out.println("3. Update Patient Details");
                System.out.println("4. Search Patient");
                System.out.println("5. Assign Bed");
                System.out.println("6. Exit");

                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        // Admit patient
                        System.out.println("Enter Patient ID:");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter Patient Name:");
                        String name = scanner.nextLine();
                        System.out.println("Enter Patient Age:");
                        int age = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter Patient Gender:");
                        String gender = scanner.nextLine();
                        System.out.println("Enter Diagnosis:");
                        String diagnosis = scanner.nextLine();
                        System.out.println("Enter Treatment:");
                        String treatment = scanner.nextLine();
                        System.out.println("Enter Bed Number:");
                        int bedNumber = scanner.nextInt();
                        Patient patient = new Patient(id, name, age, gender, diagnosis, treatment, new Date());
                        manager.admitPatient(patient, bedNumber);
                        break;
                    case 2:
                        // Discharge patient
                        System.out.println("Enter Patient ID:");
                        int dischargeId = scanner.nextInt();
                        manager.dischargePatient(dischargeId);
                        break;
                    case 3:
                        // Update patient details
                        System.out.println("Enter Patient ID:");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter Updated Name:");
                        String updatedName = scanner.nextLine();
                        System.out.println("Enter Updated Age:");
                        int updatedAge = scanner.nextInt();
                        scanner.nextLine();
                        System.out.println("Enter Updated Gender:");
                        String updatedGender = scanner.nextLine();
                        System.out.println("Enter Updated Diagnosis:");
                        String updatedDiagnosis = scanner.nextLine();
                        System.out.println("Enter Updated Treatment:");
                        String updatedTreatment = scanner.nextLine();
                        Patient updatedPatient = new Patient(updateId, updatedName, updatedAge, updatedGender, updatedDiagnosis, updatedTreatment, new Date());
                        manager.updatePatientDetails(updateId, updatedPatient);
                        break;
                    case 4:
                        // Search patient
                        System.out.println("Enter search keyword:");
                        scanner.nextLine();
                        String keyword = scanner.nextLine();
                        manager.searchPatient(keyword);
                        break;
                    case 5:
                        // Assign bed to the patient
                        System.out.println("Enter Patient ID:");
                        int assignId = scanner.nextInt();
                        System.out.println("Enter Bed Number:");
                        int assignBedNumber = scanner.nextInt();
                        manager.assignBed(assignId, assignBedNumber);
                        break;
                    case 6:
                        // Exit
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.nextLine(); // to clear the buffer.
            }
        }
    }
}
