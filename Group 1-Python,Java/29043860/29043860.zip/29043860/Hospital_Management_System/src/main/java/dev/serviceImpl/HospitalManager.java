package dev.serviceImpl;
import dev.model.Patient;
import dev.model.Bed;
import dev.service.HospitalService;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/*
HospitalManager is an implementation class of HospitalService.
This class provides you the all implementation of HospitalService.
 */



public class HospitalManager implements HospitalService
{
    //Two hashMaps to store the data of patients and beds
    HashMap<Integer, Patient> patients;
    HashMap<Integer, Bed> beds ;


    public HospitalManager()
    {
        patients = new HashMap<>();
        beds = new HashMap<>();
        //creates 40 beds which describes the capacity of a hospital
        for (int i = 1; i <= 40; i++)
            beds.put(i, new Bed(i));

        System.out.println("Welcome to the hospital manager!");
    }

    // To save the data of the patient in the map
    public void admitPatient(Patient p, int bedNumber) {
        try {
            if (beds.containsKey(bedNumber) && !beds.get(bedNumber).isOccupied()) {
                patients.put(p.getId(), p);
                beds.get(bedNumber).setOccupied(true);
                System.out.println("Patient admitted successfully.");
            } else {
                System.out.println("Bed not available.");
            }
        } catch (Exception e) {
            System.out.println("Error admitting patient: " + e.getMessage());
        }
    }

    // To remove the particular Patient using the patient Id.
    public void dischargePatient(int patientId) {
        try {
            if (patients.containsKey(patientId)) {
                Patient patient = patients.get(patientId);
                patient.setDischargeDate(new Date());
                for (Map.Entry<Integer, Bed> entry : beds.entrySet()) {
                    if (entry.getValue().isOccupied() && patients.get(patientId).equals(entry.getValue())) {
                        entry.getValue().setOccupied(false);
                        break;
                    }
                }
                patients.remove(patientId);
                System.out.println("Patient discharged successfully.");
            } else {
                System.out.println("Patient not found.");
            }
        } catch (Exception e) {
            System.out.println("Error discharging patient: " + e.getMessage());
        }
    }
     // To update the existing record of particular patient using patient.First it will search then update it.
    public void updatePatientDetails(int patientId, Patient updatedPatient) {
        try {
            if (patients.containsKey(patientId)) {
                patients.put(patientId, updatedPatient);
                System.out.println("Patient details updated successfully.");
            } else {
                System.out.println("Patient not found.");
            }
        } catch (Exception e) {
            System.out.println("Error updating patient details: " + e.getMessage());
        }
    }

    //To search the patient using the patient name.
    public void searchPatient(String keyword) {
        try {
            for (Patient patient : patients.values()) {
                if (patient.getName().contains(keyword) || Integer.toString(patient.getId()).contains(keyword) || patient.getDiagnosis().contains(keyword)) {
                    System.out.println(patient);
                }
            }
        } catch (Exception e) {
            System.out.println("Error searching for patient: " + e.getMessage());
        }
    }

    // To book the bed to the patient using patient id and bed number
    public void assignBed(int patientId, int bedNumber) {
        try {
            if (patients.containsKey(patientId) && beds.containsKey(bedNumber) && !beds.get(bedNumber).isOccupied()) {
                beds.get(bedNumber).setOccupied(true);
                System.out.println("Bed assigned successfully.");
            } else {
                System.out.println("Cannot assign bed.");
            }
        } catch (Exception e) {
            System.out.println("Error assigning bed: " + e.getMessage());
        }
    }


}

