import java.util.*;
import java.time.LocalDateTime;
 class MenuItem {
    private int id;
    private String name;
    private String category;
    private double price;
    private boolean available;

    public MenuItem(int id, String name, String category, double price, boolean available) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.available = available;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return "MenuItem{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", category='" + category + '\'' +
                ", price=" + price +
                ", available=" + available +
                '}';
    }
}
 class Order {
    private int id;
    private int menuItemId;
    private int quantity;
    private LocalDateTime orderTime;
    private String status; // "pending", "preparing", "ready", "served"

    public Order(int id, int menuItemId, int quantity, LocalDateTime orderTime, String status) {
        this.id = id;
        this.menuItemId = menuItemId;
        this.quantity = quantity;
        this.orderTime = orderTime;
        this.status = status;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMenuItemId() { return menuItemId; }
    public void setMenuItemId(int menuItemId) { this.menuItemId = menuItemId; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public LocalDateTime getOrderTime() { return orderTime; }
    public void setOrderTime(LocalDateTime orderTime) { this.orderTime = orderTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", menuItemId=" + menuItemId +
                ", quantity=" + quantity +
                ", orderTime=" + orderTime +
                ", status='" + status + '\'' +
                '}';
    }
}
public class RestaurantManager {
    private HashMap<Integer, MenuItem> menuItems;
    private ArrayList<Order> orders;
    private int menuItemIdCounter;
    private int orderIdCounter;

    public RestaurantManager() {
        menuItems = new HashMap<>();
        orders = new ArrayList<>();
        menuItemIdCounter = 1;
        orderIdCounter = 1;
    }

    public void addMenuItem(MenuItem item) {
        menuItems.put(item.getId(), item);
    }

    public void removeMenuItem(int itemId) {
        if (menuItems.containsKey(itemId)) {
            menuItems.remove(itemId);
        } else {
            System.out.println("Menu item not found.");
        }
    }

    public void updateMenuItem(int itemId, MenuItem updatedItem) {
        if (menuItems.containsKey(itemId)) {
            menuItems.put(itemId, updatedItem);
        } else {
            System.out.println("Menu item not found.");
        }
    }

    public List<MenuItem> searchMenuItems(String keyword) {
        List<MenuItem> result = new ArrayList<>();
        for (MenuItem item : menuItems.values()) {
            if (item.getName().toLowerCase().contains(keyword.toLowerCase()) || 
                item.getCategory().toLowerCase().contains(keyword.toLowerCase())) {
                result.add(item);
            }
        }
        return result;
    }

    public void placeOrder(int itemId, int quantity) {
        if (menuItems.containsKey(itemId) && menuItems.get(itemId).isAvailable()) {
            Order order = new Order(orderIdCounter++, itemId, quantity, LocalDateTime.now(), "pending");
            orders.add(order);
            System.out.println("Order placed successfully.");
        } else {
            System.out.println("Menu item not available.");
        }
    }

    public void processOrder(int orderId) {
        for (Order order : orders) {
            if (order.getId() == orderId) {
                if (order.getStatus().equals("pending")) {
                    order.setStatus("preparing");
                    System.out.println("Order is now being prepared.");
                } else if (order.getStatus().equals("preparing")) {
                    order.setStatus("ready");
                    System.out.println("Order is now ready.");
                } else if (order.getStatus().equals("ready")) {
                    order.setStatus("served");
                    System.out.println("Order has been served.");
                }
                return;
            }
        }
        System.out.println("Order not found.");
    }

    public void displayMenu() {
        for (MenuItem item : menuItems.values()) {
            System.out.println(item);
        }
    }

    public void displayOrders() {
        for (Order order : orders) {
            System.out.println(order);
        }
    }

    public static void main(String[] args) {
        RestaurantManager manager = new RestaurantManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            try{
            System.out.println("\nRestaurant Management System:");
            System.out.println("1. Add and remove Menu Item");
            System.out.println("2. Update Menu Item");
            System.out.println("3. Search Menu Items");
            System.out.println("4. Process order");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.println("To Add Menu Item enter 1");
                    System.out.println("To Remove Menu Item enter 2");
                    System.out.print("Choose an option: ");
                    int choice1 = scanner.nextInt();
                    scanner.nextLine();
                    switch(choice1){
                            case 1:
                                System.out.print("Enter item name: ");
                                String name = scanner.nextLine();
                                System.out.print("Enter item category: ");
                                String category = scanner.nextLine();
                                System.out.print("Enter item price: ");
                                double price = scanner.nextDouble();
                                System.out.print("Is the item available (true/false): ");
                                boolean available = scanner.nextBoolean();
                                MenuItem newItem = new MenuItem(manager.menuItemIdCounter++, name, category, price, available);
                                manager.addMenuItem(newItem);
                                break;
                            case 2:
                                System.out.print("Enter item ID to remove: ");
                                int removeId = scanner.nextInt();
                                manager.removeMenuItem(removeId);
                                break;
                             }
                             break;
                case 2:
                    System.out.print("Enter item ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new item name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new item category: ");
                    String newCategory = scanner.nextLine();
                    System.out.print("Enter new item price: ");
                    double newPrice = scanner.nextDouble();
                    System.out.print("Is the item available (true/false): ");
                    boolean newAvailable = scanner.nextBoolean();
                    MenuItem updatedItem = new MenuItem(updateId, newName, newCategory, newPrice, newAvailable);
                    manager.updateMenuItem(updateId, updatedItem);
                    break;
                case 3:
                    System.out.print("Enter keyword to search: ");
                    String keyword = scanner.nextLine();
                    List<MenuItem> results = manager.searchMenuItems(keyword);
                    if (results.isEmpty()) {
                        System.out.println("No items found.");
                    } else {
                        for (MenuItem item : results) {
                            System.out.println(item);
                        }
                    }
                    break;
                case 4:
                        System.out.println("To Place Order enter 1");
                        System.out.println("To Process Order enter 2");
                        System.out.println("To Display Menu enter 3");
                        System.out.println("To Display Orders 4");
                        System.out.print("Choose an option: ");
                        int choice2 = scanner.nextInt();
                        scanner.nextLine();
                           switch(choice2){
                                    case 1:
                                        System.out.print("Enter item ID to order: ");
                                        int orderId = scanner.nextInt();
                                        System.out.print("Enter quantity: ");
                                        int quantity = scanner.nextInt();
                                        manager.placeOrder(orderId, quantity);
                                        break;
                                    case 2:
                                        System.out.print("Enter order ID to process: ");
                                        int processId = scanner.nextInt();
                                        manager.processOrder(processId);
                                        break;
                                    case 3:
                                        manager.displayMenu();
                                        break;
                                    case 4:
                                        manager.displayOrders();
                                        break;
                                 }
                                 break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }catch(InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid option.");
            scanner.nextLine(); // Consume newline to avoid infinite loop
        }
    }
}
}

