package case6;
import java.util.*;
public class EmployeeManagementSystem {
    private Map<Integer, Employee> employees = new HashMap<>();
    private Map<Integer, Department> departments = new HashMap<>();

    // Add a new employee
    public void addEmployee(Employee employee) {
        employees.put(employee.getId(), employee);
        System.out.println("Employee added: " + employee);
    }

    // Remove an employee
    public void removeEmployee(int employeeId) {
        Employee removedEmployee = employees.remove(employeeId);
        if (removedEmployee != null) {
            System.out.println("Employee removed: " + removedEmployee);
        } else {
            System.out.println("Employee not found.");
        }
    }

    // Update employee details
    public void updateEmployee(int employeeId, Employee updatedEmployee) {
        if (employees.containsKey(employeeId)) {
            employees.put(employeeId, updatedEmployee);
            System.out.println("Employee updated: " + updatedEmployee);
        } else {
            System.out.println("Employee not found.");
        }
    }

    // Add a new department
    public void addDepartment(Department department) {
        departments.put(department.getId(), department);
        System.out.println("Department added: " + department);
    }

    // Remove a department
    public void removeDepartment(int departmentId) {
        Department removedDepartment = departments.remove(departmentId);
        if (removedDepartment != null) {
            System.out.println("Department removed: " + removedDepartment);
        } else {
            System.out.println("Department not found.");
        }
    }

    // Assign an employee to a department
    public void assignEmployeeToDepartment(int employeeId, int departmentId) {
        Employee employee = employees.get(employeeId);
        Department department = departments.get(departmentId);
        if (employee != null && department != null) {
            employee.setDepartmentId(departmentId);
            System.out.println("Assigned employee " + employeeId + " to department " + departmentId);
        } else {
            System.out.println("Employee or department not found.");
        }
    }

    // Update the department of an employee
    public void updateEmployeeDepartment(int employeeId, int newDepartmentId) {
        Employee employee = employees.get(employeeId);
        Department department = departments.get(newDepartmentId);
        if (employee != null && department != null) {
            employee.setDepartmentId(newDepartmentId);
            System.out.println("Updated department of employee " + employeeId + " to " + newDepartmentId);
        } else {
            System.out.println("Employee or department not found.");
        }
    }

    // Other helper methods for input validation and exception handling can be added here.
}
