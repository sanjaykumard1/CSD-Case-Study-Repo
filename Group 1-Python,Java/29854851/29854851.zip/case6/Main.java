package case6;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nEmployee Management System Menu:");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Add Department");
            System.out.println("5. Remove Department");
            System.out.println("6. Assign Employee to Department");
            System.out.println("7. Update Employee Department");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter employee ID: ");
                    int addEmpId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter employee name: ");
                    String addEmpName = scanner.nextLine();
                    System.out.print("Enter designation: ");
                    String addEmpDesignation = scanner.nextLine();
                    System.out.print("Enter salary: ");
                    double addEmpSalary = scanner.nextDouble();
                    System.out.print("Enter department ID: ");
                    int addEmpDeptId = scanner.nextInt();
                    
                    Employee newEmployee = new Employee(addEmpId, addEmpName, addEmpDesignation, addEmpSalary, addEmpDeptId);
                    ems.addEmployee(newEmployee);
                    break;

                case 2:
                    System.out.print("Enter employee ID to remove: ");
                    int removeEmpId = scanner.nextInt();
                    ems.removeEmployee(removeEmpId);
                    break;

                case 3:
                    System.out.print("Enter employee ID to update: ");
                    int updateEmpId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new name: ");
                    String updateEmpName = scanner.nextLine();
                    System.out.print("Enter new designation: ");
                    String updateEmpDesignation = scanner.nextLine();
                    System.out.print("Enter new salary: ");
                    double updateEmpSalary = scanner.nextDouble();
                    System.out.print("Enter new department ID: ");
                    int updateEmpDeptId = scanner.nextInt();

                    Employee updatedEmployee = new Employee(updateEmpId, updateEmpName, updateEmpDesignation, updateEmpSalary, updateEmpDeptId);
                    ems.updateEmployee(updateEmpId, updatedEmployee);
                    break;

                case 4:
                    System.out.print("Enter department ID: ");
                    int addDeptId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter department name: ");
                    String addDeptName = scanner.nextLine();
                    System.out.print("Enter department description: ");
                    String addDeptDescription = scanner.nextLine();

                    Department newDepartment = new Department(addDeptId, addDeptName, addDeptDescription);
                    ems.addDepartment(newDepartment);
                    break;

                case 5:
                    System.out.print("Enter department ID to remove: ");
                    int removeDeptId = scanner.nextInt();
                    ems.removeDepartment(removeDeptId);
                    break;

                case 6:
                    System.out.print("Enter employee ID to assign: ");
                    int assignEmpId = scanner.nextInt();
                    System.out.print("Enter department ID to assign to: ");
                    int assignDeptId = scanner.nextInt();
                    ems.assignEmployeeToDepartment(assignEmpId, assignDeptId);
                    break;

                case 7:
                    System.out.print("Enter employee ID to update department: ");
                    int updateDeptEmpId = scanner.nextInt();
                    System.out.print("Enter new department ID: ");
                    int updateNewDeptId = scanner.nextInt();
                    ems.updateEmployeeDepartment(updateDeptEmpId, updateNewDeptId);
                    break;

                case 8:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}

