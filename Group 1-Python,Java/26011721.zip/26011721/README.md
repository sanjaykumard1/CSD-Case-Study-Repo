# Hotel Management System

## Project Owner
Ambuj Tripathi   
Candidate ID : 26011721  
[acc.ambujtripathi@gmail.com](mailto:acc.ambujtripathi@gmail.com)  
Case Study No.: 12  
## Project Demonstration Video
[https://drive.google.com/file/d/1RI2n5ym9GDUm_VMQELalNacu5C4m-oe1/view?usp=sharing](https://drive.google.com/file/d/1RI2n5ym9GDUm_VMQELalNacu5C4m-oe1/view?usp=sharing)

## Project Description

This Hotel Management System is a console-based application developed in Core Java. The application allows hotel staff to manage rooms, reservations, and guest services. It utilizes Java Collections for storing room and reservation information and implements Object-Oriented Programming principles along with exception handling to manage potential errors.

### Features:

1. **Add and Remove Rooms:**
    - Allows hotel staff to add new rooms to the system.
    - Allows hotel staff to remove rooms from the system.

2. **Update Room Details:**
    - Allows hotel staff to update details of existing rooms, such as room type, price, and availability.

3. **Check Room Availability:**
    - Allows hotel staff to check the availability of rooms for a given date range.

4. **Make Reservations:**
    - Allows hotel staff to make reservations for guests.
    - Ensures that reservations do not overlap with existing reservations for the same room.

5. **Check-in and Check-out Guests:**
    - Allows hotel staff to check-in guests to their reserved rooms.
    - Allows hotel staff to check-out guests from their rooms.

### Classes and Objects:

- **Room Class:**
    - Attributes: `id`, `roomNumber`, `roomType`, `pricePerNight`, `isAvailable`.
    - Methods: Constructors, getters and setters, `toString` method.

- **Reservation Class:**
    - Attributes: `id`, `roomId`, `guestName`, `startDate`, `endDate`.
    - Methods: Constructors, getters and setters, `toString` method.

- **HotelManagementSystem Class:**
    - Attributes: `HashMap<Integer, Room> rooms`, `ArrayList<Reservation> reservations`.
    - Methods:
        - `addRoom(Room room)`: Adds a new room to the system.
        - `removeRoom(int roomId)`: Removes a room from the system.
        - `updateRoom(int roomId, Room updatedRoom)`: Updates details of an existing room.
        - `checkRoomAvailability(int roomNumber, LocalDate startDate, LocalDate endDate)`: Checks the availability of a room for a given date range.
        - `makeReservation(int roomId, String guestName, LocalDate startDate, LocalDate endDate)`: Makes a reservation for a guest.
        - `checkInGuest(int roomId, String guestName)`: Checks-in a guest to a reserved room.
        - `checkOutGuest(int roomId)`: Checks-out a guest from a room.
        - Helper methods for input validation and exception handling.

## Getting Started

### Prerequisites

- Java Development Kit (JDK) 8 or higher
- An IDE like IntelliJ IDEA, Eclipse, or NetBeans
- Git

### Installation

1. **Install JDK:**

   Download and install JDK from the [official Oracle website](https://www.oracle.com/java/technologies/javase-downloads.html).

2. **Set Up IDE:**

   - Download and install an IDE of your choice:
     - [IntelliJ IDEA](https://www.jetbrains.com/idea/download/)
     - [Eclipse](https://www.eclipse.org/downloads/)
     - [NetBeans](https://netbeans.apache.org/download/index.html)

3. **Clone the Repository:**

   Open your terminal or command prompt and run the following command to clone the repository:

   ```bash
   git clone https://github.com/ambujtripathi988/hotel-management-system.git
