import java.time.LocalDate;
import java.util.*;

class Room {
    private int id;
    private int roomNumber;
    private String roomType;
    private double pricePerNight;
    private boolean isAvailable;

    public Room(int id, int roomNumber, String roomType, double pricePerNight) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.isAvailable = true;
    }

    public int getId() {
        return id;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setPricePerNight(double pricePerNight) {
        this.pricePerNight = pricePerNight;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    @Override
    public String toString() {
        return "Room{" +
                "id=" + id +
                ", roomNumber=" + roomNumber +
                ", roomType='" + roomType + '\'' +
                ", pricePerNight=" + pricePerNight +
                ", isAvailable=" + isAvailable +
                '}';
    }
}

class Reservation {
    private int id;
    private int roomId;
    private String guestName;
    private LocalDate startDate;
    private LocalDate endDate;

    public Reservation(int id, int roomId, String guestName, LocalDate startDate, LocalDate endDate) {
        this.id = id;
        this.roomId = roomId;
        this.guestName = guestName;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getId() {
        return id;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getGuestName() {
        return guestName;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "id=" + id +
                ", roomId=" + roomId +
                ", guestName='" + guestName + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}

public class HotelManagementSystem {
    private HashMap<Integer, Room> rooms;
    private ArrayList<Reservation> reservations;
    private int nextRoomId = 1;
    private int nextReservationId = 1;

    public HotelManagementSystem() {
        rooms = new HashMap<>();
        reservations = new ArrayList<>();
    }

    public void addRoom(int roomNumber, String roomType, double pricePerNight) {
        Room room = new Room(nextRoomId++, roomNumber, roomType, pricePerNight);
        rooms.put(room.getId(), room);
        System.out.println("Room added: " + room);
    }

    public void removeRoom(int roomId) {
        if (rooms.containsKey(roomId)) {
            rooms.remove(roomId);
            System.out.println("Room removed: " + roomId);
        } else {
            System.out.println("Room not found: " + roomId);
        }
    }

    public void updateRoom(int roomId, String roomType, double pricePerNight) {
        Room room = rooms.get(roomId);
        if (room != null) {
            room.setRoomType(roomType);
            room.setPricePerNight(pricePerNight);
            System.out.println("Room updated: " + room);
        } else {
            System.out.println("Room not found: " + roomId);
        }
    }

    public void checkRoomAvailability(int roomNumber, LocalDate startDate, LocalDate endDate) {
        boolean available = true;
        for (Reservation reservation : reservations) {
            if (reservation.getRoomId() == roomNumber &&
                    !(endDate.isBefore(reservation.getStartDate()) || startDate.isAfter(reservation.getEndDate()))) {
                available = false;
                break;
            }
        }
        System.out.println("Room " + roomNumber + " is " + (available ? "available" : "not available") + " from " + startDate + " to " + endDate);
    }

    public void makeReservation(int roomId, String guestName, LocalDate startDate, LocalDate endDate) {
        Room room = rooms.get(roomId);
        if (room != null && room.isAvailable()) {
            boolean overlap = false;
            for (Reservation reservation : reservations) {
                if (reservation.getRoomId() == roomId &&
                        !(endDate.isBefore(reservation.getStartDate()) || startDate.isAfter(reservation.getEndDate()))) {
                    overlap = true;
                    break;
                }
            }
            if (!overlap) {
                Reservation reservation = new Reservation(nextReservationId++, roomId, guestName, startDate, endDate);
                reservations.add(reservation);
                room.setAvailable(false);
                System.out.println("Reservation made: " + reservation);
            } else {
                System.out.println("Reservation overlaps with an existing reservation.");
            }
        } else {
            System.out.println("Room not available or not found: " + roomId);
        }
    }

    public void checkInGuest(int roomId, String guestName) {
        Room room = rooms.get(roomId);
        if (room != null && !room.isAvailable()) {
            System.out.println("Guest " + guestName + " checked in to room " + roomId);
        } else {
            System.out.println("Room not available or not found: " + roomId);
        }
    }

    public void checkOutGuest(int roomId) {
        Room room = rooms.get(roomId);
        if (room != null) {
            room.setAvailable(true);
            System.out.println("Guest checked out from room " + roomId);
        } else {
            System.out.println("Room not found: " + roomId);
        }
    }

    public static void main(String[] args) {
        HotelManagementSystem system = new HotelManagementSystem();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Hotel Management System");
            System.out.println("1. Add Room");
            System.out.println("2. Remove Room");
            System.out.println("3. Update Room");
            System.out.println("4. Check Room Availability");
            System.out.println("5. Make Reservation");
            System.out.println("6. Check-in Guest");
            System.out.println("7. Check-out Guest");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter room number: ");
                    int roomNumber = scanner.nextInt();
                    System.out.print("Enter room type: ");
                    String roomType = scanner.next();
                    System.out.print("Enter price per night: ");
                    double pricePerNight = scanner.nextDouble();
                    system.addRoom(roomNumber, roomType, pricePerNight);
                    break;
                case 2:
                    System.out.print("Enter room ID to remove: ");
                    int roomId = scanner.nextInt();
                    system.removeRoom(roomId);
                    break;
                case 3:
                    System.out.print("Enter room ID to update: ");
                    int updateRoomId = scanner.nextInt();
                    System.out.print("Enter new room type: ");
                    String newRoomType = scanner.next();
                    System.out.print("Enter new price per night: ");
                    double newPricePerNight = scanner.nextDouble();
                    system.updateRoom(updateRoomId, newRoomType, newPricePerNight);
                    break;
                case 4:
                    System.out.print("Enter room number: ");
                    int checkRoomNumber = scanner.nextInt();
                    System.out.print("Enter start date (YYYY-MM-DD): ");
                    LocalDate startDate = LocalDate.parse(scanner.next());
                    System.out.print("Enter end date (YYYY-MM-DD): ");
                    LocalDate endDate = LocalDate.parse(scanner.next());
                    system.checkRoomAvailability(checkRoomNumber, startDate, endDate);
                    break;
                case 5:
                    System.out.print("Enter room ID: ");
                    int reserveRoomId = scanner.nextInt();
                    System.out.print("Enter guest name: ");
                    String guestName = scanner.next();
                    System.out.print("Enter start date (YYYY-MM-DD): ");
                    LocalDate reservationStartDate = LocalDate.parse(scanner.next());
                    System.out.print("Enter end date (YYYY-MM-DD): ");
                    LocalDate reservationEndDate = LocalDate.parse(scanner.next());
                    system.makeReservation(reserveRoomId, guestName, reservationStartDate, reservationEndDate);
                    break;
                case 6:
                    System.out.print("Enter room ID: ");
                    int checkInRoomId = scanner.nextInt();
                    System.out.print("Enter guest name: ");
                    String checkInGuestName = scanner.next();
                    system.checkInGuest(checkInRoomId, checkInGuestName);
                    break;
                case 7:
                    System.out.print("Enter room ID: ");
                    int checkOutRoomId = scanner.nextInt();
                    system.checkOutGuest(checkOutRoomId);
                    break;
                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
