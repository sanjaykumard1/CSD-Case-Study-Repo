package inventory;

import java.util.*;

// Product class definition
class Product {
    int id;
    String name;
    String category;
    double price;
    int quantity;

    Product(int id, String name, String category, double price, int quantity) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String toString() {
        return "Id: " + id + " \nName: " + name + " \nCategory: " + category + " \nPrice: " + price + " \nQuantity: " + quantity;
    }
}

// InventoryManager class definition
class InventoryManager {
    private HashMap<Integer, Product> products;

    public InventoryManager() {
        products = new HashMap<>();
    }

    public void addProduct(Product p) {
        products.put(p.getId(), p);
    }

    public void removeProduct(int productId) throws IllegalArgumentException {
        if (!products.containsKey(productId)) {
            throw new IllegalArgumentException("Product with ID " + productId + " not found.\n\n");
        }
        products.remove(productId);
    }

    public void updateProduct(int productId, Product updatedProduct) throws IllegalArgumentException {
        if (!products.containsKey(productId)) {
            throw new IllegalArgumentException("Product with ID " + productId + " does not exist.\n\n");
        }
        Product existingProduct = products.get(productId);
        existingProduct.setPrice(updatedProduct.getPrice());
        existingProduct.setQuantity(updatedProduct.getQuantity());
    }

    public List<Product> searchProduct(String keyword) {
        List<Product> result = new ArrayList<>();
        for (Map.Entry<Integer, Product> entry : products.entrySet()) {
            Product product = entry.getValue();
            if (product.getName().contains(keyword) || product.getCategory().contains(keyword)) {
                result.add(product);
            }
        }
        if (result.isEmpty()) {
            throw new IllegalArgumentException("Product with keyword " + keyword + " not found.\n\n");
        }
        return result;
    }

    public void viewInventoryStatus() throws IllegalArgumentException {
        if (products.isEmpty()) {
            throw new IllegalArgumentException("No products available currently.\n\n");
        }
        int totalProducts = products.size();
        double totalValue = 0.0;
        for (Map.Entry<Integer, Product> entry : products.entrySet()) {
            Product product = entry.getValue();
            totalValue += product.getPrice() * product.getQuantity();
        }
        System.out.println("\nTotal value: " + totalValue);
        System.out.println("Total products: " + totalProducts);
        System.out.println();
    }
}

// Main class definition
public class Main extends Thread {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventoryManager inventoryManager = new InventoryManager();
        while (true) {
            System.out.println("------Inventory Management System------");
            System.out.println("Enter your choice: ");
            System.out.println("1. Add product");
            System.out.println("2. Remove product");
            System.out.println("3. Update product");
            System.out.println("4. Search product");
            System.out.println("5. View inventory status");
            System.out.println("6. Exit");
            System.out.println("\nEnter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            switch (choice) {
                case 1:
                   try {
            System.out.print("Enter product ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // Consume newline left behind by nextInt()

            System.out.print("Enter product name: ");
            String name = scanner.nextLine();

            System.out.print("Enter product category: ");
            String category = scanner.nextLine();

            System.out.print("Enter product price: ");
            double price = scanner.nextDouble();
            
            System.out.print("Enter product quantity: ");
            int quantity = scanner.nextInt();
            
            // Create the product object
            Product product = new Product(id, name, category, price, quantity);
            
            // Add the product to inventory
            inventoryManager.addProduct(product);
            
            System.out.println("Product added successfully.\n");
            
        } catch (InputMismatchException e) {
            System.out.println("Invalid input format. Please enter valid data types.\n");
            scanner.nextLine(); // Clear the buffer
        } 
                    break;
                case 2:
                    try {
                        System.out.print("Enter product ID to remove: ");
                        int removeId = scanner.nextInt();
                        inventoryManager.removeProduct(removeId);
                        System.out.println("Product removed successfully.\n\n");
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        System.out.print("Enter product ID to update: ");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();
                        
                        System.out.print("Enter new product price: ");
                        double newPrice = scanner.nextDouble();
                        System.out.print("Enter new product quantity: ");
                        int newQuantity = scanner.nextInt();
                        
                        Product updatedProduct = new Product(updateId, "", "", newPrice, newQuantity);
                        inventoryManager.updateProduct(updateId, updatedProduct);
                        System.out.println("\nProduct with ID: " + updateId + " has been updated successfully.\n\n");
                       
                    } catch (InputMismatchException e) {
                        System.out.println("\nPlease check the values entered.\n\n");
                        scanner.nextLine(); // Clear the buffer
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    try {
                        System.out.print("Enter product keyword to search: ");
                        String keyword = scanner.nextLine();
                        List<Product> searchedProducts = inventoryManager.searchProduct(keyword);
                        for (Product p : searchedProducts) {
                            System.out.println(p);
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    try {
                        inventoryManager.viewInventoryStatus();
                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 6:
                    System.out.println("Thank you for using the Inventory Management System.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a correct choice.");
            }
        }
    }
}
