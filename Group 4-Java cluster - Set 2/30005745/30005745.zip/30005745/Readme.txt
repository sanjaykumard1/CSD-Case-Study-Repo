# Customer feedback and review process

## Setup instructions

1. Install MySQL and use the provided SQL script to create the required database and tables.
2. Update the database connection information (url,user,password) in the `CustomerFeedbackApp` class.
3. Compile and run the Java application.

## Usage Instructions

1. Run the `CustomerFeedbackApp` class.
2. Follow the menu options to manage feedback submissions, surveys, and analysis.
3. 3. Use appropriate menu options to submit new feedback, view feedback details, update feedback information, delete feedback, create new surveys, view survey details, update survey questions, delete surveys, analyze feedback, generate reports, and export reports to CSV.

## Functional structure

- `CustomerFeedbackApp.java`: Main application class with menu and application main arguments.
- `FeedbackSubmission.java`: Handles all the tasks associated with submitting feedback.
- `SurveyManagement.java`: handle all survey management related services.
- `AnalysisAndReporting.java`: Handle analysis and report generation.

## Database configuration

- `Run the following MySQL query to create the necessary table schema`
- `Also add dummy records if wanted to begin with`

CREATE DATABASE CustomerFeedbackDB;

USE CustomerFeedbackDB;

CREATE TABLE Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100),
    email VARCHAR(100)
);

CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    feedback_date DATE,
    feedback_text TEXT,
    rating INT,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

CREATE TABLE Survey (
    survey_id INT PRIMARY KEY AUTO_INCREMENT,
    survey_name VARCHAR(100),
    survey_description TEXT,
    status VARCHAR(20)
);

CREATE TABLE SurveyResponse (
    response_id INT PRIMARY KEY AUTO_INCREMENT,
    survey_id INT,
    customer_id INT,
    response_date DATE,
    response_text TEXT,
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

Add records into each of the tables: `Customer`,`Feedback`,`Survey`,`SurveyResponse` 
INSERT INTO Customer (customer_name, email) VALUES ('John Doe', 'john.doe@example.com');
INSERT INTO Customer (customer_name, email) VALUES ('Jane Smith', jane.smith@example.com');
INSERT INTO Customer (customer_name, email) VALUES ('Alice Johnson',  'alice.johnson@example.com');

INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) 
VALUES (1, '2023-07-01', 'Great product!', 5);
INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) 
VALUES (2, '2023-07-02', 'Average quality.', 3);
INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) 
VALUES (3, '2023-07-03', 'Not satisfied with the service.', 2);


INSERT INTO Survey (survey_name, survey_description, status) 
VALUES ('Customer Satisfaction Survey', 'Survey to measure customer satisfaction.', 'active');
INSERT INTO Survey (survey_name, survey_description, status) 
VALUES ('Product Feedback Survey', 'Survey to get feedback on our products.', 'inactive');
INSERT INTO Survey (survey_name, survey_description, status) 
VALUES ('Service Quality Survey', 'Survey to assess the quality of our service.', 'active');

INSERT INTO SurveyResponse (survey_id, customer_id, response_date, response_text) 
VALUES (1, 1, '2023-07-05', 'Very satisfied with the product.');
INSERT INTO SurveyResponse (survey_id, customer_id, response_date, response_text) 
VALUES (2, 2, '2023-07-06', 'The product quality is good.');
INSERT INTO SurveyResponse (survey_id, customer_id, response_date, response_text) 
VALUES (3, 3, '2023-07-07', 'Service was slow and not satisfactory.');


