import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class SurveyManagement {

    public static void menu(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nSurvey Management");
            System.out.println("-----------------");
            System.out.println("1. Create new survey");
            System.out.println("2. View survey details");
            System.out.println("3. Update survey questions");
            System.out.println("4. Delete survey");
            System.out.println("5. Back to main menu");
            System.out.print("\nEnter your choice: ");

            try {
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    createSurvey(connection);
                    break;
                case 2:
                    viewSurveyDetails(connection);
                    break;
                case 3:
                    updateSurveyQuestions(connection);
                    break;
                case 4:
                    deleteSurvey(connection);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            
            }
            catch (InputMismatchException e) {
                System.out.println("\nError: Invalid input. Please enter an integer.");
                scanner.next();
            }
            
        }
    }

    private static void createSurvey(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter survey name: ");
            String surveyName = scanner.nextLine();
            System.out.print("Enter survey description: ");
            String surveyDescription = scanner.nextLine();
            System.out.print("Enter survey status (active/inactive): ");
            String status = scanner.nextLine();

            String sql = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, surveyName);
            pstmt.setString(2, surveyDescription);
            pstmt.setString(3, status);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Survey created successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error creating survey.");
        }
    }

    private static void viewSurveyDetails(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter survey ID: ");
            int surveyId = scanner.nextInt();

            String sql = "SELECT * FROM Survey WHERE survey_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, surveyId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Survey ID: " + rs.getInt("survey_id"));
                System.out.println("Survey Name: " + rs.getString("survey_name"));
                System.out.println("Survey Description: " + rs.getString("survey_description"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Survey not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving survey details.");
        }
    }

    private static void updateSurveyQuestions(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter survey ID: ");
            int surveyId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter new survey name: ");
            String surveyName = scanner.nextLine();
            System.out.print("Enter new survey description: ");
            String surveyDescription = scanner.nextLine();
            System.out.print("Enter new survey status (active/inactive): ");
            String status = scanner.nextLine();

            String sql = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, surveyName);
            pstmt.setString(2, surveyDescription);
            pstmt.setString(3, status);
            pstmt.setInt(4, surveyId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Survey updated successfully!");
            } else {
                System.out.println("Survey not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating survey.");
        }
    }

    private static void deleteSurvey(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter survey ID: ");
            int surveyId = scanner.nextInt();

            String sql = "DELETE FROM Survey WHERE survey_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, surveyId);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Survey deleted successfully!");
            } else {
                System.out.println("Survey not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting survey.");
        }
    }
}
