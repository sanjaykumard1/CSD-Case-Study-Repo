import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.InputMismatchException;


public class CustomerFeedbackApp {

    private static final String url = "jdbc:mysql://localhost:3306/CustomerFeedbackDB";
    private static final String user = "root";
    private static final String password = "root";

    private static Connection conn;

    public static void main(String[] args) {
        try {
            conn = DriverManager.getConnection(url, user, password);
            mainMenu();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error - connecting to the database.");
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void mainMenu() {
        Scanner scanner = new Scanner(System.in);
        while(true){
          System.out.println("\nCustomer Feedback and Survey System");
          System.out.println("------------------------------------");
          System.out.println("1. Feedback Submission");
            System.out.println("2. Survey Management");
            System.out.println("3. Analysis and Reporting");
            System.out.println("4. Exit");
            System.out.print("\nEnter your choice: ");

            try {
            int cho = scanner.nextInt();

            switch (cho) {
                case 1:
                    FeedbackSubmission.menu(conn);
                    break;
                case 2:
                    SurveyManagement.menu(conn);
                    break;
                case 3:
                    AnalysisAndReporting.menu(conn);
                    break;
                case 4:
                    System.out.println("\nExiting.....");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            
            }
            catch (InputMismatchException e) {
                System.out.println("\nError: Invalid input. Please enter an integer.");
                scanner.next();
            }
            
        }
    }
}
