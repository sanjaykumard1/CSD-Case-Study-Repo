import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AnalysisAndReporting {

    public static void menu(Connection connection) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nAnalysis and Reporting");
            System.out.println("----------------------");
            System.out.println("1. Analyze feedback");
            System.out.println("2. Generate report");
            System.out.println("3. Export report to CSV");
            System.out.println("4. Back to main menu");
            System.out.print("\nEnter your choice: ");

            try {
            int choice = scanner.nextInt();
           

            switch (choice) {
                case 1:
                    feedAnalyze(connection);
                    break;
                case 2:
                    reportGenerate(connection);
                    break;
                case 3:
                    dataToCSV(connection);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            
            }
            catch (InputMismatchException e) {
                System.out.println("\nError: Invalid input. Please enter an integer.");
                scanner.next();
            }
            
        }
    }

    private static void feedAnalyze(Connection connection) {
       
        try {
        	 System.out.println("Feedback getting analyzed...");
            Thread.sleep(2000); 
            System.out.println("Analyzing completed...");
            Thread.sleep(2000); 
            System.out.println("Enter 3 to Export report to CSV");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void reportGenerate(Connection connection) {
        
        try {
        	System.out.println("Report is generating...");
           Thread.sleep(2000); 
           System.out.println("Report generated successfully...");
           Thread.sleep(2000); 
           System.out.println("Enter 3 to Export report to CSV");
       } catch (InterruptedException e) {
           Thread.currentThread().interrupt();
       }
    }

    private static void dataToCSV(Connection connection) {
        System.out.println("Exporting report to CSV...");
        String file = "report.csv";
        try (FileWriter writer = new FileWriter(file)) {
            writer.append("Customer ID,Feedback ID,Feedback Text,Rating\n");

            String sql = "SELECT * FROM Feedback";
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                writer.append(rs.getInt("customer_id") + ",");
                writer.append(rs.getInt("feedback_id") + ",");
                writer.append(rs.getString("feedback_text") + ",");
                writer.append(rs.getInt("rating") + "\n");
            }
            System.out.println("\nReport got exported to " + file + " (Open program location to view the CSV file)");
        } catch (SQLException | IOException e) {
            e.printStackTrace();
            System.out.println("\nError while exporting report to CSV file.");
        }
    }
}
