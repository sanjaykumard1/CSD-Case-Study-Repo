import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class FeedbackSubmission {

    public static void menu(Connection connection) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\nFeedback Submission");
            System.out.println("-------------------");
            System.out.println("1. Submit new feedback");
            System.out.println("2. View feedback details");
            System.out.println("3. Update feedback information");
            System.out.println("4. Delete feedback");
            System.out.println("5. Back to main menu");
            System.out.print("\nEnter your choice: ");

            try {
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    submitFeedback(connection);
                    break;
                case 2:
                    viewFeedbackDetails(connection);
                    break;
                case 3:
                    updateFeedback(connection);
                    break;
                case 4:
                    deleteFeedback(connection);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            
            }
            catch (InputMismatchException e) {
                System.out.println("Error: Invalid input. Please enter an integer.");
                sc.next();
            }
        }
    }

    private static void submitFeedback(Connection connection) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter customer ID: ");
            int customerId = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter feedback text: ");
            String feedbackText = sc.nextLine();
            System.out.print("Enter rating (1-5): ");
            int rating = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter feedback date (YYYY-MM-DD): ");
            String feedbackDate = sc.nextLine();

            String sql = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            pstmt.setDate(2, Date.valueOf(feedbackDate));
            pstmt.setString(3, feedbackText);
            pstmt.setInt(4, rating);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Feedback submitted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error submitting feedback.");
        }
    }

    private static void viewFeedbackDetails(Connection connection) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter feedback ID: ");
            int feedbackId = sc.nextInt();

            String sql = "SELECT * FROM Feedback WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, feedbackId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Feedback ID: " + rs.getInt("feedback_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Feedback Date: " + rs.getDate("feedback_date"));
                System.out.println("Feedback Text: " + rs.getString("feedback_text"));
                System.out.println("Rating: " + rs.getInt("rating"));
            } else {
                System.out.println("Feedback not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error retrieving feedback details.");
        }
    }

    private static void updateFeedback(Connection connection) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter feedback ID: ");
            int feedbackId = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter new feedback text: ");
            String feedbackText = sc.nextLine();
            System.out.print("Enter new rating (1-5): ");
            int rating = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter new feedback date (YYYY-MM-DD): ");
            String feedbackDate = sc.nextLine();

            String sql = "UPDATE Feedback SET feedback_text = ?, rating = ?, feedback_date = ? WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, feedbackText);
            pstmt.setInt(2, rating);
            pstmt.setDate(3, Date.valueOf(feedbackDate));
            pstmt.setInt(4, feedbackId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Feedback updated successfully!");
            } else {
                System.out.println("Feedback not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating feedback.");
        }
    }

    private static void deleteFeedback(Connection connection) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("Enter feedback ID: ");
            int feedbackId = sc.nextInt();

            String sql = "DELETE FROM Feedback WHERE feedback_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, feedbackId);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Feedback deleted successfully!");
            } else {
                System.out.println("Feedback not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error deleting feedback.");
        }
    }
}
