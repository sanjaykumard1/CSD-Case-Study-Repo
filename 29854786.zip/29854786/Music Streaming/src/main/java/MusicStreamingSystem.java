import java.sql.*;
import java.util.Scanner;

public class MusicStreamingSystem {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/music_streaming";
    private static final String USER = "root";
    private static final String PASS = "Root@123";

    private static Connection conn = null;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            // Establish database connection
            Class.forName("com.mysql.jdbc.Driver");

            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected to the database successfully.");

            // Create tables if they don't exist
//            createTables();

            // Main menu loop
            while (true) {
                displayMenu();
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        addTrack();
                        break;
                    case 2:
                        addArtist();
                        break;
                    case 3:
                        createPlaylist();
                        break;
                    case 4:
                        addTrackToPlaylist();
                        break;
                    case 5:
                        listTracks();
                        break;
                    case 6:
                        listArtists();
                        break;
                    case 7:
                        listPlaylists();
                        break;
                    case 8:
                        System.out.println("Exiting the application. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Music Streaming Service Management System ---");
        System.out.println("1. Add a new track");
        System.out.println("2. Add a new artist");
        System.out.println("3. Create a new playlist");
        System.out.println("4. Add a track to a playlist");
        System.out.println("5. List all tracks");
        System.out.println("6. List all artists");
        System.out.println("7. List all playlists");
        System.out.println("8. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void createTables() throws SQLException {
        Statement stmt = conn.createStatement();

        // Create Tracks table
        stmt.execute("CREATE TABLE IF NOT EXISTS Tracks (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "title VARCHAR(100) NOT NULL," +
                "artist_id INT NOT NULL," +
                "duration INT NOT NULL," +
                "release_year INT NOT NULL)");

        // Create Artists table
        stmt.execute("CREATE TABLE IF NOT EXISTS Artists (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(100) NOT NULL," +
                "country VARCHAR(50))");

        // Create Playlists table
        stmt.execute("CREATE TABLE IF NOT EXISTS Playlists (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(100) NOT NULL)");

        // Create PlaylistTracks table
        stmt.execute("CREATE TABLE IF NOT EXISTS PlaylistTracks (" +
                "playlist_id INT," +
                "track_id INT," +
                "PRIMARY KEY (playlist_id, track_id)," +
                "FOREIGN KEY (playlist_id) REFERENCES Playlists(id)," +
                "FOREIGN KEY (track_id) REFERENCES Tracks(id))");

        stmt.close();
    }

    private static void addTrack() throws SQLException {
        System.out.print("Enter track title: ");
        String title = scanner.nextLine();

        System.out.print("Enter artist ID: ");
        int artistId = scanner.nextInt();

        System.out.print("Enter track duration (in seconds): ");
        int duration = scanner.nextInt();

        System.out.print("Enter release year: ");
        int releaseYear = scanner.nextInt();

        String sql = "INSERT INTO Tracks (title, artist_id, duration, release_year) VALUES (?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, title);
        pstmt.setInt(2, artistId);
        pstmt.setInt(3, duration);
        pstmt.setInt(4, releaseYear);

        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Track added successfully.");
        } else {
            System.out.println("Failed to add track.");
        }

        pstmt.close();
    }

    private static void addArtist() throws SQLException {
        System.out.print("Enter artist name: ");
        String name = scanner.nextLine();

        System.out.print("Enter artist country: ");
        String country = scanner.nextLine();

        String sql = "INSERT INTO Artists (name, country) VALUES (?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, name);
        pstmt.setString(2, country);

        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Artist added successfully.");
        } else {
            System.out.println("Failed to add artist.");
        }

        pstmt.close();
    }

    private static void createPlaylist() throws SQLException {
        System.out.print("Enter playlist name: ");
        String name = scanner.nextLine();

        String sql = "INSERT INTO Playlists (name) VALUES (?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, name);

        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Playlist created successfully.");
        } else {
            System.out.println("Failed to create playlist.");
        }

        pstmt.close();
    }

    private static void addTrackToPlaylist() throws SQLException {
        System.out.print("Enter playlist ID: ");
        int playlistId = scanner.nextInt();

        System.out.print("Enter track ID: ");
        int trackId = scanner.nextInt();

        String sql = "INSERT INTO PlaylistTracks (playlist_id, track_id) VALUES (?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, playlistId);
        pstmt.setInt(2, trackId);

        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Track added to playlist successfully.");
        } else {
            System.out.println("Failed to add track to playlist.");
        }

        pstmt.close();
    }

    private static void listTracks() throws SQLException {
        String sql = "SELECT t.id, t.title, a.name AS artist, t.duration, t.release_year " +
                "FROM Tracks t JOIN Artists a ON t.artist_id = a.id";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        System.out.println("\n--- All Tracks ---");
        System.out.printf("%-5s %-30s %-20s %-10s %-10s%n", "ID", "Title", "Artist", "Duration", "Year");
        System.out.println("------------------------------------------------------------");

        while (rs.next()) {
            System.out.printf("%-5d %-30s %-20s %-10d %-10d%n",
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("artist"),
                    rs.getInt("duration"),
                    rs.getInt("release_year"));
        }

        rs.close();
        stmt.close();
    }

    private static void listArtists() throws SQLException {
        String sql = "SELECT * FROM Artists";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        System.out.println("\n--- All Artists ---");
        System.out.printf("%-5s %-30s %-20s%n", "ID", "Name", "Country");
        System.out.println("--------------------------------------------");

        while (rs.next()) {
            System.out.printf("%-5d %-30s %-20s%n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("country"));
        }

        rs.close();
        stmt.close();
    }

    private static void listPlaylists() throws SQLException {
        String sql = "SELECT p.id, p.name, COUNT(pt.track_id) AS track_count " +
                "FROM Playlists p LEFT JOIN PlaylistTracks pt ON p.id = pt.playlist_id " +
                "GROUP BY p.id, p.name";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        System.out.println("\n--- All Playlists ---");
        System.out.printf("%-5s %-30s %-15s%n", "ID", "Name", "Track Count");
        System.out.println("--------------------------------------------");

        while (rs.next()) {
            System.out.printf("%-5d %-30s %-15d%n",
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("track_count"));
        }

        rs.close();
        stmt.close();
    }
}